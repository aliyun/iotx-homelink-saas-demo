package com.aliyun.iot.homelink.demo.commons.base;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

/**
 * Created by ZhuBingYang on 2019/3/21.
 */
@SuppressLint("Registered")
public class BaseActivity extends AppCompatActivity implements BaseView, ResourceProvider {
    private BaseView mBaseView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBaseView = new BaseViewImpl(this);
    }

    public void setBaseView(BaseView baseView) {
        this.mBaseView = baseView;
    }

    @Override
    public void toast(String message) {
        mBaseView.toast(message);
    }

    @Override
    public void showLoading() {
        mBaseView.showLoading();
    }

    @Override
    public void showLoading(View view) {
        mBaseView.showLoading(view);

    }

    @Override
    public void dismissLoading() {
        mBaseView.dismissLoading();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mBaseView.dismissLoading();
    }
}
