package com.aliyun.iot.homelink.demo.commons.network;

import android.content.Context;
import android.support.annotation.Nullable;
import android.widget.Toast;

import com.aliyun.iot.aep.sdk.apiclient.callback.IoTCallback;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.link.ui.component.LinkToast;

/**
 * Created by ZhuBingYang on 2019/4/15.
 */
public abstract class IotCallbackBase<T> implements IoTCallback {
    private Context mContext;

    public IotCallbackBase(@Nullable Context mContext) {
        this.mContext = mContext;
    }

    protected abstract void onSuccess(IoTRequest request, T response);

    public void onFailureOverrideThis(IoTRequest request, final Exception e) {
        e.printStackTrace();
        if (mContext != null)
            LinkToast.makeText(mContext, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
    }
}
