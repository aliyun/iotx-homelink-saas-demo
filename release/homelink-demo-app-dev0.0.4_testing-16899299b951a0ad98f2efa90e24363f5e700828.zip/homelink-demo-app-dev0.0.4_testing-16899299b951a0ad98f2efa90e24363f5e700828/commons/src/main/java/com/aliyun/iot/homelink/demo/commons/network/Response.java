package com.aliyun.iot.homelink.demo.commons.network;

/**
 * Created by ZhuBingYang on 2019/3/26.
 */
public class Response<T> {
    private int total;
    private int pageNo;
    private int pageSize;
    private T data;

    public boolean hasData() {
        return data != null;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "Response{" +
                "total=" + total +
                ", pageNo=" + pageNo +
                ", pageSize=" + pageSize +
                ", data=" + data +
                '}';
    }
}
