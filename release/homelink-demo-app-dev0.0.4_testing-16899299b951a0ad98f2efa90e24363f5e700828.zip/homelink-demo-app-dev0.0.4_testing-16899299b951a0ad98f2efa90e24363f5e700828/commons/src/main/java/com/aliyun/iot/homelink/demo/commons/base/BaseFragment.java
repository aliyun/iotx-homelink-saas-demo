package com.aliyun.iot.homelink.demo.commons.base;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.ColorRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by ZhuBingYang on 2019/3/25.
 */
public abstract class BaseFragment extends Fragment implements BaseView, ResourceProvider {
    /**
     * 保存宿主对象实例，避免{@link Fragment#getActivity }为空
     */
    private Activity mActivity;

    private View mView;
    private BaseView mBaseView;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mActivity = getActivity();
        mBaseView = new BaseViewImpl(mActivity);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mView = inflater.inflate(getLayoutId(), null);
        doSomeDefaultSetting();
        initView(mView);
        mView.setClickable(true);
        return mView;
    }

    protected void doSomeDefaultSetting() {

    }

    protected abstract int getLayoutId();

    protected abstract void initView(View view);

    @Nullable
    @Override
    public View getView() {
        return mView;
    }

    public Activity getMActivity() {
        return mActivity;
    }

    public void setBaseView(BaseView baseView) {
        this.mBaseView = baseView;
    }

    @Override
    public void toast(String message) {
        mBaseView.toast(message);
    }

    @Override
    public void showLoading() {
        mBaseView.showLoading();
    }

    @Override
    public void showLoading(View view) {
        mBaseView.showLoading(view);
    }

    @Override
    public void dismissLoading() {
        mBaseView.dismissLoading();
    }

    @Override
    public int getColor(int id) {
        return ContextCompat.getColor(mActivity, id);
    }

    @Override
    public void onDetach() {
        mBaseView.dismissLoading();
        super.onDetach();
    }
}
