package com.aliyun.iot.homelink.demo.commons.view.divider;

import android.graphics.Rect;

/**
 * Created by 朱炳杨 on 2019/1/28.
 */
public interface InsetColorDecoration extends ColorDecoration {

    void setInset(int position, Rect rect);
}
