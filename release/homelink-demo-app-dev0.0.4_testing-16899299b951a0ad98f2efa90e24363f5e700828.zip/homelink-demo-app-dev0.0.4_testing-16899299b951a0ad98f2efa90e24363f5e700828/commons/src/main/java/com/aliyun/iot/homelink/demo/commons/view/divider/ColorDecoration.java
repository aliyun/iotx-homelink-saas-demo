package com.aliyun.iot.homelink.demo.commons.view.divider;

public interface ColorDecoration extends Decoration {
    int getHeight(int position);

    int getColor(int position);
}
