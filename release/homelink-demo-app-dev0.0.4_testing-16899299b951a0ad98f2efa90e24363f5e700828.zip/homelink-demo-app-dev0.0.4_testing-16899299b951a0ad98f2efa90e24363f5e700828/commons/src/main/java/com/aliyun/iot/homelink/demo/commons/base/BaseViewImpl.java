package com.aliyun.iot.homelink.demo.commons.base;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.aliyun.iot.drawableview.DrawableTextView;
import com.aliyun.iot.drawableview.background.TextDrawableBackgroundImpl;
import com.aliyun.iot.homelink.demo.commons.R;
import com.aliyun.iot.homelink.demo.commons.util.DimensionUtil;
import com.aliyun.iot.link.ui.component.LinkToast;

/**
 * Created by ZhuBingYang on 2019/3/25.
 */
public class BaseViewImpl implements BaseView {
    private Activity mActivity;
    private Dialog mLoadingDialog;

    public BaseViewImpl(Activity activity) {
        this.mActivity = activity;
    }

    @Override
    public void toast(String message) {
        LinkToast.makeText(mActivity, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showLoading() {
        DrawableTextView textView = new DrawableTextView(mActivity);
        textView.setTextColor(Color.WHITE);
        textView.setText(R.string.common_loading);
        int padding = DimensionUtil.dip2px(mActivity, 10);
        textView.setPadding(padding, padding, padding, padding);

        TextDrawableBackgroundImpl drawableBackground = textView.getDrawableBackground();
        drawableBackground.solidColor = 0xff3d3d3d;
        drawableBackground.cornerRadius = DimensionUtil.dip2px(mActivity, 5);
        drawableBackground.invalidate();

        showLoading(textView);
    }

    @Override
    public void showLoading(View view) {
        if (mLoadingDialog != null) return;

        mLoadingDialog = new AlertDialog.Builder(mActivity).setView(view).show();

        int w = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        int h = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        view.measure(w, h);
        int height = view.getMeasuredHeight();
        int width = view.getMeasuredWidth();

        Window window = mLoadingDialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.transparent);
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.width = width;
            attributes.height = height;
            window.setAttributes(attributes);
        }
    }

    @Override
    public void dismissLoading() {
        if (mLoadingDialog != null) {
            mLoadingDialog.dismiss();
            mLoadingDialog = null;
        }
    }
}
