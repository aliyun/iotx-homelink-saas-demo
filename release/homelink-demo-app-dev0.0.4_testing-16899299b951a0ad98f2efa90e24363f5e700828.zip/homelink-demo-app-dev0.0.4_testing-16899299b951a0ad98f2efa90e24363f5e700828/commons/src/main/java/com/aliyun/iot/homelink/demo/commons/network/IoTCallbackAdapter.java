package com.aliyun.iot.homelink.demo.commons.network;


import android.content.Context;

import com.alibaba.fastjson.JSON;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTResponse;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

/**
 * Created by ZhuBingYang on 2019/3/26.
 */
public abstract class IoTCallbackAdapter<T> extends IotCallbackBase<T> {
    private Type mType;

    public IoTCallbackAdapter(Context context) {
        super(context);
        mType = ((ParameterizedType) this.getClass().getGenericSuperclass()).getActualTypeArguments()[0];
    }

    @Override
    public void onResponse(final IoTRequest request, final IoTResponse response) {
        if (response.getCode() == 200) {
            if (response.getData() != null) {
                final T data = JSON.parseObject(response.getData().toString(), mType);

                ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                    @Override
                    public void run() {
                        onSuccess(request, data);
                    }
                });
            } else {
                ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                    @Override
                    public void run() {
                        onFailureOverrideThis(request, new Exception("data == null"));
                    }
                });
            }
        } else {
            ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                @Override
                public void run() {
                    onFailureOverrideThis(request, new Exception(response.getLocalizedMsg()));
                }
            });
        }
    }

    @Override
    public void onFailure(final IoTRequest request, final Exception e) {
        ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
            @Override
            public void run() {
                onFailureOverrideThis(request, e);
            }
        });
    }
}
