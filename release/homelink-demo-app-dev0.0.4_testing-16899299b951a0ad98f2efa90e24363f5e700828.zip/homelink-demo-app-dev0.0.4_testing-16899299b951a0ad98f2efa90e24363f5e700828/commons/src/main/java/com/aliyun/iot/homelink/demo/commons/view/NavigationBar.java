package com.aliyun.iot.homelink.demo.commons.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.support.annotation.DrawableRes;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.aliyun.iot.homelink.demo.commons.R;
import com.aliyun.iot.homelink.demo.commons.util.DimensionUtil;

public class NavigationBar extends RelativeLayout {
    private String mTitle;
    private int mTitleColor;
    private float mTitleSize;
    private int mTitleAlign;
    private int mIconRes;
    private int mBackgroundColor;
    private int mIconTintColor;

    private ImageView mIconView;
    private TextView mTitleView;
    private LinearLayout mMenuLayout;

    public NavigationBar(Context context) {
        this(context, null);
    }

    public NavigationBar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public NavigationBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        obtainAttrs(context, attrs);
        init();
    }

    private void obtainAttrs(Context context, AttributeSet attrs) {
        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.NavigationBar);
        mTitle = ta.getString(R.styleable.NavigationBar_title);
        mTitleColor = ta.getColor(R.styleable.NavigationBar_titleColor, Color.BLACK);
        mTitleSize = ta.getDimension(R.styleable.NavigationBar_titleSize, 16);
        mTitleAlign = ta.getInt(R.styleable.NavigationBar_titleAlign, 0);
        mIconRes = ta.getResourceId(R.styleable.NavigationBar_icon, 0);
        mBackgroundColor = ta.getColor(R.styleable.NavigationBar_backgroundColor, getResources().getColor(R.color.common_colorPrimary));
        mIconTintColor = ta.getColor(R.styleable.NavigationBar_iconTint, 0);

        ta.recycle();
    }

    private void init() {
        LayoutInflater.from(getContext()).inflate(R.layout.view_navigation, this);

        mIconView = findViewById(R.id.navigation_icon);
        mTitleView = findViewById(R.id.navigation_title_tv);
        mMenuLayout = findViewById(R.id.navigation_ll);

        mTitleView.setText(mTitle);
        mTitleView.setTextColor(mTitleColor);
        mTitleView.setTextSize(mTitleSize);

        if (mTitleAlign == 1) {
            LayoutParams params = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
            params.addRule(CENTER_IN_PARENT, TRUE);
            mTitleView.setLayoutParams(params);
        }

        if (mIconTintColor > 0) {
            mIconView.setColorFilter(mIconTintColor);
        }

        if (mIconRes > 0) {
            mIconView.setImageResource(mIconRes);
        }

        setBackgroundColor(mBackgroundColor);
    }

    public void addMenuItem(View view) {
        mMenuLayout.addView(view);
    }

    public ImageView addMenuItem(@DrawableRes int iconRes, OnClickListener onClickListener) {
        return addMenuItem(iconRes, onClickListener, DimensionUtil.dip2px(getContext(), 10));
    }

    public ImageView addMenuItem(@DrawableRes int iconRes, OnClickListener onClickListener, int padding) {
        ImageView imageView = new ImageView(getContext());
        imageView.setImageResource(iconRes);
        imageView.setPadding(padding, padding, padding, padding);
        imageView.setOnClickListener(onClickListener);

        mMenuLayout.addView(imageView, 0, new LinearLayout.LayoutParams(DimensionUtil.dip2px(getContext(), 40), ViewGroup.LayoutParams.MATCH_PARENT));

        return imageView;
    }

    public TextView addMenuButton(String text, OnClickListener onClickListener) {
        TextView textView = new TextView(getContext());
        textView.setText(text);
        textView.setGravity(Gravity.CENTER);
        textView.setTextSize(16);
        textView.setTextColor(getResources().getColor(R.color.common_colorAccent));
        int padding = DimensionUtil.dip2px(getContext(), 10);
        textView.setPadding(padding, padding, padding, padding);
        textView.setOnClickListener(onClickListener);

        mMenuLayout.addView(textView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        return textView;
    }

    public ImageView getIconView() {
        return mIconView;
    }

    public TextView getTitleView() {
        return mTitleView;
    }

    public void setOnClickListener(int vId, OnClickListener listener) {
        View v = findViewById(vId);
        if (v != null) {
            v.setOnClickListener(listener);
        }
    }

    public void setOnIconClickListener(OnClickListener clickListener) {
        mIconView.setOnClickListener(clickListener);
    }
}
