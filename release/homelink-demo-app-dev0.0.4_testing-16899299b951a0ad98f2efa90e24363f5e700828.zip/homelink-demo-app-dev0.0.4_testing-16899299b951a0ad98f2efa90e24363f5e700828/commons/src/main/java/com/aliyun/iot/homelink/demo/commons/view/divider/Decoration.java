package com.aliyun.iot.homelink.demo.commons.view.divider;

public interface Decoration {
}
