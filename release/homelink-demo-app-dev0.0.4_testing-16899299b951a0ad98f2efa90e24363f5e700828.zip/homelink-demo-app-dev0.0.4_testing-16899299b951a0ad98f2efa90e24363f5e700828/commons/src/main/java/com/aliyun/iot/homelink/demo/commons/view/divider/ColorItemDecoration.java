package com.aliyun.iot.homelink.demo.commons.view.divider;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;

public class ColorItemDecoration extends RecyclerView.ItemDecoration {
    private ColorDecoration mColorDecoration;
    private Paint mPaint;

    public ColorItemDecoration(ColorDecoration colorDecoration) {
        mColorDecoration = colorDecoration;
        mPaint = new Paint();
    }

    @Override
    public void onDraw(@NonNull Canvas c, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
        super.onDraw(c, parent, state);

        int position;
        Rect rect = new Rect();

        for (int i = 0; i < parent.getChildCount(); i++) {

            View view = parent.getChildAt(i);

            position = parent.getChildAdapterPosition(view);
            rect.top = view.getTop() - mColorDecoration.getHeight(position);
            rect.left = parent.getPaddingLeft();
            rect.bottom = view.getTop();
            rect.right = parent.getWidth() - parent.getPaddingRight();

            mPaint.setColor(mColorDecoration.getColor(position));

            if (mColorDecoration instanceof InsetColorDecoration) {
                ((InsetColorDecoration) mColorDecoration).setInset(position, rect);
            }
            c.drawRect(rect.left, rect.top, rect.right, rect.bottom, mPaint);
        }
    }

    @Override
    public void getItemOffsets(@NonNull Rect outRect, @NonNull View view, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
        outRect.set(0, mColorDecoration.getHeight(parent.getChildAdapterPosition(view)), 0, 0);
    }
}
