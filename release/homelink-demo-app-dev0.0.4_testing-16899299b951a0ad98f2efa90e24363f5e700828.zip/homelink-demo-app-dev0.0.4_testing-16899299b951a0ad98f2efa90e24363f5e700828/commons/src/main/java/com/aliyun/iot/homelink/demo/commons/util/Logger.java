package com.aliyun.iot.homelink.demo.commons.util;


import com.aliyun.iot.aep.sdk.log.ALog;

import java.util.List;

/**
 * Created by ZhuBingYang on 2019/4/15.
 * 打印长字符串，调试用
 */
public class Logger {
    public static void d(String tag, String message) {
        if (message != null && message.length() > 2048) {
            int index;
            for (index = 0; index < message.length(); index += 2048) {
                if (index + 2048 >= message.length()) {
                    ALog.d(tag, message.substring(index));
                } else {
                    ALog.d(tag, message.substring(index, index + 2048));
                }
            }
        } else {
            ALog.d(tag, message);
        }
    }

    public static void list(String tag, List list) {
        if (list == null) {
            ALog.e(tag, "list == null");
            return;
        }

        if (list.isEmpty()) {
            ALog.d(tag, "empty list");
            return;
        }

        for (Object o : list) {
            d(tag, o.toString());
        }
    }
}
