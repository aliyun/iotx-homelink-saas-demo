package com.aliyun.iot.homelink.demo.commons.base;

/**
 * Created by ZhuBingYang on 2019/3/21.
 */
public interface BasePresenter<T extends BaseView> {
//    void setView(T view);
}
