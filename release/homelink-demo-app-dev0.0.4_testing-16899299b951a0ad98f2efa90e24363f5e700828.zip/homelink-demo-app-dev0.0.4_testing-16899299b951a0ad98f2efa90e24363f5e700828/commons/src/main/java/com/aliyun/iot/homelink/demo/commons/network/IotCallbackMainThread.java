package com.aliyun.iot.homelink.demo.commons.network;

import android.content.Context;

import com.aliyun.iot.aep.sdk.apiclient.callback.IoTResponse;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;

/**
 * Created by ZhuBingYang on 2019/4/15.
 */
public abstract class IotCallbackMainThread extends IotCallbackBase<IoTResponse> {
    public IotCallbackMainThread(Context mContext) {
        super(mContext);
    }

    @Override
    public void onResponse(final IoTRequest ioTRequest, final IoTResponse ioTResponse) {
        ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
            @Override
            public void run() {
                if (ioTResponse.getCode() == 200) {
                    onSuccess(ioTRequest, ioTResponse);
                } else {
                    onFailureOverrideThis(ioTRequest, new Exception(ioTResponse.getLocalizedMsg()));
                }
            }
        });
    }

    @Override
    public void onFailure(final IoTRequest request, final Exception e) {
        ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
            @Override
            public void run() {
                onFailureOverrideThis(request, e);
            }
        });
    }
}
