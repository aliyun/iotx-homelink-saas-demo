package com.aliyun.iot.homelink.demo.commons.base;

import android.support.annotation.ColorRes;

/**
 * Created by ZhuBingYang on 2019-04-25.
 */
public interface ResourceProvider {
    int getColor(@ColorRes int id);
}
