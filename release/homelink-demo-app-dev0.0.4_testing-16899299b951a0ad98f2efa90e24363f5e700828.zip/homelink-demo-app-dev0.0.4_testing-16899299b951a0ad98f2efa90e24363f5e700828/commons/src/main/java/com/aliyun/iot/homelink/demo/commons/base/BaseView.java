package com.aliyun.iot.homelink.demo.commons.base;

import android.view.View;

/**
 * Created by ZhuBingYang on 2019/3/21.
 */
public interface BaseView {
    void toast(String message);

    void showLoading();

    void showLoading(View view);

    void dismissLoading();
}
