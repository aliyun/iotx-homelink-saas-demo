package com.aliyun.iot.homelink.demo.bluetooth;

import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.aliyun.iot.homelink.demo.R;
import com.aliyun.iot.homelink.demo.bluetooth.BluetoothEntryFragment.OnListFragmentInteractionListener;

import java.util.List;

/**
 * {@link RecyclerView.Adapter} that can display a {@link DeviceTuple} and makes a call to the
 * specified {@link OnListFragmentInteractionListener}.
 *
 * @author sinyuk
 */
public class DeviceTupleAdapter extends RecyclerView.Adapter<DeviceTupleAdapter.ViewHolder> {

    private final List<DeviceTuple> mValues;
    private final OnListFragmentInteractionListener mListener;

    public DeviceTupleAdapter(List<DeviceTuple> items, OnListFragmentInteractionListener listener) {
        mValues = items;
        mListener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_device_tuple, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.mItem = mValues.get(position);
        holder.mIdView.setText(mValues.get(position).pk);
        holder.mContentView.setText(mValues.get(position).pid);
        holder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != mListener) {
                    // Notify the active callbacks interface (the activity, if the
                    // fragment is attached to one) that an item has been selected.
                    mListener.onListFragmentInteraction(holder.mItem);
                }
            }
        });
        if (position % 2 == 0) {
            holder.mView.setBackgroundColor(Color.WHITE);
        } else {
            holder.mView.setBackgroundColor(Color.LTGRAY);
        }
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        final View mView;
        final TextView mIdView;
        final TextView mContentView;
        DeviceTuple mItem;

        ViewHolder(View view) {
            super(view);
            mView = view;
            mIdView = view.findViewById(R.id.text_pk);
            mContentView = view.findViewById(R.id.text_pid);
        }

        @Override
        public String toString() {
            return super.toString() + " '" + mContentView.getText() + "'";
        }
    }
}
