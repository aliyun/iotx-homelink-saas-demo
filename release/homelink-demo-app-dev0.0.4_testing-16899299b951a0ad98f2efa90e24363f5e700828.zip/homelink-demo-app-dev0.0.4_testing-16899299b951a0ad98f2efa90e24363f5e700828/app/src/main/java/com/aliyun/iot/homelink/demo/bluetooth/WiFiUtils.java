package com.aliyun.iot.homelink.demo.bluetooth;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.ResultReceiver;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.aliyun.alink.business.devicecenter.utils.WifiManagerUtil;
import com.aliyun.alink.linksdk.tools.ALog;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

/**
 * date:    2018-01-23
 * author:  jeeking
 * description: null
 */

public class WiFiUtils {

    private static final String TAG = "WiFiUtils";

    private static WifiManager mWifiManager = null;
    private static WifiManager.WifiLock wifiLock;
    private static List<WifiConfiguration> wifiConfigedList = new ArrayList<>();

    public static WifiConfiguration configWifiInfo(Context context, String SSID, String password, int type) {
        WifiConfiguration config = new WifiConfiguration();
        if (mWifiManager == null) {
            mWifiManager = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        }
        updateConfigedWifi(context);

        config.allowedAuthAlgorithms.clear();
        config.allowedGroupCiphers.clear();
        config.allowedKeyManagement.clear();
        config.allowedPairwiseCiphers.clear();
        config.allowedProtocols.clear();
        config.SSID = SSID;

        WifiConfiguration tempConfig;
        if (type == 0) {
            tempConfig = isOpenWifiExist(SSID);
        } else {
            tempConfig = isWifiExist(SSID);
        }
        if (tempConfig != null) {
            mWifiManager.removeNetwork(tempConfig.networkId);
        }

        // 分为三种情况：1没有密码2用wep加密3用wpa加密
        if (type == 0) {
            // WIFICIPHER_NOPASS
            config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);

        } else if (type == 1) {
            //  WIFICIPHER_WEP
            config.wepKeys[0] = password;
            config.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.SHARED);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP40);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP104);
            config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
            config.wepTxKeyIndex = 0;
        } else if (type == 2) {
            // WIFICIPHER_WPA
            config.preSharedKey = password;
            config.hiddenSSID = false;
            config.allowedAuthAlgorithms.set(WifiConfiguration.AuthAlgorithm.OPEN);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
            config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);
            config.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.TKIP);
            config.allowedProtocols.set(WifiConfiguration.Protocol.WPA);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
            config.allowedPairwiseCiphers.set(WifiConfiguration.PairwiseCipher.CCMP);
            config.status = WifiConfiguration.Status.ENABLED;
        }

        try {
//            setStaticIp(config);
        } catch (Exception e) {

        }
        return config;
    }

    public static List<WifiConfiguration> getWifiConfigedList() {
        return wifiConfigedList;
    }

    public static WifiConfiguration createWifiConfiguration(Context context, String SSID, String password, int type) {
        WifiConfiguration config = null;
        if (mWifiManager == null) {
            mWifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        }
        if (type == 0) {
            config = isOpenWifiExist(SSID);
        } else {
            config = isWifiExist(SSID);
        }
        if (config == null) {
            config = new WifiConfiguration();
        }
        config.allowedAuthAlgorithms.clear();
        config.allowedGroupCiphers.clear();
        config.allowedKeyManagement.clear();
        config.allowedPairwiseCiphers.clear();
        config.allowedProtocols.clear();
        config.SSID = SSID;
        // 分为三种情况：0没有密码1用wep加密2用wpa加密
        if (type == 0) {// WIFICIPHER_NOPASSwifiCong.hiddenSSID = false;
            config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
        } else if (type == 1) {  //  WIFICIPHER_WEP
            config.hiddenSSID = true;
            config.wepKeys[0] = password;
            config.allowedAuthAlgorithms
                    .set(WifiConfiguration.AuthAlgorithm.SHARED);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP40);
            config.allowedGroupCiphers
                    .set(WifiConfiguration.GroupCipher.WEP104);
            config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
            config.wepTxKeyIndex = 0;
        } else if (type == 2) {   // WIFICIPHER_WPA
            config.preSharedKey = password;
            config.hiddenSSID = true;
            config.allowedAuthAlgorithms
                    .set(WifiConfiguration.AuthAlgorithm.OPEN);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
            config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);
            config.allowedPairwiseCiphers
                    .set(WifiConfiguration.PairwiseCipher.TKIP);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
            config.allowedPairwiseCiphers
                    .set(WifiConfiguration.PairwiseCipher.CCMP);
            config.status = WifiConfiguration.Status.ENABLED;
        }
        return config;
    }


    public final static String ALINK_SOFT_AP_GATEWAY = "172.31.254.250"; // 172.31.254.250    192.192.192.192
    public final static String ALINK_SOFT_AP_STATIC_IP = "172.31.254.153";// 172.31.254.153    192.192.192.10
    public final static String ALINK_SOFT_AP_DNS = "192.192.192.192";//same with gateway

//    public static void setStaticIp(WifiConfiguration configuration) throws ClassNotFoundException, NoSuchFieldException, IllegalAccessException, IllegalArgumentException, NoSuchMethodException, InstantiationException, InvocationTargetException, UnknownHostException, UnknownHostException {
//        setEnumField(configuration, "STATIC", "ipAssignment");
//        Object linkProperties = getField(configuration, "linkProperties");
//        if (linkProperties == null)
//            return;
//        //set IpAddress
//        Class<?> laClass = Class.forName("android.net.LinkAddress");
//        Constructor<?> laConstructor = laClass.getConstructor(new Class[] {
//                InetAddress.class, int.class });
//        Object linkAddress = laConstructor.newInstance(InetAddress.getByName(ALINK_SOFT_AP_STATIC_IP), 24);
//
//        ArrayList<Object> mLinkAddresses = (ArrayList<Object>) getDeclaredField(
//                linkProperties, "mLinkAddresses");
//        mLinkAddresses.clear();
//        mLinkAddresses.add(linkAddress);
//        //set Gateway
//        if (android.os.Build.VERSION.SDK_INT >= 14) { // android4.x版本
//            Class<?> routeInfoClass = Class.forName("android.net.RouteInfo");
//            Constructor<?> routeInfoConstructor = routeInfoClass.getConstructor(new Class[] { InetAddress.class });
//            Object routeInfo = routeInfoConstructor.newInstance(InetAddress.getByName(ALINK_SOFT_AP_GATEWAY));
//
//            ArrayList<Object> mRoutes = (ArrayList<Object>) getDeclaredField(linkProperties, "mRoutes");
//            mRoutes.clear();
//            mRoutes.add(routeInfo);
//        } else { // android3.x版本
//            ArrayList<InetAddress> mGateways = (ArrayList<InetAddress>) getDeclaredField(
//                    linkProperties, "mGateways");
//            mGateways.clear();
//            mGateways.add(InetAddress.getByName(ALINK_SOFT_AP_GATEWAY));
//        }
//        //setDNS,DNS 不设置部分手机softAP static 模式会导致手机重启
//        ArrayList<InetAddress> mDnses = (ArrayList<InetAddress>)getDeclaredField(linkProperties, "mDnses");
//        mDnses.clear();
//        mDnses.add(InetAddress.getByName(ALINK_SOFT_AP_DNS));
//
//    }

//    private Object getField(Object obj, String productName) throws NoSuchFieldException, IllegalAccessException, IllegalArgumentException {
//        Field f = obj.getClass().getField(productName);
//        Object out = f.get(obj);
//        return out;
//    }
//
//    private static Object getDeclaredField(Object obj, String productName)throws SecurityException, NoSuchFieldException,IllegalArgumentException, IllegalAccessException {
//        Field f = obj.getClass().getDeclaredField(productName);
//        f.setAccessible(true);
//        Object out = f.get(obj);
//        return out;
//    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void setEnumField(Object obj, String value, String name) throws SecurityException, NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
        Field f = obj.getClass().getField(name);
        f.set(obj, Enum.valueOf((Class<Enum>) f.getType(), value));
    }


    public static WifiConfiguration isOpenWifiExist(String ssid) {
        ALog.d(TAG, "isOpenWifiExist,ssid=" + ssid);
        for (int i = 0; i < wifiConfigedList.size(); i++) {
            WifiConfiguration wifiConfiguration = wifiConfigedList.get(i);
            if (wifiConfiguration != null && !TextUtils.isEmpty(wifiConfiguration.SSID) &&
                    wifiConfiguration.SSID.equals("\"" + ssid + "\"")
                    && wifiConfiguration.allowedKeyManagement.get(WifiConfiguration.KeyMgmt.NONE)) {
                ALog.d(TAG, "isOpenWifiExist(),found config");
                return wifiConfigedList.get(i);
            }
        }
        return null;
    }


    public static WifiConfiguration isWifiExist(String ssid) {
        ALog.d(TAG, "isWifiExist");
        for (int i = 0; i < wifiConfigedList.size(); i++) {
            WifiConfiguration wifiConfiguration = wifiConfigedList.get(i);
            if (wifiConfiguration != null && !TextUtils.isEmpty(wifiConfiguration.SSID)
                    && wifiConfiguration.SSID.equals("\"" + ssid + "\"")) {
                ALog.d(TAG, "isWifiExist(),found config");
                return wifiConfiguration;
            }
        }
        return null;
    }

    public static void acquireWifiLock() {
        if (wifiLock == null) {
            wifiLock = mWifiManager.createWifiLock("Test");
        }
        wifiLock.acquire();
    }


    public static void releaseWifiLock() {
        if (wifiLock != null && wifiLock.isHeld()) {
            wifiLock.acquire();
        }
    }

    static public InetAddress getBroadcast(InetAddress inetAddr) {
        if (inetAddr == null) {
            return null;
        }

        ALog.d(TAG, "getBroadcast(),inetAddr = " + inetAddr);
        NetworkInterface temp;
        InetAddress iAddr = null;
        try {
            temp = NetworkInterface.getByInetAddress(inetAddr);
            List<InterfaceAddress> addresses = temp.getInterfaceAddresses();

            for (InterfaceAddress inetAddress : addresses) {
                if (inetAddress.getAddress() instanceof Inet4Address) {
                    iAddr = inetAddress.getBroadcast();
                }
            }
            ALog.d(TAG, "iAddr=" + iAddr);
            return iAddr;

        } catch (SocketException e) {
            e.printStackTrace();
            ALog.d(TAG, "getBroadcast" + e.getMessage());
        }
        return null;
    }

    public static void updateConfigedWifi(Context context) {
        ALog.d("AlinkDC_WifiManagerUtil", "updateConfigedWifi()");

        try {
            if (mWifiManager == null) {
                mWifiManager = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            }
            if (null != mWifiManager.getConfiguredNetworks()) {
                wifiConfigedList.clear();
                wifiConfigedList.addAll(mWifiManager.getConfiguredNetworks());
            }
        } catch (Exception var2) {
            ALog.d("AlinkDC_WifiManagerUtil", "updateConfigedWifi(),error," + var2);
            var2.printStackTrace();
        }

    }

    public static String getRouterBSsid(Context context) {
        WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = wifiManager.getConnectionInfo();
        if (info == null) {
            return null;
        }
        return info.getBSSID();
    }

    public static void addWifi(WifiConfiguration configuration) {
        ALog.d(TAG, "addWifi()");
        if (configuration == null) {
            ALog.d(TAG, "addwifi(),config is null");
            return;
        }
        int netId = configuration.networkId;
        if (netId == -1) {
            ALog.d(TAG, "addWifi(), addNetwork..");
            //Returns -1 on failure
            netId = mWifiManager.addNetwork(configuration);
        }

        ALog.d(TAG, "addWifi(),netId = " + netId);
        if (netId == -1) {
            return;
        }
        try {
            disconnectAllConfiguredWifi();
            boolean enableNetwork = mWifiManager.enableNetwork(netId, true);
//			boolean saveConfig = wifiManager.saveConfiguration(); // 可能会改变netIDs
            boolean reconnect = mWifiManager.reconnect();
            ALog.d(TAG, "addWifi(),enable = " + enableNetwork + " reconnect = " + reconnect);
            Thread.sleep(1000L);
        } catch (Exception e) {
            ALog.e(TAG, "addWifi(),error,", e);
        }
    }

    public void removeWifi(int netId) {
        mWifiManager.removeNetwork(netId);
    }

    private static void disconnectAllConfiguredWifi() {
        try {
            ALog.w(TAG, "disconnectAllConfiguredWifi");
            for (int i = 0; i < wifiConfigedList.size(); i++) {
                if (wifiConfigedList.get(i) != null) {
                    disconnectWifi(wifiConfigedList.get(i).networkId);
                }
            }
        } catch (Exception e) {
            ALog.w(TAG, "disconnectAllConfiguredWifi e=" + e);
        }
    }

    public static void disconnectWifi(int netId) {
        mWifiManager.disableNetwork(netId);
        mWifiManager.disconnect();
    }

    @SuppressLint("NewApi")
    public static void startHotspot(Context context) {
        ALog.e(TAG, "startHotspot.");
        WifiManagerUtil util = new WifiManagerUtil(context.getApplicationContext());
        WifiConfiguration configuration = util.a("aha", "12345678", 2, true);
        if (mWifiManager == null) {
            mWifiManager = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        }

        ConnectivityManager connectivityManager = (ConnectivityManager) context.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N_MR1) {
            try {
                ALog.e(TAG, "setWifiApEnabled.");

                Method method = mWifiManager.getClass().getMethod(
                        "setWifiApEnabled", WifiConfiguration.class,
                        boolean.class);

                method.invoke(mWifiManager, configuration, true);
            } catch (Exception e) {
                ALog.e(TAG, " setWifiApEnabled(), e = " + e);
                e.printStackTrace();
            }
        } else {
            try {
                Field iConnMgrField = connectivityManager.getClass().getDeclaredField("mService");
                iConnMgrField.setAccessible(true);
                Object iConnMgr = iConnMgrField.get(connectivityManager);
                Class<?> iConnMgrClass = Class.forName(iConnMgr.getClass().getName());
                Method startTethering = iConnMgrClass.getMethod("startTethering", int.class, ResultReceiver.class, boolean.class);
                startTethering.invoke(iConnMgr, 0, new ResultReceiver(new Handler()) {
                    @Override
                    protected void onReceiveResult(int resultCode, Bundle resultData) {
                        super.onReceiveResult(resultCode, resultData);
                    }
                }, true);
            } catch (NoSuchFieldException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (false) {
            try {
                ALog.e(TAG, "cancelLocalOnlyHotspotRequest.");
                Method method = mWifiManager.getClass().getMethod(
                        "cancelLocalOnlyHotspotRequest");

                method.invoke(mWifiManager);
            } catch (Exception e) {
                ALog.e(TAG, " setWifiApEnabled(), e = " + e);
                e.printStackTrace();
            }
            ALog.e(TAG, "startLocalOnlyHotspot.");
            mWifiManager.startLocalOnlyHotspot(new WifiManager.LocalOnlyHotspotCallback() {
                @Override
                public void onStarted(WifiManager.LocalOnlyHotspotReservation reservation) {
                    super.onStarted(reservation);
                    ALog.e(TAG, "onstarted ssid=" + reservation.getWifiConfiguration().SSID);
                }

                @Override
                public void onStopped() {
                    super.onStopped();
                    ALog.e(TAG, "onstarted");
                }

                @Override
                public void onFailed(int reason) {
                    super.onFailed(reason);
                    ALog.e(TAG, "onFail");
                }
            }, new Handler());
        }
        return;
    }

    static public InetAddress getIpAddress(WifiManagerUtil.NetworkType networkType) {
        ALog.d(TAG, "getIpAddress()");
        InetAddress inetAddress = null;
        InetAddress myAddr = null;

        try {
            for (Enumeration<NetworkInterface> networkInterface = NetworkInterface
                    .getNetworkInterfaces(); networkInterface.hasMoreElements(); ) {

                NetworkInterface singleInterface = networkInterface.nextElement();

                for (Enumeration<InetAddress> IpAddresses = singleInterface.getInetAddresses(); IpAddresses
                        .hasMoreElements(); ) {
                    inetAddress = IpAddresses.nextElement();

                    if (!inetAddress.isLoopbackAddress() && (inetAddress instanceof Inet4Address)) {
                        if (singleInterface.getDisplayName().contains("wlan0") && networkType == WifiManagerUtil.NetworkType.WLAN) {
                            myAddr = inetAddress;
                            return myAddr;
                        }
                        if (singleInterface.getDisplayName().contains("eth0") && networkType == WifiManagerUtil.NetworkType.ETHERNET) {
                            myAddr = inetAddress;
                            return myAddr;
                        }
                        if ((singleInterface.getDisplayName().contains("wlan0") ||
                                singleInterface.getDisplayName().contains("eth0") ||
                                singleInterface.getDisplayName().contains("ap0"))) {

                            myAddr = inetAddress;
                        }
                    }
                }
            }

        } catch (SocketException ex) {
            ALog.d(TAG, ex.toString());
        }

        return myAddr;
    }

    public static boolean hasSimCard(Context context) {
        TelephonyManager telMgr = (TelephonyManager)
                context.getSystemService(Context.TELEPHONY_SERVICE);
        int simState = 0;
        if (telMgr != null) {
            simState = telMgr.getSimState();
        }
        boolean result = true;
        switch (simState) {
            case TelephonyManager.SIM_STATE_ABSENT:
                result = false;
                break;
            case TelephonyManager.SIM_STATE_UNKNOWN:
                result = false;
                break;
            default:
                break;
        }
        return result;
    }

    /**
     * 返回手机移动数据的状态**
     *
     * @param pContext*
     * @param arg       默认填null*
     * @return true 连接 false 未连接
     **/

    @SuppressWarnings({"rawtypes", "unchecked"})
    public static boolean getMobileDataState(Context pContext, Object[] arg) {
        try {
            ConnectivityManager mConnectivityManager = (ConnectivityManager) pContext.getSystemService(Context.CONNECTIVITY_SERVICE);
            Class ownerClass = mConnectivityManager.getClass();
            Class[] argsClass = null;
            if (arg != null) {
                argsClass = new Class[1];
                argsClass[0] = arg.getClass();
            }
            Method method = ownerClass.getMethod("getMobileDataEnabled", argsClass);
            return (Boolean) method.invoke(mConnectivityManager, arg);
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean isWiFiConnected(Context context) {
        ConnectivityManager conMan = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        //wifi
        NetworkInfo.State wifi = conMan.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState();
        return wifi == NetworkInfo.State.CONNECTED || wifi == NetworkInfo.State.CONNECTING;
    }

    private static WifiInfo getWifiInfo(Context context) {
        WifiManager wifiManager = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (wifiManager == null) {
            return null;
        }
        return wifiManager.getConnectionInfo();
    }

    public static String getWifiSsid(Context context) {
        WifiInfo info = getWifiInfo(context);
        if (info == null) {
            return "";
        }
        String ssid = "";
        try {
            ssid = new String(info.getSSID().replace("\"", "").getBytes(), "UTF-8");
            if (ssid.equals("<unknown ssid>") || ssid.equals("0x")) {
                ssid = "";
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ssid;
    }
}