package com.aliyun.iot.homelink.demo;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.aliyun.iot.aep.component.router.IUrlHandler;
import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.homelink.demo.page.scan.ScanActivity;
import com.aliyun.iot.ilop.page.deviceadd.bind.DeviceBindActivity;
import com.aliyun.iot.ilop.page.deviceadd.category.CategoryDeviceActivity;
import com.aliyun.iot.ilop.page.deviceadd.product.ProductListActivity;
import com.aliyun.iot.ilop.page.deviceadd.search.SearchActivity;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by xingwei on 2018/4/28.
 */

public class NativeRouterHelper {

    private List<String> mNativeUrls;

    private static class SingletonHolder {
        private static final NativeRouterHelper INSTANCE = new NativeRouterHelper();
    }

    private NativeRouterHelper() {
        mNativeUrls = new ArrayList<>();
//        mNativeUrls.add("")
    }

    public static final NativeRouterHelper getInstance() {
        return SingletonHolder.INSTANCE;
    }

    public void init() {
        IUrlHandler nativeUrlHandle = new IUrlHandler() {
            @Override
            public void onUrlHandle(Context context, String url, Bundle bundle, boolean isForResult, int requestCode) {
                try {
                    Intent intent = new Intent();
                    intent.setData(Uri.parse(url));
                    if (null != bundle) {
                        intent.putExtras(bundle);
                    }
                    if (isForResult && context instanceof Activity) {
                        ((Activity) context).startActivityForResult(intent, requestCode);
                    } else {
                        context.startActivity(intent);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        Router.getInstance().registerRegexUrlHandler("hld://.*$", nativeUrlHandle);
        Router.getInstance().registerRegexUrlHandler(DeviceBindActivity.CODE, new IUrlHandler() {
            @Override
            public void onUrlHandle(Context context, String s, Bundle bundle, boolean isForResult, int requestCode) {
                Intent intent = new Intent(context, DeviceBindActivity.class);
                if (null != bundle) {
                    intent.putExtras(bundle);
                }
                if (isForResult && context instanceof Activity) {
                    ((Activity) context).startActivityForResult(intent, requestCode);
                } else {
                    context.startActivity(intent);
                }
            }
        });

        Router.getInstance().registerRegexUrlHandler(CategoryDeviceActivity.CODE, new IUrlHandler() {
            @Override
            public void onUrlHandle(Context context, String s, Bundle bundle, boolean isForResult, int requestCode) {
                Intent intent = new Intent(context, CategoryDeviceActivity.class);
                if (null != bundle) {
                    intent.putExtras(bundle);
                }
                if (isForResult && context instanceof Activity) {
                    ((Activity) context).startActivityForResult(intent, requestCode);
                } else {
                    context.startActivity(intent);
                }
            }
        });

        Router.getInstance().registerRegexUrlHandler(SearchActivity.CODE_SEARCH, new IUrlHandler() {
            @Override
            public void onUrlHandle(Context context, String s, Bundle bundle, boolean isForResult, int requestCode) {
                Intent intent = new Intent(context, SearchActivity.class);
                if (null != bundle) {
                    intent.putExtras(bundle);
                }
                if (isForResult && context instanceof Activity) {
                    ((Activity) context).startActivityForResult(intent, requestCode);
                } else {
                    context.startActivity(intent);
                }
            }
        });


        Router.getInstance().registerRegexUrlHandler(ProductListActivity.CODE, new IUrlHandler() {
            @Override
            public void onUrlHandle(Context context, String s, Bundle bundle, boolean isForResult, int requestCode) {
                Intent intent = new Intent(context, ProductListActivity.class);
                if (null != bundle) {
                    intent.putExtras(bundle);
                }
                if (isForResult && context instanceof Activity) {
                    ((Activity) context).startActivityForResult(intent, requestCode);
                } else {
                    context.startActivity(intent);
                }
            }
        });

        Router.getInstance().registerRegexUrlHandler(ScanActivity.CODE, new IUrlHandler() {
            @Override
            public void onUrlHandle(Context context, String s, Bundle bundle, boolean isForResult, int requestCode) {
                Intent intent = new Intent(context, ScanActivity.class);
                if (null != bundle) {
                    intent.putExtras(bundle);
                }
                if (isForResult && context instanceof Activity) {
                    ((Activity) context).startActivityForResult(intent, requestCode);
                } else {
                    context.startActivity(intent);
                }
            }
        });

    }


}
