package com.aliyun.iot.homelink.demo.page.init;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.text.TextUtils;
import android.widget.Toast;

import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.aep.sdk.framework.AActivity;
import com.aliyun.iot.aep.sdk.login.ILoginCallback;
import com.aliyun.iot.aep.sdk.login.LoginBusiness;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;
import com.aliyun.iot.homelink.demo.R;
import com.aliyun.iot.link.ui.component.LinkToast;

/**
 * @author xingwei
 * @date 2018/6/13
 */
public class InitAct extends AActivity {

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);

        setContentView(R.layout.init_act);
        ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
            @Override
            public void run() {
                toLogin();
            }
        }, 1000);
    }

    void toLogin() {
        if (LoginBusiness.isLogin()) {
            toIndex();
        } else {
            LoginBusiness.login(new ILoginCallback() {
                @Override
                public void onLoginSuccess() {
                    toIndex();
                }

                @Override
                public void onLoginFailed(int i, String s) {
                    String msg = s;
                    if (TextUtils.isEmpty(msg)) {
                        msg = "登入失败";
                    }
                    LinkToast.makeText(InitAct.this, msg, Toast.LENGTH_LONG).show();
                    finish();
                }
            });
        }
    }

    void toIndex() {
        Router.getInstance().toUrl(this, "hld://index");
        finish();
    }
}
