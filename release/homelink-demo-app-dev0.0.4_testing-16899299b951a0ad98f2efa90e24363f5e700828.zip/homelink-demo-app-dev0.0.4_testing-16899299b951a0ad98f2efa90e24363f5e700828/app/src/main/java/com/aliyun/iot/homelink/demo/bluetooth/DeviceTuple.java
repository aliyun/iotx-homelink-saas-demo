package com.aliyun.iot.homelink.demo.bluetooth;

/**
 * @author sinyuk
 * @date 2019-09-11
 */
public class DeviceTuple {
    public String pk;
    public String pid;

    public DeviceTuple(String pk, String pid) {
        this.pk = pk;
        this.pid = pid;
    }

    @Override
    public String toString() {
        return "DeviceTuple{" +
                "pk='" + pk + '\'' +
                ", pid='" + pid + '\'' +
                '}';
    }
}
