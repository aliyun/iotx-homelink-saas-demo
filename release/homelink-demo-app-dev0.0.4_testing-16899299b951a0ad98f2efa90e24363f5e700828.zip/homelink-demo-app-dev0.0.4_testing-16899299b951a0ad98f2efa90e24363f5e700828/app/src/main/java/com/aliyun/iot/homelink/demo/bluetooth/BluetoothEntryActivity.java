package com.aliyun.iot.homelink.demo.bluetooth;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.aliyun.iot.homelink.demo.R;
import com.aliyun.iot.link.ui.component.LinkToast;

import cn.dreamtobe.kpswitch.util.KeyboardUtil;
import cn.dreamtobe.kpswitch.widget.KPSwitchPanelFrameLayout;

/**
 * @author sinyuk
 * @date 2019-09-11
 */
public class BluetoothEntryActivity extends AppCompatActivity implements BluetoothEntryFragment.OnListFragmentInteractionListener {

    private Button button;
    private TextInputEditText editTextPk;
    private TextInputEditText editTextPid;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ble_entry);
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        button = findViewById(R.id.btn_ok);
        editTextPid = findViewById(R.id.et_pid);
        editTextPk = findViewById(R.id.et_pk);

        editTextPid.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                boolean enable = !TextUtils.isEmpty(s) && !TextUtils.isEmpty(editTextPk.getText());
                button.setEnabled(enable);
            }
        });

        editTextPk.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                boolean enable = !TextUtils.isEmpty(s) && !TextUtils.isEmpty(editTextPid.getText());
                button.setEnabled(enable);
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onListFragmentInteraction(
                        new DeviceTuple(editTextPk.getText().toString(), editTextPid.getText().toString()));
            }
        });


        KPSwitchPanelFrameLayout panel = findViewById(R.id.panel);
        KeyboardUtil.attach(this, panel, new KeyboardUtil.OnKeyboardShowingListener() {
            @Override
            public void onKeyboardShowing(boolean isShowing) {
                if (!isShowing) {
                    editTextPk.clearFocus();
                    editTextPid.clearFocus();
                }
            }
        });

        NestedScrollView scrollView = findViewById(R.id.scroll_view);
        scrollView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (MotionEvent.ACTION_UP == motionEvent.getAction() ||
                        MotionEvent.ACTION_CANCEL == motionEvent.getAction()) {
                    KeyboardUtil.hideKeyboard(view);
                }
                return false;
            }
        });


        editTextPid.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if (keyEvent != null && keyEvent.getKeyCode() == KeyEvent.ACTION_DOWN) {
                    return false;
                } else if (EditorInfo.IME_ACTION_NEXT == i ||
                        EditorInfo.IME_ACTION_DONE == i ||
                        EditorInfo.IME_NULL == i ||
                        keyEvent == null ||
                        KeyEvent.KEYCODE_ENTER == keyEvent.getAction()) {
                    editTextPid.clearFocus();
                    editTextPk.requestFocus();
                }
                return false;
            }
        });

        editTextPk.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if (keyEvent != null && keyEvent.getKeyCode() == KeyEvent.ACTION_DOWN) {
                    return false;
                } else if (EditorInfo.IME_ACTION_NEXT == i || EditorInfo.IME_ACTION_DONE == i || EditorInfo.IME_NULL == i || keyEvent == null || KeyEvent.KEYCODE_ENTER == keyEvent.getAction()) {
                    if (button.isEnabled()) {
                        onListFragmentInteraction(
                                new DeviceTuple(editTextPk.getText().toString(), editTextPid.getText().toString()));
                    } else {
                        LinkToast.makeText(textView.getContext(), "pk和pid不能为空", Toast.LENGTH_SHORT).show();
                    }
                }
                return false;
            }
        });
    }

    @Override
    public void onListFragmentInteraction(DeviceTuple item) {
        BluetoothActivity.start(this, item);
        finish();
    }
}
