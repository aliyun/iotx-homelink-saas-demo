package com.aliyun.iot.homelink.demo.page.index;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatImageView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.aliyun.alink.linksdk.tools.ALog;
import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClient;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientFactory;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTCallback;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTResponse;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequestBuilder;
import com.aliyun.iot.aep.sdk.credential.IotCredentialManager.IoTCredentialManageImpl;
import com.aliyun.iot.aep.sdk.credential.listener.IoTTokenInvalidListener;
import com.aliyun.iot.aep.sdk.login.ILogoutCallback;
import com.aliyun.iot.aep.sdk.login.LoginBusiness;
import com.aliyun.iot.homelink.demo.BuildConfig;
import com.aliyun.iot.homelink.demo.PageIndexNew.view.main.IndexFragment;
import com.aliyun.iot.homelink.demo.R;
import com.aliyun.iot.homelink.demo.page.scene.list.SceneListFragment;
import com.aliyun.iot.homelink.demo.page.scene.list.SceneListPresenter;
import com.aliyun.iot.homelink.si.component.ExceptionToast;
import com.aliyun.iot.ilop.page.deviceadd.bind.DeviceBindActivity;
import com.aliyun.iot.ilop.page.deviceadd.external.scan.AddDeviceScanHelper;
import com.aliyun.iot.ilop.page.mine.home.MineFragment;
import com.aliyun.iot.link.ui.component.LinkToast;
import com.facebook.react.bridge.AssertionException;

import java.util.ArrayList;
import java.util.List;

//import com.aliyun.iot.homelink.demo.page.my.tab.MyFragment;
//import demo.homelink.iot.demo.index.main.IndexFragment;


/**
 * @author sinyuk
 * @date 2018/6/13
 * <p>
 * index activity
 */
public class IndexActivity extends AppCompatActivity {
    public static final String TAG = "IndexActivity";
    public static final String ACTION_CHANGE_HOUSE = "HOUSE_CHENGE_ACTION";
    public static final String KEY_GROUP_ID = "groupId";
    public static final String KEY_ROLE = "role";
    public static final int ROLE_ADMIN = 1;
    public static final int ROLE_FAMILY = 2;

    private LocalBroadcastManager broadcastManager;
    private HouseChangeReceiver receiver;
    private final Runnable logoutRunnable = new Runnable() {
        @Override
        public void run() {
            LoginBusiness.logout(new ILogoutCallback() {
                @Override
                public void onLogoutSuccess() {
                    toInit();
                }

                @Override
                public void onLogoutFailed(int i, String s) {
                    toInit();
                }
            });
        }
    };


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_index);
        registerBroadcast();
        setupViewpager();

        // TODO: Resume的时候会crash: IoTCredentialManageImpl must call init first
        try {
            IoTCredentialManageImpl.getInstance(getApplication())
                    .setIotCredentialListenerList(new IoTTokenInvalidListener() {
                        @Override
                        public void onIoTTokenInvalid() {
                            runOnUiThread(logoutRunnable);
                        }
                    });
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }

        groupId = IoTCredentialManageImpl.getInstance(getApplication()).getIoTIdentity();
        ALog.e(TAG, "groupId:" + groupId);
    }

    private void toInit() {
        Intent intent = new Intent();
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        intent.setData(Uri.parse("hld://init"));
        startActivity(intent);
        finish();
    }


    private String groupId = "HOMELINK_AQUARIUS";
    /**
     * 0: admin
     * 1: family
     */
    private int role = ROLE_FAMILY;

    private void registerBroadcast() {
        broadcastManager = LocalBroadcastManager.getInstance(this);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ACTION_CHANGE_HOUSE);
        receiver = new HouseChangeReceiver();
        broadcastManager.registerReceiver(receiver, intentFilter);
    }

    public final static int PAGE_COUNT = 2;

    private void setupViewpager() {
        ViewPager viewPager = findViewById(R.id.viewPager);
        tabLayout = findViewById(R.id.tabLayout);
        final List<Fragment> fragments = initFragments();
        if (BuildConfig.DEBUG && PAGE_COUNT != fragments.size()) {
            throw new AssertionException("Fragments size must be equal to: " + PAGE_COUNT);
        }
        viewPager.setOffscreenPageLimit(fragments.size() - 1);
        viewPager.setAdapter(new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                return fragments.get(position);
            }

            @Override
            public int getCount() {
                return PAGE_COUNT;
            }
        });

        tabLayout.setupWithViewPager(viewPager);
        initTabs();
    }

    private SceneListPresenter sceneListPresenter = null;

    /**
     * TODO: replace specific fragment here
     */
    private List<Fragment> initFragments() {
        IndexFragment indexFragment = new IndexFragment();
//        SceneListFragment sceneListFragment = new SceneListFragment();
//        sceneListPresenter =
//                new SceneListPresenter(SceneRepository.getInstance(), sceneListFragment, groupId, role);
        MineFragment myFragment = new MineFragment();
        List<Fragment> fragments = new ArrayList<>();
        fragments.add(indexFragment);
        fragments.add(myFragment);
//        fragments.add(new IndexFragment());
        return fragments;
    }

    private static final int[] TAB_ICONS = {
            R.drawable.index_ic_tab_device,
//            R.drawable.index_ic_tab_scene,
            R.drawable.index_ic_tab_my
    };

    private TabLayout tabLayout = null;

    private void initTabs() {
        final String[] titles = getResources().getStringArray(R.array.index_tab_titles);
        for (int i = 0; i < PAGE_COUNT; i++) {
            View view = View.inflate(this, R.layout.custom_tab, null);
            ((TextView) view.findViewById(R.id.text)).setText(titles[i]);
            ((AppCompatImageView) view.findViewById(R.id.icon)).setImageResource(TAB_ICONS[i]);
            //noinspection ConstantConditions
            tabLayout.getTabAt(i).setCustomView(view);
        }
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                onSelectedStateChanged(tab, true);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                onSelectedStateChanged(tab, false);
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    private void onSelectedStateChanged(TabLayout.Tab tab, boolean selected) {
        if (tab.getCustomView() == null) {
            return;
        }
        TextView text = tab.getCustomView().findViewById(R.id.text);
        if (text != null) {
            text.setSelected(selected);
        }
        ImageView icon = tab.getCustomView().findViewById(R.id.icon);
        if (icon != null) {
            icon.setSelected(selected);
        }
    }

    /**
     * According to bizType, there are two situations:
     * <p>
     * - house/room: send url to server to parsing code
     * - device: handle url by client
     *
     * @param requestCode request
     * @param resultCode  result
     * @param data        qrCode url
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case AddDeviceScanHelper.REQUEST_CODE_SCAN: {
                if ((RESULT_OK == resultCode)) {
                    if (data == null) {
                        LinkToast.makeText(this, "二维码解析失败", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    // result can be either bar code or failed message
                    String result = data.getStringExtra("data");
                    Uri uri = Uri.parse(result);
                    if (null == uri) {
                        LinkToast.makeText(this, "二维码解析失败", Toast.LENGTH_SHORT).show();
                        return;
                    } else if (null == uri.getQueryParameter("pk")) {
                        handleQRCode(uri);
                    } else {
                        AddDeviceScanHelper.wiFiConfig(this, data, groupId);
                    }
                } else if (resultCode == RESULT_CANCELED && data != null) {
                    String message = data.getStringExtra("data");
                    if (message != null) {
                        LinkToast.makeText(this, message, Toast.LENGTH_SHORT).show();
                    }
                }
                break;
            }
            case AddDeviceScanHelper.REQUEST_CODE_CONFIG_WIFI: {
                String pk = data.getStringExtra("productKey");
                String dn = data.getStringExtra("deviceName");
                if (pk == null || groupId == null) {
                    return;
                }
                Bundle bundle = new Bundle();
                bundle.putString(DeviceBindActivity.ARGS_KEY_PK, pk);
                bundle.putString(DeviceBindActivity.ARGS_KEY_DN, dn);
                bundle.putString(DeviceBindActivity.ARGS_KEY_GROUP_ID, groupId);
                Router.getInstance().toUrlForResult(this,
                        DeviceBindActivity.CODE, DeviceBindActivity.REQUEST_CODE, bundle);
                break;
            }
            case SceneListFragment.REQUEST_CODE_INIT_SCENE:
            case SceneListFragment.REQUEST_CODE_EDIT_SCENE:
                if (Activity.RESULT_OK == resultCode) {
                    sceneListPresenter.loadScenes(1);
                }
                break;
            case 1010:
            case 1011:
            case 1015:
                if (tabLayout.getSelectedTabPosition() == 0) {
                    getSupportFragmentManager().getFragments().get(0)
                            .onActivityResult(requestCode, resultCode, data);
                }
                break;
            case DeviceBindActivity.REQUEST_CODE: {
                if (resultCode == RESULT_OK) {
                    Intent intent = new Intent();
                    intent.setAction("UP_INDEX_FRAGMENT_ACTION");
                    LocalBroadcastManager.getInstance(IndexActivity.this).sendBroadcast(intent);
                }
                break;
            }
            default:
                Log.w(TAG, "Forgot to deal with the Activity's result."
                        + "\nrequestCode: " + requestCode
                        + "\nresultCode: " + resultCode);
                break;
        }
    }

    private void handleQRCode(@NonNull final Uri uri) {
        final String bizType = uri.getQueryParameter("bizType");
        String apiVersion = "1.0.3";
        IoTRequestBuilder builder = new IoTRequestBuilder()
                .setAuthType("iotAuth")
                .setPath("/homelink/share/parse/qrCode")
                .setApiVersion(apiVersion)
                .addParam("qrCode", uri.toString());
        IoTAPIClient mIoTAPIClient = new IoTAPIClientFactory().getClient();
        mIoTAPIClient.send(builder.build(), new IoTCallback() {
            @Override
            public void onFailure(final IoTRequest ioTRequest, final Exception e) {
                if (bizType == null) {
                    ExceptionToast.toastNetworkException(IndexActivity.this, e);
                } else {
                    String message;
                    switch (bizType) {
                        case "DEVICE_SHARE":
                        case "SCENE_SHARE":
                        case "HOUSE_SHARE":
                            message = "分享失败";
                            break;
                        case "MEMBER_ADD":
                            message = "添加成员失败";
                            break;
                        case "HOUSE_DELIVERY":
                            message = "转让家失败";
                            break;
                        default:
                            message = "扫描失败";
                            break;
                    }
                    LinkToast.makeText(IndexActivity.this, message, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onResponse(final IoTRequest ioTRequest, final IoTResponse ioTResponse) {
                ExceptionToast.toastNetworkResponseError(IndexActivity.this, ioTResponse);
                if (200 == ioTResponse.getCode()) {
                    Intent intent = new Intent();
                    intent.setAction("UP_INDEX_FRAGMENT_ACTION");
                    LocalBroadcastManager.getInstance(IndexActivity.this).sendBroadcast(intent);
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (broadcastManager != null) {
            broadcastManager.unregisterReceiver(receiver);
        }
    }


    private class HouseChangeReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent != null && intent.hasExtra(KEY_GROUP_ID)) {
                groupId = intent.getStringExtra(KEY_GROUP_ID);
                role = intent.getIntExtra(KEY_ROLE, ROLE_FAMILY);
                if (sceneListPresenter != null) {
                    sceneListPresenter.switchHouse(groupId, role);
                }
            }
        }
    }
}
