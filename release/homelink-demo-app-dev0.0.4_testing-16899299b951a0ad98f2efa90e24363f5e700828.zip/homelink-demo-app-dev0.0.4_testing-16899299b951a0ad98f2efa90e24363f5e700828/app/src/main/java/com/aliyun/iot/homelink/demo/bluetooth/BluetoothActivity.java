package com.aliyun.iot.homelink.demo.bluetooth;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.aliyun.alink.business.devicecenter.api.add.AddDeviceBiz;
import com.aliyun.alink.business.devicecenter.api.add.DeviceInfo;
import com.aliyun.alink.business.devicecenter.api.add.IAddDeviceListener;
import com.aliyun.alink.business.devicecenter.api.add.LinkType;
import com.aliyun.alink.business.devicecenter.api.add.ProvisionStatus;
import com.aliyun.alink.business.devicecenter.api.discovery.IOnDeviceTokenGetListener;
import com.aliyun.alink.business.devicecenter.api.discovery.LocalDeviceMgr;
import com.aliyun.alink.business.devicecenter.base.DCErrorCode;
import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.homelink.demo.R;
import com.aliyun.iot.ilop.page.deviceadd.bind.DeviceBindActivity;
import com.aliyun.iot.link.ui.component.LinkToast;
import com.aliyun.iot.link.ui.component.simpleLoadview.LinkSimpleLoadView;

import cn.dreamtobe.kpswitch.util.KeyboardUtil;
import cn.dreamtobe.kpswitch.widget.KPSwitchPanelFrameLayout;

/**
 * @author sinyuk
 * @date 2018/9/5
 */
public class BluetoothActivity extends AppCompatActivity {
    public final static String ARGS_KEY_PK = "ARGS_KEY_PK";
    public final static String ARGS_KEY_PID = "ARGS_KEY_PID";
    private static final int REQUEST_BLUETOOTH_CODE = 0x10010;
    private static final String TAG = "BluetoothActivity";
    private final static int REQUEST_CODE_QR = 0x11;
    private EditText ssidInput = null;
    private EditText passwordInput = null;
    private Button nextButton = null;
    private LinkSimpleLoadView loadView;

    public static void start(Context context, DeviceTuple tuple) {
        Log.d(TAG, "start: " + tuple.toString());
        Intent starter = new Intent(context, BluetoothActivity.class);
        starter.putExtra(ARGS_KEY_PK, tuple.pk);
        starter.putExtra(ARGS_KEY_PID, tuple.pid);
        context.startActivity(starter);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.deviceadd_bluetooth_activity);
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        nextButton = findViewById(R.id.nextButton);
        nextButton.setEnabled(false);

        loadView = findViewById(R.id.loadingView);
        loadView.setLoadViewLoacation(1);
        loadView.setTipViewLoacation(1);
        loadView.hide();

        setupKeyboard();
        String ssid = AddDeviceBiz.getInstance().getCurrentSsid(this);
        ssidInput.setText(ssid);
        ssidInput.setFocusableInTouchMode(false);
        ssidInput.setFocusable(false);

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startConfig(view);
            }
        });
        checkBluetoothPermission();
    }

    private void checkBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            int p1 = ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH);
            int p2 = ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN);

            if (p1 == PackageManager.PERMISSION_GRANTED && p2 == PackageManager.PERMISSION_GRANTED) {
                //already has bluetooth permission
            } else if (p1 == PackageManager.PERMISSION_DENIED && p2 == PackageManager.PERMISSION_DENIED) {
                //permission denied
                new AlertDialog.Builder(this)
                        .setMessage("需要蓝牙权限开启此功能")
                        .setPositiveButton("去开启", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                Uri packageURI = Uri.parse("package:" + getPackageName());
                                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, packageURI);
                                startActivity(intent);
                            }
                        }).setNegativeButton("取消", null)
                        .show();
            } else {
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH, Manifest.permission.BLUETOOTH_ADMIN}, REQUEST_BLUETOOTH_CODE);
            }
        } else {
            //no need to request permission
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_BLUETOOTH_CODE) {
            // do nothing
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupKeyboard() {
        ssidInput = findViewById(R.id.ssidInput);
        passwordInput = findViewById(R.id.passwordInput);

        NestedScrollView scrollView = findViewById(R.id.scrollView);
        KPSwitchPanelFrameLayout panel = findViewById(R.id.panel);

        KeyboardUtil.attach(this, panel, new KeyboardUtil.OnKeyboardShowingListener() {
            @Override
            public void onKeyboardShowing(boolean isShowing) {
                if (isShowing) {
                    passwordInput.requestFocus();
                } else {
                    passwordInput.clearFocus();
                }
            }
        });

        scrollView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (MotionEvent.ACTION_UP == motionEvent.getAction() ||
                        MotionEvent.ACTION_CANCEL == motionEvent.getAction()) {
                    KeyboardUtil.hideKeyboard(view);
                }
                return false;
            }
        });

        ssidInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                passwordInput.setFocusableInTouchMode(!TextUtils.isEmpty(editable));
            }
        });

        passwordInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                if (keyEvent != null && keyEvent.getKeyCode() == KeyEvent.ACTION_DOWN) {
                    return false;
                } else if (EditorInfo.IME_ACTION_NEXT == i ||
                        EditorInfo.IME_ACTION_DONE == i ||
                        EditorInfo.IME_NULL == i ||
                        keyEvent == null ||
                        KeyEvent.KEYCODE_ENTER == keyEvent.getAction()) {
                    startConfig(textView);
                }
                return false;
            }
        });

        nextButton.setEnabled(true);
    }

    private void startConfig(final View view) {

        if ("5GHZ".equals(AddDeviceBiz.getInstance().getWifiType(this))) {
            Log.d(TAG, "设备不支持5GHZ WiFi配网，请切换到2.4GHZ WiFi，当前配网结束。");
            loadView.hide();
            LinkToast.makeText(this, "当前连接的是5G网络，请切换至2.4G网络再开始配网", Toast.LENGTH_LONG).show();
            return;
        }

        if (!WiFiUtils.isWiFiConnected(this)) {
            Log.d(TAG, "WiFi 未打开，请先打开WiFi然后再开始配网。");
            loadView.hide();
            LinkToast.makeText(this, "WiFi 未打开，请先打开WiFi然后再开始配网。", Toast.LENGTH_LONG).show();
            return;
        }

        DeviceInfo info = new DeviceInfo();
        info.productKey = getIntent().getStringExtra(ARGS_KEY_PK);
        info.productId = getIntent().getStringExtra(ARGS_KEY_PID);
        info.linkType = "ForceAliLinkTypeBLE";

        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null || !adapter.isEnabled()) {
            loadView.hide();
            LinkToast.makeText(this, "蓝牙未打开，请打开蓝牙 然后再开始配网。", Toast.LENGTH_LONG).show();
            return;
        }

        if (TextUtils.isEmpty(info.productId)) {
            loadView.hide();
            LinkToast.makeText(this, "蓝牙配网未指定productId，请设置后重新开始配网。", Toast.LENGTH_LONG).show();
            return;
        }

        final String ssid = ssidInput.getText().toString();
        final String password = passwordInput.getText().toString();

        if (TextUtils.isEmpty(info.productKey)) {
            loadView.hide();
            LinkToast.makeText(this, "PK为空，配网失败", Toast.LENGTH_LONG).show();
            return;
        }

        loadView.showLoading(getString(R.string.deviceadd_loading));
        AddDeviceBiz.getInstance().setDevice(info);
        AddDeviceBiz.getInstance().startAddDevice(this, new IAddDeviceListener() {
            @Override
            public void onPreCheck(boolean b, DCErrorCode dcErrorCode) {
                Log.d(TAG, "onPreCheck: " + b);
            }

            @Override
            public void onProvisionPrepare(int i) {
                Log.d(TAG, "onProvisionPrepare:  prepareType=" + i);
                if (i == 1) {
                    AddDeviceBiz.getInstance().toggleProvision(ssid, password, 60);
                } else if (i == 2) {
                    showOpenHotspotDialog(ssid, password);
                }
            }

            @Override
            public void onProvisioning() {
                Log.d(TAG, "onProvisioning: ");
            }

            @Override
            public void onProvisionStatus(ProvisionStatus provisionStatus) {

            }

            @Override
            public void onProvisionedResult(boolean b, DeviceInfo deviceInfo, DCErrorCode dcErrorCode) {
                Log.d(TAG, "onProvisionedResult: " + (b ? "成功" : "失败 " + (dcErrorCode == null ? "" : dcErrorCode.msg)));
                if (b) {
                    Log.d(TAG, "onProvisionedResult: " + JSON.toJSONString(deviceInfo));
                    getProvisionToken(deviceInfo);
                } else {
                    loadView.hide();
                    String message = dcErrorCode == null ? "匹配蓝牙失败" : dcErrorCode.msg;
                    LinkToast.makeText(BluetoothActivity.this, message, Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void onTerminate(@SuppressWarnings("unused") View view) {
        Log.d(TAG, "onTerminate: ");
        if (AddDeviceBiz.getInstance() != null) {
            AddDeviceBiz.getInstance().stopAddDevice();
        }
        if (view != null) {
            KeyboardUtil.hideKeyboard(view);
        }
        loadView.hide();
        setResult(RESULT_CANCELED);
    }

    private void onSucceed(final DeviceInfo deviceInfo) {
        AddDeviceBiz.getInstance().stopAddDevice();
        if (passwordInput != null) {
            KeyboardUtil.hideKeyboard(passwordInput);
        }
        loadView.hide();
        String productKey = deviceInfo.productKey;
        String deviceName = deviceInfo.deviceName;

        //noinspection ConstantConditions
        if (null == productKey) {
            LinkToast.makeText(this, "productKey不能为空", Toast.LENGTH_LONG).show();
            return;
        }
        if (null == deviceInfo.token) {
            LinkToast.makeText(this, "设备token不能为空", Toast.LENGTH_LONG).show();
            return;
        }

        Log.d(TAG, "to DeviceBindActivity: " + productKey + ", " + deviceName);
        Bundle bundle = new Bundle();
        bundle.putString(DeviceBindActivity.ARGS_KEY_PK, productKey);
        bundle.putString(DeviceBindActivity.ARGS_KEY_DN, deviceName);
        bundle.putString(DeviceBindActivity.ARGS_KEY_TOKEN, deviceInfo.token);
        Router.getInstance().toUrlForResult(this, DeviceBindActivity.CODE, DeviceBindActivity.REQUEST_CODE, bundle);
        finish();
    }

    private void getProvisionToken(final DeviceInfo info) {
        LinkToast.makeText(this, "开始获取设备端Token", Toast.LENGTH_SHORT);
        LocalDeviceMgr.getInstance().getDeviceToken(info.productKey, info.deviceName, 2000, new IOnDeviceTokenGetListener() {
            @Override
            public void onSuccess(String token) {
                Log.d(TAG, "getDeviceToken token：" + token);
                LinkToast.makeText(BluetoothActivity.this, "获取Token成功", Toast.LENGTH_SHORT);
                DeviceInfo copyInfo = new DeviceInfo();
                copyInfo.deviceName = info.deviceName;
                copyInfo.productKey = info.productKey;
                copyInfo.productId = info.productId;
                copyInfo.token = token;
                onSucceed(copyInfo);
            }

            @Override
            public void onFail(String reason) {
                Log.e(TAG, "getDeviceToken onFail: " + reason);
                LinkToast.makeText(BluetoothActivity.this, reason, Toast.LENGTH_SHORT);
            }
        });
    }

    @SuppressWarnings("unused")
    private String getLinkType(String type) {
        if ("0".equalsIgnoreCase(type)) {
            return LinkType.ALI_BROADCAST.getName();
        }
        if ("1".equalsIgnoreCase(type)) {
            return LinkType.ALI_PHONE_AP.getName();
        }
        if ("2".equalsIgnoreCase(type)) {
            return LinkType.ALI_ROUTER_AP.getName();
        }
        if ("3".equalsIgnoreCase(type)) {
            return LinkType.ALI_ZERO_AP.getName();
        }
        if ("5".equalsIgnoreCase(type)) {
            return "ForceAliLinkTypeBLE";
        }
        return "ForceAliLinkTypeNone";
    }

    @SuppressWarnings("unused")
    private String getProvisionType(String type) {
        if ("0".equals(type)) {
            return "广播";
        }
        if ("1".equals(type)) {
            return "热点";
        }
        if ("2".equals(type)) {
            return "路由器";
        }
        if ("3".equals(type)) {
            return "零配";
        }
        if ("5".equals(type)) {
            return "蓝牙辅助";
        }
        return "ERROR";
    }

    private void showOpenHotspotDialog(final String ssid, final String password) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setPositiveButton("确认", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                // User clicked OK button
                AddDeviceBiz.getInstance().toggleProvision(ssid, password, 60);
            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                // User cancelled the dialog
                onTerminate(null);
            }
        });

        builder.setMessage("请开启aha手机热点，并设置热点密码12345678。" +
                "\n热点设置完毕后，点击OK键开始配网。")
                .setTitle("热点开启提示");

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @SuppressWarnings("unused")
    private boolean requestBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.System.canWrite(this)) {
                LinkToast.makeText(this, "请求设置蓝牙权限", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQUEST_CODE_QR);
                return false;
            } else {
                LinkToast.makeText(this, "已有设置权限", Toast.LENGTH_LONG).show();
            }
        }
        return true;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (requestCode == REQUEST_CODE_QR) {
                String message;
                if (Settings.System.canWrite(this)) {
                    //检查返回结果
                    message = "WRITE_SETTINGS permission granted";
                } else {
                    message = "WRITE_SETTINGS permission not granted";
                }
                LinkToast.makeText(this, message, Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        WiFiUtils.getWifiSsid(this);
    }

    @Override
    protected void onDestroy() {
        onTerminate(null);
        super.onDestroy();
    }

}