package com.aliyun.iot.homelink.demo;

import com.aliyun.alink.linksdk.channel.mobile.api.MobileChannel;
import com.aliyun.alink.linksdk.tools.ThreadTools;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientImpl;
import com.aliyun.iot.aep.sdk.framework.AApplication;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;
import com.facebook.drawee.backends.pipeline.Fresco;

//import com.aliyun.iot.aghanim.utils.ShakeUtils;

/**
 * 需要继承AApplication，会将所有配置在sdk_config 下的sdk 进行初始化
 *
 * @author xingwei
 */
public class IoTApplication extends AApplication {

    @Override
    public void onCreate() {
        super.onCreate();

        String packageName = this.getPackageName();
        if (!packageName.equals(ThreadTools.getProcessName(this, android.os.Process.myPid()))) {
            // 非主进程直接退出
            return;
        }

        // 注册本地native 路由
        NativeRouterHelper.getInstance().init();

        // 开启网络请求日志
        ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
            @Override
            public void run() {
                // 开启网络请求日志
                IoTAPIClientImpl.getInstance().registerTracker(new Tracker());
                ALog.setLevel(ALog.LEVEL_VERBOSE);
                // 开启长连接日志
                com.aliyun.alink.linksdk.tools.ALog.setLevel(ALog.LEVEL_VERBOSE);
                MobileChannel.setOpenLog(true);
            }
        });

        // 初始化Fresco
        Fresco.initialize(this);
    }
}