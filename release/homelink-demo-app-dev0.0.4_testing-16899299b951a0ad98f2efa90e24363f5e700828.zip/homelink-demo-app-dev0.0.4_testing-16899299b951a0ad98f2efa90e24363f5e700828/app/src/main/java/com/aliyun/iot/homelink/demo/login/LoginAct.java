package com.aliyun.iot.homelink.demo.login;

import android.os.Bundle;
import android.view.View;

import com.aliyun.iot.aep.oa.page.OALoginActivity;

/**
 * Created by xingwei on 2018/7/17.
 */

public class LoginAct extends OALoginActivity {

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        //  不显示返回键
        this.findViewById(com.aliyun.iot.aep.sdk.login.oa.ui.R.id.imageview_account_back).setVisibility(View.GONE);
    }
}
