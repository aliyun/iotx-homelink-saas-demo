package com.aliyun.iot.ilop.page.mine.smallcomponents.listener;

import android.os.Handler;
import android.os.Message;

import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.ilop.page.mine.MineAPIClientConstants;
import com.aliyun.iot.ilop.page.mine.MineConstants;
import com.aliyun.iot.ilop.page.mine.base.MineBaseBusinessListener;

import java.util.HashMap;
import java.util.Map;

public class SmallComponentDeviceListener extends MineBaseBusinessListener {

    public SmallComponentDeviceListener(Handler handler) {
        super(handler);
    }

    @Override
    protected void onResponseSuccess(IoTRequest ioTRequest, String ioTResponse) {

        if (mHandler == null) {
            return;
        }
        if (ioTRequest.getPath().equals(MineAPIClientConstants.SMALL_COMMPONENT_PATH_GETDEVICELIST)) {
            onRequestGetDeviceListSuccess(ioTRequest, ioTResponse);
        } else if (ioTRequest.getPath().equals(MineAPIClientConstants.SMALL_COMMPONENT_PATH_GETDEVICEPROPRETYLIST)) {
            onRequestGetDevicePropertySuccess(ioTRequest, ioTResponse);
        } else if (ioTRequest.getPath().equals(MineAPIClientConstants.SMALL_COMMPONENT_PATH_QUERYCOMPONENTPRODUCT)) {
            onRequestQueryComponentProductSuccess(ioTRequest, ioTResponse);
        }else if(ioTRequest.getPath().equals(MineAPIClientConstants.SMALL_COMMPONENT_PATH_UPDATECOMPONENTPROPERTY)){
            onRequestUpdateComponentProductSuccess(ioTRequest,ioTResponse);
        }

    }

    @Override
    protected void onResponseFailure(IoTRequest ioTRequest, String ioTResponse) {
        if (mHandler == null) {
            return;
        }
        if (ioTRequest.getPath().equals(MineAPIClientConstants.SMALL_COMMPONENT_PATH_GETDEVICELIST)) {
            onRequestGetDeviceListFailed(ioTRequest, ioTResponse);
        } else if (ioTRequest.getPath().equals(MineAPIClientConstants.SMALL_COMMPONENT_PATH_GETDEVICEPROPRETYLIST)) {
            onRequestGetDevicePropertyFailed(ioTRequest, ioTResponse);
        } else if (ioTRequest.getPath().equals(MineAPIClientConstants.SMALL_COMMPONENT_PATH_QUERYCOMPONENTPRODUCT)) {
            onRequestQueryComponentProductFailed(ioTRequest, ioTResponse);
        }else if(ioTRequest.getPath().equals(MineAPIClientConstants.SMALL_COMMPONENT_PATH_UPDATECOMPONENTPROPERTY)){
            onRequestUpdateComponentProductFailed(ioTRequest,ioTResponse);
        }

    }

    @Override
    protected void onRequestFailure(IoTRequest ioTRequest, Exception e) {
        if (mHandler == null) {
            return;
        }
        Map<String, Object> map = new HashMap<>();
        map.put("ioTRequest", ioTRequest);
        Message.obtain(mHandler, MineConstants.MINE_MESSAGE_NETWORK_ERROR, map).sendToTarget();
    }

    //返回设备列表
    private void onRequestGetDeviceListSuccess(IoTRequest ioTRequest, String ioTResponse) {
        if (null == mHandler) {
            return;
        }

        Message.obtain(mHandler, MineConstants.MINE_SMALL_COMPONENT_GET_DEVICE_LIST_SUCCESS, ioTResponse).sendToTarget();
    }

    private void onRequestGetDeviceListFailed(IoTRequest ioTRequest, String ioTResponse) {
        if (null == mHandler) {
            return;
        }
        Message.obtain(mHandler, MineConstants.MINE_SMALL_COMPONENT_GET_DEVICE_LIST_FAIL, ioTResponse).sendToTarget();
    }

    //返回设备属性列表
    private void onRequestGetDevicePropertySuccess(IoTRequest ioTRequest, String ioTResponse) {
        if (null == mHandler) {
            return;
        }
        Map<String, Object> map = new HashMap<>();
        map.put("ioTRequest", ioTRequest);
        map.put("ioTResponse", ioTResponse);
        Message.obtain(mHandler, MineConstants.MINE_SMALL_COMPONENT_GET_DEVICE_PROPERTY_SUCCESS, map).sendToTarget();
    }

    private void onRequestGetDevicePropertyFailed(IoTRequest ioTRequest, String ioTResponse) {
        if (null == mHandler) {
            return;
        }
        Map<String, Object> map = new HashMap<>();
        map.put("ioTRequest", ioTRequest);
        map.put("ioTResponse", ioTResponse);
        Message.obtain(mHandler, MineConstants.MINE_SMALL_COMPONENT_GET_DEVICE_PROPERTY_FAIL, map).sendToTarget();
    }

    //获取已添加设备列表
    private void onRequestQueryComponentProductSuccess(IoTRequest ioTRequest, String ioTResponse) {
        if (null == mHandler) {
            return;
        }

        Message.obtain(mHandler, MineConstants.MINE_SMALL_COMPONENT_QUERY_COMPONENT_PRODUCT_SUCCESS, ioTResponse).sendToTarget();
    }

    private void onRequestQueryComponentProductFailed(IoTRequest ioTRequest, String ioTResponse) {
        if (null == mHandler) {
            return;
        }
        Message.obtain(mHandler, MineConstants.MINE_SMALL_COMPONENT_QUERY_COMPONENT_PRODUCT_FAIL, ioTResponse).sendToTarget();
    }

    //更新小组件设备
    private void onRequestUpdateComponentProductSuccess(IoTRequest ioTRequest, String ioTResponse) {
        if (null == mHandler) {
            return;
        }

        Message.obtain(mHandler, MineConstants.MINE_SMALL_COMPONENT_UPDATE_COMPONENT_PROPERTY_SUCCESS, ioTResponse).sendToTarget();
    }

    private void onRequestUpdateComponentProductFailed(IoTRequest ioTRequest, String ioTResponse) {
        if (null == mHandler) {
            return;
        }
        Message.obtain(mHandler, MineConstants.MINE_SMALL_COMPONENT_UPDATE_COMPONENT_PROPERTY_FAIL, ioTResponse).sendToTarget();
    }

}
