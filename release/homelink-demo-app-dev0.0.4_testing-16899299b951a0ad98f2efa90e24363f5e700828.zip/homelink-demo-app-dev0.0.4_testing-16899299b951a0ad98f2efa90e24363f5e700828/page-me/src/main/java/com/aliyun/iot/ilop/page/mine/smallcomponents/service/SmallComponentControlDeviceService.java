package com.aliyun.iot.ilop.page.mine.smallcomponents.service;

import android.app.Notification;
import android.app.Service;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.alink.linksdk.tmp.device.panel.PanelDevice;
import com.aliyun.alink.linksdk.tmp.device.panel.listener.IPanelCallback;
import com.aliyun.alink.linksdk.tmp.device.panel.listener.IPanelEventCallback;
import com.aliyun.iot.aep.sdk.login.LoginBusiness;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.ilop.page.mine.MineConstants;
import com.aliyun.iot.ilop.page.mine.smallcomponents.appwidgetprovider.SmallComponentDeviceAppWidget;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.PropertyBean;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.SmallComponentDeviceBean;
import com.aliyun.iot.ilop.page.mine.smallcomponents.business.SmallComponentDeviceBusiness;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SmallComponentControlDeviceService extends Service {

    private final String TAG = "SmallComponentControlDeviceService";

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case MineConstants.MINE_SMALL_COMPONENT_QUERY_COMPONENT_PRODUCT_SUCCESS:
                    //刷新界面
                    smallComponentDeviceBeans.clear();
                    String data = msg.obj.toString();
                    analyticalDeviceList(data);
                    subDeviceAllEvent();
                    sendUpdateListBoadcast();
                    break;
                case MineConstants.MINE_SMALL_COMPONENT_QUERY_COMPONENT_PRODUCT_SERVICE_SUCCESS:
                    ArrayList<SmallComponentDeviceBean> beans = (ArrayList<SmallComponentDeviceBean>) msg.obj;
                    if (beans.size() != smallComponentDeviceBeans.size()) {
                        smallComponentDeviceBeans = beans;
                        sendUpdateListBoadcast();
                    }
                    break;
            }
        }
    };


    //获取设备列表
    private final String GETDEVICELIST = "GETDEVICELIST";
    private final String GETDEVICELIST_CLEAR_PROPERTY_MAP = "GETDEVICELIST_CLEAR_PROPERTY_MAP";
    //设置设备属性
    private static final String SETDEVICEATTRIBUTE = "SETDEVICEATTRIBUTE";
    private static final String REFRESHDEVICE = "REFRESHDEVICE";
    private final String REFERSH_CURRENT_CHECK = "DEVICE_REFERSH_CURRENT_CHECK";
    private SmallComponentDeviceBusiness smallComponentDeviceBusiness;
    private Map<String, PanelDevice> panelDeviceMap = new HashMap<>();
    private ArrayList<SmallComponentDeviceBean> smallComponentDeviceBeans = new ArrayList<>();
    private static final String REFERSH_PROPERTY = "REFERSH_PROPERTY";

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public ComponentName startService(Intent service) {
        return super.startService(service);

    }

    @RequiresApi(api = Build.VERSION_CODES.CUPCAKE)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForeground(1, new Notification());
        }

        if (intent == null) {
            return super.onStartCommand(intent, flags, startId);
        }
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        int[] appWidgetIds = manager.getAppWidgetIds(new ComponentName(this.getPackageName(), SmallComponentDeviceAppWidget.class.getName()));
        if (appWidgetIds.length > 0) {

            String key = intent.getStringExtra("KEY");
            if (GETDEVICELIST_CLEAR_PROPERTY_MAP.equalsIgnoreCase(key)) {
                //调用获取设备列表接口
                /*   //登录，调用获取设备列表
                 */
                panelDeviceMap.clear();
                key = GETDEVICELIST;
            }
            if (!LoginBusiness.isLogin()) {
                //没有登录，反馈列表为空
                smallComponentDeviceBeans.clear();
                Intent ref_intent = new Intent(REFRESHDEVICE);
                Bundle bundle = new Bundle();
                bundle.putParcelableArrayList("DEVICELIST", smallComponentDeviceBeans);
                ref_intent.putExtra("DEVICELIST", bundle);
                ref_intent.setComponent(new ComponentName(this, SmallComponentDeviceAppWidget.class));
                sendBroadcast(ref_intent);
            } else {
                if (GETDEVICELIST.equals(key)) {
                    //调用获取设备列表接口
                    /*   //登录，调用获取设备列表
                     */
                    smallComponentDeviceBusiness = new SmallComponentDeviceBusiness(handler);
                    smallComponentDeviceBusiness.queryComponentProductByIdentityId();
                } else if (SETDEVICEATTRIBUTE.equals(key)) {
                    //打开设备属性列表
                    final int swicth_position = intent.getIntExtra("CHECK_SWITCH_POSITION", -1);
                    final int current_position = intent.getIntExtra("CHECK_POSITION", -1);
                    if (swicth_position == -1) {
                        Intent intent1 = new Intent();
                        intent1.putExtra("CHECK_POSITION", current_position);
                        intent1.setAction(REFERSH_CURRENT_CHECK);
                        intent1.setComponent(new ComponentName(this, SmallComponentDeviceAppWidget.class));
                        sendBroadcast(intent1);
                        //检查设备列表是否正确
                        CheckDeviceListNum();
                    } else {
                        //设置设备属性
                        int status = intent.getIntExtra("status", -1);
                        if (status == 1 || status == 2) {
                            final String iotid = intent.getStringExtra("iotId");
                            final String attributeName = intent.getStringExtra("attributeName");
                            final int attributeValue = intent.getIntExtra("attributeValue", -1);
                            Map<String, Object> map1 = new HashMap<>();
                            map1.put(attributeName, attributeValue);
                            Map<String, Object> map = new HashMap<>();
                            map.put("iotId", iotid);
                            map.put("items", map1);
                            try {
                                PanelDevice panelDevice = panelDeviceMap.get(iotid);
                                if (panelDevice == null) {
                                    panelDevice = new PanelDevice(iotid);
                                    panelDevice.init(this, new IPanelCallback() {
                                        @Override
                                        public void onComplete(boolean b, Object o) {
                                            ALog.e(TAG, "panelDevice.init:" + b);
                                        }
                                    });
                                }
                                String str = JSON.toJSONString(map);
                                panelDevice.setProperties(str, new IPanelCallback() {

                                    @Override
                                    public void onComplete(boolean b, Object o) {
                                        if (o != null) {
                                            JSONObject jsonObject = JSON.parseObject(o.toString());
                                            Integer code = jsonObject.getInteger("code");
                                            if (code == 200) {
                                                //设置成功
                                                for (int i = 0; i < smallComponentDeviceBeans.size(); i++) {
                                                    SmallComponentDeviceBean smallComponentDeviceBean = smallComponentDeviceBeans.get(i);
                                                    if (smallComponentDeviceBean.getIotId().equals(iotid)) {
                                                        ArrayList<PropertyBean> list = smallComponentDeviceBean.getSwitchList();
                                                        for (int j = 0; j < list.size(); j++) {
                                                            PropertyBean propertyBean = list.get(j);
                                                            if (propertyBean.getPropertyIdentifier().equals(attributeName)) {
                                                                propertyBean.setCheck(attributeValue == 0 ? false : true);
                                                                sendRefershPropertyBoadcast();
                                                                return;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                });
                            } catch (Exception ex) {
                                ALog.e(TAG, "Disconnection of small component equipment" + ":" + ex.getMessage());
                            }
                        }
                        //检查设备列表是否正确
                        CheckDeviceListNum();
                    }
                }
            }
        }
        return super.onStartCommand(intent, flags, startId);
    }

    //解析设备更新状态数据
    private void notifyDeviceList(String method, String json) {

        if (method.equalsIgnoreCase("/app/down/thing/status")) {
            //更改设备状态
            JSONObject jsonObject = JSON.parseObject(json);
            if (jsonObject != null) {
                String iotId = jsonObject.getString("iotId");
                JSONObject jsonObject1 = jsonObject.getJSONObject("status");
                if (jsonObject1 != null) {
                    int value = jsonObject1.getIntValue("value");
                    for (int i = 0; i < smallComponentDeviceBeans.size(); i++) {
                        SmallComponentDeviceBean smallComponentDeviceBean = smallComponentDeviceBeans.get(i);
                        if (smallComponentDeviceBean.getIotId().equals(iotId)) {
                            smallComponentDeviceBean.setStatus(value);
                            sendRefershPropertyBoadcast();
                            return;
                        }
                    }
                }
            }
        } else if (method.equalsIgnoreCase("/app/down/thing/properties")) {
            //更改设备状态
            JSONObject jsonObject = JSON.parseObject(json);
            if (jsonObject != null) {
                String iotId = jsonObject.getString("iotId");
                JSONObject jsonObject1 = jsonObject.getJSONObject("items");
                for (int i = 0; i < smallComponentDeviceBeans.size(); i++) {
                    SmallComponentDeviceBean smallComponentDeviceBean = smallComponentDeviceBeans.get(i);
                    if (smallComponentDeviceBean.getIotId().equals(iotId)) {
                        ArrayList<PropertyBean> propertyBeans = smallComponentDeviceBean.getSwitchList();
                        for (int j = 0; j < propertyBeans.size(); j++) {
                            PropertyBean propertyBean = propertyBeans.get(j);
                            JSONObject jsonObject2 = jsonObject1.getJSONObject(propertyBean.getPropertyIdentifier());
                            if (jsonObject2 != null) {
                                Integer values = jsonObject2.getInteger("value");
                                int check = (propertyBean.isCheck() == false ? 0 : 1);
                                if (values == null || values == check) {
                                    return;
                                }
                                propertyBean.setCheck(values == 0 ? false : true);
                                if (smallComponentDeviceBean.getStatus() == 2) {
                                    smallComponentDeviceBean.setStatus(1);
                                }
                            }
                        }
                        sendRefershPropertyBoadcast();
                        return;
                    }
                }

            }

        }
        smallComponentDeviceBusiness = new SmallComponentDeviceBusiness(handler);
        smallComponentDeviceBusiness.queryComponentProductByIdentityId();
    }

    /**
     * 发送广播更新界面
     */
    public void sendUpdateListBoadcast() {
        Intent intent = new Intent();
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("DEVICELIST", smallComponentDeviceBeans);
        intent.putExtra("DEVICELIST", bundle);
        intent.setAction(REFRESHDEVICE);
        intent.setComponent(new ComponentName(SmallComponentControlDeviceService.this, SmallComponentDeviceAppWidget.class));
        sendBroadcast(intent);
    }

    public void sendRefershPropertyBoadcast() {
        Intent intent = new Intent();
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("DEVICELIST", smallComponentDeviceBeans);
        intent.putExtra("DEVICELIST", bundle);
        intent.setAction(REFERSH_PROPERTY);
        intent.setComponent(new ComponentName(SmallComponentControlDeviceService.this, SmallComponentDeviceAppWidget.class));
        sendBroadcast(intent);
    }

    /**
     * 订阅设备事件
     */
    private void subDeviceAllEvent() {
        //循环列表，绑定设备监听
        if (smallComponentDeviceBeans.size() == 0) {
            panelDeviceMap.clear();
        }
        for (int i = 0; i < smallComponentDeviceBeans.size(); i++) {
            String iot = smallComponentDeviceBeans.get(i).getIotId();
            if (panelDeviceMap.get(iot) != null) {
                break;
            }
            try {
                PanelDevice panelDevice = new PanelDevice(iot);
                panelDevice.subAllEvents(new IPanelEventCallback() {
                    @Override
                    public void onNotify(String s, String s1, Object o) {
                        /*smallComponentDeviceBusiness = new SmallComponentDeviceBusiness(handler);
                        smallComponentDeviceBusiness.queryComponentProductByIdentityId();*/
                        notifyDeviceList(s1, o.toString());
                    }
                }, new IPanelCallback() {
                    @Override
                    public void onComplete(boolean b, Object o) {
                        /* */
                    }
                });
                panelDevice.init(this, new IPanelCallback() {
                    @Override
                    public void onComplete(boolean b, Object o) {
                        ALog.e(TAG, "panelDevice.init:" + b);
                    }
                });
                panelDeviceMap.put(iot, panelDevice);
            } catch (Exception ex) {
                ALog.e(TAG, "Disconnection of small component equipment" + ":" + ex.getMessage());
            }
        }
    }

    /**
     * 解析设备列表数据
     *
     * @param data
     */
    private void analyticalDeviceList(String data) {

        JSONArray array = JSON.parseArray(data);
        for (int i = 0; i < array.size(); i++) {
            JSONObject json = array.getJSONObject(i);
            SmallComponentDeviceBean smallComponentDeviceBean = new SmallComponentDeviceBean();
            smallComponentDeviceBean.setProductKey(json.getString("productKey"));
            smallComponentDeviceBean.setDeviceName(json.getString("deviceName"));
            smallComponentDeviceBean.setIotId(json.getString("iotId"));
            smallComponentDeviceBean.setNickName(json.getString("nickName"));
            smallComponentDeviceBean.setProductName(json.getString("productName"));
            smallComponentDeviceBean.setProductImage(json.getString("iconUrl"));
            smallComponentDeviceBean.setStatus(json.getInteger("deviceStatus"));
            JSONArray jsonArray = json.getJSONArray("properties");
            ArrayList properArray = new ArrayList();
            for (int j = 0; j < jsonArray.size(); j++) {
                JSONObject jsonObject = jsonArray.getJSONObject(j);
                PropertyBean propertyBean = new PropertyBean();
                String dataType = jsonObject.getString("propertyDataType");
                if (dataType != null && dataType.equalsIgnoreCase("bool")) {
                    String values = jsonObject.getString("propertyValue");
                    if (values != null) {
                        if ("1".equals(values)) {
                            propertyBean.setCheck(true);
                        } else {
                            propertyBean.setCheck(false);
                        }
                    }
                }
                propertyBean.setPropertyName(jsonObject.getString("propertyName"));
                propertyBean.setPropertyIdentifier(jsonObject.getString("propertyIdentifier"));
                properArray.add(propertyBean);
            }
            smallComponentDeviceBean.setSwitchList(properArray);
            smallComponentDeviceBeans.add(smallComponentDeviceBean);
        }
    }

    /**
     * 检查设备列表是否返回正确
     */
    public void CheckDeviceListNum() {

        smallComponentDeviceBusiness.queryComponentProductListNumber();

    }

}
