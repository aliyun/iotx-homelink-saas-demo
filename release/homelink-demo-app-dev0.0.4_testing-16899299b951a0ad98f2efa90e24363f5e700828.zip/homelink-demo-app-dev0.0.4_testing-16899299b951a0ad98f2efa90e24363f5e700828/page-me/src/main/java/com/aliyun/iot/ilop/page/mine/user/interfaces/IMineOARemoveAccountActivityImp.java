package com.aliyun.iot.ilop.page.mine.user.interfaces;

public interface IMineOARemoveAccountActivityImp {

    void onFailed(String error);


    void onRemoveSuccess();

}
