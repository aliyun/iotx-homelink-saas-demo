package com.aliyun.iot.ilop.page.mine.smallcomponents.service;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.smallcomponents.appwidgetprovider.SmallComponentSceneAppWidget;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.SmallComponentSceneBean;

import java.util.List;

public class SmallComponentSceneService extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new SmallComponentSceneFactory(this.getApplicationContext());
    }

    private class SmallComponentSceneFactory implements RemoteViewsFactory {

        private List<SmallComponentSceneBean> list;
        private Context context;

        public SmallComponentSceneFactory(Context context) {
            this.context = context;
        }

        @Override
        public void onCreate() {

        }

        @Override
        public void onDataSetChanged() {

        }

        @Override
        public void onDestroy() {

        }

        @Override
        public int getCount() {
            list = SmallComponentSceneAppWidget.getSmallComponentSceneBeans();
            return list.size();
        }

        @Override
        public RemoteViews getViewAt(int position) {
            list = SmallComponentSceneAppWidget.getSmallComponentSceneBeans();
            SmallComponentSceneBean smallComponentSceneBean = list.get(position);

            RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.small_component_scene_item);
            // remoteViews.setImageViewBitmap(R.id.iv_scene,smallComponentSceneBean.getSceneBitmap());
            if (smallComponentSceneBean.getState() == 1) {
                remoteViews.setTextViewText(R.id.tv_scene, context.getResources().getString(R.string.appExtension_device_execute));
                remoteViews.setViewVisibility(R.id.progress_bar_scene, View.VISIBLE);
            } else if (smallComponentSceneBean.getState() == 2) {
                remoteViews.setTextViewText(R.id.tv_scene, context.getResources().getString(R.string.appExtension_device_execute_fail));
                remoteViews.setViewVisibility(R.id.progress_bar_scene, View.GONE);
            } else if (smallComponentSceneBean.getState() == 3) {
                remoteViews.setTextViewText(R.id.tv_scene, context.getResources().getString(R.string.appExtension_device_execute_success));
                remoteViews.setViewVisibility(R.id.progress_bar_scene, View.GONE);
            } else {
                remoteViews.setTextViewText(R.id.tv_scene, smallComponentSceneBean.getSceneName());
                remoteViews.setViewVisibility(R.id.progress_bar_scene, View.GONE);
            }
            if (smallComponentSceneBean.getState() != 1)

            {
                Intent intent = new Intent();
                intent.putExtra("CHECK_POSITION", position);
                intent.putExtra("SCENE_STATE", 1);
                remoteViews.setOnClickFillInIntent(R.id.ll_scene_item, intent);
            }
            return remoteViews;
        }

        @Override
        public RemoteViews getLoadingView() {
            return null;
        }

        @Override
        public int getViewTypeCount() {
            return 1;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public boolean hasStableIds() {
            return false;
        }
    }

}
