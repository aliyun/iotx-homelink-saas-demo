package com.aliyun.iot.utils;

import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AppWidgetHelper {

    //刷新设备列表小组件
    public static void refreshDeviceWidget(Context context,String key) {
        Class service = null;
        try {
            service = Class.forName("com.aliyun.iot.ilop.page.mine.smallcomponents.service.SmallComponentControlDeviceService");
            Intent intent = new Intent(context, service);
            intent.putExtra("KEY", key);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent);
            }else{
                context.startService(intent);
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

}
