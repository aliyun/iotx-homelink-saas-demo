package com.aliyun.iot.ilop.page.mine.entity;

import com.chad.library.adapter.base.entity.MultiItemEntity;

/**
 * Created by ZhuBingYang on 2019-04-18.
 */
public class SettingItem implements MultiItemEntity {
    private String text;

    public SettingItem(String text) {
        this.text = text;
    }

    @Override
    public int getItemType() {
        return 0;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return "SettingItem{" +
                "text='" + text + '\'' +
                '}';
    }
}
