package com.aliyun.iot.ilop.page.mine.user.business;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;

import com.alibaba.sdk.android.openaccount.OpenAccountSDK;
import com.alibaba.sdk.android.openaccount.OpenAccountService;
import com.alibaba.sdk.android.openaccount.OpenAccountSessionService;
import com.alibaba.sdk.android.openaccount.callback.LoginCallback;
import com.alibaba.sdk.android.openaccount.model.OpenAccountSession;
import com.alibaba.sdk.android.openaccount.util.ResourceUtils;
import com.aliyun.alink.linksdk.tools.ALog;
//import com.aliyun.iot.aep.oa.OAUserHelper;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientFactory;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTCallback;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTResponse;
import com.aliyun.iot.aep.sdk.apiclient.emuns.Scheme;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequestBuilder;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class MineClipImageBusiness {


    public static final int RESULT_UPDATE_IMAGE_SUCCESS = 0x00000001;
    public static final int RESULT_UPDATE_IMAGE_ERROE = 0x00000002;

    private Handler handler;
    private OkHttpClient mOkHttpClient;

    public MineClipImageBusiness(Handler handler) {
        this.handler = handler;
        OkHttpClient.Builder builder = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .writeTimeout(20, TimeUnit.SECONDS)
                .addNetworkInterceptor(new Interceptor() {
                    @Override
                    public Response intercept(Chain chain) throws IOException {
                        //在发送请求前删除该请求头
                        Request request = chain.request()
                                .newBuilder()
                                .removeHeader("Accept-Encoding")
                                .removeHeader("Content-Type")
                                .removeHeader("Connection")
                                .build();
                        return chain.proceed(request);
                    }
                })
                .readTimeout(20, TimeUnit.SECONDS);

        mOkHttpClient = builder.build();

    }


    private File generateUri(Bitmap zoomedCropBitmap) {
        if (zoomedCropBitmap == null) {
            return null;
        }

        OutputStream outputStream = null;
        File file = null;
        try {
            file = new File(OpenAccountSDK.getAndroidContext().getExternalCacheDir(), "cropped_avatar.jpg");
            outputStream = new FileOutputStream(file);
            zoomedCropBitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
        } catch (IOException ex) {
            if (file!=null){
                ALog.e("updateAvatar", "Cannot open file: " + file.getAbsolutePath(), ex);
            }else {
                ALog.e("updateAvatar", "file=null", ex);

            }
        } finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return file;

    }


    /**
     * 请求上传地址
     */
    public void updateImage(final Bitmap bitmap) {
        Map<String, Object> params = new HashMap<>();
        params.put("ossProfile", "app_avanter");
        params.put("action", "PUT");

        final OpenAccountService openAccountService = (OpenAccountService) OpenAccountSDK.getService(OpenAccountService.class);
        String userId = openAccountService.getSession().getUserId();

        params.put("ossKey", "iotx_uc/images/user/profile/" + userId.hashCode() + ".png");

        IoTRequestBuilder builder = new IoTRequestBuilder();
        builder.setApiVersion("1.0.1");
        builder.setScheme(Scheme.HTTPS);
        builder.setPath("/app/oss/operate");
        builder.setAuthType("iotAuth");
        builder.setParams(params);
        IoTRequest request = builder.build();
        (new IoTAPIClientFactory()).getClient().send(request, new IoTCallback() {
            @Override
            public void onFailure(IoTRequest ioTRequest, Exception e) {
                ALog.e("updateAvatar", "onFailure: " + e);
                Message.obtain(handler, RESULT_UPDATE_IMAGE_ERROE, ResourceUtils.getString("mine_network_error")).sendToTarget();
            }

            @Override
            public void onResponse(IoTRequest ioTRequest, IoTResponse ioTResponse) {
                if (ioTResponse.getCode() != 200 || !(ioTResponse.getData() instanceof String)) {
                    Message.obtain(handler, RESULT_UPDATE_IMAGE_ERROE, ioTResponse.getMessage()).sendToTarget();
                } else {
                    File file = generateUri(bitmap);
                    if (file == null || !file.exists()) {
                        Message.obtain(handler, RESULT_UPDATE_IMAGE_ERROE, ResourceUtils.getString("mine_update_error")).sendToTarget();
                        return;
                    }
                    String url = ioTResponse.getData().toString();

                    try {
                        RequestBody fileBody = RequestBody.create(MediaType.parse("image/png"), file);

                        Request request = new Request.Builder()
                                .url(url)
                                .put(fileBody)
                                .build();
                        Response response = mOkHttpClient.newCall(request).execute();
                        if (response.isSuccessful()) {
                            //更新用户信息
                            updateProfile(url.substring(0, url.indexOf('?')));
                        } else {
                            Message.obtain(handler, RESULT_UPDATE_IMAGE_ERROE, ResourceUtils.getString("mine_update_error")).sendToTarget();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                        ALog.e("updateAvatar", "updateImage: error  " + e.getMessage());
                        Message.obtain(handler, RESULT_UPDATE_IMAGE_ERROE, ResourceUtils.getString("mine_network_error")).sendToTarget();
                    }

                }

            }
        });

    }


    public void updateProfile(String imageUrl) {
//        OAUserHelper.updateAvatarUrl(OpenAccountSDK.getAndroidContext(), imageUrl, new LoginCallback() {
//            @Override
//            public void onSuccess(OpenAccountSession openAccountSession) {
//                ALog.e("updateAvatar", "onSuccess: ");
//                OpenAccountSessionService var1x = (OpenAccountSessionService) OpenAccountSDK.getService(OpenAccountSessionService.class);
//                var1x.refreshSession(true);
//                Message.obtain(handler, RESULT_UPDATE_IMAGE_SUCCESS).sendToTarget();
//            }
//
//            @Override
//            public void onFailure(int i, String s) {
//                ALog.e("updateAvatar", "onFailure: " + s);
//                Message.obtain(handler, RESULT_UPDATE_IMAGE_ERROE, s).sendToTarget();
//            }
//        });
    }


}
