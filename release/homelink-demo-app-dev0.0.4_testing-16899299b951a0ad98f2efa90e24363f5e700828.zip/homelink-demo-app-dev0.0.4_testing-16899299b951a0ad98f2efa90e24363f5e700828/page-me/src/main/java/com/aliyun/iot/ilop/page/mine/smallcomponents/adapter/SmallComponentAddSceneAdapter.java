package com.aliyun.iot.ilop.page.mine.smallcomponents.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.SmallComponentSceneBean;

import java.util.ArrayList;

public class SmallComponentAddSceneAdapter extends RecyclerView.Adapter<SmallComponentAddSceneAdapter.SceneViewHoler> {

    private ArrayList sceneList = new ArrayList();
    private Context context;

    public SmallComponentAddSceneAdapter(ArrayList sceneList, Context context) {
        this.sceneList = sceneList;
        this.context = context;
    }


    @Override
    public SceneViewHoler onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.ilop_mine_small_component_scene_grid_item, parent, false);
        return new SceneViewHoler(itemView);
    }

    @Override
    public void onBindViewHolder(SceneViewHoler holder, final int position) {

        if (position >= sceneList.size()) {
            holder.tv_scene_add_text.setVisibility(View.INVISIBLE);
            holder.iv_scene_delete.setVisibility(View.INVISIBLE);
            holder.ll_scene_add_img.setBackgroundResource(R.drawable.small_component_scene_dotted_line);
        } else {
            holder.ll_scene_add_img.setBackgroundResource(R.drawable.small_component_scene);
            SmallComponentSceneBean smallComponentSceneBean = (SmallComponentSceneBean) sceneList.get(position);
            holder.tv_scene_add_text.setVisibility(View.VISIBLE);
            holder.iv_scene_delete.setVisibility(View.VISIBLE);
            holder.tv_scene_add_text.setText(smallComponentSceneBean.getSceneName());
            final SmallComponentSceneBean smallComponentSceneBean1 = (SmallComponentSceneBean) sceneList.get(position);
            holder.iv_scene_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onDeteleSceneListener != null) {
                        onDeteleSceneListener.onDeleteScene(position);
                    }
                }
            });

        }

    }


    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return 8;
    }


    class SceneViewHoler extends RecyclerView.ViewHolder {
        private ImageView iv_scene_add_img;
        private ImageView iv_scene_delete;
        private TextView tv_scene_add_text;
        private LinearLayout ll_scene_add_img;

        public SceneViewHoler(View itemView) {
            super(itemView);
            iv_scene_add_img = itemView.findViewById(R.id.iv_scene_add_img);
            iv_scene_delete = itemView.findViewById(R.id.iv_scene_delete);
            tv_scene_add_text = itemView.findViewById(R.id.tv_scene_add_text);
            ll_scene_add_img=itemView.findViewById(R.id.ll_scene_add_img);
        }
    }

    public interface OnDeteleSceneListener {
        void onDeleteScene(int position);
    }

    private OnDeteleSceneListener onDeteleSceneListener;

    public void setOnDeteleSceneListener(OnDeteleSceneListener onDeteleSceneListener) {
        this.onDeteleSceneListener = onDeteleSceneListener;
    }


}
