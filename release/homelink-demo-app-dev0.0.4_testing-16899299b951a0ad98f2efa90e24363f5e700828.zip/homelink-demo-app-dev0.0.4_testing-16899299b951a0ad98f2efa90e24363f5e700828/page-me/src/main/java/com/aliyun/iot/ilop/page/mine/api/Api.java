package com.aliyun.iot.ilop.page.mine.api;

import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClient;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientFactory;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTCallback;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequestBuilder;
import com.aliyun.iot.aep.sdk.framework.config.AConfigure;
import com.aliyun.iot.ilop.page.mine.MineConstants;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;

/**
 * Created by nht.
 */

public class Api {
    private final static String TAG = "Api";

    private static class SingletonHolder {
        private static final Api INSTANCE = new Api();
    }

    private Api() {
    }

    public static final Api getInstance() {
        return SingletonHolder.INSTANCE;
    }

    /**
     * 消息中心
     *
     * @param map
     * @param iotCallback
     */
    public void requestMessage(Map<String, Object> map, IoTCallback iotCallback) {
        Map<String, Object> warpParam = new HashMap<>();
        warpParam.put("requestDTO", map);
        String apiVersion = "1.0.5";
        IoTRequestBuilder builder = new IoTRequestBuilder()
                .setAuthType("iotAuth")
                .setPath("/message/center/record/query")
                .setApiVersion(apiVersion)
                .setParams(warpParam);
        IoTRequest request = builder.build();
        IoTAPIClient ioTAPIClient = new IoTAPIClientFactory().getClient();
        ioTAPIClient.send(request, iotCallback);
    }

    /**
     * 清空消息
     *
     * @param msgType
     * @param iotCallback
     */
    public void clearMessage(String msgType, IoTCallback iotCallback) {
        String apiVersion = "1.0.1";
        Map<String, Object> params = new HashMap<>();
        params.put("type", "NOTICE");
        params.put("minId", 0);
        params.put("messageType", msgType);

        Map<String, Object> wrapParam = new HashMap<>();
        wrapParam.put("requestDTO", params);

        IoTRequestBuilder builder = new IoTRequestBuilder()
                .setAuthType("iotAuth")
                .setPath("/message/center/record/delete")
                .setApiVersion(apiVersion)
                .setParams(wrapParam);
        IoTRequest request = builder.build();
        IoTAPIClient ioTAPIClient = new IoTAPIClientFactory().getClient();
        ioTAPIClient.send(request, iotCallback);
    }

    public void requestUpgradeInfo(Callback callback) {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.connectTimeout(10, TimeUnit.SECONDS);
        OkHttpClient client = builder.hostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {

                if (hostname.equals("gaic.alicdn.com")) {
                    return true;
                }
                return false;
            }
        }).build();

        String url = "";
        String suffix = AConfigure.getInstance().getConfig("suffix");
        if ("develop".equalsIgnoreCase(suffix)) {
            url = MineConstants.MINE_URL_APP_UPGRADE_TEST;
        } else {
            url = MineConstants.MINE_URL_APP_UPGRADE_ONLINE;
        }

        Request request = new Request.Builder()
                .url(url)
                .build();
        client.newCall(request).enqueue(callback);
    }
}
