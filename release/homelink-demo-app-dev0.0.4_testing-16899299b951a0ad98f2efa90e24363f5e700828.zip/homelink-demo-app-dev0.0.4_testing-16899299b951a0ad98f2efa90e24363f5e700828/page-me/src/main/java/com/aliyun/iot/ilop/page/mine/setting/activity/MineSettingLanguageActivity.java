package com.aliyun.iot.ilop.page.mine.setting.activity;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import com.aliyun.iot.aep.component.router.IUrlHandler;
import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.aep.sdk.framework.config.AConfigure;
//import com.aliyun.iot.bean.RefreshUIBean;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.MineConstants;
import com.aliyun.iot.ilop.page.mine.base.MinePTRBaseActivity;
import com.aliyun.iot.ilop.page.mine.setting.adapter.MineLanguageAdapter;
import com.aliyun.iot.ilop.page.mine.setting.adapter.MineLanguageAdapter.OnItemClickListener;
import com.aliyun.iot.ilop.page.mine.setting.bean.LanguageModel;
import com.aliyun.iot.ilop.page.mine.view.MineDialog;
import com.aliyun.iot.ilop.page.mine.view.MineDialog.OnDialogButtonClickListener;
import com.aliyun.iot.ilop.page.mine.view.SimpleTopbar;
import com.aliyun.iot.ilop.page.mine.view.SimpleTopbar.onBackClickListener;
import com.aliyun.iot.utils.AppWidgetHelper;
import com.aliyun.iot.utils.LanguageUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static com.aliyun.iot.aep.Util.CountryUtils.globalProductList;

//import de.greenrobot.event.EventBus;

/**
 * Created by david on 2018/4/11.
 *
 * @author david
 * @date 2018/04/11
 */
public class MineSettingLanguageActivity extends MinePTRBaseActivity implements OnItemClickListener, onBackClickListener,
        OnDialogButtonClickListener {
    private SimpleTopbar mTopbar;
    private RecyclerView mRecyclerView;

    private MineLanguageAdapter mAdapter;
    private List<LanguageModel> mLanguageList = new ArrayList<>();

    private MineDialog mConfirmDialog;
    private final int autoLanguagePosition = 0;
    private int prePosition;
    private int postion;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ilop_mine_setting_language_activity);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (null != mTopbar) {
            mTopbar.setTitle(getString(R.string.mine_language));
        }

        chooseApplicationLanguage();
    }

    @Override
    protected void onDestroy() {
        if (null != mConfirmDialog) {
            if (mConfirmDialog.isShowing()) {
                mConfirmDialog.dismiss();
            }

            mConfirmDialog.cancel();
            mConfirmDialog = null;
        }
        super.onDestroy();
    }

    @Override
    protected void initView() {
        mTopbar = (SimpleTopbar) findViewById(R.id.mine_topbar);
        mRecyclerView = (RecyclerView) findViewById(R.id.mine_setting_language_recyclerview);
    }

    @Override
    protected void initData() {
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        mAdapter = new MineLanguageAdapter(this);
        mRecyclerView.setAdapter(mAdapter);
        loadList();
    }

    private void loadList() {
        //语言设置-现在只支持中文，英文,德语，法语
        mLanguageList = new ArrayList<>();
        mLanguageList.add(new LanguageModel(getString(R.string.setting_follow_system_langure), LanguageUtils.GetSysLocale()));
        mLanguageList.add(new LanguageModel(getString(R.string.mine_language_simplified_chinese), Locale.SIMPLIFIED_CHINESE));
        mLanguageList.add(new LanguageModel(getString(R.string.mine_language_english), Locale.US));
        mLanguageList.add(new LanguageModel(getString(R.string.mine_language_simplified_french), Locale.FRANCE));
        mLanguageList.add(new LanguageModel(getString(R.string.mine_language_simplified_German), Locale.GERMANY));
        mLanguageList.add(new LanguageModel(getString(R.string.mine_language_japanese), Locale.JAPAN));
        mLanguageList.add(new LanguageModel(getString(R.string.mine_language_korean), Locale.KOREA));
        mLanguageList.add(new LanguageModel(getString(R.string.mine_language_spain), new Locale("es", "ES")));
        mLanguageList.add(new LanguageModel(getString(R.string.mine_language_russian), new Locale("ru", "RU")));
        mAdapter.setData(mLanguageList);
    }


    @Override
    protected void initEvent() {
        if (null != mAdapter) {
            mAdapter.setOnItemClickListener(this);
        }

        if (null != mTopbar) {
            mTopbar.setOnBackClickListener(this);
        }
    }

    @Override
    protected void initHandler() {
    }

    @Override
    public void onItemClick(LanguageModel data, int position) {
        if (null == mLanguageList || mLanguageList.size() == 0) {
            ALog.e(TAG, "onItemClick() mLanguageList is null");
            return;
        }
        this.postion = position;
        if (TextUtils.isEmpty(prePosition + "")) {
            ALog.e(TAG, "onItemClick() prePosition is null");
            return;
        }
        if (prePosition != position) {
            showConfirmDialog();
        }
    }


    @Override
    public void onBackClick() {
        if (isFinishing()) {
            return;
        }

        this.finish();
    }

    private void switchLanguage() {
        if (TextUtils.isEmpty(postion + "")) {
            ALog.e(TAG, "onItemClick() prePosition is null");
            return;
        }
        String autoLang = "";
        if (postion != autoLanguagePosition) autoLang = "no";
        AConfigure.getInstance().updateSpConfig(MineConstants.AUTO_LANGUAGE, autoLang);

        Locale mCurrentLocale = mLanguageList.get(postion).getLocale();
        Resources resources = getApplication().getResources();
        LanguageUtils.switchLanguage(resources, LanguageUtils.MakeLanguageString(mCurrentLocale));
        Router.getInstance().registerModuleUrlHandler(MineConstants.MINE_URL_APP_HOME, new IUrlHandler() {
            @Override
            public void onUrlHandle(Context context, String s, Bundle bundle, boolean b, int i) {
                Intent intent = new Intent();
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                intent.setAction(MineConstants.MINE_URL_ACTION_NAVIGATION);
                intent.setData(Uri.parse(s));
                context.startActivity(intent);
            }
        });
//        Router.getInstance().toUrl(getApplicationContext(), MineConstants.MINE_URL_APP_HOME);
        refreshUi();
        //更新小组件
        AppWidgetHelper.refreshDeviceWidget(this,"GETDEVICELIST");
    }

    public void refreshUi() {
//        EventBus.getDefault().post(new RefreshUIBean());
//        //刷新当前界面
//        Intent intent = getIntent();
//        overridePendingTransition(0, 0);
//        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
//        finish();
//        overridePendingTransition(0, 0);
//        startActivity(intent);
    }

    private void chooseApplicationLanguage() {
        Configuration configuration = getApplication().getResources().getConfiguration();
        Locale locale = configuration.locale;

        if (null == locale) {
            ALog.e(TAG, "onResume, local is null");
            return;
        }

        String localLanguage = LanguageUtils.MakeLanguageString(locale);
        if (LanguageUtils.isAutoLanguage()) {
            localLanguage = "autoLanguage";
        }
        for (int i = 0; i < mLanguageList.size(); i++) {
            LanguageModel languageModel = mLanguageList.get(i);
            Locale localeTmp = languageModel.getLocale();
            String localTempLanguage = LanguageUtils.MakeLanguageString(localeTmp);
            if (LanguageUtils.isAutoLanguage()) {
                if (i == autoLanguagePosition) {
                    languageModel.setSelected(true);
                    prePosition = i;
                } else {
                    languageModel.setSelected(false);
                }
            } else {
                if (localLanguage.equals(localTempLanguage) && i != autoLanguagePosition) {
                    languageModel.setSelected(true);
                    prePosition = i;
                } else {
                    languageModel.setSelected(false);
                }
            }
        }

        if (null != mAdapter) {
            mAdapter.notifyDataSetChanged();
        }
    }

    private void showConfirmDialog() {
        if (null == mConfirmDialog) {
            mConfirmDialog = new MineDialog(this);
            mConfirmDialog.setCancelable(false);
            mConfirmDialog.setOnDialogButtonClickListener(this);
        }
        mConfirmDialog.setTitle(getString(R.string.mine_language_dialog_modify_confirm));
        mConfirmDialog.setNegativeButtonText(getString(R.string.mine_dialog_negative));
        mConfirmDialog.setPositiveButtonText(getString(R.string.mine_dialog_positive));
        mConfirmDialog.show();
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    @Override
    public void onNegativeClick(MineDialog dialog) {
        if (isDestroyed()) {
            return;
        }

        dialog.dismiss();

        chooseApplicationLanguage();
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    @Override
    public void onPositiveClick(MineDialog dialog) {
        if (isDestroyed()) {
            return;
        }
        dialog.dismiss();
        switchLanguage();
        //切换语言后，搜索接口更新请求
        globalProductList.clear();
    }

}
