package com.aliyun.iot.utils.view;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.SparseArray;
import android.view.View;

import com.aliyun.iot.ilop.page.mine.R;


/**
 * 悬浮标题
 */
public class FloatingBarItemDecoration extends RecyclerView.ItemDecoration {

    private Context mContext;
    private int mTitleHeight;
    private Paint mBackgroundPaint;
    private Paint mTextPaint;
    private int mTextHeight;
    private int mTextBaselineOffset;
    private int mTextStartMargin;
    /**
     * Integer means the related position of the Recyclerview#getViewAdapterPosition()
     * (the position of the view in original adapter's list)
     * String means the title to be drawn
     */
    private SparseArray<String> mList;

    public FloatingBarItemDecoration(Context context) {
        this.mContext = context;
        mList = new SparseArray<>();

        mBackgroundPaint = new Paint();
        mBackgroundPaint.setColor(ContextCompat.getColor(mContext, R.color.item_decoration_title_background));

        mTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mTextPaint.setColor(ContextCompat.getColor(mContext, R.color.item_decoration_title_fontcolor));
        mTextPaint.setTextSize(13);

        Paint.FontMetrics fm = mTextPaint.getFontMetrics();
        Resources resources = mContext.getResources();
        this.mTitleHeight = resources.getDimensionPixelSize(R.dimen.item_decoration_title_height);
        mTextHeight = (int) (fm.bottom - fm.top);
        mTextBaselineOffset = (int) fm.bottom;
        mTextStartMargin = resources.getDimensionPixelOffset(R.dimen.item_decoration_title_start_margin);

    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        super.getItemOffsets(outRect, view, parent, state);
        int position = ((RecyclerView.LayoutParams) view.getLayoutParams()).getViewAdapterPosition();

        outRect.set(0, mList.get(position) != null ? mTitleHeight : 0, 0, 0);
    }

    @Override
    public void onDraw(Canvas c, RecyclerView parent, RecyclerView.State state) {
        super.onDraw(c, parent, state);
        final int left = parent.getPaddingLeft();
        final int right = parent.getWidth() - parent.getPaddingRight();
        final int childCount = parent.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View child = parent.getChildAt(i);
            RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) child.getLayoutParams();
            int position = params.getViewAdapterPosition();
            if (mList.get(position) == null) {
                continue;
            }
            drawTitleArea(c, left, right, parent.getWidth(), child, params, position);
        }
    }

    private void drawTitleArea(Canvas c, int left, int right, int recycleViewWidth, View child,
                               RecyclerView.LayoutParams params, int position) {
        int rectBottom = child.getTop() - params.topMargin;
        //画头部背景色
        c.drawRect(left, rectBottom - mTitleHeight, right,
                rectBottom, mBackgroundPaint);
        //画标题
        c.drawText(mList.get(position), child.getPaddingLeft() + mTextStartMargin,
                rectBottom - (mTitleHeight - mTextHeight) / 2 - mTextBaselineOffset, mTextPaint);
    }

    @Override
    public void onDrawOver(Canvas c, RecyclerView parent, RecyclerView.State state) {
        super.onDrawOver(c, parent, state);
        final int position = ((LinearLayoutManager) parent.getLayoutManager()).findFirstVisibleItemPosition();
        if (position == RecyclerView.NO_POSITION) {
            return;
        }
        View child = parent.findViewHolderForAdapterPosition(position).itemView;
        String initial = getTag(position);
        if (initial == null) {
            return;
        }

        //flag指示当标题栏是否发生碰撞
        boolean flag = false;
        if (getTag(position + 1) != null && !initial.equals(getTag(position + 1))) {
            if (child.getHeight() + child.getTop() < mTitleHeight) {
                c.save();
                flag = true;
                c.translate(0, child.getHeight() + child.getTop() - mTitleHeight);
            }
        }
        int bottom = parent.getPaddingTop() + mTitleHeight;
        int recycleRight = parent.getRight();
        c.drawRect(parent.getPaddingLeft(), parent.getPaddingTop(),
                recycleRight - parent.getPaddingRight(), bottom, mBackgroundPaint);
        c.drawText(initial, child.getPaddingLeft() + mTextStartMargin,
                parent.getPaddingTop() + mTitleHeight - (mTitleHeight - mTextHeight) / 2 - mTextBaselineOffset, mTextPaint);
        if (flag) {
            c.restore();
        }
    }

    private String getTag(int position) {
        while (position >= 0) {
            if (mList.get(position) != null) {
                return mList.get(position);
            }
            position--;
        }
        return null;
    }

    public SparseArray<String> getTagDatas() {
        return mList;
    }

    public void setFloatingData(SparseArray<String> list) {
        this.mList = list;
    }

    public int getTitleHeight() {
        return mTitleHeight;
    }
}