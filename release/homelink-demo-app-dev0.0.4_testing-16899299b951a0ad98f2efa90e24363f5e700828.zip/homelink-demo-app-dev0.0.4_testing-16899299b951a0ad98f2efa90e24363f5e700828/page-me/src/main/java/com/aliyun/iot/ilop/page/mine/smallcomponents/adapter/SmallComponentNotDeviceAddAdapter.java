package com.aliyun.iot.ilop.page.mine.smallcomponents.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.PropertyBean;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.SmallComponentDeviceBean;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.List;

public class SmallComponentNotDeviceAddAdapter extends BaseExpandableListAdapter {

    private List<SmallComponentDeviceBean> smallComponentDeviceBeanList;
    private Context context;

    public SmallComponentNotDeviceAddAdapter(List<SmallComponentDeviceBean> smallComponentDeviceBeanList, Context context) {
        this.smallComponentDeviceBeanList = smallComponentDeviceBeanList;
        this.context = context;

    }

    @Override
    public int getGroupCount() {
        return smallComponentDeviceBeanList.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return smallComponentDeviceBeanList.get(groupPosition).getSwitchList().size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return smallComponentDeviceBeanList.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return smallComponentDeviceBeanList.get(groupPosition).getSwitchList().get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        GroupHolder groupHolder;
        if (convertView == null) {
            convertView = View.inflate(context, R.layout.ilop_mine_small_component_device_group_item, null);
            groupHolder = new GroupHolder();
            groupHolder.iv_device_img = convertView.findViewById(R.id.iv_device_img);
            groupHolder.tv_device_text = convertView.findViewById(R.id.tv_device_text);
            groupHolder.iv_device_arrow = convertView.findViewById(R.id.iv_device_arrow);
            convertView.setTag(groupHolder);
        } else {
            groupHolder = (GroupHolder) convertView.getTag();
        }
        SmallComponentDeviceBean smallComponentDeviceBean = smallComponentDeviceBeanList.get(groupPosition);
        if(smallComponentDeviceBean.getNickName()==null) {
            groupHolder.tv_device_text.setText(smallComponentDeviceBean.getProductName());
        }else{
            groupHolder.tv_device_text.setText(smallComponentDeviceBean.getNickName());
        }
        if (isExpanded) {
            groupHolder.iv_device_arrow.setBackgroundResource(R.drawable.ilop_mine_icon_up_arrow);
        } else {
            groupHolder.iv_device_arrow.setBackgroundResource(R.drawable.ilop_mine_icon_down_arrow);
        }
        RequestOptions options = new RequestOptions()
                .placeholder(R.drawable.ilop_mine_icon_default)
                .error(R.drawable.ilop_mine_icon_default);
        Glide.with(context)
                .load(smallComponentDeviceBean.getProductImage())
                .apply(options)
                .into(groupHolder.iv_device_img);
        return convertView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        ChildHolder childHolder;
        if (convertView == null) {
            convertView = View.inflate(context, R.layout.ilop_mine_small_component_device_child_item, null);
            childHolder = new ChildHolder();
            childHolder.tv_device_switch_name = convertView.findViewById(R.id.tv_device_switch_name);
            childHolder.iv_device_switch_check = convertView.findViewById(R.id.iv_device_switch_check);
            childHolder.dividing_line = convertView.findViewById(R.id.dividing_line);
            convertView.setTag(childHolder);
        } else {
            childHolder = (ChildHolder) convertView.getTag();
        }
        SmallComponentDeviceBean smallComponentDeviceBean = smallComponentDeviceBeanList.get(groupPosition);
        PropertyBean propertyBean = smallComponentDeviceBean.getSwitchList().get(childPosition);
        childHolder.tv_device_switch_name.setText(propertyBean.getPropertyName());
        if (propertyBean.isCheck()) {
            childHolder.iv_device_switch_check.setBackgroundResource(R.drawable.small_component_device_switch_check);
        } else {
            childHolder.iv_device_switch_check.setBackgroundResource(R.drawable.small_component_device_switch_not_check);
        }
        if (childPosition == smallComponentDeviceBean.getSwitchList().size() - 1) {
            childHolder.dividing_line.setVisibility(View.VISIBLE);
        } else {
            childHolder.dividing_line.setVisibility(View.GONE);
        }
        return convertView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    class GroupHolder {
        private ImageView iv_device_img;
        private TextView tv_device_text;
        private ImageView iv_device_arrow;
    }

    class ChildHolder {
        private TextView tv_device_switch_name;
        private ImageView iv_device_switch_check;
        private View dividing_line;

    }

}
