package com.aliyun.iot.ilop.page.mine.setting.handler;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import com.aliyun.iot.ilop.page.mine.MineConstants;
import com.aliyun.iot.ilop.page.mine.home.bean.MineMessageCounter;
import com.aliyun.iot.ilop.page.mine.setting.business.MineSettingHomeActivityBusiness;
import com.aliyun.iot.ilop.page.mine.setting.interfaces.IMineSettingHomeActivity;

/**
 * Created by david on 2018/4/8.
 *
 * @author david
 * @date 2018/04/08
 */
public class MineSettingHomeActivityHandler extends Handler {
    private IMineSettingHomeActivity mIActivity;
    private MineSettingHomeActivityBusiness mBusiness;


    public MineSettingHomeActivityHandler(IMineSettingHomeActivity iMineSettingHomeActivity) {
        super(Looper.getMainLooper());
        mIActivity = iMineSettingHomeActivity;

        mBusiness = new MineSettingHomeActivityBusiness(this);
    }

    public void refreshData() {
        if (null == mBusiness) {
            return;
        }

        mBusiness.requestNotify();
    }




    @Override
    public void handleMessage(Message msg) {
        super.handleMessage(msg);

        if (null == mIActivity) {
            return;
        }

        if (MineConstants.MINE_MESSAGE_NETWORK_ERROR == msg.what) {
            mIActivity.showNetWorkError();
        } else if (MineConstants.MINE_MESSAGE_RESPONSE_MESSAGE_COUNT_SUCCESS == msg.what) {
            MineMessageCounter counter = (MineMessageCounter) msg.obj;

            if (counter.firmwareCount > 0) {
                mIActivity.showOTANotify(true);
            } else {
                mIActivity.showOTANotify(false);
            }
        }
    }

    public void destroy() {
        removeMessages(MineConstants.MINE_MESSAGE_NETWORK_ERROR);
        removeMessages(MineConstants.MINE_MESSAGE_RESPONSE_MESSAGE_COUNT_SUCCESS);


        mBusiness = null;
        mIActivity = null;
    }

}
