package com.aliyun.iot.ilop.page.mine.home;

import android.graphics.Rect;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.aep.sdk.login.data.UserInfo;
import com.aliyun.iot.homelink.demo.commons.base.BaseFragment;
import com.aliyun.iot.homelink.demo.commons.util.DimensionUtil;
import com.aliyun.iot.homelink.demo.commons.view.divider.ColorItemDecoration;
import com.aliyun.iot.homelink.demo.commons.view.divider.InsetColorDecoration;
import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.entity.MineItem;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseQuickAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ZhuBingYang on 2019-04-18.
 */
public class MineFragment extends BaseFragment implements MineContract.MineView {
    private RecyclerView mRecyclerView;
    private MineAdapter mAdapter;
    private List<MineItem> mItemList = new ArrayList<>();

    private MineContract.MinePresenter mPresenter;

    private ImageView mAvatarIV;
    private TextView mNicknameTv;

    @Override
    protected int getLayoutId() {
        return R.layout.ilop_mine_fragment_mine;
    }

    @Override
    protected void doSomeDefaultSetting() {
        mPresenter = new MinePresenterImpl(getMActivity(), this);
    }

    @Override
    protected void initView(View view) {
        mRecyclerView = view.findViewById(R.id.f_mine_rv);

        generateListItem();
        mAdapter = new MineAdapter(mItemList);

        View userInfoView = LayoutInflater.from(getMActivity()).inflate(R.layout.ilop_mine_view_user_info, null);
        mAvatarIV = userInfoView.findViewById(R.id.user_info_avatar_iv);
        mNicknameTv = userInfoView.findViewById(R.id.user_info_nickname_tv);
        userInfoView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.getInstance().toUrl(getActivity(), "hld://account_setting");
            }
        });
        mAdapter.setHeaderView(userInfoView);

        mRecyclerView.addItemDecoration(new ColorItemDecoration(new InsetColorDecoration() {
            @Override
            public void setInset(int position, Rect rect) {
                if (position > 1)
                    rect.left += DimensionUtil.dip2px(getMActivity(), 24);
            }

            @Override
            public int getHeight(int position) {
                switch (position) {
                    case 0:
                        return 0;
                    case 1:
                        return DimensionUtil.dip2px(getMActivity(), 20);
                    default:
                        return DimensionUtil.dip2px(getMActivity(), 1f);
                }
            }

            @Override
            public int getColor(int position) {
                return getResources().getColor(R.color.mine_color_F6F6F6);
            }
        }));

        mAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                MineItem item = mItemList.get(position);
                if (item.getAction() != null) {
                    item.getAction().run();
                }
            }
        });

        mRecyclerView.setAdapter(mAdapter);


        mPresenter.requestUserInfo();
        mPresenter.requestUpdateInfo();
    }

    private void generateListItem() {
        //天猫精灵
        mItemList.add(new MineItem(getString(R.string.mine_tp_tmallgenine), "", false, new Runnable() {
            @Override
            public void run() {
                Router.getInstance().toUrl(getMActivity(), "hld://tmallgenie");
            }
        }));


//        //固件升级
//        mItemList.add(new MineItem(getString(R.string.firmware_update), "", false, new Runnable() {
//            @Override
//            public void run() {
//                Router.getInstance().toUrl(getMActivity(), "hld://firmware");
//            }
//        }));


//        关于
//        mItemList.add(new MineItem(getString(R.string.mine_about), "", false, new Runnable() {
//            @Override
//            public void run() {
//                Router.getInstance().toUrl(getMActivity(),"hld://mine_about");
// //               Router.getInstance().toUrl(getMActivity(),"link://plugin/a1230glxWMwGDsba");
//            }
//        }));

//        toast(DimensionUtil.dip2px(13)+"");
    }

    @Override
    public void updateUserInfo(UserInfo userInfo) {
        mNicknameTv.setText(userInfo.userNick);
        Glide.with(this)
                .load(userInfo.userAvatarUrl)
                .apply(new RequestOptions()
                        .error(R.drawable.ilop_mine_home_avatar_default)
                        .placeholder(R.drawable.ilop_mine_home_avatar_default))
                .into(mAvatarIV);
    }

    @Override
    public void showDot(String tag, boolean show) {
        for (int i = 0; i < mItemList.size(); i++) {
            MineItem item = mItemList.get(i);
            if (item.getText().equals(tag)) {
                item.setHasMessage(show);
                mAdapter.notifyItemChanged(i + mAdapter.getHeaderLayoutCount());
                break;
            }
        }
    }
}
