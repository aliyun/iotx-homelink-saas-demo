package com.aliyun.iot.ilop.page.mine.tripartite_platform.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.widget.Toast;

import com.aliyun.iot.ilop.page.mine.MineConstants;
import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.base.MineBaseActivity;
import com.aliyun.iot.ilop.page.mine.tripartite_platform.adapter.TmallGenieAdapter;
import com.aliyun.iot.ilop.page.mine.tripartite_platform.bean.BindTaoBaoAccountBean;
import com.aliyun.iot.ilop.page.mine.tripartite_platform.bean.GetThirdpartyBean;
import com.aliyun.iot.ilop.page.mine.tripartite_platform.bean.TripartitePlatformListBean;
import com.aliyun.iot.ilop.page.mine.tripartite_platform.bean.UnBindBean;
import com.aliyun.iot.ilop.page.mine.tripartite_platform.handler.TmallGenieHandler;
import com.aliyun.iot.ilop.page.mine.tripartite_platform.interfaces.ITmallGenieActivity;
import com.aliyun.iot.ilop.page.mine.view.SimpleTopbar;
import com.aliyun.iot.link.ui.component.simpleLoadview.SimpleLoadingDialog;

public class TmallGenieActivity extends MineBaseActivity implements ITmallGenieActivity {

    private SimpleTopbar topbar;
    private RecyclerView mRecyclerView;
    private TmallGenieHandler mHandler;
    private String channel;
    private TmallGenieAdapter mAdapter;
    public static final int REQUEST_CODE = 0X101;
    private String authCode;
    private SimpleLoadingDialog mLoadingDialog;
    private int headImgResId;
    private boolean isTMFlag = false;
    private String accountId = "";
    private boolean bindAccountFlag = false;
//    private LoginService loginService;

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.ilop_mine_tmall_genie_activity);
    }

    @Override
    protected void onResume() {
        super.onResume();


        if (null != mHandler) {
            mHandler.requestDeviceList(channel, 1, 50);
            if (isTMFlag) {
                mHandler.queryAccount(MineConstants.ACCOUNT_TYPE);
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (null != mLoadingDialog) {
            mLoadingDialog.cancel();
            mLoadingDialog = null;
        }

        if (null != mHandler) {
            mHandler.destroy();
        }
        super.onDestroy();
    }

    @Override
    protected void initView() {
        topbar = findViewById(R.id.mine_topbar);
        mRecyclerView = findViewById(R.id.mine_tmallgenine_rv);
        mLoadingDialog = new SimpleLoadingDialog(this);
        mLoadingDialog.setLoadingViewStyle(R.style.mineLoadingStyle);
    }

    @Override
    protected void initData() {
        String title = getIntent().getStringExtra(MineConstants.TITLE);
        topbar.setTitle(TextUtils.isEmpty(title) ? "" : title);
        channel = getIntent().getStringExtra(MineConstants.CHANNEL);
        if (channel == null){
            channel=MineConstants.TM;
        }
        config(channel);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(linearLayoutManager);
//        mAdapter = new TmallGenieAdapter(this, channel, !channel.equals(MineConstants.TM));
        mAdapter = new TmallGenieAdapter(this, channel, true);
        mRecyclerView.setAdapter(mAdapter);
//        loginService = MemberSDK.getService(LoginService.class);

    }

    @Override
    protected void initEvent() {
        if (null != topbar) {
            topbar.setOnBackClickListener(new SimpleTopbar.onBackClickListener() {
                @Override
                public void onBackClick() {
                    onBackPressed();
                }
            });
        }
    }

    @Override
    protected void initHandler() {
        mHandler = new TmallGenieHandler(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == H5Activity.RESULT_CODE) {
            authCode = data.getStringExtra("AuthCode");
            if (null != mHandler) {
                mHandler.bindAccount(authCode);
            }
        }
    }

    @Override
    public void setTitle() {

    }

    @Override
    public void showList(TripartitePlatformListBean bean) {
        bean.setImg(headImgResId);
        bean.setChannel(channel);
        mAdapter.setmList(bean.getData(), bean);
    }

    @Override
    public void showEmptyList() {

    }

    @Override
    public void showLoading() {

        if (null != mLoadingDialog && !mLoadingDialog.isShowing()) {
            mLoadingDialog.showLoading(getString(R.string.mine_tp_loading));
        }
    }

    @Override
    public void showLoaded() {
        if (null != mLoadingDialog && mLoadingDialog.isShowing()) {
            mLoadingDialog.dismiss();
        }
    }

    @Override
    public void showLoadError() {
        Toast.makeText(this, getString(R.string.mine_network_error), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void bindAccountSuccess(BindTaoBaoAccountBean data) {
        bindAccountFlag = true;
        mAdapter.isBindAccountFlag(bindAccountFlag);
        Toast.makeText(this, getString(R.string.thirdparty_binded_account_success), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void bindAccountFail() {
        bindAccountFlag = false;
        mAdapter.isBindAccountFlag(bindAccountFlag);
        Toast.makeText(this, getString(R.string.thirdparty_binded_account_failed), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void unBindAccountSuccess(UnBindBean data) {
        bindAccountFlag = false;
        mAdapter.isBindAccountFlag(bindAccountFlag);
        Toast.makeText(this, getString(R.string.thirdparty_unbinded_account_success), Toast.LENGTH_SHORT).show();
//        loginService.logout(new LogoutCallback() {
//            @Override
//            public void onSuccess() {
//
//            }
//
//            @Override
//            public void onFailure(int i, String s) {
//
//            }
//        });
    }

    @Override
    public void unBindAccountFail() {
        Toast.makeText(this, getString(R.string.thirdparty_binded_account_failed), Toast.LENGTH_SHORT).show();

    }

    @Override
    public void queryTAOBAOAccountSuccess(GetThirdpartyBean data) {
        bindAccountFlag = false;
        if (null != data && null != data.getLinkIndentityId()) {
            bindAccountFlag = true;
        }
        mAdapter.isBindAccountFlag(bindAccountFlag);
    }

    @Override
    public void queryTAOBAOAccountFail() {
        bindAccountFlag = false;
        mAdapter.isBindAccountFlag(bindAccountFlag);
    }

    public int config(String channel) {
        headImgResId = 0;
        isTMFlag = false;
        if (channel.equals(MineConstants.TM)) {
            headImgResId = R.drawable.tmallgenie;
            isTMFlag = true;
        } else if (channel.equals(MineConstants.AA)) {
            headImgResId = R.drawable.amazonalexa;
        } else if (channel.equals(MineConstants.GA)) {
            headImgResId = R.drawable.googleassistant;
        } else {
            headImgResId = R.drawable.ifttt;
        }
        return headImgResId;
    }

    public void unBindAccount() {
        mHandler.unBindAccount(accountId, MineConstants.ACCOUNT_TYPE);
    }
//    public void BindAccount() {
//        loginService.auth(new LoginCallback() {
//            @Override
//            public void onSuccess(Session session) {
//                ALog.d("TmallGenieActivity", session.toString());
//                if (null != mHandler) {
//                    mHandler.bindAccount(session.topAuthCode);
//                }
//            }
//
//            @Override
//            public void onFailure(int code, String message) {
//                ALog.d("TmallGenieActivity", "message="+message+"code="+code);
//            }
//        });
//
//    }
}
