package com.aliyun.iot.ilop.page.mine.base;


/**
 * Created by nht on 2018/6/14.
 */

public interface BaseFragmentView<Presenter extends BaseFragmentPresenter> extends BaseView<Presenter> {

    int getLayoutId();

    void initView();

    void bindEvent();

    android.view.View getContentView();
}
