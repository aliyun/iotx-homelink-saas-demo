package com.aliyun.iot.ilop.page.mine.setting.interfaces;

/**
 * Created by david on 2018/4/8.
 *
 * @author david
 * @date 2018/04/08
 */
public interface IMineSettingHomeActivity {
    void showOTANotify(boolean shouldNotify);

    void showNetWorkError();



}
