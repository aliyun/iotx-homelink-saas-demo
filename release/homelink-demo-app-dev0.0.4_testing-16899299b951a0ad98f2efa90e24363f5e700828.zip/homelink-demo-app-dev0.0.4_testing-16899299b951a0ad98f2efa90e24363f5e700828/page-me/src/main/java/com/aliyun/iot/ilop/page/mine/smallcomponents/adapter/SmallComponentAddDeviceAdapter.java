package com.aliyun.iot.ilop.page.mine.smallcomponents.adapter;

import android.content.Context;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.PropertyBean;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.SmallComponentDeviceBean;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;
import java.util.List;

public class SmallComponentAddDeviceAdapter extends RecyclerView.Adapter<SmallComponentAddDeviceAdapter.DeviceViewHoler> {

    private ArrayList deviceList;
    private Context context;

    public SmallComponentAddDeviceAdapter(ArrayList sceneList, Context context) {
        this.deviceList = sceneList;
        this.context = context;
    }


    @Override
    public DeviceViewHoler onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.ilop_mine_small_component_device_grid_item, parent, false);
        return new DeviceViewHoler(itemView);
    }

    @Override
    public void onBindViewHolder(DeviceViewHoler holder, final int position) {

        if (position >= deviceList.size()) {
            holder.tv_device_add_text.setVisibility(View.INVISIBLE);
            holder.iv_device_delete.setVisibility(View.INVISIBLE);
            holder.iv_more.setVisibility(View.INVISIBLE);
            holder.ll_device_add_img.setBackgroundResource(R.drawable.small_component_device_dotted_line);
        } else {
            holder.ll_device_add_img.setBackgroundResource(R.drawable.small_component_device);
            SmallComponentDeviceBean smallComponentDeviceBean = (SmallComponentDeviceBean) deviceList.get(position);
            List<PropertyBean> propertyBeanList = smallComponentDeviceBean.getSwitchList();
            if (propertyBeanList.size() > 1) {
                holder.iv_more.setVisibility(View.VISIBLE);
            } else {
                holder.iv_more.setVisibility(View.INVISIBLE);
            }
            holder.tv_device_add_text.setVisibility(View.VISIBLE);
            holder.iv_device_delete.setVisibility(View.VISIBLE);
            if (smallComponentDeviceBean.getNickName() == null) {
                holder.tv_device_add_text.setText(smallComponentDeviceBean.getProductName());
            } else {
                holder.tv_device_add_text.setText(smallComponentDeviceBean.getNickName());
            }
            RequestOptions options = new RequestOptions()
                    .placeholder(R.drawable.ilop_mine_icon_default)
                    .error(R.drawable.ilop_mine_icon_default);
            Glide.with(context)
                    .load(smallComponentDeviceBean.getProductImage())
                    .apply(options)
                    .into(holder.iv_device_add_img);
            holder.iv_device_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onDeteleDeviceListener != null) {
                        onDeteleDeviceListener.onDeleteDevice(position);
                    }
                }
            });
        }
        /*ConstraintLayout.LayoutParams lp = (ConstraintLayout.LayoutParams) holder.ll_device_add_img.getLayoutParams();
        ConstraintLayout.LayoutParams lp1 = (ConstraintLayout.LayoutParams) holder.iv_device_delete.getLayoutParams();
        if (position > 3) {
            lp.setMargins(0, DensityUtil.dip2px(context, 8), 0, 0);
            lp1.setMargins(0, 0, 0, 0);
        } else {
            lp.setMargins(0, DensityUtil.dip2px(context, 20), 0, 0);
            lp1.setMargins(0, DensityUtil.dip2px(context, 12), 0, 0);
        }
        holder.ll_device_add_img.setLayoutParams(lp);
        holder.iv_device_delete.setLayoutParams(lp1);*/
    }


    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return 8;
    }


    class DeviceViewHoler extends RecyclerView.ViewHolder {
        private ImageView iv_device_add_img;
        private ImageView iv_device_delete;
        private TextView tv_device_add_text;
        private ImageView iv_more;
        private LinearLayout ll_device_add_img;

        public DeviceViewHoler(View itemView) {
            super(itemView);
            iv_device_add_img = itemView.findViewById(R.id.iv_device_add_img);
            iv_device_delete = itemView.findViewById(R.id.iv_device_delete);
            tv_device_add_text = itemView.findViewById(R.id.tv_device_add_text);
            iv_more = itemView.findViewById(R.id.iv_more);
            ll_device_add_img = itemView.findViewById(R.id.ll_device_add_img);
        }
    }

    public interface OnDeteleDeviceListener {
        void onDeleteDevice(int position);
    }

    private OnDeteleDeviceListener onDeteleDeviceListener;

    public void setOnDeteleDeviceListener(OnDeteleDeviceListener onDeteleDeviceListener) {
        this.onDeteleDeviceListener = onDeteleDeviceListener;
    }


}
