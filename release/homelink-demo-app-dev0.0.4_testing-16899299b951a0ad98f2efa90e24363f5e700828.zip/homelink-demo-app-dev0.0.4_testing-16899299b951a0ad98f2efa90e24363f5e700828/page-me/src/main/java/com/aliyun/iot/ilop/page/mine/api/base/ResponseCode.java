package com.aliyun.iot.ilop.page.mine.api.base;

/**
 * Created by nht on 2018/6/15.
 */

public class ResponseCode {
    public static final int SUCCEED_CODE = 200;
}
