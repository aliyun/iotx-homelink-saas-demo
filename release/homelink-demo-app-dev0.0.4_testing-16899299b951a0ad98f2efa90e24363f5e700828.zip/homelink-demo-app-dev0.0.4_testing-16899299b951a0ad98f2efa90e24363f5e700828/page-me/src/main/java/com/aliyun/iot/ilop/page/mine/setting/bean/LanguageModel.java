package com.aliyun.iot.ilop.page.mine.setting.bean;

import java.io.Serializable;
import java.util.Locale;

/**
 * Created by david on 2018/4/11.
 *
 * @author david
 * @date 2018/04/11
 */
public class LanguageModel implements Serializable{
    private static final long serialVersionUID = 7490956987077532930L;

    private String language = "";
    private Locale locale;
    private boolean selected = false;

    public LanguageModel(String language, Locale locale) {
        this.language = language;
        this.locale = locale;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public Locale getLocale() {
        return locale;
    }

    public void setLocale(Locale locale) {
        this.locale = locale;
    }
}
