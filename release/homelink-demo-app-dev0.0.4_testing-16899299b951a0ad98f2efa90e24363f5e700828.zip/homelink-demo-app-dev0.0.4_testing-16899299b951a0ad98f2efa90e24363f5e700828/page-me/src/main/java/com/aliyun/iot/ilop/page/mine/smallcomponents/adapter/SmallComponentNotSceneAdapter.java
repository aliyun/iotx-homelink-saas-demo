package com.aliyun.iot.ilop.page.mine.smallcomponents.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.SmallComponentSceneBean;

import java.util.ArrayList;


public class SmallComponentNotSceneAdapter extends RecyclerView.Adapter<SmallComponentNotSceneAdapter.SmallSceneViewHolder> {
    private ArrayList sceneList = new ArrayList();
    private Context context;

    public SmallComponentNotSceneAdapter(ArrayList sceneList, Context context) {
        this.sceneList = sceneList;
        this.context = context;
    }


    @Override
    public SmallSceneViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(context).inflate(R.layout.ilop_mine_small_component_not_scene_item, parent, false);
        return new SmallSceneViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(SmallSceneViewHolder holder, final int position) {
        final SmallComponentSceneBean smallComponentSceneBean = (SmallComponentSceneBean) sceneList.get(position);
        holder.tv_scene_text.setText(smallComponentSceneBean.getSceneName());
        holder.ll_scene.setTag(position);
        holder.ll_scene.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onAddSceneListener != null) {
                    onAddSceneListener.addScene(position);
                }
            }
        });
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return sceneList.size();
    }


    class SmallSceneViewHolder extends RecyclerView.ViewHolder {
        private ImageView iv_scene_img;
        private TextView tv_scene_text;
        private LinearLayout ll_scene;

        public SmallSceneViewHolder(View itemView) {
            super(itemView);
            iv_scene_img = itemView.findViewById(R.id.iv_scene_img);
            tv_scene_text = itemView.findViewById(R.id.tv_scene_text);
            ll_scene = itemView.findViewById(R.id.ll_scene);
        }
    }


    //添加场景接口
    private onAddSceneListener onAddSceneListener;

    public interface onAddSceneListener {
        void addScene(int position);
    }

    public void setOnAddSceneListener(onAddSceneListener onAddSceneListener) {
        this.onAddSceneListener = onAddSceneListener;
    }

}
