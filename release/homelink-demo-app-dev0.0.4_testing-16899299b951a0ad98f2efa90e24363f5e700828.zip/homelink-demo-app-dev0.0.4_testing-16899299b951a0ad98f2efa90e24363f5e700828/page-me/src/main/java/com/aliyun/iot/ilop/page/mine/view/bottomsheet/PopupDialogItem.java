package com.aliyun.iot.ilop.page.mine.view.bottomsheet;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.aliyun.iot.ilop.page.mine.R;

import static android.support.annotation.Dimension.SP;

/**
 * @author sinyuk
 */
public class PopupDialogItem extends LinearLayout {


    private Context mContext;

    private TextView mContentView;

    private View mLineView;

    private String mContent;

    public PopupDialogItem(Context context) {
        super(context);
        mContext = context;
        initView();
    }

    public PopupDialogItem(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        initView();
    }

    private void initView() {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        assert inflater != null;
        View view = inflater.inflate(R.layout.item_bottom_popup_dialog, this);
        mContentView = view.findViewById(R.id.popup_dialog_item);
        mLineView = view.findViewById(R.id.popup_dialog_line);
    }

    public void refreshData(String text) {
        mContentView.setText(text);
        mContent = text;
    }

    public void setLineColor(int color) {
        mLineView.setBackgroundResource(color);
    }

    public void hideLine() {
        mLineView.setVisibility(GONE);
    }

    public String getItemContent() {
        return mContent;
    }

    public void setTextColor(int textColor) {
        mContentView.setTextColor(ContextCompat.getColor(mContext, textColor));
    }

    public void setTextSize(float size) {
        mContentView.setTextSize(SP, size);
    }

}