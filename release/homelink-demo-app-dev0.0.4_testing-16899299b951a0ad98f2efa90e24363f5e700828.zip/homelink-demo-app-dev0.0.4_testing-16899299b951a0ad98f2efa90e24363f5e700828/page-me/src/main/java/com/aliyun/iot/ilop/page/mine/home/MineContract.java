package com.aliyun.iot.ilop.page.mine.home;

import com.aliyun.iot.aep.sdk.login.data.UserInfo;
import com.aliyun.iot.homelink.demo.commons.base.BaseView;
import com.aliyun.iot.ilop.page.mine.base.BasePresenter;

/**
 * Created by ZhuBingYang on 2019-04-18.
 */
public class MineContract {
    public interface MineView extends BaseView {
        void updateUserInfo(UserInfo userInfo);

        void showDot(String tag, boolean show);
    }

    public interface MinePresenter extends BasePresenter {
        void requestUserInfo();

        void requestUpdateInfo();
    }
}
