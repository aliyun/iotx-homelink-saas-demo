package com.aliyun.iot.ilop.page.mine.about.activity;

import java.util.Locale;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import android.app.DownloadManager;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.aliyun.iot.aep.Util.CountryUtils;
import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.ilop.page.mine.MineConstants;
import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.about.AppUpgradeHelper;
import com.aliyun.iot.ilop.page.mine.base.MineBaseActivity;
import com.aliyun.iot.ilop.page.mine.utils.MineSPUtils;
import com.aliyun.iot.ilop.page.mine.view.MineDialog;
import com.aliyun.iot.ilop.page.mine.view.MineDialog.OnDialogButtonClickListener;
import com.aliyun.iot.ilop.page.mine.view.MineNotifyItem;
import com.aliyun.iot.ilop.page.mine.view.SimpleTopbar;
import com.aliyun.iot.ilop.page.mine.view.SimpleTopbar.onBackClickListener;

/**
 * Created by david on 2018/4/16.
 *
 * @author david
 * @date 2018/04/16
 */
public class MineSettingAboutPageActivity extends MineBaseActivity implements onBackClickListener, OnClickListener {
    private SimpleTopbar mTopbar;
    private ImageView mIconImageView;
    private TextView mVersionTextView;
    private MineNotifyItem mPrivacyPolicy;
    private MineNotifyItem mServiceProtocol;
    private MineNotifyItem mTripleProtocol;
    private MineNotifyItem mUpgradeCheck;
    private boolean hasNewVersion;
    private MineDialog upgradeDialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ilop_mine_setting_about_activity);
    }

    @Override
    protected void onDestroy() {
        if (null != upgradeDialog) {
            upgradeDialog.cancel();
            upgradeDialog = null;
        }

        super.onDestroy();
    }

    @Override
    protected void initView() {
        mTopbar = (SimpleTopbar) findViewById(R.id.mine_topbar);
        mIconImageView = (ImageView) findViewById(R.id.mine_setting_about_icon_imageview);
        mVersionTextView = (TextView) findViewById(R.id.mine_setting_about_version_textview);
        mPrivacyPolicy = (MineNotifyItem) findViewById(R.id.mine_setting_about_privacy_policy_minenotifyitem);
        mServiceProtocol = (MineNotifyItem) findViewById(R.id.mine_setting_about_service_protocol_minenotifyitem);
        mTripleProtocol = (MineNotifyItem) findViewById(R.id.mine_setting_about_triple_protocol_minenotifyitem);
        mUpgradeCheck = (MineNotifyItem) findViewById(R.id.mine_setting_about_upgrade_check_minenotifyitem);
    }

    @Override
    protected void initData() {
        mTopbar.setTitle(getString(R.string.mine_about));
        mPrivacyPolicy.setTitle(getString(R.string.mine_about_privacy_policy));
        mServiceProtocol.setTitle(getString(R.string.mine_about_service_protocol));
        mTripleProtocol.setTitle(getString(R.string.mine_about_triple_protocol));
        mUpgradeCheck.setTitle(getString(R.string.mine_about_upgrade_check));
        mUpgradeCheck.showUnderLine(false);

        PackageManager pm = getPackageManager();

        try {
            //版本显示
            PackageInfo packageInfo = pm.getPackageInfo(getPackageName(), 0);
            if (!TextUtils.isEmpty(packageInfo.versionName)) {
                String versionTips = getString(R.string.mine_about_version_tips) + packageInfo.versionName;
                mVersionTextView.setText(versionTips);
            }

            //升级红点提示
            int remoteVersionCode = Integer.valueOf(MineSPUtils.getString(MineSPUtils.KEY_VERSION_CODE, "-1"));
            int currentVersionCode = packageInfo.versionCode;

            if (currentVersionCode < remoteVersionCode) {
                mUpgradeCheck.showNotify(true);
                hasNewVersion = true;
            } else {
                hasNewVersion = false;
            }
        } catch (NameNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void initEvent() {
        if (null != mTopbar) {
            mTopbar.setOnBackClickListener(this);
        }

        if (null != mPrivacyPolicy) {
            mPrivacyPolicy.setOnClickListener(this);
        }

        if (null != mServiceProtocol) {
            mServiceProtocol.setOnClickListener(this);
        }

        if (null != mTripleProtocol) {
            mTripleProtocol.setOnClickListener(this);
        }

        if (null != mUpgradeCheck) {
            mUpgradeCheck.setOnClickListener(this);
        }
    }

    @Override
    protected void initHandler() {

    }

    @Override
    public void onBackClick() {
        if (isFinishing()) {
            return;
        }

        onBackPressed();
    }

    @Override
    public void onClick(View v) {
        if (R.id.mine_setting_about_privacy_policy_minenotifyitem == v.getId()) {
            Bundle bundle = new Bundle();
            bundle.putString("title", getString(R.string.mine_about_privacy_policy));
            //TODO gdpr
            if (CountryUtils.judgeIsChina(this.getApplicationContext())) {
                //国内地址
                bundle.putString("url", getString(R.string.mine_url_privacy_policy));
            } else {
                //海外地址
                bundle.putString("url", getString(R.string.mine_url_privacy_policy_oversea));
            }
            Router.getInstance().toUrl(this, MineConstants.MINE_URL_PROTOCOL, bundle);
        } else if (R.id.mine_setting_about_service_protocol_minenotifyitem == v.getId()) {
            Bundle bundle = new Bundle();
            bundle.putString("title", getString(R.string.mine_about_service_protocol));
            if (CountryUtils.judgeIsChina(this.getApplicationContext())) {
                //国内地址
                bundle.putString("url", getString(R.string.mine_url_service_protocol));
            } else {
                //海外地址
                bundle.putString("url", getString(R.string.mine_url_service_protocol));
            }

            Router.getInstance().toUrl(this, MineConstants.MINE_URL_PROTOCOL, bundle);
        } else if (R.id.mine_setting_about_triple_protocol_minenotifyitem == v.getId()) {
            Bundle bundle = new Bundle();
            bundle.putString("title", getString(R.string.mine_about_triple_protocol));
            if (CountryUtils.judgeIsChina(this.getApplicationContext())) {
                //国内地址
                bundle.putString("url", getString(R.string.mine_url_triple_protocol));
            } else {
                //海外地址
                bundle.putString("url", getString(R.string.mine_url_triple_protocol));
            }
            //TODO gdpr
            Router.getInstance().toUrl(this, MineConstants.MINE_URL_PROTOCOL, bundle);
        } else if (R.id.mine_setting_about_upgrade_check_minenotifyitem == v.getId()) {
            if (hasNewVersion) {
                preUpgrade();
            } else {
                Toast.makeText(this, getString(R.string.mine_about_is_latestversion), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void startWebView(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }

    private void preUpgrade() {
        if (null == upgradeDialog) {
            upgradeDialog = new MineDialog(this);
            upgradeDialog.setCancelable(false);
            upgradeDialog.setTitle(getString(R.string.mine_about_upgrade_tips));

            String content = MineSPUtils.getString(MineSPUtils.KEY_VERSION_DESC, "");

            try {
                JSONObject descObject = JSON.parseObject(content);

                Locale locale = getResources().getConfiguration().locale;
                String languageKey = locale.getLanguage() + "-" + locale.getCountry();

                if (descObject.containsKey(languageKey)) {
                    content = descObject.getString(languageKey);
                } else {
                    content = descObject.getString("zh-CN");
                }
            } catch (Exception e) {
                ALog.e(TAG, "获取更新desc错误", e);
                content = "";
            }

            if (!TextUtils.isEmpty(content)) {
                upgradeDialog.setContent(content);
            }

            upgradeDialog.setNegativeButtonText(getString(R.string.mine_dialog_negative));
            upgradeDialog.setPositiveButtonText(getString(R.string.mine_dialog_upgrade));
        }

        //先拿下载状态
        int latestVersionCode = Integer.valueOf(MineSPUtils.getString(MineSPUtils.KEY_VERSION_CODE, "-1"));
        int status = AppUpgradeHelper.getInstance().getDownloadStatus(latestVersionCode);
        if (status == DownloadManager.STATUS_RUNNING) {
            //正在下载
            Toast.makeText(this, getString(R.string.mine_about_download_upgrade), Toast.LENGTH_SHORT).show();
        } else if (status == DownloadManager.STATUS_SUCCESSFUL) {
            //已经下载成功逻辑
            upgradeDialog.setPositiveButtonText(getString(R.string.mine_dialog_install));
            upgradeDialog.setOnDialogButtonClickListener(new OnDialogButtonClickListener() {
                @Override
                public void onNegativeClick(MineDialog dialog) {
                    if (isFinishing()) {
                        return;
                    }

                    dialog.dismiss();
                }

                @Override
                public void onPositiveClick(MineDialog dialog) {
                    if (isFinishing()) {
                        return;
                    }

                    dialog.dismiss();

                    AppUpgradeHelper.getInstance().startInstall();
                }
            });

            upgradeDialog.show();
        } else {
            //调用系统下载逻辑
            upgradeDialog.setPositiveButtonText(getString(R.string.mine_dialog_upgrade));
            upgradeDialog.setOnDialogButtonClickListener(new OnDialogButtonClickListener() {
                @Override
                public void onNegativeClick(MineDialog dialog) {
                    if (isFinishing()) {
                        return;
                    }

                    dialog.dismiss();
                }

                @Override
                public void onPositiveClick(MineDialog dialog) {
                    if (isFinishing()) {
                        return;
                    }

                    upgradeDialog.show();
                    String url = MineSPUtils.getString(MineSPUtils.KEY_VERSION_APKURL, "");
                    AppUpgradeHelper.getInstance().downLoadApk(url);

                    dialog.dismiss();

                    Toast.makeText(dialog.getContext(), getString(R.string.mine_about_download_upgrade),
                            Toast.LENGTH_SHORT).show();
                }
            });

            upgradeDialog.show();
        }
    }
}
