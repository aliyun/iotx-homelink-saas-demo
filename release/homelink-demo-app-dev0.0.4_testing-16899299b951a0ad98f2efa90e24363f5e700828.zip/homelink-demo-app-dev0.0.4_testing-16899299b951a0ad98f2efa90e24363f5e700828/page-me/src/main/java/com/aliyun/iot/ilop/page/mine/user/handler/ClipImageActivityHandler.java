package com.aliyun.iot.ilop.page.mine.user.handler;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.aliyun.iot.ilop.page.mine.user.business.MineClipImageBusiness;
import com.aliyun.iot.ilop.page.mine.user.interfaces.IClipImageActivityImp;

public class ClipImageActivityHandler extends Handler {


    private IClipImageActivityImp iClipImageActivityImp;
    private MineClipImageBusiness mineClipImageBusiness;


    public ClipImageActivityHandler(IClipImageActivityImp iClipImageActivityImp) {
        super(Looper.getMainLooper());
        this.iClipImageActivityImp = iClipImageActivityImp;
        mineClipImageBusiness = new MineClipImageBusiness(this);
    }


    public void updateImage(Bitmap bitmap) {
        mineClipImageBusiness.updateImage(bitmap);
    }


    @Override
    public void handleMessage(Message msg) {
        super.handleMessage(msg);
        if (iClipImageActivityImp == null) {
            return;
        }
        if (msg.what == MineClipImageBusiness.RESULT_UPDATE_IMAGE_SUCCESS) {
            iClipImageActivityImp.onUpdateSuccess();
        } else if (msg.what == MineClipImageBusiness.RESULT_UPDATE_IMAGE_ERROE) {
            iClipImageActivityImp.onUpdateError(msg.obj.toString());
        }

    }


    public void onDestory() {
        iClipImageActivityImp = null;

        removeMessages(MineClipImageBusiness.RESULT_UPDATE_IMAGE_SUCCESS);
        removeMessages(MineClipImageBusiness.RESULT_UPDATE_IMAGE_ERROE);
    }
}
