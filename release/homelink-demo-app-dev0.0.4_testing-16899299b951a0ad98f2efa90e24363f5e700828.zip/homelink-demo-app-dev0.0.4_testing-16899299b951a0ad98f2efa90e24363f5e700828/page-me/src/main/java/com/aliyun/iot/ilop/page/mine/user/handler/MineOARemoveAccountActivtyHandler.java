package com.aliyun.iot.ilop.page.mine.user.handler;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import com.aliyun.iot.ilop.page.mine.user.business.MineOARemoveAccountBusiness;
import com.aliyun.iot.ilop.page.mine.user.interfaces.IMineOARemoveAccountActivityImp;

public class MineOARemoveAccountActivtyHandler extends Handler {


    private IMineOARemoveAccountActivityImp iMineOARemoveAccountActivityImp;
    private MineOARemoveAccountBusiness oaRemoveAccountBusiness;

    public MineOARemoveAccountActivtyHandler(IMineOARemoveAccountActivityImp iMineOARemoveAccountActivityImp) {
        super(Looper.getMainLooper());
        this.iMineOARemoveAccountActivityImp = iMineOARemoveAccountActivityImp;
        oaRemoveAccountBusiness = new MineOARemoveAccountBusiness(this);
    }


    public void unRegisterAccount() {
        oaRemoveAccountBusiness.unRegisterAccount();
    }


    @Override
    public void handleMessage(Message msg) {
        super.handleMessage(msg);
        if (iMineOARemoveAccountActivityImp == null) {
            return;
        }

        if (msg.what == MineOARemoveAccountBusiness.RESULT_SUCCESS) {
            iMineOARemoveAccountActivityImp.onRemoveSuccess();
        } else if (msg.what == MineOARemoveAccountBusiness.RESULT_FAILE) {
            iMineOARemoveAccountActivityImp.onFailed(msg.obj.toString());
        }
    }


    public void onDestory() {
        iMineOARemoveAccountActivityImp = null;
        removeMessages(MineOARemoveAccountBusiness.RESULT_SUCCESS);
        removeMessages(MineOARemoveAccountBusiness.RESULT_FAILE);

    }


}
