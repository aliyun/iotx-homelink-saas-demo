package com.aliyun.iot.ilop.page.mine;

/**
 * Created by david on 2018/4/13.
 *
 * @author david
 * @date 2018/04/13
 */
public class MineAPIClientConstants {
    /* APIClient */
    public static final String APICLIENT_IOTAUTH = "iotAuth";
    public static final String APICLIENT_VERSION = "1.0.1";
    public static final String APICLIENT_PATH_QUERYSYSTEMREMINDINGSTATE = "/uc/system/reminding/get";
    public static final String APICLIENT_PATH_FEEDBACKREDPOINT = "/feedback/redpoint/get";

    /*小组件 /uc/listBindingByAccount /iotx/ilop/queryBindingProduct*/
    public static final String SMALL_COMMPONENT_PATH_GETDEVICELIST = "/iotx/ilop/queryBindingProduct";
    //查询设备属性
    public static final String SMALL_COMMPONENT_PATH_GETDEVICEPROPRETYLIST = "/iotx/ilop/queryComponentProperty";
    //查询已添加小组件设备列表
    public static final String SMALL_COMMPONENT_PATH_QUERYCOMPONENTPRODUCT = "/iotx/ilop/queryComponentProduct";
    //更新小组件设备
    public static final String SMALL_COMMPONENT_PATH_UPDATECOMPONENTPROPERTY="/iotx/ilop/updateComponentProduct";
}
