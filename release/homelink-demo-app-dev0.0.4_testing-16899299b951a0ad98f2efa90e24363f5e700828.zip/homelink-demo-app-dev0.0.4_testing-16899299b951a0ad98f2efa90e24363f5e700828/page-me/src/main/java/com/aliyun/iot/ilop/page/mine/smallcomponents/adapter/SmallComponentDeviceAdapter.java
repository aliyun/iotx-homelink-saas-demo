package com.aliyun.iot.ilop.page.mine.smallcomponents.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.SmallComponentDeviceBean;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class SmallComponentDeviceAdapter extends BaseAdapter {

    private ArrayList list = new ArrayList();
    private Context context;

    public SmallComponentDeviceAdapter(ArrayList list, Context context) {
        this.list = list;
        this.context = context;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder;
        if (convertView == null) {
            convertView = View.inflate(context, R.layout.ilop_mine_small_component_device_item, null);
            holder = new ViewHolder();
            holder.iv_device_small_component = convertView.findViewById(R.id.iv_device_small_component);
            holder.tv_device_small_component = convertView.findViewById(R.id.tv_device_small_component);
            holder.iv_more = convertView.findViewById(R.id.iv_more);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        SmallComponentDeviceBean smallComponentDeviceBean = (SmallComponentDeviceBean) list.get(position);
        if (smallComponentDeviceBean.getNickName() == null) {
            holder.tv_device_small_component.setText(smallComponentDeviceBean.getProductName());
        } else {
            holder.tv_device_small_component.setText(smallComponentDeviceBean.getNickName());
        }
        if (smallComponentDeviceBean.getSwitchList().size() > 1) {
            holder.iv_more.setVisibility(View.VISIBLE);
        } else {
            holder.iv_more.setVisibility(View.INVISIBLE);
        }
        RequestOptions options = new RequestOptions()
                .placeholder(R.drawable.ilop_mine_icon_default)
                .error(R.drawable.ilop_mine_icon_default);
        Glide.with(context)
                .load(smallComponentDeviceBean.getProductImage())
                .apply(options)
                .into(holder.iv_device_small_component);

        return convertView;
    }


    class ViewHolder {
        private ImageView iv_device_small_component;
        private TextView tv_device_small_component;
        private ImageView iv_more;
    }

}
