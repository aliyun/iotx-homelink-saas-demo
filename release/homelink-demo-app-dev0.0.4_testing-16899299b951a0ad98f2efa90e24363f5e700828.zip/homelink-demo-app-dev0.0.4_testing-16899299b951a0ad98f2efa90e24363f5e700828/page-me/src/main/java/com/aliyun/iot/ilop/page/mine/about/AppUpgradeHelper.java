package com.aliyun.iot.ilop.page.mine.about;

import java.io.File;

import android.app.DownloadManager;
import android.app.DownloadManager.Request;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION_CODES;
import android.os.Environment;
import android.provider.MediaStore.Files.FileColumns;
import android.text.TextUtils;

import com.aliyun.iot.aep.sdk.framework.AApplication;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;
import com.aliyun.iot.ilop.page.mine.R;

/**
 * Created by david on 2018/4/19.
 *
 * @author david
 * @date 2018/04/19
 */
public class AppUpgradeHelper {
    private static final String TAG = "AppUpgradeHelper";
    private static final String SP_FILE_NAME = "AppUpgradeInfo";
    private static final String SP_KEY_DOWNLOAD_ID = "SP_KEY_DOWNLOAD_ID";
    private static final String LATEST_APK_NAME = "upgradePackage.apk";
    private static volatile AppUpgradeHelper mInstance;
    private DownloadManager mDownloadManager;

    private AppUpgradeHelper() {
        mDownloadManager = (DownloadManager) AApplication.getInstance().getSystemService(Context.DOWNLOAD_SERVICE);
    }

    public static AppUpgradeHelper getInstance() {
        if (null == mInstance) {
            synchronized (AppUpgradeHelper.class) {
                if (null == mInstance) {
                    mInstance = new AppUpgradeHelper();
                }
            }
        }

        return mInstance;
    }

    public void downLoadApk(String url) {
        if (TextUtils.isEmpty(url)) {
            ALog.e(TAG, "url is null!");
            return;
        }
        final Context context = AApplication.getInstance().getApplicationContext();

        final DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));

        updateNotification(context, request);

        //设置文件存放目录
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            request.setDestinationInExternalFilesDir(context,
                    Environment.DIRECTORY_DOWNLOADS,
                    LATEST_APK_NAME);
        }

        if (null == mDownloadManager) {
            return;
        }

        final long downloadId = mDownloadManager.enqueue(request);
        saveDownloadId(downloadId);

        if (Build.VERSION.SDK_INT < VERSION_CODES.N) {
            ThreadPool.DefaultThreadPool.getInstance().submit(
                    new Runnable() {
                        @Override
                        public void run() {
                            try {
                                boolean isGoging = true;
                                DownloadManager.Query query = new DownloadManager.Query();
                                query.setFilterById(downloadId);
                                while (isGoging) {
                                    Cursor cursor = mDownloadManager.query(query);
                                    if (cursor != null && cursor.moveToFirst()) {
                                        int status = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS));
                                        switch (status) {
                                            //如果下载状态为成功
                                            case DownloadManager.STATUS_SUCCESSFUL:
                                                isGoging = false;
                                                //调用LocalBroadcastManager.sendBroadcast将intent传递回去
                                                startInstall();
                                                break;
                                        }
                                    }

                                    if (cursor != null) {
                                        cursor.close();
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        }
                    });
        }

    }

    public void startInstall() {
        Context context = AApplication.getInstance();
        long downloadId = loadDownloadId();

        if (downloadId == -1) {
            ALog.e(TAG, "startInstall() downloadId is -1");
            return;
        }

        if (null == mDownloadManager) {
            return;
        }

        Uri uri = mDownloadManager.getUriForDownloadedFile(downloadId);
        if (uri == null) {
            ALog.e(TAG, "startInstall() file uri is null");
            return;
        }

        Intent install = new Intent(Intent.ACTION_VIEW);
        if (Build.VERSION.SDK_INT >= VERSION_CODES.N) {
            install.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            install.setDataAndType(uri, "application/vnd.android.package-archive");
        } else {
            String path = getFilePathByUri(uri);
            File file = new File(path);
            install.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
        }
        install.addCategory("android.intent.category.DEFAULT");
        install.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(install);
    }

    /**
     * return @see {@link DownloadManager#COLUMN_STATUS} Current status of the download
     */
    public int getDownloadStatus(int latestVersionCode) {
        if (null == mDownloadManager) {
            return -1;
        }

        long downloadId = loadDownloadId();

        DownloadManager.Query query = new DownloadManager.Query().setFilterById(downloadId);
        Cursor c = mDownloadManager.query(query);
        if (c != null) {
            try {
                if (c.moveToFirst()) {
                    int status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));

                    if (status == DownloadManager.STATUS_SUCCESSFUL
                            || status == DownloadManager.STATUS_FAILED) {

                        Uri uri = mDownloadManager.getUriForDownloadedFile(downloadId);
                        String path = getFilePathByUri(uri);
                        if (TextUtils.isEmpty(path)) {
                            return -1;
                        }

                        File file = new File(path);
                        if (!file.exists()) {
                            //可能实际文件因为未知原因删除掉，需要自己check文件是否存在
                            try {
                                ALog.d(TAG, "download file not exist, remove task id");
                                mDownloadManager.remove(downloadId);
                            } catch (Exception e) {
                                ALog.e(TAG, e.getMessage(), e);
                            }
                            return -1;
                        } else {
                            //文件存在，校验文件版本
                            PackageManager pm = AApplication.getInstance().getPackageManager();
                            PackageInfo packageArchiveInfo = pm.getPackageArchiveInfo(file.getAbsolutePath(),
                                    PackageManager.GET_CONFIGURATIONS);
                            ALog.d(TAG, "downloaded package versionCode:" + packageArchiveInfo.versionCode
                                    + " versionName:" + packageArchiveInfo.versionName);
                            if (packageArchiveInfo.versionCode == latestVersionCode
                                    && packageArchiveInfo.packageName.equals(AApplication.getInstance().getPackageName())) {
                                return status;
                            } else {
                                try {
                                    ALog.d(TAG, "download file not match the versionCode, remove task id");
                                    mDownloadManager.remove(downloadId);
                                } catch (Exception e) {
                                    ALog.e(TAG, e.getMessage(), e);
                                }

                                return -1;
                            }
                        }
                    }
                    return status;
                }
            } finally {
                c.close();
            }
        }
        return -1;
    }

    private void updateNotification(Context context, Request request) {
        if (null == request) {
            return;
        }

        int labelRes = context.getApplicationInfo().labelRes;
        String appName = context.getResources().getString(labelRes);
        String desc = context.getString(R.string.mine_about_upgrading);

        //设置通知栏标题
        request.setNotificationVisibility(Request.VISIBILITY_VISIBLE);
        request.setTitle(appName);
        request.setDescription(desc);
    }

    private String getFilePathByUri(Uri uri) {
        if (null != uri) {
            Cursor cursor = AApplication.getInstance().getContentResolver().query(uri, new String[]{FileColumns.DATA},
                    null,
                    null, null);
            if (null != cursor) {
                try {
                    if (cursor.moveToFirst()) {
                        int index = cursor.getColumnIndexOrThrow(FileColumns.DATA);
                        String path = cursor.getString(index);
                        return path;
                    }
                } finally {
                    cursor.close();
                }
            }
        }
        return "";
    }

    private void saveDownloadId(long downloadId) {
        SharedPreferences sp = AApplication.getInstance().getSharedPreferences(SP_FILE_NAME, Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        try {
            editor.putLong(SP_KEY_DOWNLOAD_ID, downloadId);
            editor.commit();
        } catch (Exception e) {
            ALog.e(TAG, "saveDownloadId() error", e);
        }
    }

    public long loadDownloadId() {
        SharedPreferences sp = AApplication.getInstance().getSharedPreferences(SP_FILE_NAME, Context.MODE_PRIVATE);
        return sp.getLong(SP_KEY_DOWNLOAD_ID, -1);
    }
}
