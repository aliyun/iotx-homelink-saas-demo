package com.aliyun.iot.ilop.page.mine.smallcomponents.interfaces;

import android.support.annotation.Nullable;

import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.SmallComponentDeviceBean;

import java.util.ArrayList;

public interface ISmallComponentDevicePage {

    void showDeviceList(ArrayList<SmallComponentDeviceBean> list);

    void showAddDeviceList(ArrayList<SmallComponentDeviceBean> list);

    void showError(@Nullable String msg);

    void updateSuccess();

    void showLoading(int num);

    void hideLoading();

    void setNoMore();
}
