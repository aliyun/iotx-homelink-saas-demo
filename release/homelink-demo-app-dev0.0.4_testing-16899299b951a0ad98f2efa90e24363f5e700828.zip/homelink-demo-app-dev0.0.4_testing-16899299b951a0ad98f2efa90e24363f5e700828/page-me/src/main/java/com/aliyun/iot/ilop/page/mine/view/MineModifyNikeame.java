package com.aliyun.iot.ilop.page.mine.view;

import android.content.Context;
import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.ilop.page.mine.R;

import java.io.UnsupportedEncodingException;


public class MineModifyNikeame extends ConstraintLayout{
    //    昵称的最大长度
    public static final int MAX_LENGTH_NICKNAME = 24;

    private EditText input;
    private Button clear;
    public MineModifyNikeame(Context context){
        this(context,null);
    }
    public MineModifyNikeame(@NonNull Context context, @Nullable AttributeSet attributeSet) {
        super(context, attributeSet);
        View view = inflate(context, R.layout.ilop_mine_modify_nikename,this);
        input = view.findViewById(R.id.mine_modify_nk_input);
        clear = view.findViewById(R.id.mine_modify_nk_clear);
        Typeface typeface = Typeface.createFromAsset(context.getAssets(), "ali_sdk_openaccount/iconfont.ttf");
        clear.setTypeface(typeface);
        initEvent();
    }
    public MineModifyNikeame(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr){
        this(context,attrs);
    }

    private void initEvent(){
        clear.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                input.setText("");
            }
        });
        input.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ALog.i("MineModifyNikeName",s+"  "+start+"  "+before+"  "+count);
                if (!TextUtils.isEmpty(s) && getCharLength(s.toString())>MAX_LENGTH_NICKNAME){
                    String currentValue = s.toString().trim();
                    String sub="";
                    for (int i = MAX_LENGTH_NICKNAME/2; i < currentValue.length(); i++) {
                        String cutout= currentValue.substring(0,i);
                        if (getCharLength(cutout)>MAX_LENGTH_NICKNAME){
                            break;
                        }
                        sub = cutout;
                    }
                    input.setText(sub);
                    input.setSelection(sub.length());
                }
            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }
    public EditText getInput() {
        return input;
    }

    public Button getClear() {
        return clear;
    }

    /**
     * verify string length include chinese and english
     * 中文占俩个字符，英文占一个字符
     */
    private int getCharLength(String nk){
        try {
            if (TextUtils.isEmpty(nk))
                return 0;
            System.out.println(nk.length());
            String translate=new String(nk.getBytes("gb2312"),"iso-8859-1");
            if (!TextUtils.isEmpty(translate))
                return translate.length();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return 0;
    }
}
