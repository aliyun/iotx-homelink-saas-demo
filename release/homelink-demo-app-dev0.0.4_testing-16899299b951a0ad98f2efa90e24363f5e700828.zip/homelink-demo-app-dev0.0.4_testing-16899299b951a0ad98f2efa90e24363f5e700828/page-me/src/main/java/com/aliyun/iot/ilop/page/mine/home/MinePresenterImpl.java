package com.aliyun.iot.ilop.page.mine.home;

import android.content.Context;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.aep.sdk.login.LoginBusiness;
import com.aliyun.iot.aep.sdk.login.data.UserInfo;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;
import com.aliyun.iot.homelink.demo.commons.util.AppInfoUtil;
import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.api.Api;
import com.aliyun.iot.ilop.page.mine.home.bean.UpgradeVersionInfo;
import com.aliyun.iot.ilop.page.mine.utils.MineSPUtils;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

/**
 * Created by ZhuBingYang on 2019-04-18.
 */
public class MinePresenterImpl implements MineContract.MinePresenter {
    private static final String TAG = "MinePresenterImpl";
    private Context mContext;
    private MineContract.MineView mView;

    public MinePresenterImpl(Context mContext, MineContract.MineView mView) {
        this.mContext = mContext;
        this.mView = mView;
    }

    @Override
    public void requestUserInfo() {
        UserInfo userInfo = LoginBusiness.getUserInfo();

        if (null != userInfo) {
            mView.updateUserInfo(userInfo);
        } else {
            ALog.e(TAG, "用户信息获取失败");
            mView.toast("用户信息获取失败");
        }
    }

    @Override
    public void requestUpdateInfo() {
        Api.getInstance().requestUpgradeInfo(new Callback() {
            @Override
            public void onFailure(Call call, final IOException e) {
                ALog.e(TAG, "升级检查请求失败！", e);
//                Message.obtain(mHandler, MineConstants.MINE_MESSAGE_RESPONSE_CHECK_UPGRADE_FAILED).sendToTarget();
                ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                    @Override
                    public void run() {
                        mView.toast(e.getLocalizedMessage());
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) {

                try {
                    JSONObject jsonObject = JSON.parseObject(response.body().string());

                    ALog.e(TAG, "upgrade info:" + jsonObject.toJSONString());

                    final UpgradeVersionInfo upgradeVersionInfo = JSON.parseObject(jsonObject.toJSONString(),
                            UpgradeVersionInfo.class);
                    JSONObject descMap = new JSONObject(upgradeVersionInfo.desc);

                    int preVersionCode = Integer.valueOf(MineSPUtils.getString(MineSPUtils.KEY_VERSION_CODE, "-1"));

                    if (preVersionCode < upgradeVersionInfo.versionCode) {
                        MineSPUtils.putString(MineSPUtils.KEY_VERSION_NOTIFY, "true");
                    }

                    MineSPUtils.putString(MineSPUtils.KEY_VERSION_CODE, String.valueOf(upgradeVersionInfo.versionCode));
                    MineSPUtils.putString(MineSPUtils.KEY_VERSION_NAME, upgradeVersionInfo.versionName);
                    MineSPUtils.putString(MineSPUtils.KEY_VERSION_DESC, descMap.toJSONString());
                    MineSPUtils.putString(MineSPUtils.KEY_VERSION_APKURL, upgradeVersionInfo.apkUrl);

//                    Message.obtain(mHandler, MineConstants.MINE_MESSAGE_RESPONSE_CHECK_UPGRADE_SUCCESS,
//                            upgradeVersionInfo)
//                            .sendToTarget();

                    if (upgradeVersionInfo.versionCode > AppInfoUtil.getAppVersionCode(mContext)) {
                        ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                            @Override
                            public void run() {
                                mView.showDot(mContext.getString(R.string.mine_about), true);
                            }
                        });
                    }
                } catch (Exception e) {
                    ALog.e(TAG, "升级检查请求失败！", e);
//                    Message.obtain(mHandler, MineConstants.MINE_MESSAGE_RESPONSE_CHECK_UPGRADE_FAILED).sendToTarget();
                    ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                        @Override
                        public void run() {
                            mView.toast("升级检查请求失败！");
                        }
                    });
                }
            }
        });
    }
}
