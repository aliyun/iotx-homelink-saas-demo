package com.aliyun.iot.ilop.page.mine.base.activity;

import android.app.Dialog;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;

import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.link.ui.component.simpleLoadview.SimpleLoadingDialog;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;

/**
 * Created by nht on 2018/6/14.
 */

public abstract class BaseActivity extends FragmentActivity implements BaseActivityPresenter, IDialogControl {
    BaseActivityView mBaseView;
    protected Context activity;
    public static final int PAGE_SIZE = 20;
    protected Handler mHandler;
    private SimpleLoadingDialog waitDialog;
    private RequestManager mImgLoader;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = this;
        mHandler = new Handler(Looper.getMainLooper());
        Uri data = getIntent().getData();
        initData(data);
        Bundle extras = getIntent().getExtras();
        initData(extras);
        mBaseView = setView();
        setContentView(mBaseView.getLayoutId());
        setRefreshLayoutColor();
        mBaseView.setPresenter(this);
        mBaseView.initView(BaseActivity.this);

        mBaseView.bindEvent();
        loadData();

    }

    private void setRefreshLayoutColor() {
//        SwipeRefreshLayout refreshLayout = (SwipeRefreshLayout) findViewById(R.id.recycleview);
//        if (refreshLayout != null) {
//            refreshLayout.setColorSchemeColors(getResources().getColor(R.color.myColorPrimary));
//        }
    }

    @Override
    public void initData(Uri uri) {

    }

    @Override
    public void initData(Bundle bundle) {

    }

    @Override
    public void loadData() {

    }

    @Override
    public Dialog showWaitDialog(int resid) {
        return showWaitDialog(getString(resid));
    }

    @Override
    public Dialog showWaitDialog() {
        return showWaitDialog(getString(R.string.common_loading));
    }

    @Override
    public Dialog showWaitDialog(String msg) {
        if (waitDialog == null) {
            waitDialog = new SimpleLoadingDialog(activity);
        }
        waitDialog.showLoading(msg);
        return waitDialog;
    }

    @Override
    public void hideWaitDialog() {
        if (waitDialog != null && waitDialog.isShowing()) {
            try {
                waitDialog.dismiss();
                waitDialog = null;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 获取一个图片加载管理器
     *
     * @return RequestManager
     */
    public synchronized RequestManager getImgLoader() {
        if (mImgLoader == null)
            mImgLoader = Glide.with(this);
        return mImgLoader;
    }
}
