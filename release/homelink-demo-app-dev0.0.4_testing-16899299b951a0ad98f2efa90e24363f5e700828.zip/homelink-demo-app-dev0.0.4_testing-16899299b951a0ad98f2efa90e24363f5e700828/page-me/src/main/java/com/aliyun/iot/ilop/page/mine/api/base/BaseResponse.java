package com.aliyun.iot.ilop.page.mine.api.base;

import android.support.annotation.Nullable;

/**
 * @author sinyuk
 * @date 2018/6/14
 */
public class BaseResponse<T> {
    @Nullable
    public T data;
    public int code;
    public String message;
}
