package com.aliyun.iot.ilop.page.mine.smallcomponents.appwidgetprovider;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.RemoteViews;

import com.aliyun.iot.aep.sdk.login.LoginBusiness;
import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.smallcomponents.activity.SmallComponentSceneActivity;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.SmallComponentSceneBean;
import com.aliyun.iot.ilop.page.mine.smallcomponents.service.SmallComponentSceneService;
import com.aliyun.iot.utils.LoginUtils;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Implementation of App Widget functionality.
 */
public class SmallComponentSceneAppWidget extends AppWidgetProvider {

    private static ArrayList<SmallComponentSceneBean> smallComponentSceneBeans = new ArrayList<>();
    private static final String START_LOGIN = "SCENE_START_LOGIN";
    private static final String REFERSH_CHECK = "SCENE_REFERSH_CHECK";
    private Context context;
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    int scene_position = msg.arg2;
                    SmallComponentSceneBean smallComponentSceneBean = smallComponentSceneBeans.get(scene_position);
                    if (smallComponentSceneBean.getState() == 1) {
                        smallComponentSceneBean.setState(3);
                    } else if (smallComponentSceneBean.getState() == 2 || smallComponentSceneBean.getState() == 3) {
                        smallComponentSceneBean.setState(0);
                    }
                    int appWidgetId = msg.arg1;
                    Intent intent = new Intent(REFERSH_CHECK);
                    intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
                    intent.putExtra("CHECK_POSITION", scene_position);
                    intent.putExtra("SCENE_STATE", smallComponentSceneBean.getState());
                    context.sendBroadcast(intent);
                    break;
            }
        }
    };

    static void updateAppWidget(Context context, AppWidgetManager appWidgetManager,
                                int appWidgetId) {
        //1.请求获取小组件中的场景列表
        smallComponentSceneBeans.clear();
        smallComponentSceneBeans.add(new SmallComponentSceneBean("", "场景1", false));
        smallComponentSceneBeans.add(new SmallComponentSceneBean("", "场景2", false));
        smallComponentSceneBeans.add(new SmallComponentSceneBean("", "场景3", false));
        smallComponentSceneBeans.add(new SmallComponentSceneBean("", "场景4", false));
        smallComponentSceneBeans.add(new SmallComponentSceneBean("", "场景5", false));
        smallComponentSceneBeans.add(new SmallComponentSceneBean("", "场景6", false));
        smallComponentSceneBeans.add(new SmallComponentSceneBean("", "场景7", false));
        smallComponentSceneBeans.add(new SmallComponentSceneBean("", "场景8", false));
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.small_component_scene_app_widget);
        if (smallComponentSceneBeans.size() > 0) {
            //显示场景列表
            views.setViewVisibility(R.id.ll_no_scene, View.GONE);
            views.setViewVisibility(R.id.ll_scene, View.VISIBLE);
            Intent intent = new Intent(context, SmallComponentSceneService.class);
            views.setRemoteAdapter(R.id.grid_scene_app_widget, intent);

            Intent ref_intent = new Intent(REFERSH_CHECK);
            ref_intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 203, ref_intent, PendingIntent.FLAG_UPDATE_CURRENT);
            views.setPendingIntentTemplate(R.id.grid_scene_app_widget, pendingIntent);

        } else {
            //显示场景信息
            // Construct the RemoteViews object
            Intent intent = new Intent(START_LOGIN);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 200, intent, PendingIntent.FLAG_UPDATE_CURRENT);
            views.setOnClickPendingIntent(R.id.tv_setting, pendingIntent);
            views.setViewVisibility(R.id.ll_no_scene, View.VISIBLE);
            views.setViewVisibility(R.id.ll_scene, View.GONE);
        }

        // Instruct the widget manager to update the widget
        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        // There may be multiple widgets active, so update all of them
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    @Override
    public void onEnabled(Context context) {
        // Enter relevant functionality for when the first widget is created
    }

    @Override
    public void onDisabled(Context context) {
        // Enter relevant functionality for when the last widget is disabled
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        this.context = context;
        super.onReceive(context, intent);
        switch (intent.getAction()) {
            case START_LOGIN:
                if (LoginBusiness.isLogin()) {
                    //登录之后，跳转到小组件场景界面
                    Intent intent1 = new Intent(context, SmallComponentSceneActivity.class);
                    context.startActivity(intent1);
                } else {
                    //跳转到登录界面
                    LoginUtils.StartLogin(null, null, context.getApplicationContext());
                }
                break;
            case REFERSH_CHECK:
                final int appWidgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1);
                final int scene_position = intent.getIntExtra("CHECK_POSITION", -1);
                int scene_state = intent.getIntExtra("SCENE_STATE", -1);
                SmallComponentSceneBean smallComponentSceneBean = smallComponentSceneBeans.get(scene_position);
                smallComponentSceneBean.setState(scene_state);
                if (scene_state != 0) {
                    Timer timer = new Timer();
                    TimerTask timerTask = new TimerTask() {
                        @Override
                        public void run() {
                            Message message = new Message();
                            //执行中
                            message.what = 1;
                            message.obj = smallComponentSceneBeans.get(scene_position);
                            message.arg1 = appWidgetId;
                            message.arg2 = scene_position;
                            handler.sendMessage(message);
                        }
                    };
                    timer.schedule(timerTask, 3000);
                }
                AppWidgetManager.getInstance(context).notifyAppWidgetViewDataChanged(appWidgetId, R.id.grid_scene_app_widget);
                break;
        }
    }

    public static ArrayList<SmallComponentSceneBean> getSmallComponentSceneBeans() {
        return smallComponentSceneBeans;
    }
}

