package com.aliyun.iot.ilop.page.mine.smallcomponents.bean;

import android.os.Parcel;
import android.os.Parcelable;

public class SmallComponentSceneBean implements Parcelable {

    private String sceneBitmap;
    private String sceneName;
    //判断是否已经添加
    private boolean add;
    //0未执行 1执行中 2执行失败 3执行成功
    private int state;

    public SmallComponentSceneBean(String sceneBitmap, String sceneName, boolean add) {
        this.sceneBitmap = sceneBitmap;
        this.sceneName = sceneName;
        this.add = add;
        state = 0;
    }

    protected SmallComponentSceneBean(Parcel in) {
        sceneBitmap = in.readString();
        sceneName = in.readString();
        add = in.readByte() != 0;
        state = in.readInt();
    }

    public static final Creator<SmallComponentSceneBean> CREATOR = new Creator<SmallComponentSceneBean>() {
        @Override
        public SmallComponentSceneBean createFromParcel(Parcel in) {
            return new SmallComponentSceneBean(in);
        }

        @Override
        public SmallComponentSceneBean[] newArray(int size) {
            return new SmallComponentSceneBean[size];
        }
    };

    public String getSceneBitmap() {
        return sceneBitmap;
    }

    public void setSceneBitmap(String sceneBitmap) {
        this.sceneBitmap = sceneBitmap;
    }

    public String getSceneName() {
        return sceneName;
    }

    public void setSceneName(String sceneName) {
        this.sceneName = sceneName;
    }

    public boolean isAdd() {
        return add;
    }

    public void setAdd(boolean add) {
        this.add = add;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(sceneBitmap);
        dest.writeString(sceneName);
        dest.writeByte((byte) (add ? 1 : 0));
        dest.writeInt(state);
    }
}
