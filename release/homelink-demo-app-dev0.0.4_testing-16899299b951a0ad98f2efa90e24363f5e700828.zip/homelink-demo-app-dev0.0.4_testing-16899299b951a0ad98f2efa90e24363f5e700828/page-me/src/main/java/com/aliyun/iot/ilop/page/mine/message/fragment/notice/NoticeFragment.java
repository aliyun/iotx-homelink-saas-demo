package com.aliyun.iot.ilop.page.mine.message.fragment.notice;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTCallback;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTResponse;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.homelink.si.component.ExceptionToast;
import com.aliyun.iot.ilop.page.mine.api.Api;
import com.aliyun.iot.ilop.page.mine.api.base.ResponseCode;
import com.aliyun.iot.ilop.page.mine.base.BaseFragment;
import com.aliyun.iot.ilop.page.mine.base.BaseFragmentView;
import com.aliyun.iot.ilop.page.mine.base.activity.BaseActivity;
import com.aliyun.iot.ilop.page.mine.message.MessageActivity;
import com.aliyun.iot.ilop.page.mine.message.fragment.Message;
import com.aliyun.iot.ilop.page.mine.message.fragment.MessageList;
import com.aliyun.iot.link.ui.component.LinkToast;
import com.aliyun.iot.utils.DateUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NoticeFragment extends BaseFragment implements NoticeContract.Presenter {

    private NoticeContract.View mView;
    private String msgType;

    int mNextPageNo = 1;
    DateUtils mDateUtils = new DateUtils();

    private SparseArray<String> mHeaderList;

    public NoticeFragment() {

    }

    public static NoticeFragment newInstance(String msgType) {
        NoticeFragment fragment = new NoticeFragment();
        Bundle args = new Bundle();
        args.putString(MessageActivity.NOTICE, msgType);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void initBundle(Bundle bundle) {
        msgType = bundle.getString(MessageActivity.NOTICE);
    }

    @Override
    public BaseFragmentView setView(Context ctx, LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mView = new NoticeView(this, inflater, container, fragment.getImgLoader());
        return mView;
    }

    @Override
    public void loadData() {
        mView.showRefresh();
        final Map<String, Object> map = new HashMap<>();
        map.put("messageType", msgType);
        map.put("type", "NOTICE");
        map.put("pageNo", 1);
        map.put("pageSize", BaseActivity.PAGE_SIZE);
        Api.getInstance().requestMessage(map, new IoTCallback() {
            @Override
            public void onFailure(IoTRequest ioTRequest, Exception e) {
                mView.hideRefresh();
                ExceptionToast.toastNetworkException(getContext(), e);
            }

            @Override
            public void onResponse(IoTRequest ioTRequest, final IoTResponse ioTResponse) {
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        mView.hideRefresh();
                        if (ioTResponse.getCode() != ResponseCode.SUCCEED_CODE) {
                            LinkToast.makeText(getContext(), ioTResponse.getLocalizedMsg(), Toast.LENGTH_LONG).show();
                            return;
                        }
                        Message message = JSON.parseObject(ioTResponse.getData().toString(), Message.class);
                        mNextPageNo = message.getQueryPageNo() + 1;
                        heardStr(message.getData());
                        mView.refreshNoticeList(messageLists(message.getData()));
                        mView.updateFloatingView(mHeaderList);
                        if (message.getCount() < BaseActivity.PAGE_SIZE) {
                            mView.hideLoadMore();
                        }
                    }
                });
            }
        });
    }


    @Override
    public void loadMoreData() {
        final Map<String, Object> map = new HashMap<>();
        map.put("messageType", msgType);
        map.put("type", "NOTICE");
        map.put("pageNo", mNextPageNo);
        map.put("pageSize", BaseActivity.PAGE_SIZE);
        Api.getInstance().requestMessage(map, new IoTCallback() {
            @Override
            public void onFailure(IoTRequest ioTRequest, Exception e) {
                ExceptionToast.toastNetworkException(getContext(), e);
            }

            @Override
            public void onResponse(IoTRequest ioTRequest, final IoTResponse ioTResponse) {
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (ioTResponse.getCode() != ResponseCode.SUCCEED_CODE) {
                            LinkToast.makeText(getContext(), ioTResponse.getLocalizedMsg(), Toast.LENGTH_LONG).show();
                            return;
                        }
                        Message message = JSON.parseObject(ioTResponse.getData().toString(), Message.class);
                        heardStr(message.getData());
                        mView.loadMoreNoticeList(messageLists(message.getData()));
                        mView.updateFloatingView(mHeaderList);
                        mNextPageNo = message.getQueryPageNo() + 1;
                        if (message.getCount() < BaseActivity.PAGE_SIZE) {
                            mView.hideLoadMore();
                        }
                    }
                });
            }
        });
    }

    /**
     * 封装消息体
     * @param data
     * @return
     */
    private List<MessageList> messageLists(List<Message.DataBean> data) {
        List<MessageList> list = new ArrayList<>();
        if (data != null && data.size() > 0) {
            for (int i = 0; i < data.size(); i++) {
                Message.DataBean.ExtDataBean extData = data.get(i).getExtData();
                if (extData != null) {
                    Message.DataBean.ExtDataBean.DeviceBean device = extData.getDevice();
                    long gmtCreate = data.get(i).getGmtCreate();
                    String time = mDateUtils.covertDate2fotterDate(gmtCreate + "");
                    String body = data.get(i).getBody();
                    //创建设备消息对象
                    MessageList deviceMessage = new MessageList();
                    deviceMessage.setDesc(body);
                    deviceMessage.setTime(time);
                    deviceMessage.setTitle(device.getProductName());
                    deviceMessage.setIcon(device.getIcon());
                    list.add(deviceMessage);
                }
            }
        }
        return list;
    }

    /**
     * 设置标题title
     * @param data
     */
    private void heardStr(List<Message.DataBean> data) {
        int preDataSize = 0;
        if (mHeaderList == null) {
            mHeaderList = new SparseArray<>();
        } else if (mNextPageNo == 2) {//刷新操作
            mHeaderList.clear();
        } else {
            preDataSize = mView.getDataSize();
        }

        if (data == null || data.size() == 0) {
            return;
        }
        long gmtCreate = data.get(0).getGmtCreate();
        String preDate = null;
        String nowDate;
        String date = mDateUtils.covertDate2TitleDate(getContext(), gmtCreate + "");
        if (date != null) {
            preDate = date;
        }

        if (mNextPageNo == 2) {
            if (date != null) {
                mHeaderList.put(0, date);
            }
        } else {
            nowDate = preDate;
            preDate = mView.getPreItemDate();
            if (!TextUtils.equals(nowDate, preDate)) {
                if (date != null) {
                    mHeaderList.put(preDataSize, date);
                }
            }
        }

        Message.DataBean.ExtDataBean extDataBean;
        for (int i = 1, len = data.size(); i < len; i++) {
            extDataBean = data.get(i).getExtData();
            if (extDataBean == null) {
                continue;
            }
            gmtCreate = data.get(i).getGmtCreate();
            date = mDateUtils.covertDate2TitleDate(getContext(), gmtCreate + "");
            nowDate = date;

            if (!nowDate.equals(preDate)) {
                mHeaderList.put(preDataSize + i, date);
                preDate = nowDate;
            }
        }

    }
}
