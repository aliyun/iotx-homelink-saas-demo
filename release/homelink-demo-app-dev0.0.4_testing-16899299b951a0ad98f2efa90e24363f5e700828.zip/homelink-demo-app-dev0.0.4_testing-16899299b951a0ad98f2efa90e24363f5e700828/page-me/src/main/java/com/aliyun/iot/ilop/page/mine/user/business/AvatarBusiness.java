package com.aliyun.iot.ilop.page.mine.user.business;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;

import com.aliyun.iot.ilop.page.mine.MineConstants;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class AvatarBusiness {


    private Handler handler;
    private String avatarPath;

    public AvatarBusiness(Handler handler) {
        this.handler = handler;
    }

    public void setAvatarPath(String avatarPath) {
        this.avatarPath = avatarPath;
    }


    public void getAvatar(final String url) {
        if (TextUtils.isEmpty(url)) {
            return;
        }
        OkHttpClient okHttpClient = new OkHttpClient.Builder().build();
        Request request = new Request.Builder()
                .url(url)
                .get().build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Uri uri = getCache(url);
                if (handler != null) {
                    Message.obtain(handler, MineConstants.MINE_MESSAGE_RESPONSE_AVATAR_SUCCESS, uri).sendToTarget();
                }

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Bitmap bitmap = BitmapFactory.decodeStream(response.body().byteStream());
                if (bitmap != null) {
                    FileOutputStream fileOutputStream = new FileOutputStream(new File(avatarPath, "head" + url.hashCode() + url.substring(url.lastIndexOf("."))));
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                    bitmap.recycle();
                    fileOutputStream.close();
                    if (handler != null) {
                        Uri uri = getCache(url);
                        Message.obtain(handler, MineConstants.MINE_MESSAGE_RESPONSE_AVATAR_SUCCESS, uri).sendToTarget();
                    }
                }
            }
        });

    }


    public Uri getCache(String url) {
        if (TextUtils.isEmpty(url)) {
            return null;
        }
        File path = new File(avatarPath, "/head" + url.hashCode() + url.substring(url.lastIndexOf(".")));
        if (!path.exists()) {
            return null;
        }
        return Uri.fromFile(path);
    }


}
