package com.aliyun.iot.ilop.page.mine.base.activity;


import com.aliyun.iot.ilop.page.mine.base.BasePresenter;
import com.aliyun.iot.ilop.page.mine.base.BaseView;

/**
 * Created by nht on 2018/6/14.
 */

public interface BaseActivityView<Presenter extends BaseActivityPresenter & BasePresenter> extends BaseView<Presenter> {

    int getLayoutId();

    void initView(BaseActivity baseActivity);

    void bindEvent();
}
