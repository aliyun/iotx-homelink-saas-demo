package com.aliyun.iot.ilop.page.mine.smallcomponents.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.aliyun.iot.ilop.page.mine.R;

import java.util.ArrayList;

public class SmallComponentSceneAdapter extends BaseAdapter {

    private ArrayList list = new ArrayList();
    private Context context;

    public SmallComponentSceneAdapter(ArrayList list, Context context) {
        this.list = list;
        this.context = context;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        SmallComponentSceneAdapter.ViewHolder holder;
        if (convertView == null) {
            convertView = View.inflate(context, R.layout.ilop_mine_small_component_scene_item, null);
            holder = new SmallComponentSceneAdapter.ViewHolder();
            holder.iv_scene_small_component = convertView.findViewById(R.id.iv_scene_small_component);
            holder.tv_scene_small_component = convertView.findViewById(R.id.tv_scene_small_component);
            convertView.setTag(holder);
        } else {
            holder = (SmallComponentSceneAdapter.ViewHolder) convertView.getTag();
        }
        // holder.iv_scene_small_component.setImageResource(R.drawable.account_bg);
        holder.tv_scene_small_component.setText(list.get(position).toString());

        return convertView;
    }


    class ViewHolder {
        private ImageView iv_scene_small_component;
        private TextView tv_scene_small_component;
    }
}
