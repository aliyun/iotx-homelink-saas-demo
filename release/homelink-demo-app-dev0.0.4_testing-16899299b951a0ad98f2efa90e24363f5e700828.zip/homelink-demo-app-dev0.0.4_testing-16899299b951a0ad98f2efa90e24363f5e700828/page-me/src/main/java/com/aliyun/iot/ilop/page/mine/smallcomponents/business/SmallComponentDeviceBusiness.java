package com.aliyun.iot.ilop.page.mine.smallcomponents.business;

import android.os.Handler;

import com.alibaba.fastjson.JSON;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClient;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientFactory;
import com.aliyun.iot.aep.sdk.apiclient.emuns.Scheme;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequestBuilder;
import com.aliyun.iot.ilop.page.mine.MineAPIClientConstants;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.ComponentProductDTO;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.PropertyQueryDTO;
import com.aliyun.iot.ilop.page.mine.smallcomponents.listener.SmallComponentDeviceListener;
import com.aliyun.iot.ilop.page.mine.smallcomponents.listener.SmallComponentServiceDeviceListener;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SmallComponentDeviceBusiness {

    private IoTAPIClient ioTAPIClient;
    private Handler handler;
    private SmallComponentDeviceListener smallComponentDeviceListener;
    private SmallComponentServiceDeviceListener serviceDeviceListener;

    public SmallComponentDeviceBusiness(Handler handler) {
        this.handler = handler;
        IoTAPIClientFactory ioTAPIClientFactory = new IoTAPIClientFactory();
        ioTAPIClient = ioTAPIClientFactory.getClient();
        smallComponentDeviceListener = new SmallComponentDeviceListener(this.handler);
        serviceDeviceListener = new SmallComponentServiceDeviceListener(this.handler);
    }

    private IoTRequestBuilder getBaseIoTRequestBuilder() {

        IoTRequestBuilder ioTRequestBuilder = new IoTRequestBuilder();
        ioTRequestBuilder.setAuthType(MineAPIClientConstants.APICLIENT_IOTAUTH).setApiVersion(MineAPIClientConstants.APICLIENT_VERSION);
        return ioTRequestBuilder;
    }

    public void getDeviceListFromAccount(int page, int size) {
        Map<String, Object> params = new HashMap<>();
        params.put("offset", page * size);
        params.put("limit", size);
        params.put("dataType", "BOOL");
        IoTRequest ioTRequest = getBaseIoTRequestBuilder()
                .setApiVersion("1.0.0")
                .setPath(MineAPIClientConstants.SMALL_COMMPONENT_PATH_GETDEVICELIST)
                .setParams(params).setScheme(Scheme.HTTPS).setAuthType("iotAuth")
                .build();
        ioTAPIClient.send(ioTRequest, smallComponentDeviceListener);
    }

    /**
     * 查询设备属性
     *
     * @param key
     */
    public void getDeviceProperty(String key, String iotId) {
        Map<String, Object> params = new HashMap<>();
        params.put("productKey", key);
        params.put("iotId", iotId);
        PropertyQueryDTO propertyQueryDTO = new PropertyQueryDTO();
        propertyQueryDTO.setDataType("BOOL");
        params.put("query", JSON.parseObject(JSON.toJSONString(propertyQueryDTO)));
        IoTRequest ioTRequest = getBaseIoTRequestBuilder()
                .setApiVersion("1.0.0")
                .setPath(MineAPIClientConstants.SMALL_COMMPONENT_PATH_GETDEVICEPROPRETYLIST)
                .setParams(params).setScheme(Scheme.HTTPS).setAuthType("iotAuth")
                .build();
        ioTAPIClient.send(ioTRequest, smallComponentDeviceListener);
    }

    //获取已添加小组件设备列表
    public void queryComponentProductByIdentityId() {
        Map<String, Object> params = new HashMap<>();
        IoTRequest ioTRequest = getBaseIoTRequestBuilder()
                .setApiVersion("1.0.0")
                .setPath(MineAPIClientConstants.SMALL_COMMPONENT_PATH_QUERYCOMPONENTPRODUCT)
                .setParams(params).setScheme(Scheme.HTTPS).setAuthType("iotAuth")
                .build();
        ioTAPIClient.send(ioTRequest, smallComponentDeviceListener);
    }

    //更新已添加到小组件的设备列表
    public void updateComponentProprety(List<ComponentProductDTO> componentProductList) {
        Map<String, Object> params = new HashMap<>();
        params.put("componentProductList", JSON.parseArray(JSON.toJSONString(componentProductList)));
        IoTRequest ioTRequest = getBaseIoTRequestBuilder()
                .setApiVersion("1.0.0")
                .setPath(MineAPIClientConstants.SMALL_COMMPONENT_PATH_UPDATECOMPONENTPROPERTY)
                .setParams(params).setScheme(Scheme.HTTPS).setAuthType("iotAuth")
                .build();
        ioTAPIClient.send(ioTRequest, smallComponentDeviceListener);
    }

    /**
     * 查询小组件中设备数量
     */
    public void queryComponentProductListNumber() {
        Map<String, Object> params = new HashMap<>();
        IoTRequest ioTRequest = getBaseIoTRequestBuilder()
                .setApiVersion("1.0.0")
                .setPath(MineAPIClientConstants.SMALL_COMMPONENT_PATH_QUERYCOMPONENTPRODUCT)
                .setParams(params).setScheme(Scheme.HTTPS).setAuthType("iotAuth")
                .build();
        ioTAPIClient.send(ioTRequest, serviceDeviceListener);
    }
}

