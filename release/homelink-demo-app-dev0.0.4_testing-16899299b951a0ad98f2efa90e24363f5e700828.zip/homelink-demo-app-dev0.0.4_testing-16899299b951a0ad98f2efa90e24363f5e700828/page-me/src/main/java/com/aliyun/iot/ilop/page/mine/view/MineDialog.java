package com.aliyun.iot.ilop.page.mine.view;

import android.app.Dialog;
import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import com.aliyun.iot.ilop.page.mine.R;

/**
 * Created by david on 2018/4/11.
 *
 * @author david
 * @date 2018/04/11
 */
public class MineDialog extends Dialog implements OnClickListener {
    private TextView mTitle,mContent;
    private Button mNegativeButton, mPositiveButton;

    private OnDialogButtonClickListener mListener;

    public MineDialog(@NonNull Context context) {
        super(context, R.style.MineDialog);
        init();
    }

    private void init() {
        View root = getLayoutInflater().inflate(R.layout.ilop_mine_dialog, null);
        setContentView(root);

        mTitle = root.findViewById(R.id.mine_dialog_title_textview);
        mContent = root.findViewById(R.id.mine_dialog_content_textview);
        mNegativeButton = root.findViewById(R.id.mine_dialog_negative_button);
        mPositiveButton = root.findViewById(R.id.mine_dialog_positive_button);

        mNegativeButton.setOnClickListener(this);
        mPositiveButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (R.id.mine_dialog_negative_button == v.getId()) {
            if (null != mListener) {
                mListener.onNegativeClick(this);
            }
        } else if (R.id.mine_dialog_positive_button == v.getId()) {
            if (null != mListener) {
                mListener.onPositiveClick(this);
            }
        }
    }

    public void setTitle(String title) {
        if (null != mTitle && !TextUtils.isEmpty(title)) {
            mTitle.setText(title);
        }
    }

    public void setContent(String content) {
        if (null != mContent && !TextUtils.isEmpty(content)) {
            mContent.setText(content);
            mContent.setVisibility(View.VISIBLE);
        }
    }

    public void setNegativeButtonText(String negativeTips) {
        if (null != mNegativeButton) {
            mNegativeButton.setText(negativeTips);
        }
    }

    public void setPositiveButtonText(String positiveTips) {
        if (null != mPositiveButton) {
            mPositiveButton.setText(positiveTips);
        }
    }

    public void setOnDialogButtonClickListener(OnDialogButtonClickListener listener) {
        mListener = listener;
    }

    public interface OnDialogButtonClickListener {
        void onNegativeClick(MineDialog dialog);

        void onPositiveClick(MineDialog dialog);
    }

}
