package com.aliyun.iot.ilop.page.mine.message.fragment.device;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.base.BaseRvAdapter;
import com.aliyun.iot.ilop.page.mine.message.fragment.MessageList;
import com.aliyun.iot.utils.ImageLoader;
import com.bumptech.glide.RequestManager;

public class DeviceAdapter extends BaseRvAdapter<MessageList> {

    private RequestManager imgLoader;

    public DeviceAdapter(Context context, RequestManager imgLoader) {
        super(context);
        this.imgLoader = imgLoader;
    }

    @Override
    protected RecyclerView.ViewHolder onCreateDefaultViewHolder(ViewGroup parent, int type) {
        MessageViewHolder holder = new MessageViewHolder(mInflater.inflate(R.layout.ilop_mine_list_item_message, parent, false));
        return holder;
    }


    @Override
    protected void onBindDefaultViewHolder(RecyclerView.ViewHolder viewHolder, MessageList item, int position) {
        if (viewHolder instanceof MessageViewHolder) {
            MessageViewHolder holder = (MessageViewHolder) viewHolder;
            ImageLoader.loadImage(imgLoader, holder.ivDevice, item.getIcon(), R.drawable.default_device);
            holder.tvTitle.setText(item.getTitle());
            holder.tvDesc.setText(item.getDesc());
            holder.tvTime.setText(item.getTime());
        }
    }

    protected static class MessageViewHolder extends RecyclerView.ViewHolder {
        TextView tvTime, tvTitle, tvDesc;
        ImageView ivDevice;

        public MessageViewHolder(View itemView) {
            super(itemView);
            tvTime = itemView.findViewById(R.id.tv_time);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvDesc = itemView.findViewById(R.id.tv_desc);
            ivDevice = itemView.findViewById(R.id.iv_device);
        }
    }
}
