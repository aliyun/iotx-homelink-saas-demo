package com.aliyun.iot.ilop.page.mine.about.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.base.MineBaseActivity;
import com.aliyun.iot.ilop.page.mine.view.SimpleTopbar;
import com.aliyun.iot.ilop.page.mine.view.SimpleTopbar.onBackClickListener;

/**
 * Created by david on 2018/4/27.
 *
 * @author david
 * @date 2018/04/27
 */
public class MineProtocolActivity extends MineBaseActivity implements onBackClickListener {
    private static final String TAG = "MineProtocolActivity";
    private WebView mWebView;
    private SimpleTopbar mTopbar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ilop_mine_protocol_activity);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (null != mWebView) {
            mWebView.onResume();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (null != mWebView) {
            mWebView.onPause();
        }
    }

    @Override
    protected void onDestroy() {
        if (null != mWebView) {
            mWebView.destroy();
            mWebView = null;
        }

        super.onDestroy();
    }

    @Override
    protected void initView() {
        mWebView = findViewById(R.id.mine_protocol_webview);
        mTopbar = findViewById(R.id.mine_topbar);

        WebSettings webSettings = mWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        mWebView.setVerticalScrollBarEnabled(true);
        mWebView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
    }

    @Override
    protected void initData() {
        try {
            String url = getIntent().getStringExtra("url");
            mWebView.loadUrl(url);
            ALog.d(TAG, "url=："+url);

            String title = getIntent().getStringExtra("title");
            mTopbar.setTitle(title);
        } catch (Exception e) {
            ALog.e(TAG, e.getMessage(), e);
            this.finish();
        }
    }

    @Override
    protected void initEvent() {
        if (null != mTopbar) {
            mTopbar.setOnBackClickListener(this);
        }
    }

    @Override
    protected void initHandler() {

    }

    @Override
    public void onBackClick() {
        if (isFinishing()) {
            return;
        }

        this.finish();
    }
}
