package com.aliyun.iot.ilop.page.mine.view;

import android.app.Dialog;
import android.content.Context;
import android.support.annotation.NonNull;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.aliyun.iot.ilop.page.mine.R;

public class MineLoadingDialog extends Dialog {

    private TextView tvProgressMesssage;

    public MineLoadingDialog(@NonNull Context context) {
        this(context, 0);
    }

    public MineLoadingDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
        init();
    }

    private void init() {
        Window window = getWindow();
        window.requestFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.ilop_mine_loading_dialog);
        window.setBackgroundDrawableResource(R.drawable.ilop_mine_loading_dialog_shape);
        int with = (int) (getContext().getResources().getDisplayMetrics().widthPixels * 0.35f);
        WindowManager.LayoutParams layoutParams = window.getAttributes();
        layoutParams.width = with;
        layoutParams.height = with;
        layoutParams.gravity = Gravity.CENTER;
        layoutParams.dimAmount = 0.0f;

        window.setAttributes(layoutParams);
        setCancelable(true);
        setCanceledOnTouchOutside(false);

        initView();
    }


    private void initView() {
        tvProgressMesssage = findViewById(R.id.ilop_mine_loading_message);
    }


    public void setProgressMesssage(String messsage) {
        tvProgressMesssage.setText(messsage);

    }


    public void setProgressMesssage(int resid) {
        tvProgressMesssage.setText(resid);
    }


}
