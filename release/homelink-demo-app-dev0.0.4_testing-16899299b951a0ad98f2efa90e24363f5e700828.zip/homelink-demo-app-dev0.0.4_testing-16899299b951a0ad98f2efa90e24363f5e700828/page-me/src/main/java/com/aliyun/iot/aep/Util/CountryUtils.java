package com.aliyun.iot.aep.Util;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ZhuBingYang on 2019/4/11.
 */
public class CountryUtils {
    //用于存储全局搜索内容
    public static List<Object> globalProductList = new ArrayList<>();

    public static boolean judgeIsOverseas(Context applicationContext) {
        return false;
    }

    public static boolean judgeIsEurope(Context applicationContext) {
        return false;
    }

    public static boolean judgeIsChina(Context applicationContext) {
        return true;
    }
}
