package com.aliyun.iot.ilop.page.mine.base.activity;

import android.net.Uri;
import android.os.Bundle;

import com.aliyun.iot.ilop.page.mine.base.BasePresenter;

/**
 * Created by nht on 2018/6/14.
 */

public interface BaseActivityPresenter extends BasePresenter {

    void initData(Uri uri);

    void initData(Bundle bundle);

    BaseActivityView setView();

    void loadData();
}
