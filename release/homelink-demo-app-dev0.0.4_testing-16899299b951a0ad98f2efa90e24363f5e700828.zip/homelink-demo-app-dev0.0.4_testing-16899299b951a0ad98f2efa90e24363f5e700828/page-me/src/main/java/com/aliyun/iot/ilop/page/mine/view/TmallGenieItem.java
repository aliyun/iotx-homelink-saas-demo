package com.aliyun.iot.ilop.page.mine.view;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.aliyun.iot.ilop.page.mine.R;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

public class TmallGenieItem extends FrameLayout {

    private TextView title;
    private ImageView imageView;
    private View lineView;
    private TextView controlledDeviceTv;
    private TextView noDeviceTv;
    private LinearLayout ctLl;

    public TmallGenieItem(@NonNull Context context) {
        super(context);
        init();
    }

    public TmallGenieItem(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public TmallGenieItem(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public void init() {
        inflate(getContext(), R.layout.ilop_mine_tmall_genie_item, this);
        imageView = findViewById(R.id.mine_tp_device_item_iv);
        title = findViewById(R.id.mine_tp_device_item_tv);
        lineView = findViewById(R.id.mine_tp_device_item_line);
        controlledDeviceTv = findViewById(R.id.mine_tm_head_item_controlled_device_tv);
        noDeviceTv = findViewById(R.id.mine_tm_head_item_no_device_tv);
        ctLl = findViewById(R.id.mine_tm_head_item_device_ll);
    }

    public void isShowBlankTv(boolean flag) {
        if (noDeviceTv == null || ctLl == null) {
            return;
        }
        if (flag) {
            noDeviceTv.setVisibility(VISIBLE);
            ctLl.setVisibility(GONE);
            isShowLine(false);
        } else {
            noDeviceTv.setVisibility(GONE);
            ctLl.setVisibility(VISIBLE);
        }
    }

    public void isShowLine(boolean flag) {
        if (flag) {
            lineView.setVisibility(VISIBLE);
        } else {
            lineView.setVisibility(GONE);
        }
    }

    public void isShowBar(boolean flag) {
        if (flag) {
            controlledDeviceTv.setVisibility(VISIBLE);
        } else {
            controlledDeviceTv.setVisibility(GONE);
        }
    }

    public void setTitle(String title) {
        this.title.setText(title);
    }

    public void setImageUrl(String url) {
        if (TextUtils.isEmpty(url)) {
            return;
        }
        RequestOptions options = new RequestOptions()
                .placeholder(R.drawable.ilop_mine_icon_default)
                .error(R.drawable.ilop_mine_icon_default);
        Glide.with(this)
                .load(url).apply(options)
                .into(imageView);
    }
}
