package com.aliyun.iot.ilop.page.mine.message.fragment;

/**
 * Created：2018/6/28
 * Author：wb-415501
 * Desc：消息条数
 */
public class MessageCount {

    /**
     * share : 6
     * device : 0
     * announcement : 0
     */

    private int share;
    private int device;
    private int announcement;

    public int getShare() {
        return share;
    }

    public void setShare(int share) {
        this.share = share;
    }

    public int getDevice() {
        return device;
    }

    public void setDevice(int device) {
        this.device = device;
    }

    public int getAnnouncement() {
        return announcement;
    }

    public void setAnnouncement(int announcement) {
        this.announcement = announcement;
    }
}
