package com.aliyun.iot.ilop.page.mine.tripartite_platform.business.listener;

import android.os.Handler;
import android.os.Message;

import com.alibaba.fastjson.JSON;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.ilop.page.mine.MineConstants;
import com.aliyun.iot.ilop.page.mine.tripartite_platform.bean.BindTaoBaoAccountBean;
import com.aliyun.iot.ilop.page.mine.tripartite_platform.bean.GetThirdpartyBean;
import com.aliyun.iot.ilop.page.mine.tripartite_platform.bean.TripartitePlatformListBean;
import com.aliyun.iot.ilop.page.mine.tripartite_platform.bean.UnBindBean;

public class TmallGenieListActivityBusinessListener extends BaseBusinessListener {
    public TmallGenieListActivityBusinessListener(Handler mHandler) {
        super(mHandler);
    }

    @Override
    protected void onResponseSuccess(IoTRequest ioTRequest, String ioTResponse) {
        if (null == mHandler) {
            return;
        }

        if (MineConstants.APICLIENT_PATH_GETSUOOPRTEDEVICES.equals(ioTRequest.getPath())) {
            try {
                TripartitePlatformListBean infos = JSON.parseObject(ioTResponse, TripartitePlatformListBean.class);
                Message.obtain(mHandler, MineConstants.MINE_MESSAGE_RESPONSE_GET_SUOOPRTED_DEVICES_SUCCESS, infos).sendToTarget();
            } catch (Exception e) {
                Message.obtain(mHandler, MineConstants.MINE_MESSAGE_RESPONSE_GET_SUOOPRTED_DEVICES_FAIL).sendToTarget();
            }
        } else if (MineConstants.APICLIENT_PATH_BIND_ACCOUNT.equals(ioTRequest.getPath())) {
            try {
                BindTaoBaoAccountBean infos = JSON.parseObject(ioTResponse, BindTaoBaoAccountBean.class);
                Message.obtain(mHandler, MineConstants.MINE_MESSAGE_RESPONSE_BIND_TAOBAO_ACCOUNT_SUCCESS, infos).sendToTarget();
            } catch (Exception e) {
                ALog.e(TAG, "parse OTADeviceSimpleInfo error", e);
                Message.obtain(mHandler, MineConstants.MINE_MESSAGE_RESPONSE_BIND_TAOBAO_ACCOUNT_FAIL).sendToTarget();
            }
        } else if (MineConstants.APICLIENT_PATH_THIRDPARTY_GET.equals(ioTRequest.getPath())) {
            try {
                GetThirdpartyBean infos = JSON.parseObject(ioTResponse, GetThirdpartyBean.class);
                Message.obtain(mHandler, MineConstants.MINE_MESSAGE_RESPONSE_GET_TAOBAO_ACCOUNT_SUCCESS, infos).sendToTarget();
            } catch (Exception e) {
                ALog.e(TAG, "parse OTADeviceSimpleInfo error", e);
                Message.obtain(mHandler, MineConstants.MINE_MESSAGE_RESPONSE_GET_TAOBAO_ACCOUNT_FAIL).sendToTarget();
            }
        } else if (MineConstants.APICLIENT_PATH_UNBIND_ACCOUNT.equals(ioTRequest.getPath())) {
            try {
                UnBindBean infos = JSON.parseObject(ioTResponse, UnBindBean.class);
                Message.obtain(mHandler, MineConstants.MINE_MESSAGE_RESPONSE_UNBIND_TAOBAO_ACCOUNT_SUCCESS, infos).sendToTarget();
            } catch (Exception e) {
                ALog.e(TAG, "parse OTADeviceSimpleInfo error", e);
                Message.obtain(mHandler, MineConstants.MINE_MESSAGE_RESPONSE_UNBIND_TAOBAO_ACCOUNT_FAIL).sendToTarget();
            }
        }
    }

    @Override
    protected void onResponseFailure(IoTRequest ioTRequest, String ioTResponse) {
        if (null == mHandler) {
            return;
        }

        Message.obtain(mHandler, MineConstants.MINE_MESSAGE_RESPONSE_ERROR).sendToTarget();
    }

    @Override
    protected void onRequestFailure(IoTRequest ioTRequest, Exception e) {
        if (null == mHandler) {
            return;
        }

        Message.obtain(mHandler, MineConstants.MINE_MESSAGE_RESPONSE_ERROR).sendToTarget();
    }

}
