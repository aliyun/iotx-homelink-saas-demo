package com.aliyun.iot.ilop.page.mine.message.fragment.notice;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.base.BaseRvAdapter;
import com.aliyun.iot.ilop.page.mine.message.fragment.MessageList;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;

public class NoticeAdapter extends BaseRvAdapter<MessageList> {

    private RequestManager imgLoader;

    public NoticeAdapter(Context context, RequestManager imgLoader) {
        super(context);
        this.imgLoader = imgLoader;
    }

    @Override
    protected RecyclerView.ViewHolder onCreateDefaultViewHolder(ViewGroup parent, int type) {
        MessageViewHolder holder = new MessageViewHolder(mInflater.inflate(R.layout.ilop_mine_list_item_message, parent, false));
        return holder;
    }

    @Override
    protected void onBindDefaultViewHolder(RecyclerView.ViewHolder viewHolder, MessageList item, int position) {
        if (viewHolder instanceof MessageViewHolder) {
            MessageViewHolder holder = (MessageViewHolder) viewHolder;
            Glide.with(mContext).load(item.getIcon()).into(holder.ivDevice);
            holder.tvTitle.setText(item.getTitle());
            holder.tvDesc.setText(item.getDesc());
            holder.tvTime.setText(item.getTime());
        }
    }


    protected static class MessageViewHolder extends RecyclerView.ViewHolder {
        TextView tvTime, tvTitle, tvDesc;
        ImageView ivDevice;

        public MessageViewHolder(View itemView) {
            super(itemView);
            tvTime = itemView.findViewById(R.id.tv_time);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvDesc = itemView.findViewById(R.id.tv_desc);
            ivDevice = itemView.findViewById(R.id.iv_device);
        }
    }
}
