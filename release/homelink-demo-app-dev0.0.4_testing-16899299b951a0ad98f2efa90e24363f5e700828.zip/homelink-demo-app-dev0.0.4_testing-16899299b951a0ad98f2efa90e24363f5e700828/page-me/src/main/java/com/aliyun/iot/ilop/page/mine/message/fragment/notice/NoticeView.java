package com.aliyun.iot.ilop.page.mine.message.fragment.notice;

import android.content.Context;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.SimpleItemAnimator;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.base.BaseFragment;
import com.aliyun.iot.ilop.page.mine.base.BasePresenter;
import com.aliyun.iot.ilop.page.mine.message.fragment.MessageList;
import com.aliyun.iot.link.ui.component.RefreshRecycleViewLayout;
import com.aliyun.iot.utils.view.FloatingBarItemDecoration;
import com.aliyun.iot.utils.view.SceneDivider;
import com.bumptech.glide.RequestManager;

import java.util.List;

public class NoticeView implements NoticeContract.View, SwipeRefreshLayout.OnRefreshListener, RefreshRecycleViewLayout.OnLoadMoreListener {

    Context mCtx;
    View mContentView;

    NoticeContract.Presenter mPresenter;

    RefreshRecycleViewLayout refreshRecycleViewLayout;
    NoticeAdapter mAdapter;
    RequestManager imgLoader;
    private FloatingBarItemDecoration floatingItemDecoration;

    public NoticeView(BaseFragment mCtx, LayoutInflater inflater, ViewGroup container, RequestManager imgLoader) {
        this.mCtx = mCtx.getContext();
        this.imgLoader = imgLoader;
        mContentView = inflater.inflate(getLayoutId(), container, false);
    }

    @Override
    public void setPresenter(BasePresenter presenter) {
        mPresenter = (NoticeContract.Presenter) presenter;
    }

    @Override
    public int getLayoutId() {
        return R.layout.ilop_mine_fragment_message;
    }

    @Override
    public View getContentView() {
        return mContentView;
    }

    @Override
    public void initView() {
        floatingItemDecoration = new FloatingBarItemDecoration(mCtx);
        refreshRecycleViewLayout = mContentView.findViewById(R.id.recycleview);
        refreshRecycleViewLayout.setLayoutManager(new LinearLayoutManager(mCtx));
        refreshRecycleViewLayout.addItemDecoration(new SceneDivider(mCtx.getResources().getDrawable(R.drawable.divider_left24)));
        ((SimpleItemAnimator) refreshRecycleViewLayout.getTargetView().getItemAnimator()).setSupportsChangeAnimations(false);
        mAdapter = new NoticeAdapter(mCtx, imgLoader);
        refreshRecycleViewLayout.addItemDecoration(floatingItemDecoration);
        refreshRecycleViewLayout.setEmptyView(R.layout.empty_view);
        TextView emptyTv = refreshRecycleViewLayout.findViewById(R.id.empty_view_text);
        emptyTv.setText(R.string.hint_no_notice);

        refreshRecycleViewLayout.setAdapter(mAdapter);
        refreshRecycleViewLayout.fullLoad();
        mAdapter.notifyDataSetChanged();
        refreshRecycleViewLayout.updateEmptyView(false);
    }

    @Override
    public void bindEvent() {
        refreshRecycleViewLayout.setOnRefreshListener(this);
        refreshRecycleViewLayout.setOnLoadMoreListener(this);
    }

    @Override
    public void showRefresh() {
        if (refreshRecycleViewLayout != null && !refreshRecycleViewLayout.isRefreshing()) {
            refreshRecycleViewLayout.setRefreshing(true);
        }
    }

    @Override
    public void hideRefresh() {
        if (refreshRecycleViewLayout != null && refreshRecycleViewLayout.isRefreshing()) {
            refreshRecycleViewLayout.setRefreshing(false);
        }
    }

    @Override
    public void refreshNoticeList(List<MessageList> datas) {
        mAdapter.resetItem(datas);
    }

    @Override
    public void loadMoreNoticeList(List<MessageList> datas) {
        mAdapter.addAll(datas);
    }

    @Override
    public void hideLoadMore() {
        refreshRecycleViewLayout.fullLoad();
    }


    @Override
    public void updateFloatingView(SparseArray<String> headerData) {
        floatingItemDecoration.setFloatingData(headerData);
        refreshRecycleViewLayout.getTargetView().invalidate();
    }

    @Override
    public int getDataSize() {
        return mAdapter != null ? mAdapter.getCount() : 0;
    }

    @Override
    public String getPreItemDate() {
        MessageList item = mAdapter.getItem(mAdapter.getCount() - 1);
        return item == null ? null : item.getDate();
    }

    @Override
    public void onRefresh() {
        mPresenter.loadData();
    }

    @Override
    public void onLoadMore() {
        mPresenter.loadMoreData();
    }
}
