package com.aliyun.iot.ilop.page.mine.view;

import android.content.Context;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.aliyun.iot.ilop.page.mine.MineConstants;
import com.aliyun.iot.ilop.page.mine.R;

public class TmallGenieHeadItem extends FrameLayout {

    private String channel;
    private ImageView imageView;
    private TextView bindTv;
    private LinearLayout bindStepLl;
    private boolean isBindAccountFlag;

    public TmallGenieHeadItem(@NonNull Context context) {
        super(context);
        init();
    }

    public TmallGenieHeadItem(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public TmallGenieHeadItem(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public void init() {
        inflate(getContext(), R.layout.ilop_mine_tmall_genie_head_item, this);
        imageView = findViewById(R.id.mine_tm_head_item_iv);
        bindTv = findViewById(R.id.mine_tm_head_item_binding_account_tv);
        bindStepLl = findViewById(R.id.mine_tm_head_item_binding_step_ll);
    }

    public void setImageResource(@DrawableRes int resId) {
        imageView.setImageResource(resId);
    }

    public void isBindAccountFlag(boolean isBindAccountFlag, CharSequence text) {
        this.isBindAccountFlag = isBindAccountFlag;
        bindTv.setText(text);
        if (isBindAccountFlag) {
            bindTv.setTextColor(0XFFFF3838);
        } else {
            bindTv.setTextColor(0XFF1FC88B);
        }
    }

    public void setChannel(String channel) {
        this.channel = channel;
        if (channel.equals(MineConstants.TM)) {
            bindTv.setVisibility(VISIBLE);
            bindStepLl.setVisibility(GONE);
        } else {
            bindStepLl.setVisibility(VISIBLE);
            bindTv.setVisibility(GONE);
        }
    }


    public void onBindClick(@Nullable OnClickListener l) {
        bindTv.setOnClickListener(l);
    }

    public void onBindStepClick(@Nullable OnClickListener l) {
        bindStepLl.setOnClickListener(l);
    }
}
