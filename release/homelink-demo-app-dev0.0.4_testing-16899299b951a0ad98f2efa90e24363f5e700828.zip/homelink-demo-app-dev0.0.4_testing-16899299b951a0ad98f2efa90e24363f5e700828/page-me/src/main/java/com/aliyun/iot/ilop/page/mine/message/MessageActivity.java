package com.aliyun.iot.ilop.page.mine.message;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.aliyun.iot.aep.sdk.apiclient.callback.IoTCallback;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTResponse;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.homelink.si.component.ExceptionToast;
import com.aliyun.iot.homelink.si.component.TopBar;
import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.api.Api;
import com.aliyun.iot.ilop.page.mine.api.base.ResponseCode;
import com.aliyun.iot.ilop.page.mine.base.activity.BaseDialogActivity;
import com.aliyun.iot.ilop.page.mine.message.fragment.device.DeviceFragment;
import com.aliyun.iot.ilop.page.mine.message.fragment.notice.NoticeFragment;
import com.aliyun.iot.ilop.page.mine.view.bottomsheet.BottomPopUpDialog;
import com.aliyun.iot.link.ui.component.LinkToast;

/**
 * Created：2018/6/26
 * Author：wb-415501
 * Desc：消息中心
 */
public class MessageActivity extends BaseDialogActivity implements TopBar.OnLeftClickListener, TopBar.OnRightClickListener, View.OnClickListener {

    public static final String DEVICE = "device";
    public static final String NOTICE = "notice";

    private TopBar topBar;
    private RelativeLayout rlLeft, rlRight;
    private TextView tvDevice, tvNotice;
    private ImageView ivLeft, ivRight;

    private FragmentManager fragmentManager;
    private Fragment mCurShowFragment;

    private DeviceFragment mDeviceFragment;
    private NoticeFragment mNoticeFragment;

    private String msgType = "device";

    private String[] clearArr;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ilop_mine_activity_message);
        fragmentManager = getSupportFragmentManager();

        initView();
        initListener();
        initData();
    }

    private void initView() {
        topBar = findViewById(R.id.topbar);
        rlLeft = findViewById(R.id.rl_left);
        tvDevice = findViewById(R.id.tv_device);
        ivLeft = findViewById(R.id.iv_left);
        rlRight = findViewById(R.id.rl_right);
        ivRight = findViewById(R.id.iv_right);
        tvNotice = findViewById(R.id.tv_notice);
    }

    private void initListener() {

        topBar.setOnLeftClickListener(this);
        topBar.setOnRightClickListener(this);
        rlLeft.setOnClickListener(this);
        rlRight.setOnClickListener(this);
    }

    private void initData() {
        initLeftStatus();
    }

    @Override
    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.rl_left) {
            initLeftStatus();
        } else if (i == R.id.rl_right) {
            initRightStatus();
        }
    }

    @Override
    public void onLeftClick() {
        onBackPressed();
    }

    @Override
    public void onRightClick() {
        initCancelDialog();
    }

    /**
     * 左状态
     */
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void initLeftStatus() {
        msgType = DEVICE;
        rlLeft.setBackground(getResources().getDrawable(R.drawable.shape_message_left));
        rlRight.setBackground(null);
        tvDevice.setTextColor(Color.parseColor("#ffffff"));
        tvNotice.setTextColor(Color.parseColor("#1FC88B"));
        ivLeft.setVisibility(View.GONE);
        if (mDeviceFragment == null)
            mDeviceFragment = DeviceFragment.newInstance(DEVICE);
        replaceChartFragment(mDeviceFragment);
    }

    /**
     * 右状态
     */
    private void initRightStatus() {
        msgType = NOTICE;
        rlRight.setBackground(getResources().getDrawable(R.drawable.shape_message_right));
        rlLeft.setBackground(null);
        tvNotice.setTextColor(Color.parseColor("#ffffff"));
        tvDevice.setTextColor(Color.parseColor("#1FC88B"));
        ivRight.setVisibility(View.GONE);
        if (mNoticeFragment == null)
            mNoticeFragment = NoticeFragment.newInstance(NOTICE);
        replaceChartFragment(mNoticeFragment);
    }

    private void initCancelDialog() {
        if (clearArr == null) {
            clearArr = getResources().getStringArray(R.array.array_message);
        }
        new BottomPopUpDialog.Builder()
                .setDialogData(clearArr)
                .setCallBackDismiss(true)
                .setItemTextColor(0, R.color.text_gray)
                .setItemTextColor(1, R.color.text_red)
                .setItemOnListener(new BottomPopUpDialog.BottomPopDialogOnClickListener() {
                    @Override
                    public void onDialogClick(String tag) {
                        clearMessage();
                    }

                    @Override
                    public void onCancleClick() {
                    }
                })
                .show(getSupportFragmentManager(), BottomPopUpDialog.class.getSimpleName());

    }

    /**
     * 清空消息
     */
    private void clearMessage() {
        Api.getInstance().clearMessage(msgType, new IoTCallback() {
            @Override
            public void onFailure(IoTRequest ioTRequest, Exception e) {
                ExceptionToast.toastNetworkException(getBaseContext(), e);
            }

            @Override
            public void onResponse(IoTRequest ioTRequest, IoTResponse ioTResponse) {
                clearResult(ioTResponse);
            }
        });
    }

    /**
     * 清空消息返回处理
     *
     * @param ioTResponse
     */
    private void clearResult(final IoTResponse ioTResponse) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (ioTResponse.getCode() != ResponseCode.SUCCEED_CODE) {
                    LinkToast.makeText(getBaseContext(), ioTResponse.getLocalizedMsg(), Toast.LENGTH_SHORT).show();
                    return;
                }
                if (msgType.equals(DEVICE)) {
                    initLeftStatus();
                    mDeviceFragment.loadData();
                } else {
                    initRightStatus();
                    mNoticeFragment.loadData();
                }

            }
        });
    }


    private void replaceChartFragment(Fragment fragment) {
        if (mCurShowFragment == fragment) {
            return;
        }

        FragmentTransaction transaction = fragmentManager.beginTransaction();

        if (!fragment.isAdded()) {
            transaction.add(R.id.fl_content, fragment);
        }

        if (mCurShowFragment != null) {
            transaction.hide(mCurShowFragment);
        }

        if (fragment.isHidden()) {
            transaction.show(fragment);
        }

        transaction.commit();

        mCurShowFragment = fragment;
    }
}
