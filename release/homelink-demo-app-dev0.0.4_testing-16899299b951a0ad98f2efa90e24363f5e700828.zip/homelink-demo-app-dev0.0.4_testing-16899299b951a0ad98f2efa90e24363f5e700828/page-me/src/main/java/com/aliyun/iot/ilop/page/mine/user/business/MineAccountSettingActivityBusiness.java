package com.aliyun.iot.ilop.page.mine.user.business;


import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import com.alibaba.sdk.android.openaccount.OpenAccountSDK;
import com.alibaba.sdk.android.openaccount.util.ResourceUtils;
import com.aliyun.iot.aep.sdk.EnvConfigure;
import com.aliyun.iot.aep.sdk.login.LoginBusiness;
import com.aliyun.iot.aep.sdk.login.data.UserInfo;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.ilop.page.mine.MineConstants;


public class MineAccountSettingActivityBusiness {


    private static final String TAG = MineAccountSettingActivityBusiness.class.getSimpleName();
    private Handler mHandler;
    private static final String CODE_CHINA = "86";

    public MineAccountSettingActivityBusiness(Handler handler) {
        this.mHandler = handler;
    }


    public void requestPersonInfo() {
       UserInfo userInfo= LoginBusiness.getUserInfo();

        if (null != userInfo && null != mHandler) {
            Message.obtain(mHandler, MineConstants.MINE_MESSAGE_RESPONSE_PERSONINFO_SUCCESS, userInfo).sendToTarget();
        } else {
            ALog.e(TAG, "用户信息获取失败");
            Message.obtain(mHandler, MineConstants.MINE_MESSAGE_RESPONSE_PERSONINFO_FAILED).sendToTarget();
        }
    }

    public void requestRegion() {
        String region = EnvConfigure.getEnvArg("countryName");
        if (TextUtils.isEmpty(region)) {
            SharedPreferences sp = OpenAccountSDK.getAndroidContext().getSharedPreferences("ilop_sp", 0);
            region = sp.getString("codeSelected", "");
        }

        if (TextUtils.isEmpty(region)) {
            region = ResourceUtils.getString("mine_current_region_china");
        } else if (region.equalsIgnoreCase(CODE_CHINA)) {
            region = ResourceUtils.getString("mine_current_region_china");
        } else {
            region = ResourceUtils.getString("mine_current_region_international");
        }
        Message.obtain(mHandler, MineConstants.MINE_MESSAGE_RESPONSE_REGION_SUCCESS, region).sendToTarget();

    }


}
