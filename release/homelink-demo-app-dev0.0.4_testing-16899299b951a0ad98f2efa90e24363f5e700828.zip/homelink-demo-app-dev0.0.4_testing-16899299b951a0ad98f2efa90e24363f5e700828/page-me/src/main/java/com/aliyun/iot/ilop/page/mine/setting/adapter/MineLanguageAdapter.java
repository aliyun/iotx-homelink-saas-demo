package com.aliyun.iot.ilop.page.mine.setting.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import com.aliyun.iot.ilop.page.mine.setting.adapter.holder.BaseViewHolder;
import com.aliyun.iot.ilop.page.mine.setting.adapter.holder.LanguageViewHolder;
import com.aliyun.iot.ilop.page.mine.setting.bean.LanguageModel;
import com.aliyun.iot.ilop.page.mine.view.MineLanguageItem;

/**
 * Created by david on 2018/4/11.
 *
 * @author david
 * @date 2018/04/11
 */
public class MineLanguageAdapter extends BaseAdapter<LanguageModel> {
    private List<LanguageModel> mList = new ArrayList<>();
    private Context mContext;
    private OnItemClickListener mItemClickListener;

    public MineLanguageAdapter(Context context) {
        mContext = context;
    }

    public void setData(List<LanguageModel> list) {
        mList = list;

        notifyDataSetChanged();
    }

    @Override
    public BaseViewHolder<LanguageModel> onCreateViewHolder(ViewGroup parent, int viewType) {
        View root = new MineLanguageItem(mContext);
        LanguageViewHolder holder = new LanguageViewHolder(root);
        return holder;
    }

    @Override
    public void onBindViewHolder(BaseViewHolder<LanguageModel> holder, final int position) {
        if (null == holder) {
            return;
        }

        if (null != mItemClickListener) {

            holder.itemView.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (null != mItemClickListener) {
                        mItemClickListener.onItemClick(mList.get(position), position);
                    }
                }
            });
        } else {
            holder.itemView.setOnClickListener(null);
        }

        boolean maybeLatest = (position == mList.size() - 1);
        holder.bindData(mList.get(position), maybeLatest);
    }

    @Override
    public int getItemCount() {
        if (null == mList) {
            return 0;
        }
        return mList.size();
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mItemClickListener = listener;
    }

    public interface OnItemClickListener {
        void onItemClick(LanguageModel data, int position);
    }
}
