package com.aliyun.iot.ilop.page.mine.home.bean;

import java.io.Serializable;
import java.util.HashMap;

/**
 * Created by david on 2018/4/19.
 *
 * @author david
 * @date 2018/04/19
 */
public class UpgradeVersionInfo implements Serializable{
    public int versionCode;
    public String url;
    public String versionName;
    public HashMap<String, Object> desc = new HashMap<>();
    public String timestamp;
    public String apkUrl;
}
