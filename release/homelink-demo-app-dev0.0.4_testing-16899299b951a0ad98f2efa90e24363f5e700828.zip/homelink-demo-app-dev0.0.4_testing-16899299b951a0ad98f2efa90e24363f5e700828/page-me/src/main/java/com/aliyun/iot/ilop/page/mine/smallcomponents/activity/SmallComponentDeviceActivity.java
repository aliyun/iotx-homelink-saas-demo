package com.aliyun.iot.ilop.page.mine.smallcomponents.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.base.MineBaseActivity;
import com.aliyun.iot.ilop.page.mine.smallcomponents.adapter.SmallComponentAddDeviceAdapter;
import com.aliyun.iot.ilop.page.mine.smallcomponents.adapter.SmallComponentNotDeviceAddAdapter;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.ComponentProductDTO;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.PropertyBean;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.SmallComponentDeviceBean;
import com.aliyun.iot.ilop.page.mine.smallcomponents.handler.SmallComponentDeviceHandler;
import com.aliyun.iot.ilop.page.mine.smallcomponents.interfaces.ISmallComponentDevicePage;
import com.aliyun.iot.ilop.page.mine.view.XExpandableListView;
import com.aliyun.iot.link.ui.component.simpleLoadview.LinkSimpleLoadView;
import com.aliyun.iot.utils.AppWidgetHelper;

import java.util.ArrayList;
import java.util.List;

public class SmallComponentDeviceActivity extends MineBaseActivity implements ISmallComponentDevicePage, View.OnClickListener, ExpandableListView.OnChildClickListener {

    private ImageView iv_add_device_back;
    private TextView tv_save_device;
    private TextView tv_device_num;
    private RecyclerView recy_add_device;
    private LinearLayout ll_no_device;
    private XExpandableListView lv_device_view;
    private ArrayList<SmallComponentDeviceBean> device_add_list = new ArrayList();
    private ArrayList device_not_add_list = new ArrayList();
    private SmallComponentAddDeviceAdapter addDeviceAdapter;
    private SmallComponentNotDeviceAddAdapter notAddDeviceAdapter;
    private int current_drag_position = 0;
    private SmallComponentDeviceHandler smallComponentDeviceHandler;
    private int currentLoading = 0;
    private LinkSimpleLoadView loading_view;
    private int page = 0;
    private int size = 20;
    private final int RESULT_OK = 201;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ilop_mine_small_component_device_activity);

    }

    @Override
    protected void initView() {
        iv_add_device_back = findViewById(R.id.iv_add_device_back);
        tv_save_device = findViewById(R.id.tv_save_device);
        tv_device_num = findViewById(R.id.tv_device_num);
        recy_add_device = findViewById(R.id.recy_add_device);
        ll_no_device = findViewById(R.id.ll_no_device);
        lv_device_view = findViewById(R.id.lv_device_view);
        loading_view = findViewById(R.id.loading_view);
    }

    @Override
    protected void initData() {
        recordSceneNum();
        recy_add_device.setLayoutManager(new GridLayoutManager(this, 4));
        /*addDeviceAdapter = new SmallComponentAddDeviceAdapter(device_add_list, this);
        recy_add_device.setAdapter(addDeviceAdapter);
        notAddDeviceAdapter = new SmallComponentNotDeviceAddAdapter(device_not_add_list, this);
        lv_device_view.setAdapter(notAddDeviceAdapter);*/
       /* mineLoadingDialog = new MineLoadingDialog(this);
        mineLoadingDialog.setProgressMesssage(R.string.mine_tp_loading);*/
    }

    @Override
    protected void initEvent() {
        iv_add_device_back.setOnClickListener(this);
        tv_save_device.setOnClickListener(this);
        //1.创建item helper
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(callback);
        // 2.绑定到recyclerview上面去
        itemTouchHelper.attachToRecyclerView(recy_add_device);
        // 3.在ItemHelper的接口回调中过滤开启长按拖动，拓展其他操作
        lv_device_view.setOnChildClickListener(this);
        lv_device_view.setLoadingMoreEnabled(true);
        lv_device_view.setPullRefreshEnabled(false);
        lv_device_view.setmLoadingListener(new XExpandableListView.LoadingListener() {
            @Override
            public void onLoadMore() {
                page++;
                smallComponentDeviceHandler.refresDeviceData(page, size);
            }

            @Override
            public void onRefresh() {

            }
        });
    }

    @Override
    protected void initHandler() {
        smallComponentDeviceHandler = new SmallComponentDeviceHandler(this);
    }

    /**
     * 记录添加设备个数
     */
    private void recordSceneNum() {
        tv_device_num.setText(device_add_list.size() + "");
        if (device_not_add_list.size() > 0) {
            ll_no_device.setVisibility(View.GONE);
            lv_device_view.setVisibility(View.VISIBLE);
        } else {
            ll_no_device.setVisibility(View.VISIBLE);
            lv_device_view.setVisibility(View.GONE);
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.iv_add_device_back) {
            this.finish();
        } else if (v.getId() == R.id.tv_save_device) {

            ArrayList list = new ArrayList();
            for (int i = 0; i < device_add_list.size(); i++) {
                list.add(new ComponentProductDTO(device_add_list.get(i)));
            }
            smallComponentDeviceHandler.updateComponentProprety(list);
        }
    }

    //itemHelper的回调
    ItemTouchHelper.Callback callback = new ItemTouchHelper.Callback() {
        /**
         *官方文档的说明如下：
         *
         o control
         which actions
         user can
         take on
         each view, you
         should override

         getMovementFlags(RecyclerView, View
         Holder)
         *and return
         appropriate set
         of direction flags.(LEFT,RIGHT,START,END,UP,DOWN).
         *返回我们要监控的方向，上下左右，我们做的是上下拖动，要返回都是UP和DOWN
         *关键坑爹的是下面方法返回值只有1个，也就是说只能监控一个方向。
         *不过点入到源码里面有惊喜。源码标记方向如下：
         *
         public static final int UP = 1     0001
         *
         public static final int DOWN = 1 << 1; （位运算：值其实就是2）0010
         *
         public static final int LEFT = 1 << 2
         左 值是3
         *
         public static final int RIGHT = 1 << 3
         右 值是8
         */

        @Override
        public int getMovementFlags(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {
            //也就是说返回值是组合式的
            // makeMovementFlags (int dragFlags, int swipeFlags)，看下面的解释说明
            // int swipFlag=ItemTouchHelper.LEFT|ItemTouchHelper.RIGHT;
            //如果也监控左右方向的话，swipFlag=ItemTouchHelper.LEFT|ItemTouchHelper.RIGHT;
            //int dragflag = ItemTouchHelper.UP | ItemTouchHelper.DOWN;
            int dragflag = ItemTouchHelper.UP | ItemTouchHelper.DOWN |
                    ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT;
            int swipFlag = 0;
            //等价于：0001&0010;多点触控标记触屏手指的顺序和个数也是这样标记哦
            current_drag_position = viewHolder.getAdapterPosition();
            return makeMovementFlags(dragflag, swipFlag); /**
             *备注：由getMovementFlags可以联想到setMovementFlags，不过文档么有这个方法，但是：
             *有 makeMovementFlags ( int dragFlags, int swipeFlags)
             *Convenience method to create movement flags.便捷方法创建moveMentFlag
             * For instance,if you want to let your items be drag &dropped vertically
             and swiped
             left to be dismissed,
             *you can call this method with:makeMovementFlags(UP | DOWN, LEFT);
             *这个recyclerview的文档写的简直完美，示例代码都弄好了！！！
             *如果你想让item上下拖动和左边滑动删除，应该这样用：makeMovementFlags(UP | DOWN, LEFT)
             */
            //拓展一下：如果只想上下的话：makeMovementFlags（UP | DOWN, 0）,标记方向的最小值1
        }

        /**
         *官方文档的说明如下
         * If user drags an item, ItemTouchHelper will call
         onMove(recyclerView, dragged, target).Upon receiving this callback,
         *you should move the item from the old position(dragged.getAdapterPosition()) to
         new position(target.getAdapterPosition())
         * in your adapter and also call notifyItemMoved ( int,int).
         *拖动某个item的回调，在return前要更新item位置，调用notifyItemMoved（draggedPosition，targetPosition）
         *viewHolde:
         正在拖动item
         * target：要拖到的目标
         * @return true 表示消费事件
         */
        @Override
        public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {

            if (target.getAdapterPosition() < device_add_list.size()) {
                int viewHolderAdapterPosition = viewHolder.getAdapterPosition();
                int targetAdapterPosition = target.getAdapterPosition();
                //直接按照文档来操作啊，这文档写得太给力了,简直完美！
                addDeviceAdapter.notifyItemMoved(viewHolder.getAdapterPosition(), target.getAdapterPosition());
                //注意这里有个坑的，itemView 都移动了，对应的数据也要移动
                SmallComponentDeviceBean smallComponentDeviceBean = device_add_list.get(viewHolderAdapterPosition);
                device_add_list.remove(smallComponentDeviceBean);
                device_add_list.add(targetAdapterPosition, smallComponentDeviceBean);
                // Collections.swap(device_add_list, viewHolder.getAdapterPosition(), target.getAdapterPosition());

            }
            return true;
        }

        /**
         *谷歌官方文档说明如下：
         *这个看了一下主要是做左右拖动的回调
         * When a View is swiped, ItemTouchHelper animates it until it goes out
         of bounds, then calls onSwiped (ViewHolder,int).
         *At this point, you should update your adapter (e.g.remove the item)and call
         related Adapter#notify event.
         *@param viewHolder
         * @param direction
         */
        @Override
        public void onSwiped(RecyclerView.ViewHolder viewHolder,
                             int direction) {
            //暂不处理
        }

        /**
         *官方文档如下：返回true 当前tiem可以被拖动到目标位置后，直接”落“在target上，其他的上面的tiem跟着“落”，
         *所以要重写这个方法，不然只是拖动的tiem在动，target tiem不动，静止的
         * Return true if the current ViewHolder can be dropped over the the target
         ViewHolder.
         * @param recyclerView
         * @param current
         * @param target
         * @return
         */
        @Override
        public boolean canDropOver(RecyclerView recyclerView, RecyclerView.ViewHolder
                current, RecyclerView.ViewHolder target) {
            return true;
        }

        /**
         * 官方文档说明如下：
         * Returns whether ItemTouchHelper should start a drag and drop operation if an item is long pressed.
         * 是否开启长按 拖动
         * @return
         */
        @Override
        public boolean isLongPressDragEnabled() {
            //return true后，可以实现长按拖动排序和拖动动画了
            if (current_drag_position >= device_add_list.size()) {
                return false;
            }
            return true;
        }
    };

    @Override
    public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {

        SmallComponentDeviceBean deviceBean_not_add = (SmallComponentDeviceBean) device_not_add_list.get(groupPosition);
        if (deviceBean_not_add.getSwitchList() != null && deviceBean_not_add.getSwitchList().size() > 0) {
            PropertyBean propertyBean = deviceBean_not_add.getSwitchList().get(childPosition);
            boolean alreay = false;
            for (int i = 0; i < device_add_list.size(); i++) {
                SmallComponentDeviceBean deviceBean_add = (SmallComponentDeviceBean) device_add_list.get(i);
                if (deviceBean_add.getIotId().equals(deviceBean_not_add.getIotId())) {
                    alreay = true;
                    List<PropertyBean> propertyBeans = deviceBean_add.getSwitchList();
                    if (propertyBean.isCheck()) {
                        for (int j = 0; j < propertyBeans.size(); j++) {
                            if (propertyBeans.get(j).getPropertyIdentifier().equalsIgnoreCase(propertyBean.getPropertyIdentifier())) {
                                propertyBeans.remove(j);
                            }
                        }

                        if (propertyBeans.size() == 0) {
                            device_add_list.remove(i);
                        }
                    } else {
                        if (propertyBeans.size() >= 5) {
                            Toast toast = new Toast(this);
                            View view = LayoutInflater.from(this).inflate(R.layout.ilop_mine_small_component_toast, null);
                            TextView textView = view.findViewById(R.id.tv_toast);
                            textView.setText(R.string.appExtension_device_switch_max);
                            toast.setView(view);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                            return false;
                        }
                        propertyBeans.add(propertyBean);
                    }
                    break;
                }
            }
            if (!alreay) {
                if (device_add_list.size() >= 8) {
                    Toast toast = new Toast(this);
                    View view = LayoutInflater.from(this).inflate(R.layout.ilop_mine_small_component_toast, null);
                    TextView textView = view.findViewById(R.id.tv_toast);
                    textView.setText(R.string.appExtension_device_max);
                    toast.setView(view);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    return false;
                }
                ArrayList arrayList = new ArrayList();
                arrayList.add(propertyBean);
                SmallComponentDeviceBean deviceBean = deviceBean_not_add.copy();
                deviceBean.setSwitchList(arrayList);
                device_add_list.add(deviceBean);
            }

            propertyBean.setCheck(!propertyBean.isCheck());

            addDeviceAdapter.notifyDataSetChanged();
            notAddDeviceAdapter.notifyDataSetChanged();
            recordSceneNum();
        }
        return false;
    }


    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        smallComponentDeviceHandler.refreshData(page, size);
    }

    @Override
    public void showDeviceList(ArrayList<SmallComponentDeviceBean> list) {
        device_not_add_list = list;
        recordSceneNum();
        notAddDeviceAdapter = new SmallComponentNotDeviceAddAdapter(device_not_add_list, this);
        lv_device_view.setAdapter(notAddDeviceAdapter);
        if ((device_not_add_list.size() % size) != 0) {
            lv_device_view.setNoMore(true);
        }
    }

    @Override
    public void showAddDeviceList(ArrayList<SmallComponentDeviceBean> list) {
        this.device_add_list = list;
        recordSceneNum();
        addDeviceAdapter = new SmallComponentAddDeviceAdapter(device_add_list, this);
        recy_add_device.setAdapter(addDeviceAdapter);
        addDeviceAdapter.setOnDeteleDeviceListener(new SmallComponentAddDeviceAdapter.OnDeteleDeviceListener() {
            @Override
            public void onDeleteDevice(int position) {
                SmallComponentDeviceBean smallComponentDeviceBean = (SmallComponentDeviceBean) device_add_list.get(position);
                device_add_list.remove(position);
                for (Object deviceBean : device_not_add_list) {
                    SmallComponentDeviceBean deviceBean1 = (SmallComponentDeviceBean) deviceBean;
                    if (deviceBean1.getIotId().equals(smallComponentDeviceBean.getIotId())) {
                        for (PropertyBean propertyBean : deviceBean1.getSwitchList()) {
                            propertyBean.setCheck(false);
                        }
                        break;
                    }
                }
                addDeviceAdapter.notifyDataSetChanged();
                notAddDeviceAdapter.notifyDataSetChanged();
                recordSceneNum();
            }
        });
    }

    @Override
    public void showError(@Nullable String msg) {
        if (null != msg) {
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.mine_network_error, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void updateSuccess() {
        AppWidgetHelper.refreshDeviceWidget(this, "GETDEVICELIST");
        //数据是使用Intent返回
        Intent intent = new Intent();
        //把返回数据存入Intent
        //设置返回数据
        this.setResult(RESULT_OK, intent);
        this.finish();
    }

    @Override
    public void showLoading(int num) {
        currentLoading += num;
        /* mineLoadingDialog.show();*/
        loading_view.showLoading(getResources().getString(R.string.mine_tp_loading));
    }

    @Override
    public void hideLoading() {
        currentLoading--;
        if (currentLoading <= 0) {
            //mineLoadingDialog.dismiss();
            loading_view.hide();
        }
    }

    @Override
    public void setNoMore() {
        lv_device_view.setNoMore(true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (smallComponentDeviceHandler != null) {
            smallComponentDeviceHandler.destroy();
        }
       /* if (mineLoadingDialog.isShowing()) {
            currentLoading = 0;
            mineLoadingDialog.dismiss();
        }*/
    }
}
