package com.aliyun.iot.ilop.page.mine.smallcomponents.bean;

public class PropertyQueryDTO {

    private String dataType;
    private String I18Language;
    private String languageList;
    private String allLanguage;
    private String replaceOrigin;

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getI18Language() {
        return I18Language;
    }

    public void setI18Language(String i18Language) {
        I18Language = i18Language;
    }

    public String getLanguageList() {
        return languageList;
    }

    public void setLanguageList(String languageList) {
        this.languageList = languageList;
    }

    public String getAllLanguage() {
        return allLanguage;
    }

    public void setAllLanguage(String allLanguage) {
        this.allLanguage = allLanguage;
    }

    public String getReplaceOrigin() {
        return replaceOrigin;
    }

    public void setReplaceOrigin(String replaceOrigin) {
        this.replaceOrigin = replaceOrigin;
    }
}
