package com.aliyun.iot.ilop.page.mine.smallcomponents.service;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.smallcomponents.appwidgetprovider.SmallComponentDeviceAppWidget;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.PropertyBean;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.SmallComponentDeviceBean;
import com.aliyun.iot.utils.BitmapUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SmallComponentDeviceService extends RemoteViewsService {

    private Map<String, Bitmap> bitmapMap = new HashMap<>();

    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new SmallComponentDeviceFactory(this.getApplicationContext());
    }

    private class SmallComponentDeviceFactory implements RemoteViewsFactory {

        private Context context;
        private ArrayList<SmallComponentDeviceBean> smallComponentDeviceBeanList = new ArrayList<>();
        private int current = -1;


        public SmallComponentDeviceFactory(Context context) {
            this.context = context;
        }

        @Override
        public void onCreate() {

        }

        @Override
        public void onDataSetChanged() {

        }

        @Override
        public void onDestroy() {

        }

        @Override
        public int getCount() {
            return 1;
        }

        @Override
        public RemoteViews getViewAt(int position) {
            RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.small_component_device_item);
            smallComponentDeviceBeanList = SmallComponentDeviceAppWidget.getDeviceList();
            current = SmallComponentDeviceAppWidget.getCurrentPosition();
            if (smallComponentDeviceBeanList.size() == 0) {
                //显示去设置按钮
            } else {
                setContext(remoteViews);
            }
            return remoteViews;
        }

        @Override
        public RemoteViews getLoadingView() {
            return getViewAt(0);
        }

        @Override
        public int getViewTypeCount() {
            return 1;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }


        private void setContext(RemoteViews remoteViews) {

            remoteViews.setViewVisibility(R.id.ll_device_list2, View.GONE);
            remoteViews.setViewVisibility(R.id.ll_triangle_list2, View.GONE);
            remoteViews.setViewVisibility(R.id.ll_device_swicth_list2, View.GONE);
            switch (smallComponentDeviceBeanList.size()) {
                case 1:
                    setViewVisibility(remoteViews, new int[]{R.id.ll_device1}, new int[]{R.id.ll_device2, R.id.ll_device3, R.id.ll_device4}, new int[]{});
                    setDeviceInfo(remoteViews, 0);
                    break;
                case 2:
                    setViewVisibility(remoteViews, new int[]{R.id.ll_device1, R.id.ll_device2}, new int[]{R.id.ll_device3, R.id.ll_device4}, new int[]{});
                    setDeviceInfo(remoteViews, 0);
                    setDeviceInfo(remoteViews, 1);
                    break;
                case 3:
                    setViewVisibility(remoteViews, new int[]{R.id.ll_device1, R.id.ll_device2, R.id.ll_device3}, new int[]{R.id.ll_device4}, new int[]{});
                    setDeviceInfo(remoteViews, 0);
                    setDeviceInfo(remoteViews, 1);
                    setDeviceInfo(remoteViews, 2);
                    break;
                default:
                    setViewVisibility(remoteViews, new int[]{R.id.ll_device1, R.id.ll_device2, R.id.ll_device3, R.id.ll_device4}, new int[]{}, new int[]{});
                    setDeviceInfo(remoteViews, 0);
                    setDeviceInfo(remoteViews, 1);
                    setDeviceInfo(remoteViews, 2);
                    setDeviceInfo(remoteViews, 3);
                    break;
            }

            if (smallComponentDeviceBeanList.size() > 4) {
                remoteViews.setViewVisibility(R.id.ll_device_list2, View.VISIBLE);
                switch (smallComponentDeviceBeanList.size()) {
                    case 5:
                        setViewVisibility(remoteViews, new int[]{R.id.ll_device5}, new int[]{R.id.ll_device6, R.id.ll_device7, R.id.ll_device8}, new int[]{});
                        setDeviceInfo(remoteViews, 4);
                        break;
                    case 6:
                        setViewVisibility(remoteViews, new int[]{R.id.ll_device5, R.id.ll_device6}, new int[]{R.id.ll_device7, R.id.ll_device8}, new int[]{});
                        setDeviceInfo(remoteViews, 4);
                        setDeviceInfo(remoteViews, 5);
                        break;
                    case 7:
                        setViewVisibility(remoteViews, new int[]{R.id.ll_device5, R.id.ll_device6, R.id.ll_device7}, new int[]{R.id.ll_device8}, new int[]{});
                        setDeviceInfo(remoteViews, 4);
                        setDeviceInfo(remoteViews, 5);
                        setDeviceInfo(remoteViews, 6);
                        break;
                    case 8:
                        setViewVisibility(remoteViews, new int[]{R.id.ll_device5, R.id.ll_device6, R.id.ll_device7, R.id.ll_device8}, new int[]{}, new int[]{});
                        setDeviceInfo(remoteViews, 4);
                        setDeviceInfo(remoteViews, 5);
                        setDeviceInfo(remoteViews, 6);
                        setDeviceInfo(remoteViews, 7);
                        break;
                }
            }
            //控制按钮显示
            switch (current) {
                case -1:
                    setViewVisibility(remoteViews, new int[]{}, new int[]{}, new int[]{R.id.ll_triangle_list1, R.id.ll_device_swicth_list1, R.id.ll_triangle_list2, R.id.ll_device_swicth_list2});
                    break;
                case 0:
                    setViewVisibility(remoteViews,
                            new int[]{R.id.ll_triangle_list1, R.id.ll_device_swicth_list1, R.id.ll_triangle1},
                            new int[]{R.id.ll_triangle2, R.id.ll_triangle3, R.id.ll_triangle4},
                            new int[]{R.id.ll_triangle_list2, R.id.ll_device_swicth_list2});
                    setSwitch(1, remoteViews);
                    break;
                case 1:
                    setViewVisibility(remoteViews,
                            new int[]{R.id.ll_triangle_list1, R.id.ll_device_swicth_list1, R.id.ll_triangle2},
                            new int[]{R.id.ll_triangle1, R.id.ll_triangle3, R.id.ll_triangle4},
                            new int[]{R.id.ll_triangle_list2, R.id.ll_device_swicth_list2});
                    setSwitch(1, remoteViews);
                    break;
                case 2:
                    setViewVisibility(remoteViews,
                            new int[]{R.id.ll_triangle_list1, R.id.ll_device_swicth_list1, R.id.ll_triangle3},
                            new int[]{R.id.ll_triangle1, R.id.ll_triangle2, R.id.ll_triangle4},
                            new int[]{R.id.ll_triangle_list2, R.id.ll_device_swicth_list2});
                    setSwitch(1, remoteViews);
                    break;
                case 3:
                    setViewVisibility(remoteViews,
                            new int[]{R.id.ll_triangle_list1, R.id.ll_device_swicth_list1, R.id.ll_triangle4},
                            new int[]{R.id.ll_triangle1, R.id.ll_triangle2, R.id.ll_triangle3},
                            new int[]{R.id.ll_triangle_list2, R.id.ll_device_swicth_list2});
                    setSwitch(1, remoteViews);
                    break;
                case 4:
                    setViewVisibility(remoteViews,
                            new int[]{R.id.ll_triangle_list2, R.id.ll_device_swicth_list2, R.id.ll_triangle5},
                            new int[]{R.id.ll_triangle6, R.id.ll_triangle7, R.id.ll_triangle8},
                            new int[]{R.id.ll_triangle_list1, R.id.ll_device_swicth_list1});
                    setSwitch(2, remoteViews);
                    break;
                case 5:
                    setViewVisibility(remoteViews,
                            new int[]{R.id.ll_triangle_list2, R.id.ll_device_swicth_list2, R.id.ll_triangle6},
                            new int[]{R.id.ll_triangle5, R.id.ll_triangle7, R.id.ll_triangle8},
                            new int[]{R.id.ll_triangle_list1, R.id.ll_device_swicth_list1});
                    setSwitch(2, remoteViews);
                    break;
                case 6:
                    setViewVisibility(remoteViews,
                            new int[]{R.id.ll_triangle_list2, R.id.ll_device_swicth_list2, R.id.ll_triangle7},
                            new int[]{R.id.ll_triangle5, R.id.ll_triangle6, R.id.ll_triangle8},
                            new int[]{R.id.ll_triangle_list1, R.id.ll_device_swicth_list1});
                    setSwitch(2, remoteViews);
                    break;
                case 7:
                    setViewVisibility(remoteViews,
                            new int[]{R.id.ll_triangle_list2, R.id.ll_device_swicth_list2, R.id.ll_triangle8},
                            new int[]{R.id.ll_triangle5, R.id.ll_triangle6, R.id.ll_triangle7},
                            new int[]{R.id.ll_triangle_list1, R.id.ll_device_swicth_list1});
                    setSwitch(2, remoteViews);
                    break;
            }
        }


        private void setSwitch(int tag, RemoteViews remoteViews) {
            int switchsize = smallComponentDeviceBeanList.get(current).getSwitchList().size();
            if (tag == 1) {
                switch (switchsize) {
                    case 0:
                        setViewVisibility(remoteViews,
                                new int[]{},
                                new int[]{R.id.ll_device_switch1, R.id.ll_device_switch2, R.id.ll_device_switch3, R.id.ll_device_switch4, R.id.ll_device_switch5},
                                new int[]{});
                        break;
                    case 1:
                        setViewVisibility(remoteViews,
                                new int[]{R.id.ll_device_switch1},
                                new int[]{R.id.ll_device_switch2, R.id.ll_device_switch3, R.id.ll_device_switch4, R.id.ll_device_switch5},
                                new int[]{});
                        setDeviceSwitch(remoteViews, 0);
                        break;
                    case 2:
                        setViewVisibility(remoteViews,
                                new int[]{R.id.ll_device_switch1, R.id.ll_device_switch2},
                                new int[]{R.id.ll_device_switch3, R.id.ll_device_switch4, R.id.ll_device_switch5},
                                new int[]{});
                        setDeviceSwitch(remoteViews, 0);
                        setDeviceSwitch(remoteViews, 1);
                        break;
                    case 3:
                        setViewVisibility(remoteViews,
                                new int[]{R.id.ll_device_switch1, R.id.ll_device_switch2, R.id.ll_device_switch3},
                                new int[]{R.id.ll_device_switch4, R.id.ll_device_switch5},
                                new int[]{});
                        setDeviceSwitch(remoteViews, 0);
                        setDeviceSwitch(remoteViews, 1);
                        setDeviceSwitch(remoteViews, 2);
                        break;
                    case 4:
                        setViewVisibility(remoteViews,
                                new int[]{R.id.ll_device_switch1, R.id.ll_device_switch2, R.id.ll_device_switch3, R.id.ll_device_switch4},
                                new int[]{R.id.ll_device_switch5},
                                new int[]{});
                        setDeviceSwitch(remoteViews, 0);
                        setDeviceSwitch(remoteViews, 1);
                        setDeviceSwitch(remoteViews, 2);
                        setDeviceSwitch(remoteViews, 3);
                        break;
                    case 5:
                        setViewVisibility(remoteViews,
                                new int[]{R.id.ll_device_switch1, R.id.ll_device_switch2, R.id.ll_device_switch3, R.id.ll_device_switch4, R.id.ll_device_switch5},
                                new int[]{},
                                new int[]{});
                        setDeviceSwitch(remoteViews, 0);
                        setDeviceSwitch(remoteViews, 1);
                        setDeviceSwitch(remoteViews, 2);
                        setDeviceSwitch(remoteViews, 3);
                        setDeviceSwitch(remoteViews, 4);
                        break;
                }
            } else if (tag == 2) {
                switch (switchsize) {
                    case 0:
                        setViewVisibility(remoteViews,
                                new int[]{},
                                new int[]{R.id.ll_device_switch10, R.id.ll_device_switch6, R.id.ll_device_switch7, R.id.ll_device_switch8, R.id.ll_device_switch9},
                                new int[]{});
                        break;
                    case 1:
                        setViewVisibility(remoteViews,
                                new int[]{R.id.ll_device_switch6},
                                new int[]{R.id.ll_device_switch7, R.id.ll_device_switch8, R.id.ll_device_switch9, R.id.ll_device_switch10},
                                new int[]{});
                        setDeviceSwitch(remoteViews, 5);
                        break;
                    case 2:
                        setViewVisibility(remoteViews,
                                new int[]{R.id.ll_device_switch6, R.id.ll_device_switch7},
                                new int[]{R.id.ll_device_switch8, R.id.ll_device_switch9, R.id.ll_device_switch10},
                                new int[]{});
                        setDeviceSwitch(remoteViews, 5);
                        setDeviceSwitch(remoteViews, 6);
                        break;
                    case 3:
                        setViewVisibility(remoteViews,
                                new int[]{R.id.ll_device_switch6, R.id.ll_device_switch7, R.id.ll_device_switch8},
                                new int[]{R.id.ll_device_switch9, R.id.ll_device_switch10},
                                new int[]{});
                        setDeviceSwitch(remoteViews, 5);
                        setDeviceSwitch(remoteViews, 6);
                        setDeviceSwitch(remoteViews, 7);
                        break;
                    case 4:
                        setViewVisibility(remoteViews,
                                new int[]{R.id.ll_device_switch6, R.id.ll_device_switch7, R.id.ll_device_switch8, R.id.ll_device_switch9},
                                new int[]{R.id.ll_device_switch10},
                                new int[]{});
                        setDeviceSwitch(remoteViews, 5);
                        setDeviceSwitch(remoteViews, 6);
                        setDeviceSwitch(remoteViews, 7);
                        setDeviceSwitch(remoteViews, 8);
                        break;
                    case 5:
                        setViewVisibility(remoteViews,
                                new int[]{R.id.ll_device_switch6, R.id.ll_device_switch7, R.id.ll_device_switch8, R.id.ll_device_switch9, R.id.ll_device_switch10},
                                new int[]{},
                                new int[]{});
                        setDeviceSwitch(remoteViews, 5);
                        setDeviceSwitch(remoteViews, 6);
                        setDeviceSwitch(remoteViews, 7);
                        setDeviceSwitch(remoteViews, 8);
                        setDeviceSwitch(remoteViews, 9);
                        break;
                }
            }
        }

        private void setViewVisibility(RemoteViews remoteViews, int[] visibles, int[] invisibles, int[] gones) {
            for (int i = 0; i < visibles.length; i++) {
                remoteViews.setViewVisibility(visibles[i], View.VISIBLE);
            }
            for (int i = 0; i < invisibles.length; i++) {
                remoteViews.setViewVisibility(invisibles[i], View.INVISIBLE);
            }
            for (int i = 0; i < gones.length; i++) {
                remoteViews.setViewVisibility(gones[i], View.GONE);
            }
        }

        //设置显示开关按钮的点击事件
        private Intent setCheckClick(int position) {
            Intent intent = new Intent();
            intent.putExtra("CHECK_POSITION", position);
            if (current == position) {
                intent.putExtra("CHECK_POSITION", -1);
            }
            return intent;
        }


        //设置显示设备信息
        private void setDeviceInfo(final RemoteViews remoteViews, int position) {
            final SmallComponentDeviceBean smallComponentDeviceBean = smallComponentDeviceBeanList.get(position);
            if (smallComponentDeviceBean.getStatus() == 3 || smallComponentDeviceBean.getStatus() == 0 || smallComponentDeviceBean.getStatus() == 8) {
                if (current == position) {
                    current = -1;
                }
            }
            judgeDown(smallComponentDeviceBean);
            Bitmap bitmap = bitmapMap.get(smallComponentDeviceBean.getIotId());
            if (bitmap == null || "".equals(bitmap)) {
                bitmap = BitmapUtil.getBitMBitmap(smallComponentDeviceBean.getProductImage());
                bitmapMap.put(smallComponentDeviceBean.getIotId(), bitmap);
            }
            String nickName = smallComponentDeviceBean.getNickName();
            if (nickName == null) {
                nickName = smallComponentDeviceBean.getProductName();
            }
            switch (position) {
                case 0:
                    remoteViews.setTextViewText(R.id.tv_device1, nickName);
                    if (bitmap != null && !"".equals(bitmap)) {
                        remoteViews.setImageViewBitmap(R.id.iv_device1, bitmap);
                    } else {
                        remoteViews.setImageViewResource(R.id.iv_device1, R.drawable.ilop_mine_icon_default);
                    }
                    if (smallComponentDeviceBean.getStatus() == 1) {
                        //正常
                        if (smallComponentDeviceBean.getSwitchList().size() == 1) {
                            remoteViews.setImageViewResource(R.id.iv_device_state1, R.drawable.device_switch_open_one_app_widget);
                        } else {
                            remoteViews.setImageViewResource(R.id.iv_device_state1, R.drawable.device_switch_open_multiple_app_widget);
                        }
                    } else {
                        if (smallComponentDeviceBean.getSwitchList().size() == 1) {
                            remoteViews.setImageViewResource(R.id.iv_device_state1, R.drawable.device_switch_close_one_app_widget);
                        } else {
                            remoteViews.setImageViewResource(R.id.iv_device_state1, R.drawable.device_switch_close_multiple_app_widget);
                        }
                    }
                    if (smallComponentDeviceBean.getStatus() == 3 || smallComponentDeviceBean.getStatus() == 0 || smallComponentDeviceBean.getStatus() == 8) {
                        //离线
                        remoteViews.setViewVisibility(R.id.iv_device_mask1, View.VISIBLE);
                        remoteViews.setTextColor(R.id.tv_device1, getResources().getColor(R.color.mine_color_80000000));
                    } else {
                        remoteViews.setViewVisibility(R.id.iv_device_mask1, View.GONE);
                        remoteViews.setTextColor(R.id.tv_device1, getResources().getColor(R.color.mine_color_000000));
                        remoteViews.setOnClickFillInIntent(R.id.ll_device1, setCheckClick(0));
                    }

                    break;
                case 1:
                    remoteViews.setTextViewText(R.id.tv_device2, nickName);
                    if (bitmap != null && !"".equals(bitmap)) {
                        remoteViews.setImageViewBitmap(R.id.iv_device2, bitmap);
                    } else {
                        remoteViews.setImageViewResource(R.id.iv_device2, R.drawable.ilop_mine_icon_default);
                    }
                    if (smallComponentDeviceBean.getStatus() == 1) {
                        if (smallComponentDeviceBean.getSwitchList().size() == 1) {
                            remoteViews.setImageViewResource(R.id.iv_device_state2, R.drawable.device_switch_open_one_app_widget);
                        } else {
                            remoteViews.setImageViewResource(R.id.iv_device_state2, R.drawable.device_switch_open_multiple_app_widget);
                        }
                    } else {
                        if (smallComponentDeviceBean.getSwitchList().size() == 1) {
                            remoteViews.setImageViewResource(R.id.iv_device_state2, R.drawable.device_switch_close_one_app_widget);
                        } else {
                            remoteViews.setImageViewResource(R.id.iv_device_state2, R.drawable.device_switch_close_multiple_app_widget);
                        }
                    }
                    if (smallComponentDeviceBean.getStatus() == 3 || smallComponentDeviceBean.getStatus() == 0 || smallComponentDeviceBean.getStatus() == 8) {
                        //离线
                        remoteViews.setViewVisibility(R.id.iv_device_mask2, View.VISIBLE);
                        remoteViews.setTextColor(R.id.tv_device2, getResources().getColor(R.color.mine_color_80000000));
                    } else {
                        remoteViews.setViewVisibility(R.id.iv_device_mask2, View.GONE);
                        remoteViews.setTextColor(R.id.tv_device2, getResources().getColor(R.color.mine_color_000000));
                        remoteViews.setOnClickFillInIntent(R.id.ll_device2, setCheckClick(1));
                    }

                    break;
                case 2:
                    remoteViews.setTextViewText(R.id.tv_device3, nickName);
                    if (bitmap != null && !"".equals(bitmap)) {
                        remoteViews.setImageViewBitmap(R.id.iv_device3, bitmap);
                    } else {
                        remoteViews.setImageViewResource(R.id.iv_device3, R.drawable.ilop_mine_icon_default);
                    }
                    if (smallComponentDeviceBean.getStatus() == 1) {
                        if (smallComponentDeviceBean.getSwitchList().size() == 1) {
                            remoteViews.setImageViewResource(R.id.iv_device_state3, R.drawable.device_switch_open_one_app_widget);
                        } else {
                            remoteViews.setImageViewResource(R.id.iv_device_state3, R.drawable.device_switch_open_multiple_app_widget);
                        }
                    } else {
                        if (smallComponentDeviceBean.getSwitchList().size() == 1) {
                            remoteViews.setImageViewResource(R.id.iv_device_state3, R.drawable.device_switch_close_one_app_widget);
                        } else {
                            remoteViews.setImageViewResource(R.id.iv_device_state3, R.drawable.device_switch_close_multiple_app_widget);
                        }
                    }
                    if (smallComponentDeviceBean.getStatus() == 3 || smallComponentDeviceBean.getStatus() == 0 || smallComponentDeviceBean.getStatus() == 8) {
                        //离线
                        remoteViews.setViewVisibility(R.id.iv_device_mask3, View.VISIBLE);
                        remoteViews.setTextColor(R.id.tv_device3, getResources().getColor(R.color.mine_color_80000000));
                    } else {
                        remoteViews.setViewVisibility(R.id.iv_device_mask3, View.GONE);
                        remoteViews.setTextColor(R.id.tv_device3, getResources().getColor(R.color.mine_color_000000));
                        remoteViews.setOnClickFillInIntent(R.id.ll_device3, setCheckClick(2));
                    }
                    break;
                case 3:
                    remoteViews.setTextViewText(R.id.tv_device4, nickName);
                    if (bitmap != null && !"".equals(bitmap)) {
                        remoteViews.setImageViewBitmap(R.id.iv_device4, bitmap);
                    } else {
                        remoteViews.setImageViewResource(R.id.iv_device4, R.drawable.ilop_mine_icon_default);
                    }
                    if (smallComponentDeviceBean.getStatus() == 1) {
                        if (smallComponentDeviceBean.getSwitchList().size() == 1) {
                            remoteViews.setImageViewResource(R.id.iv_device_state4, R.drawable.device_switch_open_one_app_widget);
                        } else {
                            remoteViews.setImageViewResource(R.id.iv_device_state4, R.drawable.device_switch_open_multiple_app_widget);
                        }
                    } else {
                        if (smallComponentDeviceBean.getSwitchList().size() == 1) {
                            remoteViews.setImageViewResource(R.id.iv_device_state4, R.drawable.device_switch_close_one_app_widget);
                        } else {
                            remoteViews.setImageViewResource(R.id.iv_device_state4, R.drawable.device_switch_close_multiple_app_widget);
                        }
                    }
                    if (smallComponentDeviceBean.getStatus() == 3 || smallComponentDeviceBean.getStatus() == 0 || smallComponentDeviceBean.getStatus() == 8) {
                        //离线
                        remoteViews.setViewVisibility(R.id.iv_device_mask4, View.VISIBLE);
                        remoteViews.setTextColor(R.id.tv_device4, getResources().getColor(R.color.mine_color_80000000));
                    } else {
                        remoteViews.setViewVisibility(R.id.iv_device_mask4, View.GONE);
                        remoteViews.setTextColor(R.id.tv_device4, getResources().getColor(R.color.mine_color_000000));
                        remoteViews.setOnClickFillInIntent(R.id.ll_device4, setCheckClick(3));
                    }

                    break;
                case 4:
                    remoteViews.setTextViewText(R.id.tv_device5, nickName);
                    if (bitmap != null && !"".equals(bitmap)) {
                        remoteViews.setImageViewBitmap(R.id.iv_device5, bitmap);
                    } else {
                        remoteViews.setImageViewResource(R.id.iv_device5, R.drawable.ilop_mine_icon_default);
                    }
                    if (smallComponentDeviceBean.getStatus() == 1) {
                        if (smallComponentDeviceBean.getSwitchList().size() == 1) {
                            remoteViews.setImageViewResource(R.id.iv_device_state5, R.drawable.device_switch_open_one_app_widget);
                        } else {
                            remoteViews.setImageViewResource(R.id.iv_device_state5, R.drawable.device_switch_open_multiple_app_widget);
                        }
                    } else {
                        if (smallComponentDeviceBean.getSwitchList().size() == 1) {
                            remoteViews.setImageViewResource(R.id.iv_device_state5, R.drawable.device_switch_close_one_app_widget);
                        } else {
                            remoteViews.setImageViewResource(R.id.iv_device_state5, R.drawable.device_switch_close_multiple_app_widget);
                        }
                    }
                    if (smallComponentDeviceBean.getStatus() == 3 || smallComponentDeviceBean.getStatus() == 0 || smallComponentDeviceBean.getStatus() == 8) {
                        //离线
                        remoteViews.setViewVisibility(R.id.iv_device_mask5, View.VISIBLE);
                        remoteViews.setTextColor(R.id.tv_device5, getResources().getColor(R.color.mine_color_80000000));
                    } else {
                        remoteViews.setViewVisibility(R.id.iv_device_mask5, View.GONE);
                        remoteViews.setTextColor(R.id.tv_device5, getResources().getColor(R.color.mine_color_000000));
                        remoteViews.setOnClickFillInIntent(R.id.ll_device5, setCheckClick(4));
                    }

                    break;
                case 5:
                    remoteViews.setTextViewText(R.id.tv_device6, nickName);
                    if (bitmap != null && !"".equals(bitmap)) {
                        remoteViews.setImageViewBitmap(R.id.iv_device6, bitmap);
                    } else {
                        remoteViews.setImageViewResource(R.id.iv_device6, R.drawable.ilop_mine_icon_default);
                    }
                    if (smallComponentDeviceBean.getStatus() == 1) {
                        if (smallComponentDeviceBean.getSwitchList().size() == 1) {
                            remoteViews.setImageViewResource(R.id.iv_device_state6, R.drawable.device_switch_open_one_app_widget);
                        } else {
                            remoteViews.setImageViewResource(R.id.iv_device_state6, R.drawable.device_switch_open_multiple_app_widget);
                        }
                    } else {
                        if (smallComponentDeviceBean.getSwitchList().size() == 1) {
                            remoteViews.setImageViewResource(R.id.iv_device_state6, R.drawable.device_switch_close_one_app_widget);
                        } else {
                            remoteViews.setImageViewResource(R.id.iv_device_state6, R.drawable.device_switch_close_multiple_app_widget);
                        }
                    }
                    if (smallComponentDeviceBean.getStatus() == 3 || smallComponentDeviceBean.getStatus() == 0 || smallComponentDeviceBean.getStatus() == 8) {
                        //离线
                        remoteViews.setViewVisibility(R.id.iv_device_mask6, View.VISIBLE);
                        remoteViews.setTextColor(R.id.tv_device6, getResources().getColor(R.color.mine_color_80000000));
                    } else {
                        remoteViews.setViewVisibility(R.id.iv_device_mask6, View.GONE);
                        remoteViews.setTextColor(R.id.tv_device6, getResources().getColor(R.color.mine_color_000000));
                        remoteViews.setOnClickFillInIntent(R.id.ll_device6, setCheckClick(5));
                    }

                    break;
                case 6:
                    remoteViews.setTextViewText(R.id.tv_device7, nickName);
                    if (bitmap != null && !"".equals(bitmap)) {
                        remoteViews.setImageViewBitmap(R.id.iv_device7, bitmap);
                    } else {
                        remoteViews.setImageViewResource(R.id.iv_device7, R.drawable.ilop_mine_icon_default);
                    }
                    if (smallComponentDeviceBean.getStatus() == 1) {
                        if (smallComponentDeviceBean.getSwitchList().size() == 1) {
                            remoteViews.setImageViewResource(R.id.iv_device_state7, R.drawable.device_switch_open_one_app_widget);
                        } else {
                            remoteViews.setImageViewResource(R.id.iv_device_state7, R.drawable.device_switch_open_multiple_app_widget);
                        }
                    } else {
                        if (smallComponentDeviceBean.getSwitchList().size() == 1) {
                            remoteViews.setImageViewResource(R.id.iv_device_state7, R.drawable.device_switch_close_one_app_widget);
                        } else {
                            remoteViews.setImageViewResource(R.id.iv_device_state7, R.drawable.device_switch_close_multiple_app_widget);
                        }
                    }
                    if (smallComponentDeviceBean.getStatus() == 3 || smallComponentDeviceBean.getStatus() == 0 || smallComponentDeviceBean.getStatus() == 8) {
                        //离线
                        remoteViews.setViewVisibility(R.id.iv_device_mask7, View.VISIBLE);
                        remoteViews.setTextColor(R.id.tv_device7, getResources().getColor(R.color.mine_color_80000000));
                    } else {
                        remoteViews.setViewVisibility(R.id.iv_device_mask7, View.GONE);
                        remoteViews.setTextColor(R.id.tv_device7, getResources().getColor(R.color.mine_color_000000));
                        remoteViews.setOnClickFillInIntent(R.id.ll_device7, setCheckClick(6));
                    }

                    break;
                case 7:
                    remoteViews.setTextViewText(R.id.tv_device8, nickName);
                    if (bitmap != null && !"".equals(bitmap)) {
                        remoteViews.setImageViewBitmap(R.id.iv_device8, bitmap);
                    } else {
                        remoteViews.setImageViewResource(R.id.iv_device8, R.drawable.ilop_mine_icon_default);
                    }
                    if (smallComponentDeviceBean.getStatus() == 1) {
                        if (smallComponentDeviceBean.getSwitchList().size() == 1) {
                            remoteViews.setImageViewResource(R.id.iv_device_state8, R.drawable.device_switch_open_one_app_widget);
                        } else {
                            remoteViews.setImageViewResource(R.id.iv_device_state8, R.drawable.device_switch_open_multiple_app_widget);
                        }
                    } else {
                        if (smallComponentDeviceBean.getSwitchList().size() == 1) {
                            remoteViews.setImageViewResource(R.id.iv_device_state8, R.drawable.device_switch_close_one_app_widget);
                        } else {
                            remoteViews.setImageViewResource(R.id.iv_device_state8, R.drawable.device_switch_close_multiple_app_widget);
                        }
                    }
                    if (smallComponentDeviceBean.getStatus() == 3 || smallComponentDeviceBean.getStatus() == 0 || smallComponentDeviceBean.getStatus() == 8) {
                        //离线
                        remoteViews.setViewVisibility(R.id.iv_device_mask8, View.VISIBLE);
                        remoteViews.setTextColor(R.id.tv_device8, getResources().getColor(R.color.mine_color_80000000));
                    } else {
                        remoteViews.setViewVisibility(R.id.iv_device_mask8, View.GONE);
                        remoteViews.setTextColor(R.id.tv_device8, getResources().getColor(R.color.mine_color_000000));
                        remoteViews.setOnClickFillInIntent(R.id.ll_device8, setCheckClick(7));
                    }

                    break;
            }

        }

        //设置开关的点击事件
        private Intent setDeviceSwitchClick(int position) {
            SmallComponentDeviceBean smallComponentDeviceBean = smallComponentDeviceBeanList.get(current);
            Intent intent = new Intent();
            intent.putExtra("iotId", smallComponentDeviceBean.getIotId());
            intent.putExtra("CHECK_SWITCH_POSITION", position % 5);
            intent.putExtra("attributeName", smallComponentDeviceBean.getSwitchList().get(position % 5).getPropertyIdentifier());
            intent.putExtra("status", smallComponentDeviceBean.getStatus());
            int attributeValue;
            if (smallComponentDeviceBean.getSwitchList().get(position % 5).isCheck()) {
                attributeValue = 0;
            } else {
                attributeValue = 1;
            }
            intent.putExtra("attributeValue", attributeValue);
            return intent;
        }

        //设置开关显示
        private void setDeviceSwitch(RemoteViews remoteViews, int position) {
            if (current != -1) {
                SmallComponentDeviceBean smallComponentDeviceBean = smallComponentDeviceBeanList.get(current);
                PropertyBean propertyBean = smallComponentDeviceBean.getSwitchList().get(position % 5);
                switch (position) {
                    case 0:
                        //remoteViews.setImageViewBitmap(R.id.iv_device_swicth_img1,propertyBean.getBitmap());
                        if (propertyBean.isCheck()) {
                            remoteViews.setInt(R.id.ll_switch_back1, "setBackgroundResource", R.drawable.small_component_device_switch_open);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img1, R.drawable.ilop_mine_small_component_switch_open);
                        } else {
                            remoteViews.setInt(R.id.ll_switch_back1, "setBackgroundResource", R.drawable.small_component_device_switch_close);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img1, R.drawable.ilop_mine_small_component_switch_close);
                        }
                        remoteViews.setTextViewText(R.id.tv_device_switch_name1, propertyBean.getPropertyName());
                        if (judgeSwitchCanClick(position % 5)) {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask1, View.GONE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name1, getResources().getColor(R.color.mine_color_000000));
                            remoteViews.setOnClickFillInIntent(R.id.ll_device_switch1, setDeviceSwitchClick(0));
                        } else {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask1, View.VISIBLE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name1, getResources().getColor(R.color.mine_color_80000000));
                        }
                        break;
                    case 1:
                        //remoteViews.setImageViewBitmap(R.id.iv_device_swicth_img1,propertyBean.getBitmap());
                        if (propertyBean.isCheck()) {
                            remoteViews.setInt(R.id.ll_switch_back2, "setBackgroundResource", R.drawable.small_component_device_switch_open);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img2, R.drawable.ilop_mine_small_component_switch_open);
                        } else {
                            remoteViews.setInt(R.id.ll_switch_back2, "setBackgroundResource", R.drawable.small_component_device_switch_close);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img2, R.drawable.ilop_mine_small_component_switch_close);
                        }
                        remoteViews.setTextViewText(R.id.tv_device_switch_name2, propertyBean.getPropertyName());
                        if (judgeSwitchCanClick(position % 5)) {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask2, View.GONE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name2, getResources().getColor(R.color.mine_color_000000));
                            remoteViews.setOnClickFillInIntent(R.id.ll_device_switch2, setDeviceSwitchClick(1));
                        } else {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask2, View.VISIBLE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name2, getResources().getColor(R.color.mine_color_80000000));
                        }
                        break;
                    case 2:
                        //remoteViews.setImageViewBitmap(R.id.iv_device_swicth_img3,propertyBean.getBitmap());
                        if (propertyBean.isCheck()) {
                            remoteViews.setInt(R.id.ll_switch_back3, "setBackgroundResource", R.drawable.small_component_device_switch_open);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img3, R.drawable.ilop_mine_small_component_switch_open);
                        } else {
                            remoteViews.setInt(R.id.ll_switch_back3, "setBackgroundResource", R.drawable.small_component_device_switch_close);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img3, R.drawable.ilop_mine_small_component_switch_close);
                        }
                        remoteViews.setTextViewText(R.id.tv_device_switch_name3, propertyBean.getPropertyName());

                        if (judgeSwitchCanClick(position % 5)) {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask3, View.GONE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name3, getResources().getColor(R.color.mine_color_000000));
                            remoteViews.setOnClickFillInIntent(R.id.ll_device_switch3, setDeviceSwitchClick(2));
                        } else {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask3, View.VISIBLE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name3, getResources().getColor(R.color.mine_color_80000000));
                        }
                        break;
                    case 3:
                        //remoteViews.setImageViewBitmap(R.id.iv_device_swicth_img4,propertyBean.getBitmap());
                        if (propertyBean.isCheck()) {
                            remoteViews.setInt(R.id.ll_switch_back4, "setBackgroundResource", R.drawable.small_component_device_switch_open);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img4, R.drawable.ilop_mine_small_component_switch_open);
                        } else {
                            remoteViews.setInt(R.id.ll_switch_back4, "setBackgroundResource", R.drawable.small_component_device_switch_close);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img4, R.drawable.ilop_mine_small_component_switch_close);
                        }
                        remoteViews.setTextViewText(R.id.tv_device_switch_name4, propertyBean.getPropertyName());

                        if (judgeSwitchCanClick(position % 5)) {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask4, View.GONE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name4, getResources().getColor(R.color.mine_color_000000));
                            remoteViews.setOnClickFillInIntent(R.id.ll_device_switch4, setDeviceSwitchClick(3));
                        } else {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask4, View.VISIBLE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name4, getResources().getColor(R.color.mine_color_80000000));
                        }
                        break;
                    case 4:
                        //remoteViews.setImageViewBitmap(R.id.iv_device_swicth_img5,propertyBean.getBitmap());
                        if (propertyBean.isCheck()) {
                            remoteViews.setInt(R.id.ll_switch_back5, "setBackgroundResource", R.drawable.small_component_device_switch_open);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img5, R.drawable.ilop_mine_small_component_switch_open);
                        } else {
                            remoteViews.setInt(R.id.ll_switch_back5, "setBackgroundResource", R.drawable.small_component_device_switch_close);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img5, R.drawable.ilop_mine_small_component_switch_close);
                        }
                        remoteViews.setTextViewText(R.id.tv_device_switch_name5, propertyBean.getPropertyName());

                        if (judgeSwitchCanClick(position % 5)) {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask5, View.GONE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name5, getResources().getColor(R.color.mine_color_000000));
                            remoteViews.setOnClickFillInIntent(R.id.ll_device_switch5, setDeviceSwitchClick(4));
                        } else {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask5, View.VISIBLE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name5, getResources().getColor(R.color.mine_color_80000000));
                        }
                        break;
                    case 5:
                        //remoteViews.setImageViewBitmap(R.id.iv_device_swicth_img6,propertyBean.getBitmap());
                        if (propertyBean.isCheck()) {
                            remoteViews.setInt(R.id.ll_switch_back6, "setBackgroundResource", R.drawable.small_component_device_switch_open);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img6, R.drawable.ilop_mine_small_component_switch_open);
                        } else {
                            remoteViews.setInt(R.id.ll_switch_back6, "setBackgroundResource", R.drawable.small_component_device_switch_close);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img6, R.drawable.ilop_mine_small_component_switch_close);
                        }
                        remoteViews.setTextViewText(R.id.tv_device_switch_name6, propertyBean.getPropertyName());

                        if (judgeSwitchCanClick(position % 5)) {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask6, View.GONE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name6, getResources().getColor(R.color.mine_color_000000));
                            remoteViews.setOnClickFillInIntent(R.id.ll_device_switch6, setDeviceSwitchClick(5));
                        } else {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask6, View.VISIBLE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name6, getResources().getColor(R.color.mine_color_80000000));
                        }
                        break;
                    case 6:
                        //remoteViews.setImageViewBitmap(R.id.iv_device_swicth_img7,propertyBean.getBitmap());
                        if (propertyBean.isCheck()) {
                            remoteViews.setInt(R.id.ll_switch_back7, "setBackgroundResource", R.drawable.small_component_device_switch_open);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img7, R.drawable.ilop_mine_small_component_switch_open);
                        } else {
                            remoteViews.setInt(R.id.ll_switch_back7, "setBackgroundResource", R.drawable.small_component_device_switch_close);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img7, R.drawable.ilop_mine_small_component_switch_close);
                        }
                        remoteViews.setTextViewText(R.id.tv_device_switch_name7, propertyBean.getPropertyName());

                        if (judgeSwitchCanClick(position % 5)) {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask7, View.GONE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name7, getResources().getColor(R.color.mine_color_000000));
                            remoteViews.setOnClickFillInIntent(R.id.ll_device_switch7, setDeviceSwitchClick(6));
                        } else {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask7, View.VISIBLE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name7, getResources().getColor(R.color.mine_color_80000000));
                        }
                        break;
                    case 7:
                        //remoteViews.setImageViewBitmap(R.id.iv_device_swicth_img8,propertyBean.getBitmap());
                        if (propertyBean.isCheck()) {
                            remoteViews.setInt(R.id.ll_switch_back8, "setBackgroundResource", R.drawable.small_component_device_switch_open);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img8, R.drawable.ilop_mine_small_component_switch_open);
                        } else {
                            remoteViews.setInt(R.id.ll_switch_back8, "setBackgroundResource", R.drawable.small_component_device_switch_close);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img8, R.drawable.ilop_mine_small_component_switch_close);
                        }
                        remoteViews.setTextViewText(R.id.tv_device_switch_name8, propertyBean.getPropertyName());

                        if (judgeSwitchCanClick(position % 5)) {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask8, View.GONE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name8, getResources().getColor(R.color.mine_color_000000));
                            remoteViews.setOnClickFillInIntent(R.id.ll_device_switch8, setDeviceSwitchClick(7));
                        } else {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask8, View.VISIBLE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name8, getResources().getColor(R.color.mine_color_80000000));
                        }
                        break;
                    case 8:
                        //remoteViews.setImageViewBitmap(R.id.iv_device_swicth_img9,propertyBean.getBitmap());
                        if (propertyBean.isCheck()) {
                            remoteViews.setInt(R.id.ll_switch_back9, "setBackgroundResource", R.drawable.small_component_device_switch_open);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img9, R.drawable.ilop_mine_small_component_switch_open);
                        } else {
                            remoteViews.setInt(R.id.ll_switch_back9, "setBackgroundResource", R.drawable.small_component_device_switch_close);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img9, R.drawable.ilop_mine_small_component_switch_close);
                        }
                        remoteViews.setTextViewText(R.id.tv_device_switch_name9, propertyBean.getPropertyName());

                        if (judgeSwitchCanClick(position % 5)) {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask9, View.GONE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name9, getResources().getColor(R.color.mine_color_000000));
                            remoteViews.setOnClickFillInIntent(R.id.ll_device_switch9, setDeviceSwitchClick(8));
                        } else {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask9, View.VISIBLE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name9, getResources().getColor(R.color.mine_color_80000000));
                        }
                        break;
                    case 9:
                        //remoteViews.setImageViewBitmap(R.id.iv_device_swicth_img10,propertyBean.getBitmap());
                        if (propertyBean.isCheck()) {
                            remoteViews.setInt(R.id.ll_switch_back10, "setBackgroundResource", R.drawable.small_component_device_switch_open);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img10, R.drawable.ilop_mine_small_component_switch_open);
                        } else {
                            remoteViews.setInt(R.id.ll_switch_back10, "setBackgroundResource", R.drawable.small_component_device_switch_close);
                            remoteViews.setImageViewResource(R.id.iv_device_swicth_img10, R.drawable.ilop_mine_small_component_switch_close);
                        }
                        remoteViews.setTextViewText(R.id.tv_device_switch_name10, propertyBean.getPropertyName());

                        if (judgeSwitchCanClick(position % 5)) {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask10, View.GONE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name10, getResources().getColor(R.color.mine_color_000000));
                            remoteViews.setOnClickFillInIntent(R.id.ll_device_switch10, setDeviceSwitchClick(9));
                        } else {
                            remoteViews.setViewVisibility(R.id.iv_switch_mask10, View.VISIBLE);
                            remoteViews.setTextColor(R.id.tv_device_switch_name10, getResources().getColor(R.color.mine_color_80000000));
                        }
                        break;
                }

            }
        }

        //判断是否关机状态
        public boolean judgeDown(SmallComponentDeviceBean smallComponentDeviceBean) {
            if (smallComponentDeviceBean.getStatus() == 2) {
                return true;
            } else if (smallComponentDeviceBean.getStatus() == 1) {
                List<PropertyBean> propertyBeans = smallComponentDeviceBean.getSwitchList();
                for (int i = 0; i < propertyBeans.size(); i++) {
                    PropertyBean propertyBean = propertyBeans.get(i);
                    if (propertyBean.getPropertyIdentifier().equals("LightSwitch")||propertyBean.getPropertyIdentifier().equals("WorkSwitch") || propertyBean.getPropertyIdentifier().equals("PowerSwitch")) {
                        if (!propertyBean.isCheck()) {
                            smallComponentDeviceBean.setStatus(2);
                            return true;
                        }

                    }
                }
            }
            return false;
        }

        //判断设备是否可以点击
        public boolean judgeSwitchCanClick(int position) {
            if (current != -1) {
                SmallComponentDeviceBean smallComponentDeviceBean = smallComponentDeviceBeanList.get(current);
                ArrayList<PropertyBean> propertyBeans = smallComponentDeviceBean.getSwitchList();
                PropertyBean propertyBean = propertyBeans.get(position);
                if (propertyBean.getPropertyIdentifier().equals("LightSwitch")
                        || propertyBean.getPropertyIdentifier().equals("PowerSwitch")) {
                    return true;
                } else {
                    for (int i = 0; i < propertyBeans.size(); i++) {
                        PropertyBean bean = propertyBeans.get(i);
                        if ((bean.getPropertyIdentifier().equals("LightSwitch") || bean.getPropertyIdentifier().equals("WorkSwitch")
                                || bean.getPropertyIdentifier().equals("PowerSwitch")) && !bean.isCheck()) {
                            return false;
                        }
                    }
                }
            }
            return true;
        }
    }


}
