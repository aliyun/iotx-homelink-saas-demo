package com.aliyun.iot.ilop.page.mine.smallcomponents.interfaces;

import android.support.annotation.Nullable;

import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.SmallComponentDeviceBean;

import java.util.ArrayList;

public interface ISmallComponentPage {
    void showDeviceList(ArrayList<SmallComponentDeviceBean> list);

    void showError(@Nullable String msg);

    void showLoading(int num);

    void hideLoading();
}
