package com.aliyun.iot.ilop;

import android.os.Bundle;

import com.aliyun.iot.aep.sdk.framework.AActivity;
//import com.aliyun.iot.bean.RefreshUIBean;
//
//import de.greenrobot.event.EventBus;

public class BaseActivity extends AActivity {
//    @Override
//    protected void onCreate(Bundle bundle) {
//        super.onCreate(bundle);
//        EventBus.getDefault().register(this);
//    }
//
//    @Override
//    protected void onDestroy() {
//        super.onDestroy();
//        EventBus.getDefault().unregister(this);
//    }
//
//    public void onEventMainThread(RefreshUIBean i) {
//        recreate();
//    }

}
