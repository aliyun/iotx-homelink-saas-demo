package com.aliyun.iot.ilop.page.mine.smallcomponents.listener;

import android.os.Handler;
import android.os.Message;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;
import com.aliyun.iot.ilop.page.mine.MineAPIClientConstants;
import com.aliyun.iot.ilop.page.mine.MineConstants;
import com.aliyun.iot.ilop.page.mine.base.MineBaseBusinessListener;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.PropertyBean;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.SmallComponentDeviceBean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SmallComponentServiceDeviceListener extends MineBaseBusinessListener {

    public SmallComponentServiceDeviceListener(Handler handler) {
        super(handler);
    }

    @Override
    protected void onResponseSuccess(IoTRequest ioTRequest, String ioTResponse) {

        if (mHandler == null) {
            return;
        }
        if (ioTRequest.getPath().equals(MineAPIClientConstants.SMALL_COMMPONENT_PATH_QUERYCOMPONENTPRODUCT)) {
            onRequestQueryComponentProductSuccess(ioTRequest, ioTResponse);
        }

    }

    @Override
    protected void onResponseFailure(IoTRequest ioTRequest, String ioTResponse) {
        if (mHandler == null) {
            return;
        }
        if (ioTRequest.getPath().equals(MineAPIClientConstants.SMALL_COMMPONENT_PATH_QUERYCOMPONENTPRODUCT)) {
            onRequestQueryComponentProductFailed(ioTRequest, ioTResponse);
        }

    }

    @Override
    protected void onRequestFailure(IoTRequest ioTRequest, Exception e) {
        if (mHandler == null) {
            return;
        }
        Map<String, Object> map = new HashMap<>();
        map.put("ioTRequest", ioTRequest);
        Message.obtain(mHandler, MineConstants.MINE_MESSAGE_NETWORK_ERROR, map).sendToTarget();
    }


    //获取已添加设备列表
    private void onRequestQueryComponentProductSuccess(IoTRequest ioTRequest, final String ioTResponse) {
        if (null == mHandler) {
            return;
        }
        try {
            ThreadPool.DefaultThreadPool.getInstance().submit(
                    new Runnable() {
                        @Override
                        public void run() {
                            JSONArray array = JSON.parseArray(ioTResponse);
                            ArrayList<SmallComponentDeviceBean> smallComponentDeviceBeans = new ArrayList<>();
                            for (int i = 0; i < array.size(); i++) {
                                JSONObject json = array.getJSONObject(i);
                                SmallComponentDeviceBean smallComponentDeviceBean = new SmallComponentDeviceBean();
                                smallComponentDeviceBean.setProductKey(json.getString("productKey"));
                                smallComponentDeviceBean.setDeviceName(json.getString("deviceName"));
                                smallComponentDeviceBean.setIotId(json.getString("iotId"));
                                smallComponentDeviceBean.setNickName(json.getString("nickName"));
                                smallComponentDeviceBean.setProductName(json.getString("productName"));
                                smallComponentDeviceBean.setProductImage(json.getString("iconUrl"));
                                smallComponentDeviceBean.setStatus(json.getInteger("deviceStatus"));
                                JSONArray jsonArray = json.getJSONArray("properties");
                                ArrayList properArray = new ArrayList();
                                for (int j = 0; j < jsonArray.size(); j++) {
                                    JSONObject jsonObject = jsonArray.getJSONObject(j);
                                    PropertyBean propertyBean = new PropertyBean();
                                    String dataType = jsonObject.getString("propertyDataType");
                                    if (dataType != null && dataType.equalsIgnoreCase("bool")) {
                                        String values = jsonObject.getString("propertyValue");
                                        if (values != null) {
                                            if ("1".equals(values)) {
                                                propertyBean.setCheck(true);
                                            } else {
                                                propertyBean.setCheck(false);
                                            }
                                        }
                                    }
                                    propertyBean.setPropertyName(jsonObject.getString("propertyName"));
                                    propertyBean.setPropertyIdentifier(jsonObject.getString("propertyIdentifier"));
                                    properArray.add(propertyBean);
                                }
                                smallComponentDeviceBean.setSwitchList(properArray);
                                smallComponentDeviceBeans.add(smallComponentDeviceBean);
                            }
                            Message.obtain(mHandler, MineConstants.MINE_SMALL_COMPONENT_QUERY_COMPONENT_PRODUCT_SERVICE_SUCCESS, smallComponentDeviceBeans).sendToTarget();
                        }
                    });

        } catch (Exception ex) {
            ALog.d(TAG, " Failed to play the scan prompt sound,errorMesage:" + ex.getMessage());
        }


    }

    private void onRequestQueryComponentProductFailed(IoTRequest ioTRequest, String ioTResponse) {
        if (null == mHandler) {
            return;
        }
        Message.obtain(mHandler, MineConstants.MINE_SMALL_COMPONENT_QUERY_COMPONENT_PRODUCT_FAIL, ioTResponse).sendToTarget();
    }


}
