package com.aliyun.iot.ilop.page.mine.api.base;


import com.aliyun.iot.aep.sdk.apiclient.callback.IoTResponse;

/**
 * @author sinyuk
 * @date 2018/6/14
 */
public interface ConvertListener {
    /**
     * When response failed
     *
     * @param e error message
     */
    void onError(Exception e);

    void onError200(String msg);

    /**
     * When response succeed
     *
     * @param response base response
     */
    void onSucceed(IoTResponse response);
}
