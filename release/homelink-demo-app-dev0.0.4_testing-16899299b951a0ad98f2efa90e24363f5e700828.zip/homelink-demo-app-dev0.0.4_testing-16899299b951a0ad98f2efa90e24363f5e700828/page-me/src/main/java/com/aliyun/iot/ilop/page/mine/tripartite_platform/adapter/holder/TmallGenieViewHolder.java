package com.aliyun.iot.ilop.page.mine.tripartite_platform.adapter.holder;

import android.view.View;

import com.aliyun.iot.ilop.page.mine.setting.adapter.holder.BaseViewHolder;
import com.aliyun.iot.ilop.page.mine.tripartite_platform.bean.TripartitePlatformListBean;
import com.aliyun.iot.ilop.page.mine.view.MineLanguageItem;
import com.aliyun.iot.ilop.page.mine.view.TmallGenieItem;

public class TmallGenieViewHolder extends BaseViewHolder<TripartitePlatformListBean> {
    private TmallGenieItem mItem;

    public TmallGenieViewHolder(TmallGenieItem itemView) {
        super(itemView);
        mItem = (TmallGenieItem)itemView;

    }
    @Override
    public void bindData(TripartitePlatformListBean data, boolean maybeLatest) {

    }

    public TmallGenieItem getView() {
        return mItem;
    }

}
