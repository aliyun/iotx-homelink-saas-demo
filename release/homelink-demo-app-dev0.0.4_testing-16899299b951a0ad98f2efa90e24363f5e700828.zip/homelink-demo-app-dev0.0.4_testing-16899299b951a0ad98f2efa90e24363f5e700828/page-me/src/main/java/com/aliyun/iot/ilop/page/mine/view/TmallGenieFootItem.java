package com.aliyun.iot.ilop.page.mine.view;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.aliyun.iot.ilop.page.mine.R;

public class TmallGenieFootItem extends FrameLayout {

    private InstructionView ct1;
    private TextView titleTv;
    private TextView tvControl;

    public TmallGenieFootItem(@NonNull Context context) {
        super(context);
        init();
    }

    public TmallGenieFootItem(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public TmallGenieFootItem(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public void init() {
        inflate(getContext(), R.layout.ilop_mine_tmall_genie_foot_item, this);
        ct1 = findViewById(R.id.mine_tm_foot_item_ct1);
        titleTv = findViewById(R.id.mine_tm_foot_item_title_tv);
        tvControl= findViewById(R.id.mine_tm_foot_item_controlled_device_tv);
    }

    public void setCt(String title, String text) {
        ct1.setContent(text);
        titleTv.setText(title);
    }


    public void setIFTTT(){
        tvControl.setText("");
        LinearLayout.LayoutParams layoutParams=new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,20,getResources().getDisplayMetrics()));
        tvControl.setLayoutParams(layoutParams);
    }
}
