package com.aliyun.iot.ilop.page.mine.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.aliyun.iot.aep.sdk.framework.AApplication;

/**
 * Created by david on 2018/4/11.
 *
 * @author david
 * @date 2018/04/11
 */
public class MineSPUtils {
    public static final String KEY_VERSION_CODE = "KEY_VERSIONCODE";
    public static final String KEY_VERSION_NAME = "KEY_VERSIONNAME";
    public static final String KEY_VERSION_DESC = "KEY_VERSION_DESC";
    public static final String KEY_VERSION_APKURL = "KEY_VERSION_APKURL";
    public static final String KEY_VERSION_NOTIFY = "KEY_VERSION_NOTIFY";
    public static final String MINE_SP_KEY_LANGUAGE = "MINE_LANGUAGE";

    public static final SharedPreferences sp = AApplication.getInstance().getSharedPreferences("MineSP",
        Context.MODE_PRIVATE);

    public static String getString(String key, String defaultValue) {
        return sp.getString(key, defaultValue);
    }

    public static long getLong(String key, long defaultValue) {
        return sp.getLong(key, defaultValue);
    }

    public static boolean putString(String key, String value) {
        Editor editor = sp.edit();
        try {
            editor.putString(key, value);
            editor.apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean putLong(String key, long value) {
        Editor editor = sp.edit();
        try {
            editor.putLong(key, value);
            editor.apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
