package com.aliyun.iot.ilop.page.mine.home.bean;

import java.io.Serializable;

/**
 * Created by david on 2018/4/8.
 *
 * @author david
 * @date 2018/04/08
 */
public class MineMessageCounter implements Serializable{
    private static final long serialVersionUID = -5994752729950231215L;

    public long unreadMsgCount;
    public long firmwareCount;
}
