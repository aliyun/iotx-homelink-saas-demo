package com.aliyun.iot.ilop.page.mine.smallcomponents.appwidgetprovider;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.view.View;
import android.widget.RemoteViews;

import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.PropertyBean;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.SmallComponentDeviceBean;
import com.aliyun.iot.ilop.page.mine.smallcomponents.service.SmallComponentControlDeviceService;
import com.aliyun.iot.ilop.page.mine.smallcomponents.service.SmallComponentDeviceService;

import java.util.ArrayList;

/**
 * Implementation of App Widget functionality.
 */
public class SmallComponentDeviceAppWidget extends AppWidgetProvider {

    private static ArrayList<SmallComponentDeviceBean> smallComponentDeviceBeanList = new ArrayList<>();
    public static final String REFERSH_CURRENT_CHECK = "DEVICE_REFERSH_CURRENT_CHECK";
    private static int current_position = -1;
    //获取设备列表
    private static final String GETDEVICELIST = "GETDEVICELIST";
    //设置设备属性
    private static final String SETDEVICEATTRIBUTE = "SETDEVICEATTRIBUTE";
    private static final String REFRESHDEVICE = "REFRESHDEVICE";
    private static final String REFERSH_PROPERTY = "REFERSH_PROPERTY";

    @RequiresApi(api = Build.VERSION_CODES.CUPCAKE)
    static void updateAppWidget(Context context, AppWidgetManager appWidgetManager,
                                int appWidgetId) {

        //1.请求获取小组件中的设备列表
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.small_component_device_app_widget);
        //显示场景信息
        // Construct the RemoteViews object
        views.setViewVisibility(R.id.ll_no_device, View.VISIBLE);
        views.setViewVisibility(R.id.ll_device, View.GONE);
        try {
            Class homeActivity = Class.forName("com.aliyun.iot.ilop.page.home.HomeActivity");
            Intent intent = new Intent(context, homeActivity);
            Bundle extras = new Bundle();
            extras.putString("origin", "app_widget");
            intent.putExtra("key", extras);
            PendingIntent pendingIntent = PendingIntent.getActivity(context, 205, intent, PendingIntent.FLAG_UPDATE_CURRENT);
            views.setOnClickPendingIntent(R.id.tv_setting, pendingIntent);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        Intent intent = new Intent(context, SmallComponentControlDeviceService.class);
        intent.putExtra("KEY", GETDEVICELIST);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        // There may be multiple widgets active, so update all of them
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    @Override
    public void onEnabled(Context context) {
        // Enter relevant functionality for when the first widget is created
    }

    @Override
    public void onDisabled(Context context) {
        // Enter relevant functionality for when the last widget is disabled
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] appWidgetIds = manager.getAppWidgetIds(new ComponentName(context.getPackageName(), SmallComponentDeviceAppWidget.class.getName()));
        for (int appWidgetId : appWidgetIds) {
            switch (intent.getAction()) {
                case REFRESHDEVICE:
                    //重新获取smallComponentDeviceBeanList
                    Bundle bundle = intent.getBundleExtra("DEVICELIST");
                    if (bundle != null) {
                        smallComponentDeviceBeanList = bundle.getParcelableArrayList("DEVICELIST");
                    }
                    //1.请求获取小组件中的设备列表
                    RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.small_component_device_app_widget);
                    //重新刷新界面
                    if (smallComponentDeviceBeanList != null && smallComponentDeviceBeanList.size() > 0) {
                        //显示场景列表
                        views.setViewVisibility(R.id.ll_no_device, View.GONE);
                        views.setViewVisibility(R.id.ll_device, View.VISIBLE);
                        Intent adapter_intener = new Intent(context, SmallComponentDeviceService.class);
                        adapter_intener.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
                        views.setRemoteAdapter(R.id.list_device_app_widget, adapter_intener);
                        Intent ref_intent = new Intent(context, SmallComponentControlDeviceService.class);
                        ref_intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
                        ref_intent.putExtra("KEY", SETDEVICEATTRIBUTE);
                        PendingIntent pendingIntent = PendingIntent.getService(context, 202, ref_intent, PendingIntent.FLAG_UPDATE_CURRENT);
                        views.setPendingIntentTemplate(R.id.list_device_app_widget, pendingIntent);
                    } else {
                        //显示场景信息
                        // Construct the RemoteViews object
                        views.setViewVisibility(R.id.ll_no_device, View.VISIBLE);
                        views.setViewVisibility(R.id.ll_device, View.GONE);
                        try {
                            Class homeActivity = Class.forName("com.aliyun.iot.ilop.page.home.HomeActivity");
                            Intent jump_intent = new Intent(context, homeActivity);
                            Bundle extras = new Bundle();
                            extras.putString("origin", "app_widget");
                            jump_intent.putExtra("key", extras);
                            PendingIntent pendingIntent = PendingIntent.getActivity(context, 205, jump_intent, PendingIntent.FLAG_UPDATE_CURRENT);
                            views.setOnClickPendingIntent(R.id.tv_setting, pendingIntent);
                        } catch (ClassNotFoundException e) {
                            e.printStackTrace();
                        }
                    }
                    AppWidgetManager.getInstance(context).updateAppWidget(appWidgetId, views);
                    AppWidgetManager.getInstance(context).notifyAppWidgetViewDataChanged(appWidgetId, R.id.list_device_app_widget);
                    break;
           /* case REFRESH_LIST:
                List<PropertyBean> deviceSwitchBeans1 = new ArrayList<>();
                deviceSwitchBeans1.add(new PropertyBean("", "开关1", false));
                deviceSwitchBeans1.add(new PropertyBean("", "开关2", false));
                deviceSwitchBeans1.add(new PropertyBean("", "开关3", false));
                deviceSwitchBeans1.add(new PropertyBean("", "开关4", false));
                deviceSwitchBeans1.add(new PropertyBean("", "开关5", false));
                smallComponentDeviceBeanList.add(new SmallComponentDeviceBean("", "设备6", false, deviceSwitchBeans1, 1));
                if (appWidgetId != -1) {
                    this.updateAppWidget(context, AppWidgetManager.getInstance(context), appWidgetId);
                }
                AppWidgetManager.getInstance(context).notifyAppWidgetViewDataChanged(appWidgetId, R.id.list_device_app_widget);
                break;*/
                case REFERSH_CURRENT_CHECK:
                    int swicth_position = intent.getIntExtra("CHECK_SWITCH_POSITION", -1);
                    if (swicth_position != -1) {
                        SmallComponentDeviceBean smallComponentDeviceBean = smallComponentDeviceBeanList.get(current_position);
                        PropertyBean propertyBean = smallComponentDeviceBean.getSwitchList().get(swicth_position);
                        int attributeValue = intent.getIntExtra("attributeValue", -1);
                        if (attributeValue == 0) {
                            smallComponentDeviceBean.getSwitchList().get(swicth_position).setCheck(false);
                        } else {
                            smallComponentDeviceBean.getSwitchList().get(swicth_position).setCheck(true);
                        }
                    } else {
                        current_position = intent.getIntExtra("CHECK_POSITION", -1);
                    }
                    AppWidgetManager.getInstance(context).notifyAppWidgetViewDataChanged(appWidgetId, R.id.list_device_app_widget);
                    break;
                case REFERSH_PROPERTY:
                    //重新获取smallComponentDeviceBeanList
                    Bundle deviceBundle = intent.getBundleExtra("DEVICELIST");
                    if (deviceBundle != null) {
                        smallComponentDeviceBeanList = deviceBundle.getParcelableArrayList("DEVICELIST");
                    }
                    if (smallComponentDeviceBeanList != null && smallComponentDeviceBeanList.size() > 0) {
                        AppWidgetManager.getInstance(context).notifyAppWidgetViewDataChanged(appWidgetId, R.id.list_device_app_widget);
                    } else {
                        //显示场景信息
                        // Construct the RemoteViews object
                        RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.small_component_device_app_widget);
                        remoteViews.setViewVisibility(R.id.ll_no_device, View.VISIBLE);
                        remoteViews.setViewVisibility(R.id.ll_device, View.GONE);
                        try {
                            Class homeActivity = Class.forName("com.aliyun.iot.ilop.page.home.HomeActivity");
                            Intent jump_intent = new Intent(context, homeActivity);
                            Bundle extras = new Bundle();
                            extras.putString("origin", "app_widget");
                            jump_intent.putExtra("key", extras);
                            PendingIntent pendingIntent = PendingIntent.getActivity(context, 205, jump_intent, PendingIntent.FLAG_UPDATE_CURRENT);
                            remoteViews.setOnClickPendingIntent(R.id.tv_setting, pendingIntent);
                        } catch (ClassNotFoundException e) {
                            e.printStackTrace();
                        }
                    }
                    break;
            }
        }
    }

    public static ArrayList<SmallComponentDeviceBean> getDeviceList() {

        return smallComponentDeviceBeanList;
    }

    public static int getCurrentPosition() {
        if (current_position >= smallComponentDeviceBeanList.size()) {
            current_position = -1;
        }
        return current_position;
    }


}

