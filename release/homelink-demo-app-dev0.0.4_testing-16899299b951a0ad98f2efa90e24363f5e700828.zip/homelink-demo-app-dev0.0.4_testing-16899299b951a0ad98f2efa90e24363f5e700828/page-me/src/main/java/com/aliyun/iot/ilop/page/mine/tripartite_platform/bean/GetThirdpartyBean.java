package com.aliyun.iot.ilop.page.mine.tripartite_platform.bean;

public class GetThirdpartyBean {

    /**
     * accountId : 1075380881
     * accountType : TAOBAO
     * linkIndentityId : 5039opd8fe0d50de261fc9c0ba2f8e3263c10525
     */

    private String accountId;
    private String accountType;
    private String linkIndentityId;

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getLinkIndentityId() {
        return linkIndentityId;
    }

    public void setLinkIndentityId(String linkIndentityId) {
        this.linkIndentityId = linkIndentityId;
    }
}
