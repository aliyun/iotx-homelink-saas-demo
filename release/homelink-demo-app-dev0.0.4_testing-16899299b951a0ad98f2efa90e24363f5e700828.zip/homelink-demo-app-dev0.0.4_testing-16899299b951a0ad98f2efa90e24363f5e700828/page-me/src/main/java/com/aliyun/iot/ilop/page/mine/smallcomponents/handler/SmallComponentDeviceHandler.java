package com.aliyun.iot.ilop.page.mine.smallcomponents.handler;

import android.os.Handler;
import android.os.Message;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.ilop.page.mine.MineAPIClientConstants;
import com.aliyun.iot.ilop.page.mine.MineConstants;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.ComponentProductDTO;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.PropertyBean;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.SmallComponentDeviceBean;
import com.aliyun.iot.ilop.page.mine.smallcomponents.business.SmallComponentDeviceBusiness;
import com.aliyun.iot.ilop.page.mine.smallcomponents.interfaces.ISmallComponentDevicePage;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SmallComponentDeviceHandler extends Handler {

    private static final String TAG = "SmallComponentDeviceHandler";
    private SmallComponentDeviceBusiness smallComponentDeviceBusiness;
    private ISmallComponentDevicePage smallComponentDevicePage;
    private ArrayList<SmallComponentDeviceBean> arrayList = new ArrayList<>();

    public SmallComponentDeviceHandler(ISmallComponentDevicePage smallComponentDevicePage) {
        smallComponentDeviceBusiness = new SmallComponentDeviceBusiness(this);
        this.smallComponentDevicePage = smallComponentDevicePage;
    }

    public void refreshData(int page, int size) {
        if (smallComponentDevicePage != null) {
            smallComponentDevicePage.showLoading(2);
        }
        //查询所有设备信息
        smallComponentDeviceBusiness.getDeviceListFromAccount(page, size);
        //查询已添加设备信息
        smallComponentDeviceBusiness.queryComponentProductByIdentityId();
    }

    public void refresDeviceData(int page, int size) {
        if (smallComponentDevicePage != null) {
            smallComponentDevicePage.showLoading(1);
        }
        //查询所有设备信息
        smallComponentDeviceBusiness.getDeviceListFromAccount(page, size);
    }

    /**
     * 保存缓存
     *
     * @param componentProductDTOS
     */
    public void updateComponentProprety(List<ComponentProductDTO> componentProductDTOS) {
        if (smallComponentDevicePage != null) {
            smallComponentDevicePage.showLoading(1);
        }
        smallComponentDeviceBusiness.updateComponentProprety(componentProductDTOS);

    }


    @Override
    public void handleMessage(Message msg) {
        super.handleMessage(msg);
        switch (msg.what) {
            case MineConstants.MINE_SMALL_COMPONENT_GET_DEVICE_LIST_SUCCESS:
                String ioTResponse = msg.obj.toString();
                if (ioTResponse != null) {
                    JSONObject jsonObject = JSON.parseObject(ioTResponse);
                    JSONArray array = jsonObject.getJSONArray("accountDevDTOList");
                    if (array.size() == 0) {
                        if (smallComponentDevicePage != null) {
                            smallComponentDevicePage.hideLoading();
                            smallComponentDevicePage.setNoMore();
                        }
                    } else {
                        for (int i = 0; i < array.size(); i++) {
                            com.alibaba.fastjson.JSONObject json = array.getJSONObject(i);
                            SmallComponentDeviceBean smallComponentDeviceBean = new SmallComponentDeviceBean();
                            smallComponentDeviceBean.setIotId(json.getString("iotId"));
                            smallComponentDeviceBean.setNetType(json.getString("netType"));
                            smallComponentDeviceBean.setThingType(json.getString("thingType"));
                            smallComponentDeviceBean.setProductKey(json.getString("productKey"));
                            smallComponentDeviceBean.setDeviceName(json.getString("deviceName"));
                            smallComponentDeviceBean.setProductName(json.getString("productName"));
                            smallComponentDeviceBean.setProductImage(json.getString("productImage"));
                            Integer status = json.getInteger("status");
                            smallComponentDeviceBean.setStatus(status == null ? 1 : status);
                            smallComponentDeviceBean.setCategoryImage(json.getString("categoryImage"));
                            arrayList.add(smallComponentDeviceBean);
                            //请求属性
                            smallComponentDeviceBusiness.getDeviceProperty(smallComponentDeviceBean.getProductKey(), smallComponentDeviceBean.getIotId());
                        }
                    }
                }
                break;
            case MineConstants.MINE_SMALL_COMPONENT_GET_DEVICE_LIST_FAIL:
                if (smallComponentDevicePage != null) {
                    smallComponentDevicePage.showError(msg.obj.toString());
                    smallComponentDevicePage.hideLoading();
                }
                break;
            case MineConstants.MINE_MESSAGE_NETWORK_ERROR:
                if (smallComponentDevicePage != null) {
                    smallComponentDevicePage.showError(null);
                    Map<String, Object> map1 = (Map<String, Object>) msg.obj;
                    IoTRequest ioTRequest1 = (IoTRequest) map1.get("ioTRequest");
                    if (ioTRequest1.getPath().equals(MineAPIClientConstants.SMALL_COMMPONENT_PATH_GETDEVICEPROPRETYLIST)) {
                        setDeviceProPerty(ioTRequest1, null);
                    } else {
                        smallComponentDevicePage.hideLoading();
                    }
                }
                break;
            case MineConstants.MINE_SMALL_COMPONENT_GET_DEVICE_PROPERTY_SUCCESS:
                if (smallComponentDevicePage != null) {
                    Map<String, Object> map2 = (Map<String, Object>) msg.obj;
                    IoTRequest ioTRequest2 = (IoTRequest) map2.get("ioTRequest");
                    String message2 = (String) map2.get("ioTResponse");
                    setDeviceProPerty(ioTRequest2, message2);
                }
                break;
            case MineConstants.MINE_SMALL_COMPONENT_GET_DEVICE_PROPERTY_FAIL:
                if (smallComponentDevicePage != null) {
                    Map<String, Object> map3 = (Map<String, Object>) msg.obj;
                    IoTRequest ioTRequest3 = (IoTRequest) map3.get("ioTRequest");
                    String message3 = (String) map3.get("ioTResponse");
                    smallComponentDevicePage.showError(message3);
                    setDeviceProPerty(ioTRequest3, null);
                }
                break;
            case MineConstants.MINE_SMALL_COMPONENT_QUERY_COMPONENT_PRODUCT_SUCCESS:
                if (smallComponentDevicePage != null) {
                    String data = msg.obj.toString();
                    JSONArray array = JSON.parseArray(data);
                    ArrayList<SmallComponentDeviceBean> smallComponentDeviceBeans = new ArrayList<>();
                    for (int i = 0; i < array.size(); i++) {
                        JSONObject json = array.getJSONObject(i);
                        SmallComponentDeviceBean smallComponentDeviceBean = new SmallComponentDeviceBean();
                        smallComponentDeviceBean.setProductKey(json.getString("productKey"));
                        smallComponentDeviceBean.setDeviceName(json.getString("deviceName"));
                        smallComponentDeviceBean.setIotId(json.getString("iotId"));
                        smallComponentDeviceBean.setNickName(json.getString("nickName"));
                        smallComponentDeviceBean.setProductName(json.getString("productName"));
                        smallComponentDeviceBean.setProductImage(json.getString("iconUrl"));
                        smallComponentDeviceBean.setStatus(json.getInteger("deviceStatus"));
                        JSONArray jsonArray = json.getJSONArray("properties");
                        ArrayList properArray = new ArrayList();
                        for (int j = 0; j < jsonArray.size(); j++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(j);
                            PropertyBean propertyBean = new PropertyBean();
                            String dataType=jsonObject.getString("propertyDataType");
                            if(dataType!=null&&dataType.equalsIgnoreCase("bool")){
                                String  values = jsonObject.getString("propertyValue");
                                if(values!=null){
                                    propertyBean.setCheck(Boolean.getBoolean(values));
                                }
                            }
                            propertyBean.setPropertyName(jsonObject.getString("propertyName"));
                            propertyBean.setPropertyIdentifier(jsonObject.getString("propertyIdentifier"));
                            properArray.add(propertyBean);
                        }
                        smallComponentDeviceBean.setSwitchList(properArray);
                        smallComponentDeviceBeans.add(smallComponentDeviceBean);
                    }
                    smallComponentDevicePage.showAddDeviceList(smallComponentDeviceBeans);
                    smallComponentDevicePage.hideLoading();

                }
                break;
            case MineConstants.MINE_SMALL_COMPONENT_QUERY_COMPONENT_PRODUCT_FAIL:
                if (smallComponentDevicePage != null) {
                    smallComponentDevicePage.showError(msg.obj.toString());
                    smallComponentDevicePage.hideLoading();
                }
                break;
            case MineConstants.MINE_SMALL_COMPONENT_UPDATE_COMPONENT_PROPERTY_SUCCESS:
                if (smallComponentDevicePage != null) {
                    smallComponentDevicePage.updateSuccess();
                    smallComponentDevicePage.hideLoading();
                }
                break;
            case MineConstants.MINE_SMALL_COMPONENT_UPDATE_COMPONENT_PROPERTY_FAIL:
                if (smallComponentDevicePage != null) {
                    smallComponentDevicePage.showError(msg.obj.toString());
                    smallComponentDevicePage.hideLoading();
                }
                break;
        }
    }

    public void destroy() {
        ALog.d(TAG, "destroy");

        removeMessages(MineConstants.MINE_SMALL_COMPONENT_GET_DEVICE_LIST_SUCCESS);
        removeMessages(MineConstants.MINE_SMALL_COMPONENT_GET_DEVICE_LIST_FAIL);
        removeMessages(MineConstants.MINE_MESSAGE_NETWORK_ERROR);
        removeMessages(MineConstants.MINE_SMALL_COMPONENT_GET_DEVICE_PROPERTY_FAIL);
        removeMessages(MineConstants.MINE_SMALL_COMPONENT_GET_DEVICE_PROPERTY_FAIL);
        smallComponentDeviceBusiness = null;
        smallComponentDevicePage = null;
        arrayList.clear();
    }

    //设置设备属性权限
    public void setDeviceProPerty(IoTRequest ioTRequest, String message) {
        if (ioTRequest.getPath().equals(MineAPIClientConstants.SMALL_COMMPONENT_PATH_GETDEVICEPROPRETYLIST)) {
            Map<String, Object> params = ioTRequest.getParams();
            String iotId = params.get("iotId").toString();
            int not_property = 0;
            for (int i = 0; i < arrayList.size(); i++) {
                SmallComponentDeviceBean smallComponentDeviceBean = arrayList.get(i);
                if (smallComponentDeviceBean.getIotId().equals(iotId)) {
                    if (message == null) {
                        smallComponentDeviceBean.setSwitchList(new ArrayList<PropertyBean>());
                    } else {
                        //解析属性
                        com.alibaba.fastjson.JSONArray jsonArray = JSON.parseArray(message);
                        ArrayList<PropertyBean> propertyBeans = new ArrayList<>();
                        for (int j = 0; j < jsonArray.size(); j++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(j);
                            String dataType = jsonObject.getString("dataType");
                            if ("BOOL".equals(dataType)) {
                                PropertyBean propertyBean = new PropertyBean();
                                propertyBean.setDataType(dataType);
                                propertyBean.setCheck(false);
                                propertyBean.setProductKey(jsonObject.getString("productKey"));
                                propertyBean.setPropertyId(jsonObject.getString("propertyId"));
                                propertyBean.setPropertyIdentifier(jsonObject.getString("propertyIdentifier"));
                                propertyBean.setPropertyName(jsonObject.getString("propertyName"));
                                Boolean check = jsonObject.getBoolean("added_component");
                                propertyBean.setCheck((check == null) ? false : check);
                                propertyBeans.add(propertyBean);
                            }
                        }
                        smallComponentDeviceBean.setSwitchList(propertyBeans);
                    }
                    if (not_property > 0) {
                        break;
                    }
                } else {
                    if (smallComponentDeviceBean.getSwitchList() == null) {
                        not_property++;
                    }
                }
            }
            if (not_property == 0) {
                smallComponentDevicePage.showDeviceList(arrayList);
                smallComponentDevicePage.hideLoading();
            }
        }
    }


}
