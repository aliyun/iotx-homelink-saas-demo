package com.aliyun.iot.ilop.page.mine.api.base;

public interface ResponseCallback<T> {
    /**
     * Callback when request failed
     *
     * @param e error message
     */
    void onFail(Exception e);

    void onFailNot200(String msg);


    T parseData(String dataStr);

    /**
     * Callback when request succeed
     *
     * @param data response data of type T
     */
    void onSuccess(T data);
}