package com.aliyun.iot.ilop.page.mine.smallcomponents.bean;


import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class SmallComponentDeviceBean implements Parcelable {

    private String iotId;
    private String deviceName;
    private String productKey;
    private String productName;
    private String nickName;
    private String netType;
    private String nodeType;
    private String thingType;
    private String categoryImage;
    private int owned;
    private int status;//设备的状态 0：未激活 ；1：在线；3：离线；8：禁用 2关机
    private String productImage;
    //判断是否已经添加
    private boolean add;
    //开关信息
    private ArrayList<PropertyBean> switchList;

    public SmallComponentDeviceBean() {

    }

    protected SmallComponentDeviceBean(Parcel in) {
        iotId = in.readString();
        deviceName = in.readString();
        productKey = in.readString();
        productName = in.readString();
        nickName = in.readString();
        netType = in.readString();
        nodeType = in.readString();
        thingType = in.readString();
        categoryImage = in.readString();
        owned = in.readInt();
        status = in.readInt();
        productImage = in.readString();
        add = in.readByte() != 0;
        switchList = in.createTypedArrayList(PropertyBean.CREATOR);
    }

    public static final Creator<SmallComponentDeviceBean> CREATOR = new Creator<SmallComponentDeviceBean>() {
        @Override
        public SmallComponentDeviceBean createFromParcel(Parcel in) {
            return new SmallComponentDeviceBean(in);
        }

        @Override
        public SmallComponentDeviceBean[] newArray(int size) {
            return new SmallComponentDeviceBean[size];
        }
    };

    public String getDeviceName() {
        return deviceName == null ? "" : deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public boolean isAdd() {
        return add;
    }

    public void setAdd(boolean add) {
        this.add = add;
    }

    public ArrayList<PropertyBean> getSwitchList() {
        return switchList;
    }

    public void setSwitchList(ArrayList<PropertyBean> switchList) {
        this.switchList = switchList;
    }


    public String getIotId() {
        return iotId;
    }

    public void setIotId(String iotId) {
        this.iotId = iotId;
    }

    public String getProductKey() {
        return productKey;
    }

    public void setProductKey(String productKey) {
        this.productKey = productKey;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getNetType() {
        return netType;
    }

    public void setNetType(String netType) {
        this.netType = netType;
    }

    public String getNodeType() {
        return nodeType;
    }

    public void setNodeType(String nodeType) {
        this.nodeType = nodeType;
    }

    public String getThingType() {
        return thingType;
    }

    public void setThingType(String thingType) {
        this.thingType = thingType;
    }

    public String getCategoryImage() {
        return categoryImage;
    }

    public void setCategoryImage(String categoryImage) {
        this.categoryImage = categoryImage;
    }

    public int getOwned() {
        return owned;
    }

    public void setOwned(int owned) {
        this.owned = owned;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(iotId);
        dest.writeString(deviceName);
        dest.writeString(productKey);
        dest.writeString(productName);
        dest.writeString(nickName);
        dest.writeString(netType);
        dest.writeString(nodeType);
        dest.writeString(thingType);
        dest.writeString(categoryImage);
        dest.writeInt(owned);
        dest.writeInt(status);
        dest.writeString(productImage);
        dest.writeByte((byte) (add ? 1 : 0));
        dest.writeTypedList(switchList);
    }

    public SmallComponentDeviceBean copy() {
        SmallComponentDeviceBean deviceBean = new SmallComponentDeviceBean();
        deviceBean.setIotId(this.getIotId());
        deviceBean.setDeviceName(this.getDeviceName());
        deviceBean.setProductKey(this.getProductKey());
        deviceBean.setProductName(this.getProductName());
        deviceBean.setNickName(this.getNickName());
        deviceBean.setNetType(this.getNetType());
        deviceBean.setNodeType(this.getNodeType());
        deviceBean.setThingType(this.getThingType());
        deviceBean.setCategoryImage(this.getCategoryImage());
        deviceBean.setOwned(this.getOwned());
        deviceBean.setStatus(this.getStatus());
        deviceBean.setProductImage(this.getProductImage());
        deviceBean.setAdd(this.isAdd());
        deviceBean.setSwitchList(this.getSwitchList());
        return deviceBean;

    }

}
