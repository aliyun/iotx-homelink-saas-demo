package com.aliyun.iot.ilop.page.mine.user.interfaces;

import android.net.Uri;

public interface IMIneSettingAccountActivityImp {


    void showAvatar(Uri url);

    void showNickName(String nickName);


    void showAccount(String accountNumber);



    void showRegion(String region);


    void showResetPwdView(String loginType);

}
