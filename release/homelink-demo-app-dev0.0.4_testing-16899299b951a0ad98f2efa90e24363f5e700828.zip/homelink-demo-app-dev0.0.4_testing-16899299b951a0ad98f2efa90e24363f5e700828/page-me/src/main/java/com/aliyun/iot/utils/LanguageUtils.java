package com.aliyun.iot.utils;

import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.LocaleList;
import android.text.TextUtils;
import android.util.DisplayMetrics;

import com.aliyun.alink.sdk.bone.plugins.config.BoneConfig;
import com.aliyun.iot.aep.oa.OAUIInitHelper;
import com.aliyun.iot.aep.sdk.EnvConfigure;
import com.aliyun.iot.aep.sdk.PushManager;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientImpl;
import com.aliyun.iot.aep.sdk.framework.AApplication;
import com.aliyun.iot.aep.sdk.framework.config.AConfigure;
import com.aliyun.iot.aep.sdk.framework.language.LanguageManager;
import com.aliyun.iot.aep.sdk.log.ALog;

import java.util.Locale;

public class LanguageUtils {

    protected static final String TAG = "LanguageUtils";
    private static final String MINE_SP_KEY_LANGUAGE = "MINE_LANGUAGE";
    private static final String AUTO_LANGUAGE = "AUTO_LANGUAGE";

    public static String MakeLanguageString(Locale locale) {
        return locale.getLanguage() + "-" + locale.getCountry();
    }

    public static String[] LoadLanguageInfo(String language) {
        String[] languageCountry;
        languageCountry = language.split("-");
        if (languageCountry.length == 1) {
            languageCountry = language.split("_");
        }
        return languageCountry;
    }

    /**
     * 获取本地语言
     *
     * @return
     */
    public static Locale GetSysLocale() {
        Locale locale;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            LocaleList locals = Resources.getSystem().getConfiguration().getLocales();
            locale = locals.get(0);
        } else {
            locale = Locale.getDefault();
        }
        String language = locale.getLanguage();
        switch (language) {
            case "zh":
                locale = Locale.SIMPLIFIED_CHINESE;
                break;
            case "en":
                locale = Locale.US;
                break;
            case "fr":
                locale = Locale.FRANCE;
                break;
            case "de":
                locale = Locale.GERMANY;
                break;
            case "ja":
                locale = Locale.JAPAN;
                break;
            case "ko":
                locale = Locale.KOREA;
                break;
            case "es":
                locale = new Locale("es", "ES");
                break;
            case "ru":
                locale = new Locale("ru", "RU");
                break;
        }
        ALog.e(TAG, "当前本地语言为：" + locale.getLanguage());
        return locale;
    }

    /**
     * 开始切换语言
     *
     * @param resources
     * @param languageFullName
     */
    public static void switchLanguage(Resources resources, String languageFullName) {
        try {
            String[] languageCountry = LanguageUtils.LoadLanguageInfo(languageFullName);
            Locale mCurrentLocale = new Locale(languageCountry[0], languageCountry[1]);
            DisplayMetrics displayMetrics = resources.getDisplayMetrics();
            Configuration configuration = resources.getConfiguration();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                configuration.setLocale(mCurrentLocale);
            }
            resources.updateConfiguration(configuration, displayMetrics);

            String language = "";
            if (!isAutoLanguage())
                language = LanguageUtils.MakeLanguageString(mCurrentLocale);
            ALog.e(TAG, "切换之后的语言：" + language);
            LanguageManager.saveAppLanguage(language);
            EnvConfigure.putEnvArg(
                    MINE_SP_KEY_LANGUAGE,
                    language,
                    true);
            OAUIInitHelper.setLanguage(mCurrentLocale);
            BoneConfig.set("language", LanguageUtils.MakeLanguageString(mCurrentLocale));
            if (IoTAPIClientImpl.getInstance() != null)
                IoTAPIClientImpl.getInstance().setLanguage(LanguageUtils.MakeLanguageString(mCurrentLocale));
            //if (!CountryUtils.judgeIsEurope(AApplication.getInstance().getApplicationContext())) {
                PushManager.getInstance().bindUser();
            //}

        } catch (Exception e) {
            ALog.e(TAG, "set language error");
        }
    }

    public static boolean isAutoLanguage() {
        return TextUtils.isEmpty(AConfigure.getInstance().getSpConfig(AUTO_LANGUAGE));
    }

    public static Locale GetCurrentLanguage(Locale locale) {
        Locale currentLocale;
        String language = locale.getLanguage();
        if ("zh".equalsIgnoreCase(language)) {
            currentLocale = Locale.SIMPLIFIED_CHINESE;
        } else if ("fr".equalsIgnoreCase(language)) {
            currentLocale = Locale.FRANCE;
        } else if ("de".equalsIgnoreCase(language)) {
            currentLocale = Locale.GERMANY;
        } else if ("en".equalsIgnoreCase(language)) {
            currentLocale = Locale.US;
        } else if ("ja".equalsIgnoreCase(language)) {
            currentLocale = Locale.JAPAN;
        } else if ("ko".equalsIgnoreCase(language)) {
            currentLocale = Locale.KOREA;
        } else if ("es".equalsIgnoreCase(language)) {
            currentLocale = new Locale("es", "ES");
        } else if ("ru".equalsIgnoreCase(language)) {
            currentLocale = new Locale("ru", "RU");
        } else if (IsHome()) {
            currentLocale = Locale.SIMPLIFIED_CHINESE;
        } else {
            currentLocale = Locale.US;
        }
        ALog.e(TAG, "当前语言为：" + currentLocale.getLanguage() + "::" + currentLocale.getCountry());
        return currentLocale;
    }

    private static boolean IsHome() {
        boolean isHome = false;
        String region = (String) AConfigure.getInstance().getConfig().get("countryName");
        if (TextUtils.isEmpty(region)) {
            SharedPreferences sp = AApplication.getInstance().getSharedPreferences("ilop_sp", 0);
            region = sp.getString("codeSelected", "");
        }
        if (TextUtils.isEmpty(region)) {
            isHome = true;
        } else if (region.equalsIgnoreCase("86")) {
            isHome = true;
        }
        return isHome;
    }
}
