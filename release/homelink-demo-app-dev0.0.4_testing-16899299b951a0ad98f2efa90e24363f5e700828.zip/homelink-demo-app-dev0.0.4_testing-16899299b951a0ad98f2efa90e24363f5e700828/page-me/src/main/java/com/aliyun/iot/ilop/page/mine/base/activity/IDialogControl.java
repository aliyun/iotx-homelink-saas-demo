package com.aliyun.iot.ilop.page.mine.base.activity;

import android.app.Dialog;

/**
 * Created by nht on 2018/6/27.
 */

public interface IDialogControl {
    void hideWaitDialog();

    Dialog showWaitDialog();

    Dialog showWaitDialog(int resid);

    Dialog showWaitDialog(String text);
}
