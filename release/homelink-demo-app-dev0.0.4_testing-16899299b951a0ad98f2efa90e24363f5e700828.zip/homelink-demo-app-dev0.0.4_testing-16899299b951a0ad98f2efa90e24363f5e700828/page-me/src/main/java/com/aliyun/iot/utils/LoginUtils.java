package com.aliyun.iot.utils;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import com.alibaba.sdk.android.openaccount.ui.impl.OpenAccountUIServiceImpl;
import com.alibaba.sdk.android.openaccount.util.ResourceUtils;
import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.aep.sdk.login.ILoginCallback;
import com.aliyun.iot.aep.sdk.login.ILoginStatusChangeListener;
import com.aliyun.iot.aep.sdk.login.LoginBusiness;
import com.aliyun.iot.aep.sdk.login.oa.OALoginAdapter;
import com.aliyun.iot.aep.sdk.log.ALog;

import java.util.HashMap;
import java.util.Map;

public class LoginUtils {
    private static final String TAG = "LoginUtils";
    private static final String KEY_CODESELECTED = "codeSelected";
    private static boolean hasGotoHome = false;

    public static void StartLogin(final Activity activity, Class<?> cls, Context context) {
        hasGotoHome = false;
        SharedPreferences sp = context.getSharedPreferences("ilop_sp", Context.MODE_PRIVATE);
        String mCountrySelected = sp.getString(KEY_CODESELECTED, "");
        //尚未进行地区选择，先去选择。
//        if (mCountrySelected.equalsIgnoreCase("")) {
//            if (cls == null) {
//                Router.getInstance().toUrl(context, "https://com.aliyun.iot.ilop/page/countryList");
//                if (activity != null) {
//                    activity.finish();
//                }
//            } else {
//                //判断是否需要选择地区
//                Intent intent = new Intent(context, cls);
//                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//                context.startActivity(intent);
//            }
//        } else {
            //直接跳转到登录界面
            OpenLoginActivity(mCountrySelected, activity, null, context);
//        }
    }


    public static void OpenLoginActivity(String areaCode, final Activity activity, String enteance, final Context context) {
        hasGotoHome = false;
        Map<String, String> params = new HashMap<>();
        params.put("countryNum", areaCode);
        if (enteance != null) {
            params.put("ENTRANCE", "COUNTRY_LIST");
        }
        ALog.i("JC", "countryNum=" + areaCode);
        ((OALoginAdapter) LoginBusiness.getLoginAdapter()).login(new ILoginCallback() {
            @Override
            public void onLoginSuccess() {
                ALog.d(TAG, "onLoginSuccess");
                gotoHomePage(activity, context);
            }

            @Override
            public void onLoginFailed(int errorCode, String errorMsg) {
                ALog.d(TAG, "onLoginFailed: errorCode:" + errorCode + " errorMsg:" + errorMsg);

                if (errorCode == 10003) {
                    return;
                }
                String loginFail = ResourceUtils.getString("account_login_failed");
                Toast.makeText(context, loginFail == null ? "" : loginFail, Toast.LENGTH_SHORT).show();
            }
        }, params);

        if (OpenAccountUIServiceImpl._loginCallback != null) {
//            OALoginActivity.setLoginCallback(OpenAccountUIServiceImpl._loginCallback);
        } else {
            ALog.e(TAG, "OpenAccountUIServiceImpl._loginCallback=null");
        }
        listenLoginStatus(activity, context);
    }

    private static void listenLoginStatus(final Activity activity, final Context context) {
        unListenLoginStatus();
        loginStatusChangeListener = new ILoginStatusChangeListener() {
            @Override
            public void onLoginStatusChange() {
                if (LoginBusiness.getLoginAdapter().isLogin()) {
                    ALog.d(TAG, "login status change: login");
                    gotoHomePage(activity, context);
                } else {
                    ALog.d(TAG, "login status change: logout");
                }
            }
        };
        LoginBusiness.getLoginAdapter().registerLoginListener(loginStatusChangeListener);
    }

    private static void unListenLoginStatus() {
        if (loginStatusChangeListener != null) {
            try {
                LoginBusiness.getLoginAdapter().unRegisterLoginListener(loginStatusChangeListener);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private static ILoginStatusChangeListener loginStatusChangeListener;

    private static void gotoHomePage(final Activity activity, final Context context) {
        if (hasGotoHome) {
            ALog.d(TAG, "already goto home");
            return;
        }
        hasGotoHome = true;
        String loginSuccess = ResourceUtils.getString("account_login_success");
        Toast.makeText(context, loginSuccess == null ? "" : loginSuccess, Toast.LENGTH_SHORT).show();
        Router.getInstance().toUrl(context, "page/home");
        ALog.i("PerformanceTag", "{\"mod\":\"android\",\"event\":\"pageopen\", \"id\":\"\", \"params\":{\"pagename\":\"homepage\"}}");
        if (activity != null) {
            if (!activity.isFinishing()) {
                activity.finish();
            }
        }
        unListenLoginStatus();
        //更新小组件
        AppWidgetHelper.refreshDeviceWidget(context,"GETDEVICELIST");

    }


}
