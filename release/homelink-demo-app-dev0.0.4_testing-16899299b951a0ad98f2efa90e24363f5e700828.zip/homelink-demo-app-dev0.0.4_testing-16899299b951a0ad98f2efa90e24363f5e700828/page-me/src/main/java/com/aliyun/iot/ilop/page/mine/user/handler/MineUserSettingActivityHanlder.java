package com.aliyun.iot.ilop.page.mine.user.handler;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;

import com.aliyun.iot.aep.sdk.login.LoginBusiness;
import com.aliyun.iot.aep.sdk.login.data.UserInfo;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.ilop.page.mine.MineConstants;
import com.aliyun.iot.ilop.page.mine.user.business.AvatarBusiness;
import com.aliyun.iot.ilop.page.mine.user.business.MineAccountSettingActivityBusiness;
import com.aliyun.iot.ilop.page.mine.user.interfaces.IMIneSettingAccountActivityImp;

public class MineUserSettingActivityHanlder extends Handler {

    private static final String TAG = MineUserSettingActivityHanlder.class.getSimpleName();

    private IMIneSettingAccountActivityImp imIneSettingAccountActivityImp;
    private MineAccountSettingActivityBusiness mineAccountSettingActivityBusiness;
    private AvatarBusiness avatarBusiness;

    public MineUserSettingActivityHanlder(IMIneSettingAccountActivityImp imIneSettingAccountActivityImp) {
        super(Looper.getMainLooper());
        this.imIneSettingAccountActivityImp = imIneSettingAccountActivityImp;
        mineAccountSettingActivityBusiness = new MineAccountSettingActivityBusiness(this);
        avatarBusiness = new AvatarBusiness(this);
        Context context = (Context) imIneSettingAccountActivityImp;
        avatarBusiness.setAvatarPath(context.getApplicationContext().getExternalCacheDir().getAbsolutePath());
    }

    public void getCache() {
        UserInfo userInfo = LoginBusiness.getUserInfo();
        if (userInfo != null) {
            Uri uri = avatarBusiness.getCache(userInfo.userAvatarUrl);
            imIneSettingAccountActivityImp.showAvatar(uri);
        }

    }



    public void requestPersonInfo() {
        mineAccountSettingActivityBusiness.requestPersonInfo();
    }

    public void requestRegion() {
        mineAccountSettingActivityBusiness.requestRegion();
    }


    @Override
    public void handleMessage(Message msg) {
        if (imIneSettingAccountActivityImp == null) {
            return;
        }
        if (msg.what == MineConstants.MINE_MESSAGE_RESPONSE_PERSONINFO_SUCCESS) {
            UserInfo userInfo = (UserInfo) msg.obj;
            if (userInfo == null) {
                return;
            }

            Uri uri = avatarBusiness.getCache(userInfo.userAvatarUrl);
            Message.obtain(this,MineConstants.MINE_MESSAGE_RESPONSE_AVATAR_SUCCESS,uri).sendToTarget();

            avatarBusiness.getAvatar(userInfo.userAvatarUrl);
            imIneSettingAccountActivityImp.showNickName(userInfo.userNick);
            if (!TextUtils.isEmpty(userInfo.userPhone)) {
                imIneSettingAccountActivityImp.showAccount("+" + userInfo.mobileLocationCode + " " + userInfo.userPhone);
                imIneSettingAccountActivityImp.showResetPwdView("phone");
            } else if (!TextUtils.isEmpty(userInfo.userEmail)) {
                imIneSettingAccountActivityImp.showAccount(userInfo.userEmail);
                imIneSettingAccountActivityImp.showResetPwdView("email");
            } else if (!TextUtils.isEmpty(userInfo.openId)) {
                imIneSettingAccountActivityImp.showResetPwdView("auth");
                imIneSettingAccountActivityImp.showAccount(userInfo.openId);
            }
        } else if (msg.what == MineConstants.MINE_MESSAGE_RESPONSE_PERSONINFO_FAILED) {

        } else if (msg.what == MineConstants.MINE_MESSAGE_RESPONSE_REGION_SUCCESS) {
            imIneSettingAccountActivityImp.showRegion(msg.obj.toString());
        } else if (msg.what == MineConstants.MINE_MESSAGE_RESPONSE_AVATAR_SUCCESS) {
            Uri uri = (Uri) msg.obj;
            imIneSettingAccountActivityImp.showAvatar(uri);
        }

    }


    public void destroy() {
        ALog.d(TAG, "destroy");

        removeMessages(MineConstants.MINE_MESSAGE_RESPONSE_PERSONINFO_SUCCESS);
        removeMessages(MineConstants.MINE_MESSAGE_RESPONSE_PERSONINFO_FAILED);
        removeMessages(MineConstants.MINE_MESSAGE_RESPONSE_REGION_SUCCESS);
        removeMessages(MineConstants.MINE_MESSAGE_RESPONSE_AVATAR_SUCCESS);


        imIneSettingAccountActivityImp = null;
    }
}
