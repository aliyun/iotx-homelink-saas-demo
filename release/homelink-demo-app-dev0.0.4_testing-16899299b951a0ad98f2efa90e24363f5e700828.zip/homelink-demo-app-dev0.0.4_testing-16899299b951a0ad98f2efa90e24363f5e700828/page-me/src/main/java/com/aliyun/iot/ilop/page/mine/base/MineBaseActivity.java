package com.aliyun.iot.ilop.page.mine.base;

import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.view.MotionEvent;

import com.aliyun.iot.ilop.BaseActivity;
import com.aliyun.iot.aep.sdk.log.ALog;

/**
 * Created by david on 2018/4/8.
 *
 * @author david
 * @date 2018/04/08
 */
public abstract class MineBaseActivity extends BaseActivity {
    protected final String TAG = this.getClass().getSimpleName();


    protected Handler mHandler;

    protected abstract void initView();

    protected abstract void initData();

    protected abstract void initEvent();

    protected abstract void initHandler();

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        initView();
        initData();
        initEvent();
        initHandler();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getPointerCount() > 1) {
            ALog.d(TAG, "Multitouch detected!");
            return true;
        }

        return super.dispatchTouchEvent(ev);
    }
}
