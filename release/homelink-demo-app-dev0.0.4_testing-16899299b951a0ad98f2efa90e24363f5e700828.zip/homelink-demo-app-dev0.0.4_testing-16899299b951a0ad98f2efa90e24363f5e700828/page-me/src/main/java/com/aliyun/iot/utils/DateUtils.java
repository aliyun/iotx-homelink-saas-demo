package com.aliyun.iot.utils;

import android.content.Context;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

/**
 * Created by wb-zyl208210 on 2018/4/11.
 */

public class DateUtils {
    private static String TAG = "DateUtils";
    public static final String refPreData = "1000";//初次比对参考时间
    private SimpleDateFormat simpleFormatter;
    private Calendar calendar;
    SimpleDateFormat titleDateFormate;
    SimpleDateFormat fotterDateFormate;

    public boolean isTheSameDay(String preTime, String afterTime) {
        if (calendar == null) {
            calendar = Calendar.getInstance();
        }
       /* if (simpleFormatter == null) {
            simpleFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        }*/
        try {
            //calendar.setTime(simpleFormatter.parse(preTime));
            calendar.setTime(new Date(Long.parseLong(preTime)));

            int preDayOfYear = calendar.get(Calendar.DAY_OF_YEAR);
            int preYear = calendar.get(Calendar.YEAR);

            calendar.setTime(new Date(Long.parseLong(afterTime)));
            int afterDayOfYear = calendar.get(Calendar.DAY_OF_YEAR);
            int afterYear = calendar.get(Calendar.YEAR);

            //System.out.println(preDayOfYear + "--" + afterDayOfYear + "," + preYear + "--" + afterYear);
            if (preYear == afterYear && preDayOfYear == afterDayOfYear) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e(TAG, "date format is not yyyy-MM-dd HH:mm:ss，please check!");
        }
        return false;
    }
    //note：当前格式化日期，在切换语言后APP是清栈的，然后DateUtils会重新实例化，可以满足需求
    public String covertDate2TitleDate(Context context, String date) {
        if (calendar == null) {
            calendar = Calendar.getInstance();
        }
        Locale locale = context.getResources().getConfiguration().locale;

        if (titleDateFormate == null) {
            titleDateFormate = new SimpleDateFormat("MM/dd EEEE", locale);//"yy/MM/dd E"
        }

        try {
            return titleDateFormate.format(new Date(Long.parseLong(date)));

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public String covertDate2fotterDate(String date) {
        if (calendar == null) {
            calendar = Calendar.getInstance();
        }
       /* if (simpleFormatter == null) {
            simpleFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        }*/
        if (fotterDateFormate == null) {
            fotterDateFormate = new SimpleDateFormat("HH:mm");
        }
        try {
            //Date parse = simpleFormatter.parse(date);
            return fotterDateFormate.format(new Date(Long.parseLong(date)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;

    }

    public String covertYearMothDay(String date) {
        if (calendar == null) {
            calendar = Calendar.getInstance();
        }
       /* if (simpleFormatter == null) {
            simpleFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        }*/
        if (fotterDateFormate == null) {
            fotterDateFormate = new SimpleDateFormat("yyyy/MM/dd");
        }
        try {
            //Date parse = simpleFormatter.parse(date);
            return fotterDateFormate.format(new Date(Long.parseLong(date)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;

    }


    public String randomDate(String preDate) {
        Random random = new Random();
        long a = random.nextInt(12 * 60) * 60 * 1000;
        if (simpleFormatter == null) {
            simpleFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        }
        try {
            //Date parse = simpleFormatter.parse(preDate);
            long preDateLong = Long.parseLong(preDate);
            long time = preDateLong - a;
            return time + "";
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public String dateFormate(long date) {
        if (simpleFormatter == null) {
            simpleFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        }
        return simpleFormatter.format(new Date(date));
    }
}
