package com.aliyun.iot.ilop.page.mine.smallcomponents.bean;

import java.util.ArrayList;
import java.util.List;

public class ComponentProductDTO {
    private String productKey;
    private String deviceName;
    private String iotId;
    private List<ComponentPropertyDTO> properties;
    private String nickName;
    private String productName;
    private String iconUrl;
    private int deviceStatus;

    public ComponentProductDTO() {
    }

    public ComponentProductDTO(SmallComponentDeviceBean deviceBean) {
        this.productKey = deviceBean.getProductKey();
        this.deviceName = deviceBean.getDeviceName();
        this.iotId = deviceBean.getIotId();
        this.nickName = deviceBean.getNickName();
        this.productName = deviceBean.getProductName();
        this.iconUrl = deviceBean.getProductImage();
        this.deviceStatus = deviceBean.getStatus();
        ArrayList<PropertyBean> arrayList = deviceBean.getSwitchList();
        ArrayList list = new ArrayList();
        for (int i = 0; i < arrayList.size(); i++) {
            PropertyBean propertyBean = arrayList.get(i);
            ComponentPropertyDTO componentPropertyDTO = new ComponentPropertyDTO();
            componentPropertyDTO.setPropertyIdentifier(propertyBean.getPropertyIdentifier());
            componentPropertyDTO.setPropertyName(propertyBean.getPropertyName());
            list.add(componentPropertyDTO);
        }
        this.properties = list;
    }

    public String getProductKey() {
        return productKey;
    }

    public void setProductKey(String productKey) {
        this.productKey = productKey;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getIotId() {
        return iotId;
    }

    public void setIotId(String iotId) {
        this.iotId = iotId;
    }

    public List<ComponentPropertyDTO> getProperties() {
        return properties;
    }

    public void setProperties(List<ComponentPropertyDTO> properties) {
        this.properties = properties;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getIconUrl() {
        return iconUrl;
    }

    public void setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
    }

    public int getDeviceStatus() {
        return deviceStatus;
    }

    public void setDeviceStatus(int deviceStatus) {
        this.deviceStatus = deviceStatus;
    }
}
