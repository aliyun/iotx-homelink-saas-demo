package com.aliyun.iot.ilop.page.mine.base;

/**
 * Created by nht on 2018/6/14.
 */

public interface BaseView <Presenter extends BasePresenter>{
    void setPresenter(Presenter presenter);
}
