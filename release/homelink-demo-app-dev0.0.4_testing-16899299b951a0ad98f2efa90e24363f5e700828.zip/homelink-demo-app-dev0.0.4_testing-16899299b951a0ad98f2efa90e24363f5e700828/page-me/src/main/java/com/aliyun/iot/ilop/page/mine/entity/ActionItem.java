package com.aliyun.iot.ilop.page.mine.entity;

/**
 * Created by ZhuBingYang on 2019-04-18.
 */
public class ActionItem extends SettingItem {
    private Runnable action;

    public ActionItem(String text) {
        super(text);
    }

    public ActionItem(String text, Runnable action) {
        super(text);
        this.action = action;
    }

    public Runnable getAction() {
        return action;
    }

    public void setAction(Runnable action) {
        this.action = action;
    }

    @Override
    public String toString() {
        return "ActionItem{" +
                "action=" + action +
                '}';
    }
}
