package com.aliyun.iot.ilop.page.mine.base.activity;

import android.app.Dialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;

import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.link.ui.component.simpleLoadview.SimpleLoadingDialog;

/**
 * Created by nht on 2018/6/27.
 */

public class BaseDialogActivity extends FragmentActivity implements IDialogControl {
    private SimpleLoadingDialog waitDialog;
    protected Handler mHandler;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        mHandler = new Handler(Looper.getMainLooper());
        super.onCreate(savedInstanceState);
    }

    @Override
    public Dialog showWaitDialog(int resid) {
        return showWaitDialog(getString(resid));
    }

    @Override
    public Dialog showWaitDialog() {
        return showWaitDialog(getString(R.string.common_loading));
    }

    @Override
    public Dialog showWaitDialog(String msg) {
        if (waitDialog == null) {
            waitDialog = new SimpleLoadingDialog(BaseDialogActivity.this);
        }
        waitDialog.showLoading(msg);
        return waitDialog;
    }

    @Override
    public void hideWaitDialog() {
        if (waitDialog != null && waitDialog.isShowing()) {
            try {
                waitDialog.dismiss();
                waitDialog = null;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
