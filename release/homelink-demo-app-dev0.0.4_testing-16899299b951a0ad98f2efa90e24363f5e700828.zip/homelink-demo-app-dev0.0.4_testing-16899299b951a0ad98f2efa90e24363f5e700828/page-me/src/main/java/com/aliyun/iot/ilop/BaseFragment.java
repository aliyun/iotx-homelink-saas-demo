package com.aliyun.iot.ilop;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.aliyun.iot.aep.sdk.log.ALog;


public class BaseFragment extends Fragment {
    private static final String TAG = "BaseFragment";
    private Bundle mPageArguments;
    private boolean isCreated = false;

    public void BaseFragment() {
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ALog.d(TAG, "onCreate");
        //TODO 可以生成ChannelID
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        ALog.d(TAG, "onCreateView()");
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.isCreated = true;
        ALog.d(TAG, "onViewCreated()");
        //注册相关第三方
    }

    @Override
    public void onResume() {
        ALog.d(TAG, "onResume()");
        super.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public boolean onBack(/*Fragment fragment*/) {
        ALog.d(TAG, "onBack:" + this.getClass().getName());
        return false;
    }

    public void onFragmentResume(/*Fragment fragment*/) {
        ALog.d(TAG, "onFragmentResume:" + this.getClass().getName() + "state-v:" + this.isVisible() + ",state-hidden:" + this.isHidden());
    }

    public void onFragmentRefresh() {
        ALog.d(TAG, "onFragmentRefresh:" + this.getClass().getName());
    }

    public void setPageArguments(Bundle pageArguments) {
        mPageArguments = pageArguments;
    }
}
