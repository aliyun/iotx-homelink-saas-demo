package com.aliyun.iot.ilop.page.mine.smallcomponents.bean;

import android.os.Parcel;
import android.os.Parcelable;

public class PropertyBean implements Parcelable {

    private boolean check;
    private String propertyName;
    private String dataType;
    private String productKey;
    private String propertyId;
    private String propertyIdentifier;

    public PropertyBean() {

    }

    protected PropertyBean(Parcel in) {
        check = in.readByte() != 0;
        propertyName = in.readString();
        dataType = in.readString();
        productKey = in.readString();
        propertyId = in.readString();
        propertyIdentifier = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeByte((byte) (check ? 1 : 0));
        dest.writeString(propertyName);
        dest.writeString(dataType);
        dest.writeString(productKey);
        dest.writeString(propertyId);
        dest.writeString(propertyIdentifier);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<PropertyBean> CREATOR = new Creator<PropertyBean>() {
        @Override
        public PropertyBean createFromParcel(Parcel in) {
            return new PropertyBean(in);
        }

        @Override
        public PropertyBean[] newArray(int size) {
            return new PropertyBean[size];
        }
    };

    public boolean isCheck() {
        return check;
    }

    public void setCheck(boolean check) {
        this.check = check;
    }

    public String getPropertyName() {
        return propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getProductKey() {
        return productKey;
    }

    public void setProductKey(String productKey) {
        this.productKey = productKey;
    }

    public String getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(String propertyId) {
        this.propertyId = propertyId;
    }

    public String getPropertyIdentifier() {
        return propertyIdentifier;
    }

    public void setPropertyIdentifier(String propertyIdentifier) {
        this.propertyIdentifier = propertyIdentifier;
    }
}
