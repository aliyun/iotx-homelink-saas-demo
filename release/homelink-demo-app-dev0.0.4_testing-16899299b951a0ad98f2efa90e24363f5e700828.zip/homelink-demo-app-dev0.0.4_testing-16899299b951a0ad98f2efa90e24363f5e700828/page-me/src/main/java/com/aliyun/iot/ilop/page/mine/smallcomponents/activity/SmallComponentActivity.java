package com.aliyun.iot.ilop.page.mine.smallcomponents.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.aliyun.iot.homelink.demo.commons.util.DimensionUtil;
import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.base.MineBaseActivity;
import com.aliyun.iot.ilop.page.mine.smallcomponents.adapter.SmallComponentDeviceAdapter;
import com.aliyun.iot.ilop.page.mine.smallcomponents.adapter.SmallComponentSceneAdapter;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.SmallComponentDeviceBean;
import com.aliyun.iot.ilop.page.mine.smallcomponents.handler.SmallComponentHandler;
import com.aliyun.iot.ilop.page.mine.smallcomponents.interfaces.ISmallComponentPage;
import com.aliyun.iot.ilop.page.mine.view.SimpleTopbar;
import com.aliyun.iot.link.ui.component.simpleLoadview.LinkSimpleLoadView;
import com.aliyun.iot.utils.view.YcCardView;

import java.util.ArrayList;

public class SmallComponentActivity extends MineBaseActivity implements ISmallComponentPage, View.OnClickListener {

    private SimpleTopbar mSmallComponentTitle;
    private YcCardView card_intelligence;
    private YcCardView card_device;
    private final float mCoefficientOne = 0.57f;
    private final float mCoefficientTwo = 0.88f;
    private ArrayList mdeviceList = new ArrayList();
    private ArrayList mIntelligenceList = new ArrayList();
    private TextView tv_no_scene;
    private TextView tv_no_device;
    private GridView grid_scene;
    private GridView grid_device;
    private SmallComponentSceneAdapter scene_adapter;
    private SmallComponentDeviceAdapter device_adapter;
    private ImageView iv_add_device, iv_add_scene;
    private SmallComponentHandler smallComponentHandler;
    private LinkSimpleLoadView loading_view;
    private int currentLoading = 0;
    private final int SET_WIDGET_CODE = 200;
    private final int RESULT_OK = 201;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ilop_mine_small_component_activity);
        //跳转到设备组件界面
        Bundle bundle = getIntent().getBundleExtra("key");
        if (bundle != null) {
            String origin = bundle.getString("origin");
            if ("app_widget".equals(origin)) {
                Intent intent1 = new Intent(this, SmallComponentDeviceActivity.class);
                startActivity(intent1);
            }

        }

    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        smallComponentHandler.refreshData();
    }

    @Override
    protected void initView() {
        mSmallComponentTitle = findViewById(R.id.small_component_title);
        card_intelligence = findViewById(R.id.card_intelligence);
        card_device = findViewById(R.id.card_device);
        tv_no_scene = findViewById(R.id.tv_no_scene);
        tv_no_device = findViewById(R.id.tv_no_device);
        grid_scene = findViewById(R.id.grid_scene);
        grid_device = findViewById(R.id.grid_device);
        iv_add_device = findViewById(R.id.iv_add_device);
        iv_add_scene = findViewById(R.id.iv_add_scene);
        loading_view=findViewById(R.id.loading_view);
    }

    @Override
    protected void initData() {
        mSmallComponentTitle.setTitle(this.getResources().getString(R.string.appExtension_home));
        setCardSize();
        /*setCardSize();
        if (mdeviceList.size() > 0) {
            tv_no_device.setVisibility(View.GONE);
            grid_device.setVisibility(View.VISIBLE);
            device_adapter = new SmallComponentDeviceAdapter(mdeviceList, this);
            grid_device.setAdapter(device_adapter);
        } else {
            tv_no_device.setVisibility(View.VISIBLE);
            grid_device.setVisibility(View.GONE);
        }

        if (mIntelligenceList.size() > 0) {
            tv_no_scene.setVisibility(View.GONE);
            grid_scene.setVisibility(View.VISIBLE);
            scene_adapter = new SmallComponentSceneAdapter(mIntelligenceList, this);
            grid_scene.setAdapter(scene_adapter);
        } else {
            tv_no_scene.setVisibility(View.VISIBLE);
            grid_scene.setVisibility(View.GONE);
        }*/
      /*  mineLoadingDialog = new MineLoadingDialog(this);
        mineLoadingDialog.setProgressMesssage(R.string.mine_tp_loading);*/

    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SET_WIDGET_CODE && resultCode == RESULT_OK) {
            smallComponentHandler.refreshData();
        }
    }

    //动态设置卡片大小
    private void setCardSize() {

       /* WindowManager manager = this.getWindowManager();
        DisplayMetrics outMetrics = new DisplayMetrics();
        manager.getDefaultDisplay().getMetrics(outMetrics);*/
        //   int width = outMetrics.widthPixels;
        // int small_component_width = (width - DensityUtil.dip2px(this, 32));
        /*float device_coefficient = mCoefficientOne;
        float intelligence_coefficient = mCoefficientOne;*/
        int hightScene = DimensionUtil.dip2px(this, 183);
        int hightDevice = DimensionUtil.dip2px(this, 183);
        if (mdeviceList.size() > 4) {
            hightDevice = DimensionUtil.dip2px(this, 283);
        }
        if (mIntelligenceList.size() > 4) {
            /*intelligence_coefficient = mCoefficientTwo;*/
            hightScene = DimensionUtil.dip2px(this, 283);
        }
        ViewGroup.LayoutParams para_intelligence = card_intelligence.getLayoutParams();
        para_intelligence.height = hightScene;
        card_intelligence.setLayoutParams(para_intelligence);
        ViewGroup.LayoutParams para_device = card_device.getLayoutParams();
        para_device.height = hightDevice;
        card_device.setLayoutParams(para_device);

    }


    @Override
    protected void initEvent() {
        mSmallComponentTitle.setOnBackClickListener(new SimpleTopbar.onBackClickListener() {
            @Override
            public void onBackClick() {
                SmallComponentActivity.this.finish();
            }
        });
        iv_add_scene.setOnClickListener(this);
        iv_add_device.setOnClickListener(this);

    }

    @Override
    protected void initHandler() {
        smallComponentHandler = new SmallComponentHandler(this);
    }

    @Override
    public void onClick(View v) {

        int i = v.getId();
        Intent intent = null;
        if (i == R.id.iv_add_device) {
            intent = new Intent(this, SmallComponentDeviceActivity.class);
        } else if (i == R.id.iv_add_scene) {
            intent = new Intent(this, SmallComponentSceneActivity.class);
        }
        startActivityForResult(intent, SET_WIDGET_CODE);

    }

    @Override
    public void showDeviceList(ArrayList<SmallComponentDeviceBean> list) {
        mdeviceList = list;
        setCardSize();
        if (mdeviceList.size() > 0) {
            tv_no_device.setVisibility(View.GONE);
            grid_device.setVisibility(View.VISIBLE);
            device_adapter = new SmallComponentDeviceAdapter(mdeviceList, this);
            grid_device.setAdapter(device_adapter);
        } else {
            tv_no_device.setVisibility(View.VISIBLE);
            grid_device.setVisibility(View.GONE);
        }

        if (mIntelligenceList.size() > 0) {
            tv_no_scene.setVisibility(View.GONE);
            grid_scene.setVisibility(View.VISIBLE);
            scene_adapter = new SmallComponentSceneAdapter(mIntelligenceList, this);
            grid_scene.setAdapter(scene_adapter);
        } else {
            tv_no_scene.setVisibility(View.VISIBLE);
            grid_scene.setVisibility(View.GONE);
        }
    }

    @Override
    public void showError(@Nullable String msg) {
        if (null != msg) {
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.mine_network_error, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void showLoading(int num) {
        currentLoading += num;
        //mineLoadingDialog.show();
        loading_view.showLoading(getResources().getString(R.string.mine_tp_loading));
    }

    @Override
    public void hideLoading() {
        currentLoading--;
        if (currentLoading == 0) {
           // mineLoadingDialog.dismiss();
            loading_view.hide();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (smallComponentHandler != null) {
            smallComponentHandler.destroy();
        }
        /*if (mineLoadingDialog.isShowing()) {
            currentLoading = 0;
            mineLoadingDialog.dismiss();
        }*/
    }
}
