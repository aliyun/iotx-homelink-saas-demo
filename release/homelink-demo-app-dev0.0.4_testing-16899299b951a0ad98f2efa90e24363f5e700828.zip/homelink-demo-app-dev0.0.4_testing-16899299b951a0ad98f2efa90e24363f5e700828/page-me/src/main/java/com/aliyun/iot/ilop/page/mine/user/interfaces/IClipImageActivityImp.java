package com.aliyun.iot.ilop.page.mine.user.interfaces;

public interface IClipImageActivityImp {


    void onUpdateSuccess();

    void onUpdateError(String error);


}
