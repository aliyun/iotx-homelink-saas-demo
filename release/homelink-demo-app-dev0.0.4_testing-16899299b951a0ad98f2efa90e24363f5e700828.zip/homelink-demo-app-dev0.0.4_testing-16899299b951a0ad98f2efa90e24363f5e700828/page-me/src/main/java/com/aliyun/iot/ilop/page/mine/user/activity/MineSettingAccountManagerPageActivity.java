package com.aliyun.iot.ilop.page.mine.user.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.sdk.android.openaccount.OpenAccountSDK;
import com.alibaba.sdk.android.openaccount.callback.InitResultCallback;
import com.alibaba.sdk.android.openaccount.callback.LoginCallback;
import com.alibaba.sdk.android.openaccount.model.OpenAccountSession;
import com.alibaba.sdk.android.openaccount.ui.OpenAccountUIConfigs;
import com.alibaba.sdk.android.openaccount.ui.OpenAccountUIService;
import com.alibaba.sdk.android.openaccount.ui.callback.EmailResetPasswordCallback;
import com.alibaba.sdk.android.openaccount.ui.impl.OpenAccountUIServiceImpl;
import com.alibaba.sdk.android.openaccount.util.ResourceUtils;
import com.aliyun.alink.linksdk.tmp.api.DeviceManager;
import com.aliyun.iot.aep.Util.CountryUtils;
import com.aliyun.iot.aep.component.router.Router;
//import com.aliyun.iot.aep.oa.page.OAResetMailPasswordActivity;
//import com.aliyun.iot.aep.oa.page.data.CountryBean;
import com.aliyun.iot.aep.sdk.PushManager;
import com.aliyun.iot.aep.sdk.framework.AApplication;
import com.aliyun.iot.aep.sdk.login.ILogoutCallback;
import com.aliyun.iot.aep.sdk.login.LoginBusiness;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.ilop.page.mine.BuildConfig;
import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.base.MineBaseActivity;
import com.aliyun.iot.ilop.page.mine.user.handler.MineUserSettingActivityHanlder;
import com.aliyun.iot.ilop.page.mine.user.interfaces.IMIneSettingAccountActivityImp;
import com.aliyun.iot.ilop.page.mine.view.MineDialog;
import com.aliyun.iot.ilop.page.mine.view.MineDialog.OnDialogButtonClickListener;
import com.aliyun.iot.ilop.page.mine.view.MineLoadingDialog;
import com.aliyun.iot.ilop.page.mine.view.MineNotifyItem;
import com.aliyun.iot.ilop.page.mine.view.SimpleTopbar;
import com.aliyun.iot.ilop.page.mine.view.SimpleTopbar.onBackClickListener;
import com.aliyun.iot.link.ui.component.LinkToast;
import com.aliyun.iot.utils.AppWidgetHelper;
import com.aliyun.iot.utils.LoginUtils;
import com.aliyun.iot.utils.SpUtil;

import java.util.HashMap;

import static com.aliyun.iot.aep.Util.CountryUtils.globalProductList;


/**
 * Created by david on 2018/4/16.
 *
 * @author david
 * @date 2018/04/16
 */
public class MineSettingAccountManagerPageActivity extends MineBaseActivity implements OnClickListener,
        onBackClickListener, OnDialogButtonClickListener, IMIneSettingAccountActivityImp {

    private final String TAG = "MineSettingAccount";

    private static final String CODE_CHINA = "86";
    //请求相册
    private static final int REQUEST_PICK = 101;
    //删除账号
    private static final int REQUEST_REMOVE = 104;
    //请求截图
    private static final int REQUEST_CROP_PHOTO = 102;

    //  修改昵称
    private static final int REQUEST_MODIFY_NIKENAME = 105;


    private static final int RESULT_PERMISSION = 200;


    private String mLoginType = "";

    private TextView mLogoutButton;
    private SimpleTopbar mTopbar;
    private MineDialog mConfirmDialog;
    private static final int TOCOUNTLISTCODE = 0x111;

    private MineUserSettingActivityHanlder hanlder;

    private ImageView mHeadAvatar;
    private ImageView mRightArraw;
    private MineNotifyItem mNickname;
    private MineNotifyItem mAccount;
    private MineNotifyItem mRegion;
    private MineNotifyItem mResetPwd;
    private MineNotifyItem mRemoveAccount;

    private long lastTime = 0;


    private MineLoadingDialog mineLoadingDialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ilop_mine_setting_account_activity);
        mineLoadingDialog = new MineLoadingDialog(this);
        mineLoadingDialog.setProgressMesssage(R.string.mine_account_loading_loginout);
    }


    @Override
    protected void initView() {
        mTopbar = (SimpleTopbar) findViewById(R.id.mine_topbar);
        mLogoutButton = (TextView) findViewById(R.id.mine_setting_account_logout_button);
        mNickname = findViewById(R.id.mine_home_nickname_minenotifyitem);
        mAccount = findViewById(R.id.mine_home_account_minenotifyitem);
        mRegion = findViewById(R.id.mine_home_region_minenotifyitem);
        mResetPwd = findViewById(R.id.mine_home_resetpwd_minenotifyitem);
        mRemoveAccount = findViewById(R.id.mine_home_remove_account_minenotifyitem);
        mHeadAvatar = findViewById(R.id.mine_account_setting_avatar);
        mRightArraw = findViewById(R.id.ilop_mine_icon_right_arrow);
    }

    @Override
    protected void initData() {
        if (null != mTopbar) {
            mTopbar.setTitle(getString(R.string.mine_account_manager));
        }
        mNickname.setTitle(getString(R.string.setting_nick_name));

        mAccount.setTitle(getString(R.string.setting_account));
        mAccount.showRightArrowImage(false);

        mRegion.setTitle(getString(R.string.setting_account_address));
        mRegion.showUnderLine(false);
        mRegion.showRightArrowImage(false);

        mResetPwd.setTitle(getString(R.string.setting_change_password));
        mRemoveAccount.setTitle(getString(R.string.setting_remove_account));
        mRemoveAccount.showUnderLine(false);
        setRegion();
    }

    @Override
    protected void initEvent() {
        if (null != mLogoutButton) {
            mLogoutButton.setOnClickListener(this);
        }

        if (null != mTopbar) {
            mTopbar.setOnBackClickListener(this);
        }

        mNickname.setOnClickListener(this);
        mResetPwd.setOnClickListener(this);
        mHeadAvatar.setOnClickListener(this);
        mRemoveAccount.setOnClickListener(this);
        if ("debugTest".equals(BuildConfig.BUILD_TYPE)) {
            mRemoveAccount.setVisibility(View.GONE);
        }
    }

    @Override
    protected void initHandler() {
        hanlder = new MineUserSettingActivityHanlder(this);
        hanlder.getCache();
    }

    @Override
    public void onClick(View v) {
        long curTime = System.currentTimeMillis();
        if ((curTime - lastTime) < 300) {
            return;
        }
        lastTime = curTime;
        if (R.id.mine_setting_account_logout_button == v.getId()) {
            showConfirmDialog();

        } else if (R.id.mine_home_nickname_minenotifyitem == v.getId()) {//修改昵称
            Intent intent = new Intent(this, ModifyNikeNameActivity.class);
            String nicknameHint = getString(R.string.setting_click_set);
            if (!nicknameHint.equalsIgnoreCase(mNickname.getRightTitleText())) {
                intent.putExtra("nikeName", mNickname.getRightTitleText());
            }
            startActivityForResult(intent, REQUEST_MODIFY_NIKENAME);
        } else if (R.id.mine_home_resetpwd_minenotifyitem == v.getId()) {//修改密码
            if (mLoginType.equals("phone")) {
                resetPhonePassword();
            } else if (mLoginType.equals("email")) {
                resetEmailPassword();
            }
        } else if (R.id.mine_home_remove_account_minenotifyitem == v.getId()) {//删除账号

            Router.getInstance().toUrl(this, "page/me/account/remove", null, REQUEST_REMOVE);

        } else if (R.id.mine_account_setting_avatar == v.getId()) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, RESULT_PERMISSION);
            } else {
                //跳转到调用系统图库
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(Intent.createChooser(intent, "choose_picture"), REQUEST_PICK);
            }
        }
    }

    //手机号修改密码
    private void resetPhonePassword() {
        OpenAccountSDK.turnOnDebug();
        OpenAccountSDK.asyncInit(this, new InitResultCallback() {
            @Override
            public void onSuccess() {
                ALog.e(TAG, "onSuccess:asyncInit ");
            }

            @Override
            public void onFailure(int i, String s) {
                ALog.e(TAG, "onFailure:asyncInit ");
            }
        });
        String account = mAccount.getRightTitleText();
        String[] mobiels = account.replace("+", "").split(" ");
        OpenAccountUIService var3 = (OpenAccountUIService) OpenAccountSDK.getService(OpenAccountUIService.class);
        HashMap var2 = new HashMap();
        if (!TextUtils.isEmpty(mobiels[0])) {
            var2.put("LocationCode", mobiels[0]);
        }
        if (!TextUtils.isEmpty(mobiels[1])) {
            var2.put("mobile", mobiels[1]);
        }
        var2.put("entrance", "app");
        var3.showResetPassword(this, var2, OpenAccountUIConfigs.UnifyLoginFlow.resetPasswordActivityClass, this.getResetPasswordLoginCallback());
    }

    //修改密码（邮箱）
    private void resetEmailPassword() {
//        String account = mAccount.getRightTitleText();
//        OpenAccountUIServiceImpl._emailResetPasswordCallback = getEmailResetPasswordCallback();
//        Intent intent = new Intent(this, OAResetMailPasswordActivity.class);
//        intent.putExtra("entrance", "app");
//        if (!TextUtils.isEmpty(account)) {
//            intent.putExtra("mail_id", account);
//        }
//        startActivity(intent);
    }


    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        hanlder.requestRegion();
    }

    @Override
    protected void onResume() {
        super.onResume();
        hanlder.requestPersonInfo();

    }

    private void showConfirmDialog() {
        if (null == mConfirmDialog) {
            mConfirmDialog = new MineDialog(this);
            mConfirmDialog.setCancelable(false);
            mConfirmDialog.setTitle(getString(R.string.mine_account_dialog_logout_confirm));
            mConfirmDialog.setPositiveButtonText(getString(R.string.mine_dialog_positive));
            mConfirmDialog.setNegativeButtonText(getString(R.string.mine_dialog_negative));
            mConfirmDialog.setOnDialogButtonClickListener(this);
        }

        if (!mConfirmDialog.isShowing()) {
            mConfirmDialog.show();
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == RESULT_PERMISSION) {
            if (Manifest.permission.READ_EXTERNAL_STORAGE.equalsIgnoreCase(permissions[0]) && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //跳转到调用系统图库
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(Intent.createChooser(intent, "choose_picture"), REQUEST_PICK);
            }
        }
    }

    @Override
    public void onBackClick() {
        if (isFinishing()) {
            return;
        }

        onBackPressed();
    }

    private void doLogout() {
        mineLoadingDialog.show();
        if (!CountryUtils.judgeIsEurope(AApplication.getInstance().getApplicationContext())) {
            PushManager.getInstance().unbindUser();
        }
       /* Router.getInstance().registerModuleUrlHandler(MineConstants.MINE_URL_COUNTRY_LIST,
                new IUrlHandler() {
                    @Override
                    public void onUrlHandle(Context context, String s, Bundle bundle, boolean b, int i) {
                        Intent intent = new Intent();
                        if (TOCOUNTLISTCODE == i) {
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        } else {
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        }
                        intent.setAction(MineConstants.MINE_URL_ACTION_NAVIGATION);
                        intent.setData(Uri.parse(s));
                        context.startActivity(intent);
                    }
                });*/
        LoginBusiness.logout(new ILogoutCallback() {
            @Override
            public void onLogoutSuccess() {
                //退出后清空设备缓存信息和搜索数据
                DeviceManager.getInstance().clearBasicDataList();
                SpUtil.remove(MineSettingAccountManagerPageActivity.this, "DEVICE_LIST_KEY");//清空缓存的设备列表
                globalProductList.clear();
                mineLoadingDialog.dismiss();
                //更新小组件
                AppWidgetHelper.refreshDeviceWidget(MineSettingAccountManagerPageActivity.this, "GETDEVICELIST_CLEAR_PROPERTY_MAP");
                // 跳转到登录界面
                LoginUtils.StartLogin(MineSettingAccountManagerPageActivity.this, null, MineSettingAccountManagerPageActivity.this.getApplicationContext());
            }

            @Override
            public void onLogoutFailed(int i, String s) {
                mineLoadingDialog.dismiss();
                ALog.e(TAG, "退出失败");
                Toast.makeText(MineSettingAccountManagerPageActivity.this, s, Toast.LENGTH_LONG).show();
            }
        });


       /* Router.getInstance().toUrl(getApplicationContext(),
                MineConstants.MINE_URL_COUNTRY_LIST, null, TOCOUNTLISTCODE);*/
    }


    private LoginCallback getResetPasswordLoginCallback() {
        return new LoginCallback() {

            @Override
            public void onFailure(int i, String s) {
                ALog.e(TAG, "onFailure: " + i + "  " + s);
//                LinkToast.makeText(MineSettingAccountManagerPageActivity.this, s, Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onSuccess(OpenAccountSession openAccountSession) {
                ALog.e(TAG, "onSuccess: ");
                doLogout();

                LinkToast.makeText(MineSettingAccountManagerPageActivity.this, ResourceUtils.getString("mine_account_reset_pwd_hint"), Toast.LENGTH_SHORT).show();

            }
        };
    }

    private EmailResetPasswordCallback getEmailResetPasswordCallback() {
        return new EmailResetPasswordCallback() {

            @Override
            public void onSuccess(OpenAccountSession session) {
                doLogout();
                LinkToast.makeText(MineSettingAccountManagerPageActivity.this, ResourceUtils.getString("mine_account_reset_pwd_hint"), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(int code, String message) {
                LinkToast.makeText(MineSettingAccountManagerPageActivity.this, message, Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onEmailSent(String email) {
//                LinkToast.makeText(getApplicationContext(), email + " 已经发送了", Toast.LENGTH_LONG).show();
            }

        };
    }

    @Override
    public void onNegativeClick(MineDialog dialog) {
        if (isFinishing()) {
            return;
        }

        if (dialog.isShowing()) {
            dialog.dismiss();
        }
    }

    @Override
    public void onPositiveClick(MineDialog dialog) {
        if (isFinishing()) {
            return;
        }
        dialog.dismiss();
        doLogout();
    }

    @Override
    public void showAvatar(Uri url) {
        if (url == null) {
            return;
        }
        mHeadAvatar.setImageBitmap(BitmapFactory.decodeFile(url.getPath()));
    }

    @Override
    public void showNickName(String nickName) {
        if (!TextUtils.isEmpty(nickName) && !"null".equalsIgnoreCase(nickName)) {  // avoid nikeName widget display null String
            mNickname.setRightText(nickName);
        } else {
            mNickname.setRightText(getString(R.string.setting_click_set));
        }
    }

    @Override
    public void showAccount(String accountNumber) {
        if (!TextUtils.isEmpty(accountNumber)) {
            mAccount.setRightText(accountNumber);
        } else {
            mAccount.setRightText("");
        }
    }

    @Override
    public void showRegion(String region) {


    }

    /**
     * 设置账号所在地
     */
    private void setRegion() {
//        SharedPreferences sp = getSharedPreferences("ilop_sp", Context.MODE_PRIVATE);
//        String countryCode = sp.getString("codeSelected", "");
//        List<CountryBean> countryBeans = CountryUtils.GetCountryBeanList(this);
//        String region = "";
//        for (int i = 0; i < countryBeans.size(); i++) {
//            if (countryBeans.get(i).getCode().equals(countryCode)) {
//                CountryBean countryBean = countryBeans.get(i);
//                String languagecode = getResources().getConfiguration().locale.getCountry();
//                if (languagecode.equals("CN")) {
//                    region = countryBean.getArea_name();
//                } else if (languagecode.equals("FR")) {
//                    region = countryBean.getArea_french_name();
//                } else if (languagecode.equals("DE")) {
//                    region = countryBean.getArea_german_name();
//                } else if (languagecode.equals("JP")) {
//                    region = countryBean.getArea_japanese_name();
//                } else if (languagecode.equals("KR")) {
//                    region = countryBean.getArea_korean_name();
//                } else if (languagecode.equals("ES")) {
//                    region = countryBean.getArea_spain_name();
//                } else if (languagecode.equals("RU")) {
//                    region = countryBean.getArea_russian_name();
//                } else {
//                    region = countryBean.getArea_english_name();
//                }
//                break;
//            }
//        }
//        if (region != null) {
//            mRegion.setRightText(region);
//        }
    }

    @Override
    public void showResetPwdView(String loginType) {
        mResetPwd.setVisibility(View.VISIBLE);
        if (loginType.equals("phone")) {
            mLoginType = loginType;
        } else if (loginType.equals("email")) {
            mLoginType = loginType;
        } else {
            //三方账号不能修改头像,用户名
            mResetPwd.setVisibility(View.GONE);
            mNickname.setOnClickListener(null);
            mNickname.showRightArrowImage(false);
            mHeadAvatar.setOnClickListener(null);
            mRightArraw.setVisibility(View.GONE);
            mAccount.setVisibility(View.GONE);
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_PICK:  //调用系统相册返回
                if (resultCode == RESULT_OK) {
                    Uri uri = data.getData();
                    gotoClipActivity(uri);
                }
                break;
            case REQUEST_CROP_PHOTO:  //剪切图片返回
                if (resultCode == RESULT_OK) {
                    LinkToast.makeText(MineSettingAccountManagerPageActivity.this, ResourceUtils.getString("mine_account_modify_success"), Toast.LENGTH_SHORT).show();
                }
                break;
            case REQUEST_MODIFY_NIKENAME:// modify nikename
                if (resultCode == RESULT_OK) {
                    LinkToast.makeText(MineSettingAccountManagerPageActivity.this, ResourceUtils.getString("setting_success"), Toast.LENGTH_SHORT).show();
                }
                break;
            case REQUEST_REMOVE://删除账号
                if (resultCode == RESULT_OK) {
                    removeAccount();
                }
                break;
        }

    }

    private void removeAccount() {
       /* Router.getInstance().registerModuleUrlHandler(MineConstants.MINE_URL_COUNTRY_LIST,
                new IUrlHandler() {
                    @Override
                    public void onUrlHandle(Context context, String s, Bundle bundle, boolean b, int i) {
                        Intent intent = new Intent();
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        intent.setAction(MineConstants.MINE_URL_ACTION_NAVIGATION);
                        intent.setData(Uri.parse(s));
                        context.startActivity(intent);
                    }
                });*/
        LoginBusiness.logout(null);
       /* Router.getInstance().toUrl(getApplicationContext(),
                MineConstants.MINE_URL_COUNTRY_LIST, null, TOCOUNTLISTCODE);*/
        // 跳转到登录界面
        LoginUtils.StartLogin(this, null, this.getApplicationContext());
    }


    private void gotoClipActivity(Uri uri) {
        if (uri == null) {
            return;
        }
        Bundle bundle = new Bundle();
        bundle.putParcelable("uri", uri);
        Router.getInstance().toUrl(this,
                "hld://clip_image", bundle, REQUEST_CROP_PHOTO);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        hanlder.destroy();
        if (mineLoadingDialog.isShowing()) {
            mineLoadingDialog.dismiss();
        }
        if (null != mConfirmDialog) {
            if (mConfirmDialog.isShowing()) {
                mConfirmDialog.dismiss();
            }

            mConfirmDialog = null;
        }
    }


}
