package com.aliyun.iot.aep.sdk;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;


/**
 * Created by xingwei on 2018/4/2.
 */

public class PushManager {

    static final String BIND = "/uc/bindPushChannel";
    static final String UN_BIND = "/uc/unbindPushChannel";


    private static class SingletonHolder {
        private static final PushManager INSTANCE = new PushManager();
    }

    private PushManager() {
    }

    public static final PushManager getInstance() {
        return SingletonHolder.INSTANCE;
    }


//    public void init(Application app) {
//        initPush(app);
//    }
//
    public void unbindUser() {
//        request(UN_BIND);
    }
//
    public void bindUser() {
//        request(BIND);
    }
//
//
//    private void initPush(Application app) {
//        PushServiceFactory.init(app);
//        CloudPushService pushService = PushServiceFactory.getCloudPushService();
//        String securityIndex = (String) AConfigure.getInstance().getConfig().get("securityIndex");
//        pushService.setSecurityGuardAuthCode(securityIndex);
////        String lang = EnvConfigure.getEnvArg("language");
////        if (TextUtils.isEmpty(lang)) {
////            lang = "zh-CN";
////        }
////        final String finalLang = lang;
//
//        pushService.register(app, new CommonCallback() {
//            @Override
//            public void onSuccess(String response) {
//                ALog.d("aep-demo", "init cloudchannel success");
////                String path = LoginBusiness.isLogin() ? BIND : UN_BIND;
////                request(path);
//
//                // set device id
//                String deviceId = PushServiceFactory.getCloudPushService().getDeviceId();
//                if (TextUtils.isEmpty(deviceId)) {
//                    deviceId = "没有获取到";
//                }
//                EnvConfigure.putEnvArg(EnvConfigure.KEY_DEVICE_ID, deviceId);
//
//                if (LoginBusiness.isLogin()) {
//                    request(BIND);
//                }
//            }
//
//            @Override
//            public void onFailed(String errorCode, String errorMessage) {
//                ALog.d("aep-demo", "init cloudchannel failed -- errorcode:" + errorCode + " -- errorMessage:" + errorMessage);
//            }
//        });
//
//        // bind user id
//        IntentFilter intentFilter = new IntentFilter();
//        intentFilter.addAction(LoginBusiness.LOGIN_CHANGE_ACTION);
//        LocalBroadcastManager lb = LocalBroadcastManager.getInstance(app);
//        lb.registerReceiver(new BroadcastReceiver() {
//            @Override
//            public void onReceive(Context context, Intent intent) {
//                if (LoginBusiness.isLogin()) {
//                    request(BIND);
//                }
//            }
//        }, intentFilter);
//    }
//
//    void request(String path) {
//        String deviceId;
//        if (CountryUtils.judgeIsEurope(AApplication.getInstance().getApplicationContext())) {
//            deviceId = DeviceUuidFactory.getInstance(AApplication.getInstance().getApplicationContext()).getDeviceUuid().toString();
//        } else {
//            CloudPushService pushService = PushServiceFactory.getCloudPushService();
//            deviceId = pushService.getDeviceId();
//            if (TextUtils.isEmpty(deviceId)) {
//                return;
//            }
//        }
//        String apiVersion = "1.0.2";
//        IoTRequestBuilder builder = new IoTRequestBuilder()
//                .setAuthType("iotAuth")
//                .setScheme(Scheme.HTTPS)
//                .setPath(path)
//                .setApiVersion(apiVersion)
//                .addParam("deviceType", "ANDROID")
//                .addParam("deviceId", deviceId);
//        IoTRequest request = builder.build();
//        IoTAPIClient ioTAPIClient = new IoTAPIClientFactory().getClient();
//        ioTAPIClient.send(request, new IoTCallback() {
//            @Override
//            public void onFailure(IoTRequest ioTRequest, Exception e) {
//                e.printStackTrace();
//                ALog.d("Bind --->>>", "Failure");
//            }
//
//            @Override
//            public void onResponse(IoTRequest ioTRequest, IoTResponse ioTResponse) {
//                ALog.d("Bind --->>>", "Success");
//            }
//        });
//    }
//
//    //绑定欧洲push服务
//    public void BindEuropeUser(Context app) {
//        IntentFilter intentFilter = new IntentFilter();
//        intentFilter.addAction(LoginBusiness.LOGIN_CHANGE_ACTION);
//        LocalBroadcastManager lb = LocalBroadcastManager.getInstance(app);
//        lb.registerReceiver(new BroadcastReceiver() {
//            @Override
//            public void onReceive(Context context, Intent intent) {
//                if (LoginBusiness.isLogin()) {
//                    request(BIND);
//                }
//            }
//        }, intentFilter);
//        if (LoginBusiness.isLogin()) {
//            request(BIND);
//        }
//    }


}
