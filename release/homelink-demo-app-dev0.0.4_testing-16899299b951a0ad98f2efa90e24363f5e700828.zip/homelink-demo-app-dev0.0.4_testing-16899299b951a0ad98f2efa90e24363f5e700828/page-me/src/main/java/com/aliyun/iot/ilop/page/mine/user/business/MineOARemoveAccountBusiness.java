package com.aliyun.iot.ilop.page.mine.user.business;

import android.os.Handler;
import android.os.Message;
import com.alibaba.sdk.android.openaccount.util.ResourceUtils;
import com.aliyun.iot.aep.Util.CountryUtils;
//import com.aliyun.iot.aep.oa.OAUserHelper;
import com.aliyun.iot.aep.sdk.PushManager;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTCallback;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTResponse;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.framework.AApplication;
import com.aliyun.iot.aep.sdk.log.ALog;

public class MineOARemoveAccountBusiness {


    public static final int RESULT_SUCCESS = 0x00000001;
    public static final int RESULT_FAILE = 0x00000002;

    private Handler handler;


    public MineOARemoveAccountBusiness(Handler handler) {
        this.handler = handler;
    }


    public void unRegisterAccount() {
        if (!CountryUtils.judgeIsEurope(AApplication.getInstance().getApplicationContext())) {
            PushManager.getInstance().unbindUser();
        }
//        OAUserHelper.unRegisterAccount(new IoTCallback() {
//            @Override
//            public void onFailure(IoTRequest ioTRequest, Exception e) {
//                Message.obtain(handler, RESULT_FAILE, ResourceUtils.getString("setting_delete_failed")).sendToTarget();
//            }
//
//            @Override
//            public void onResponse(IoTRequest ioTRequest, final IoTResponse ioTResponse) {
//                if (ioTResponse.getCode() != 200) {
//                    ALog.e("remove_account", "remove_account  failed：" + ioTResponse.getLocalizedMsg());
//                    Message.obtain(handler, RESULT_FAILE, ioTResponse.getLocalizedMsg()).sendToTarget();
//                } else {
//                    //清除数据库账号记录
//                    Message.obtain(handler, RESULT_SUCCESS).sendToTarget();
//                }
//            }
//        });
    }


}
