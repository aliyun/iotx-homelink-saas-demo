package com.aliyun.iot.ilop.page.mine.tripartite_platform.activity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.base.MineBaseActivity;
import com.aliyun.iot.ilop.page.mine.view.SimpleTopbar;

import java.net.MalformedURLException;
import java.net.URL;

public class H5Activity extends MineBaseActivity implements SimpleTopbar.onBackClickListener {
    String mAppKey = "";
    public static final int RESULT_CODE = 0X201;
    private String mAuthCode;

    private WebView mWebView;
    private SimpleTopbar topbar;
    private String url;

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.ilop_mine_h5_activity);
    }

    @Override
    protected void initView() {
        topbar = findViewById(R.id.mine_topbar);
        mWebView = findViewById(R.id.mine_webview);
    }

    @Override
    protected void initData() {
        initWebSetting();
        mWebView.setWebViewClient(new WebViewClient() {
            //设置加载前的函数
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
            }

            //设置结束加载函数
            @Override
            public void onPageFinished(WebView view, String url) {
                topbar.setTitle(view.getTitle());
            }

            @Override
            public void onLoadResource(WebView view, String url) {
                super.onLoadResource(view, url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Log.d("H5Activity", url);
                if (handleBindError(url)) {

                }

                if (isTokenUrl(url)) {
                    Intent intent = new Intent();
                    intent.putExtra("AuthCode", mAuthCode);
                    setResult(RESULT_CODE, intent);
                    finish();
                    return true;
                }
                view.loadUrl(url);
                return false;
            }
        });
        url = getIntent().getStringExtra("url");
        Log.d(TAG, url);
        mWebView.loadUrl(url);
    }

    private boolean handleBindError(String url) {
        try {
            URL path = new URL(url);
            String error = path.getQuery();
            String[] params = error.split("&");
            for (String param : params) {
                if (param.startsWith("error_description")) {
                    String errorMessage = param.split("=")[1].replace("%20", " ");
                    //session key num is larger than 1
//                    Toast.makeText(getApplicationContext(), errorMessage, Toast.LENGTH_SHORT).show();
//                    finish();
                    new AlertDialog.Builder(this)
                            .setMessage(errorMessage)
                            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            })
                            .show();
                    return true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    protected void initEvent() {
        topbar.setOnBackClickListener(this);
    }

    @Override
    protected void initHandler() {

    }

    @SuppressLint("SetJavaScriptEnabled")
    private void initWebSetting() {
        //声明WebSettings子类
        WebSettings webSettings = mWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        mWebView.setVerticalScrollBarEnabled(true);
        mWebView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
    }

    private boolean isTokenUrl(String url) {
        if (!TextUtils.isEmpty(url)) {
            if (url.contains("code=")) {
                String[] urlArray = url.split("code=");
                if (urlArray.length > 1) {
                    String[] paramArray = urlArray[1].split("&");
                    if (paramArray.length > 1) {
                        mAuthCode = paramArray[0];
                        return true;
                    }
                }
            }
        }
        return false;
    }

    //点击返回上一页面而不是退出浏览器
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && mWebView.canGoBack()) {
            mWebView.goBack();
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (!this.isFinishing()) {
            this.finish();
        }
    }

    //销毁Webview
    @Override
    protected void onDestroy() {
        if (mWebView != null) {
            mWebView.loadDataWithBaseURL(null, "", "text/html", "utf-8", null);
            mWebView.clearHistory();

            ((ViewGroup) mWebView.getParent()).removeView(mWebView);
            mWebView.destroy();
            mWebView = null;
        }
        super.onDestroy();
    }

    @Override
    public void onBackClick() {
        if (mWebView.canGoBack()) {
            mWebView.goBack();
        } else {
            onBackPressed();
        }
    }
}
