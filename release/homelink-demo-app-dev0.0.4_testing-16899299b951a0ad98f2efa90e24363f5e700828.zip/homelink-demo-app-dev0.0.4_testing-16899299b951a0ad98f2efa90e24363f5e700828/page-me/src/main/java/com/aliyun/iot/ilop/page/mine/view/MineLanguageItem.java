package com.aliyun.iot.ilop.page.mine.view;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.aliyun.iot.ilop.page.mine.R;

/**
 * Created by david on 2018/4/11.
 *
 * @author david
 * @date 2018/04/11
 */
public class MineLanguageItem extends FrameLayout {
    private TextView mTitle;
    private ImageView mCheckbox;
    private View mUnderlineView;

    public MineLanguageItem(@NonNull Context context) {
        super(context);
        init();
    }

    public MineLanguageItem(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public MineLanguageItem(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        inflate(getContext(), R.layout.ilop_mine_language_list_item, this);
        mTitle = (TextView)findViewById(R.id.mine_item_language_title_textview);
        mCheckbox = (ImageView)findViewById(R.id.mine_item_language_checkbox_imageview);
        mUnderlineView = (View)findViewById(R.id.mine_item_language_underline_view);
    }

    public void setTitle(String title) {
        if (null != mTitle) {
            mTitle.setText(title);
        }
    }

    public void setChecked(boolean maybeChecked) {
        if (null == mCheckbox) {
            return;
        }

        if (maybeChecked) {
            mCheckbox.setVisibility(VISIBLE);
        } else {
            mCheckbox.setVisibility(GONE);
        }
    }

    public void showUnderline(boolean shouldShow) {
        if (shouldShow) {
            mUnderlineView.setVisibility(VISIBLE);
        } else {
            mUnderlineView.setVisibility(INVISIBLE);
        }
    }
}
