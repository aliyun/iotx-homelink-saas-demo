package com.aliyun.iot.ilop.page.mine.message.fragment;

import java.util.List;

/**
 * Created：2018/6/28
 * Author：wb-415501
 * Desc：
 */
public class Message {

    /**
     * count : 102
     * data : [{"id":1000000000000200439,"gmtCreate":1525351832000,"gmtModified":1525351851000,"appKey":1234567,"title":"测试","body":"温度高","messageType":"device","isRead":1,"extData":{"device":{"iotId":"iotId1","productKey":"p1","productName":"1","icon":"","nickName":"","categoryId":100}},"deviceType":"iOS","messageId":"-1","scopeId":"scopeId1","target":"ACCOUNT","targetValue":"userId","tenantId":"tenantId","type":"NOTICE"}]
     * queryPageNo : 1
     * queryPageSize : 10
     */

    private int count;
    private int queryPageNo;
    private int queryPageSize;
    private List<DataBean> data;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getQueryPageNo() {
        return queryPageNo;
    }

    public void setQueryPageNo(int queryPageNo) {
        this.queryPageNo = queryPageNo;
    }

    public int getQueryPageSize() {
        return queryPageSize;
    }

    public void setQueryPageSize(int queryPageSize) {
        this.queryPageSize = queryPageSize;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * id : 1000000000000200439
         * gmtCreate : 1525351832000
         * gmtModified : 1525351851000
         * appKey : 1234567
         * title : 测试
         * body : 温度高
         * messageType : device
         * isRead : 1
         * extData : {"device":{"iotId":"iotId1","productKey":"p1","productName":"1","icon":"","nickName":"","categoryId":100}}
         * deviceType : iOS
         * messageId : -1
         * scopeId : scopeId1
         * target : ACCOUNT
         * targetValue : userId
         * tenantId : tenantId
         * type : NOTICE
         */

        private long id;
        private long gmtCreate;
        private long gmtModified;
        private int appKey;
        private String title;
        private String body;
        private String messageType;
        private int isRead;
        private ExtDataBean extData;
        private String deviceType;
        private String messageId;
        private String scopeId;
        private String target;
        private String targetValue;
        private String tenantId;
        private String type;

        public long getId() {
            return id;
        }

        public void setId(long id) {
            this.id = id;
        }

        public long getGmtCreate() {
            return gmtCreate;
        }

        public void setGmtCreate(long gmtCreate) {
            this.gmtCreate = gmtCreate;
        }

        public long getGmtModified() {
            return gmtModified;
        }

        public void setGmtModified(long gmtModified) {
            this.gmtModified = gmtModified;
        }

        public int getAppKey() {
            return appKey;
        }

        public void setAppKey(int appKey) {
            this.appKey = appKey;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getBody() {
            return body;
        }

        public void setBody(String body) {
            this.body = body;
        }

        public String getMessageType() {
            return messageType;
        }

        public void setMessageType(String messageType) {
            this.messageType = messageType;
        }

        public int getIsRead() {
            return isRead;
        }

        public void setIsRead(int isRead) {
            this.isRead = isRead;
        }

        public ExtDataBean getExtData() {
            return extData;
        }

        public void setExtData(ExtDataBean extData) {
            this.extData = extData;
        }

        public String getDeviceType() {
            return deviceType;
        }

        public void setDeviceType(String deviceType) {
            this.deviceType = deviceType;
        }

        public String getMessageId() {
            return messageId;
        }

        public void setMessageId(String messageId) {
            this.messageId = messageId;
        }

        public String getScopeId() {
            return scopeId;
        }

        public void setScopeId(String scopeId) {
            this.scopeId = scopeId;
        }

        public String getTarget() {
            return target;
        }

        public void setTarget(String target) {
            this.target = target;
        }

        public String getTargetValue() {
            return targetValue;
        }

        public void setTargetValue(String targetValue) {
            this.targetValue = targetValue;
        }

        public String getTenantId() {
            return tenantId;
        }

        public void setTenantId(String tenantId) {
            this.tenantId = tenantId;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public static class ExtDataBean {
            /**
             * device : {"iotId":"iotId1","productKey":"p1","productName":"1","icon":"","nickName":"","categoryId":100}
             */

            private DeviceBean device;

            public DeviceBean getDevice() {
                return device;
            }

            public void setDevice(DeviceBean device) {
                this.device = device;
            }

            public static class DeviceBean {
                /**
                 * iotId : iotId1
                 * productKey : p1
                 * productName : 1
                 * icon :
                 * nickName :
                 * categoryId : 100
                 */

                private String iotId;
                private String productKey;
                private String productName;
                private String icon;
                private String nickName;
                private int categoryId;

                public String getIotId() {
                    return iotId;
                }

                public void setIotId(String iotId) {
                    this.iotId = iotId;
                }

                public String getProductKey() {
                    return productKey;
                }

                public void setProductKey(String productKey) {
                    this.productKey = productKey;
                }

                public String getProductName() {
                    return productName;
                }

                public void setProductName(String productName) {
                    this.productName = productName;
                }

                public String getIcon() {
                    return icon;
                }

                public void setIcon(String icon) {
                    this.icon = icon;
                }

                public String getNickName() {
                    return nickName;
                }

                public void setNickName(String nickName) {
                    this.nickName = nickName;
                }

                public int getCategoryId() {
                    return categoryId;
                }

                public void setCategoryId(int categoryId) {
                    this.categoryId = categoryId;
                }
            }
        }
    }
}
