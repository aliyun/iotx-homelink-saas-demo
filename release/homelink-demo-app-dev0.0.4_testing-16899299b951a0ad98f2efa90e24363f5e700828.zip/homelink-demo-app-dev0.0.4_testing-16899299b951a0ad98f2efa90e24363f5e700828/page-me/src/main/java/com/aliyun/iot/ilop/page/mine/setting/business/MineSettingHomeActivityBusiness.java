package com.aliyun.iot.ilop.page.mine.setting.business;

import android.os.Handler;

import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClient;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientFactory;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequestBuilder;
import com.aliyun.iot.ilop.page.mine.MineAPIClientConstants;
import com.aliyun.iot.ilop.page.mine.setting.business.listener.MineSettingHomeActivityBusinessListener;

/**
 * Created by david on 2018/4/8.
 *
 * @author david
 * @date 2018/04/08
 */
public class MineSettingHomeActivityBusiness {
    private MineSettingHomeActivityBusinessListener mListener;
    private IoTAPIClient mIoTAPIClient;
    private Handler mHandler;
    private static final String CODE_CHINA = "86";

    public MineSettingHomeActivityBusiness(Handler handler) {
        mListener = new MineSettingHomeActivityBusinessListener(handler);
        mHandler=handler;
        IoTAPIClientFactory factory = new IoTAPIClientFactory();
        mIoTAPIClient = factory.getClient();
    }

    private IoTRequestBuilder getBaseIoTRequestBuilder() {
        IoTRequestBuilder builder = new IoTRequestBuilder();
        builder.setAuthType(MineAPIClientConstants.APICLIENT_IOTAUTH)
            .setApiVersion(MineAPIClientConstants.APICLIENT_VERSION);
        return builder;
    }

    public void requestNotify() {
        if (null == mIoTAPIClient) {
            return;
        }

        IoTRequest ioTRequest = getBaseIoTRequestBuilder()
            .setApiVersion("1.0.2")
            .setPath(MineAPIClientConstants.APICLIENT_PATH_QUERYSYSTEMREMINDINGSTATE)
            .build();
        mIoTAPIClient.send(ioTRequest, mListener);
    }


}
