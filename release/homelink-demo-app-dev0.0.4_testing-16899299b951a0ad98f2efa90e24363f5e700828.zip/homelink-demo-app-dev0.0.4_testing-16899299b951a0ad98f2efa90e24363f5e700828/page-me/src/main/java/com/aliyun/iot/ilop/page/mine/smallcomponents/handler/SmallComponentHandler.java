package com.aliyun.iot.ilop.page.mine.smallcomponents.handler;


import android.os.Handler;
import android.os.Message;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.ilop.page.mine.MineConstants;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.PropertyBean;
import com.aliyun.iot.ilop.page.mine.smallcomponents.bean.SmallComponentDeviceBean;
import com.aliyun.iot.ilop.page.mine.smallcomponents.business.SmallComponentDeviceBusiness;
import com.aliyun.iot.ilop.page.mine.smallcomponents.interfaces.ISmallComponentPage;

import java.util.ArrayList;

public class SmallComponentHandler extends Handler {

    private final static String TAG = "SmallComponentHandler";
    private ISmallComponentPage smallComponentPage;
    private SmallComponentDeviceBusiness smallComponentDeviceBusiness;

    public SmallComponentHandler(ISmallComponentPage iSmallComponentPage) {
        this.smallComponentPage = iSmallComponentPage;
        smallComponentDeviceBusiness = new SmallComponentDeviceBusiness(this);
    }

    public void refreshData() {
        if (smallComponentPage != null) {
            smallComponentPage.showLoading(1);
        }
        //查询已添加设备信息
        smallComponentDeviceBusiness.queryComponentProductByIdentityId();
    }

    @Override
    public void handleMessage(Message msg) {
        super.handleMessage(msg);
        switch (msg.what) {
            case MineConstants.MINE_MESSAGE_NETWORK_ERROR:
                if (smallComponentPage != null) {
                    smallComponentPage.showError(null);
                    smallComponentPage.hideLoading();
                }
                break;
            case MineConstants.MINE_SMALL_COMPONENT_QUERY_COMPONENT_PRODUCT_SUCCESS:
                if (smallComponentPage != null) {
                    String data = msg.obj.toString();
                    JSONArray array = JSON.parseArray(data);
                    ArrayList<SmallComponentDeviceBean> smallComponentDeviceBeans = new ArrayList<>();
                    for (int i = 0; i < array.size(); i++) {
                        JSONObject json = array.getJSONObject(i);
                        SmallComponentDeviceBean smallComponentDeviceBean = new SmallComponentDeviceBean();
                        smallComponentDeviceBean.setProductKey(json.getString("productKey"));
                        smallComponentDeviceBean.setDeviceName(json.getString("deviceName"));
                        smallComponentDeviceBean.setIotId(json.getString("iotId"));
                        smallComponentDeviceBean.setNickName(json.getString("nickName"));
                        smallComponentDeviceBean.setProductName(json.getString("productName"));
                        smallComponentDeviceBean.setProductImage(json.getString("iconUrl"));
                        smallComponentDeviceBean.setStatus(json.getInteger("deviceStatus"));
                        JSONArray jsonArray = json.getJSONArray("properties");
                        ArrayList properArray = new ArrayList();
                        for (int j = 0; j < jsonArray.size(); j++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(j);
                            PropertyBean propertyBean = new PropertyBean();
                            String dataType=jsonObject.getString("propertyDataType");
                            if(dataType!=null&&dataType.equalsIgnoreCase("bool")){
                                String  values = jsonObject.getString("propertyValue");
                                if(values!=null){
                                    propertyBean.setCheck(Boolean.getBoolean(values));
                                }
                            }
                            propertyBean.setPropertyName(jsonObject.getString("propertyName"));
                            propertyBean.setPropertyId(jsonObject.getString("propertyId"));
                            properArray.add(propertyBean);
                        }
                        smallComponentDeviceBean.setSwitchList(properArray);
                        smallComponentDeviceBeans.add(smallComponentDeviceBean);
                    }
                    smallComponentPage.showDeviceList(smallComponentDeviceBeans);
                    smallComponentPage.hideLoading();
                }
                break;
            case MineConstants.MINE_SMALL_COMPONENT_QUERY_COMPONENT_PRODUCT_FAIL:
                if (smallComponentPage != null) {
                    smallComponentPage.showError(msg.obj.toString());
                    smallComponentPage.hideLoading();
                }
                break;
        }
    }

    public void destroy() {
        ALog.d(TAG, "destroy");

        removeMessages(MineConstants.MINE_SMALL_COMPONENT_GET_DEVICE_LIST_SUCCESS);
        removeMessages(MineConstants.MINE_SMALL_COMPONENT_GET_DEVICE_LIST_FAIL);
        removeMessages(MineConstants.MINE_MESSAGE_NETWORK_ERROR);
        removeMessages(MineConstants.MINE_SMALL_COMPONENT_GET_DEVICE_PROPERTY_FAIL);
        removeMessages(MineConstants.MINE_SMALL_COMPONENT_GET_DEVICE_PROPERTY_FAIL);
        smallComponentDeviceBusiness = null;
        smallComponentPage = null;
    }

}
