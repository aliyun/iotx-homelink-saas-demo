package com.aliyun.iot.ilop.page.mine.view;

import android.content.Context;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.utils.PixelUtils;

/**
 * Created by david on 2018/4/4.
 *
 * @author david
 * @date 2018/04/04
 */
public class MineNotifyItem extends FrameLayout {
    private TextView mTitle, mRightText;
    private ImageView mRedPoint,mRightImage;
    private View mUnderLine;

    public MineNotifyItem(Context context) {
        super(context);
        init();
    }

    public MineNotifyItem(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public MineNotifyItem(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        inflate(getContext(), R.layout.ilop_mine_home_notify_item, this);

        mTitle = (TextView)findViewById(R.id.mine_item_notify_title_textview);
        mRedPoint = (ImageView)findViewById(R.id.mine_item_notify_point_imageview);
        mUnderLine = (View)findViewById(R.id.mine_item_notify_underline_view);
        mRightText = findViewById(R.id.mine_item_right_textview);
        mRightImage = findViewById(R.id.mine_item_right_arrow_imageview);

        mRightText.setMaxWidth(PixelUtils.getScreenWith(getContext())/2);
    }

    public void setTitle(String title) {
        if (TextUtils.isEmpty(title)) {
            return;
        }

        mTitle.setText(title);
    }

    public String getTitle(){
        CharSequence cs = mTitle.getText();
        if (cs!=null)
            return cs.toString().trim();
        return null;
    }
    public String getRightTitleText(){
        CharSequence cs = mRightText.getText();
        if (cs!=null)
            return cs.toString().trim();
        return null;
    }
    public void setRightText(String text) {
        if (!TextUtils.isEmpty(text)) {

        }

        mRightText.setText(text);
    }

    public void showNotify(boolean shouldShow) {
        if (shouldShow) {
            mRedPoint.setVisibility(VISIBLE);
        } else {
            mRedPoint.setVisibility(GONE);
        }
    }

    public void showUnderLine(boolean shouldShow) {
        if (shouldShow) {
            mUnderLine.setVisibility(VISIBLE);
        } else {
            mUnderLine.setVisibility(GONE);
        }
    }

    /**
     * 变量 costraintLayout 为了实现rightText对齐
     * @param shouldShow
     */
    public void showRightArrowImage(boolean shouldShow) {
        ConstraintLayout.LayoutParams costraintLayout = (ConstraintLayout.LayoutParams) mRightText.getLayoutParams();
        if (shouldShow) {
            mRightImage.setVisibility(VISIBLE);
            costraintLayout.rightToLeft = R.id.mine_item_notify_point_imageview;
            costraintLayout.rightMargin = PixelUtils.dp2px(getContext(),4);
        } else {
            mRightImage.setVisibility(GONE);
            costraintLayout.rightToLeft = R.id.gl;
            costraintLayout.rightMargin=0;
        }
        mRightText.setLayoutParams(costraintLayout);
    }
}
