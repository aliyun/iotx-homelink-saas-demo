package com.aliyun.iot.ilop.page.mine.setting.adapter.holder;

import android.view.View;
import com.aliyun.iot.ilop.page.mine.setting.bean.LanguageModel;
import com.aliyun.iot.ilop.page.mine.view.MineLanguageItem;

/**
 * Created by david on 2018/4/11.
 *
 * @author david
 * @date 2018/04/11
 */
public class LanguageViewHolder extends BaseViewHolder<LanguageModel>{
    private MineLanguageItem mItem;

    public LanguageViewHolder(View itemView) {
        super(itemView);

        if (itemView instanceof MineLanguageItem) {
            mItem = (MineLanguageItem)itemView;
        }
    }

    @Override
    public void bindData(LanguageModel data, boolean maybeLatest) {
        if (null == mItem) {
            return;
        }
        mItem.setTitle(data.getLanguage());
        mItem.setChecked(data.isSelected());

        if (maybeLatest) {
            mItem.showUnderline(false);
        }
    }
}
