package com.aliyun.iot.ilop.page.mine.tripartite_platform.activity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.ilop.page.mine.MineConstants;
import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.base.MineBaseActivity;
import com.aliyun.iot.ilop.page.mine.view.SimpleTopbar;
import com.aliyun.iot.ilop.page.mine.view.TPListItem;

public class TripartitePlatformListActivity extends MineBaseActivity implements SimpleTopbar.onBackClickListener, View.OnClickListener {

    private SimpleTopbar mTopbar;
    private TPListItem iftttItem;
    private TPListItem googleItem;
    private TPListItem amazonItem;
    private TPListItem tmItem;
    private static final String KEY_CODESELECTED = "codeSelected";

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.ilop_mine_tripartite_platfrom_list_activity);
    }

    @Override
    protected void initView() {
        mTopbar = (SimpleTopbar) findViewById(R.id.mine_topbar);
        tmItem = (TPListItem) findViewById(R.id.mine_tp_tmallgenine);
        amazonItem = (TPListItem) findViewById(R.id.mine_tp_amazon);
        googleItem = (TPListItem) findViewById(R.id.mine_tp_google);
        iftttItem = (TPListItem) findViewById(R.id.mine_tp_ifttt);
    }

    @Override
    protected void initData() {
        if (null != mTopbar) {
            mTopbar.setTitle(getString(R.string.thirdparty_access));
        }
        tmItem.setImageView(R.drawable.tmallgenie);
        amazonItem.setImageView(R.drawable.amazonalexa);
        googleItem.setImageView(R.drawable.googleassistant);
        iftttItem.setImageView(R.drawable.ifttt);
        final SharedPreferences sp = getSharedPreferences("ilop_sp", Context.MODE_PRIVATE);
        String mCountrySelected = sp.getString(KEY_CODESELECTED, "");
        if (mCountrySelected.equals("86")) {
            tmItem.setVisibility(View.VISIBLE);
        }else {
            tmItem.setVisibility(View.GONE);
        }
    }

    @Override
    protected void initEvent() {
        if (null != mTopbar) {
            mTopbar.setOnBackClickListener(this);
        }
        tmItem.setOnClickListener(this);
        amazonItem.setOnClickListener(this);
        googleItem.setOnClickListener(this);
        iftttItem.setOnClickListener(this);
    }

    @Override
    protected void initHandler() {

    }

    @Override
    public void onBackClick() {
        onBackPressed();
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        Bundle bundle = new Bundle();
        if (id == R.id.mine_tp_tmallgenine) {
            bundle.putString(MineConstants.TITLE,getString(R.string.mine_tp_tmallgenine) );
            bundle.putString(MineConstants.CHANNEL, MineConstants.TM);
        } else if (id == R.id.mine_tp_amazon) {
            bundle.putString(MineConstants.TITLE, "Amazon alexa");
            bundle.putString(MineConstants.CHANNEL, MineConstants.AA);
        } else if (id == R.id.mine_tp_google) {
            bundle.putString(MineConstants.TITLE, "Google Assistant");
            bundle.putString(MineConstants.CHANNEL,MineConstants.GA);
        } else if (id == R.id.mine_tp_ifttt) {
            bundle.putString(MineConstants.TITLE, "IFTTT");
            bundle.putString(MineConstants.CHANNEL, MineConstants.IFTTT);
        }
        Router.getInstance().toUrl(getApplicationContext(), MineConstants.MINE_URL_TRIPARTITE_TMALL_GENIE,bundle);

    }
}
