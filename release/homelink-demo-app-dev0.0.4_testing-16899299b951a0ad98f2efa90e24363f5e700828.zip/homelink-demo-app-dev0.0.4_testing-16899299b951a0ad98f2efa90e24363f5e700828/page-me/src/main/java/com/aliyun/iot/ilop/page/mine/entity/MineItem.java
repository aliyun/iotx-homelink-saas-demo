package com.aliyun.iot.ilop.page.mine.entity;

/**
 * Created by ZhuBingYang on 2019-04-19.
 */
public class MineItem extends ActionItem {
    private String subtitle;
    private boolean hasMessage;

    public MineItem(String title, String subtitle, boolean hasMessage) {
        super(title);
        this.subtitle = subtitle;
        this.hasMessage = hasMessage;
    }

    public MineItem(String title, String subtitle, boolean hasMessage, Runnable action) {
        super(title, action);
        this.subtitle = subtitle;
        this.hasMessage = hasMessage;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public boolean isHasMessage() {
        return hasMessage;
    }

    public void setHasMessage(boolean hasMessage) {
        this.hasMessage = hasMessage;
    }

    @Override
    public String toString() {
        return "MineItem{" +
                "title='" + getText() + '\'' +
                ", subtitle='" + subtitle + '\'' +
                ", hasMessage=" + hasMessage +
                '}';
    }
}
