package com.aliyun.iot.ilop.page.mine.user.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.sdk.android.openaccount.OpenAccountSDK;
import com.alibaba.sdk.android.openaccount.callback.LoginCallback;
import com.alibaba.sdk.android.openaccount.model.OpenAccountSession;
import com.alibaba.sdk.android.openaccount.ui.OpenAccountUIService;
import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.base.MineBaseActivity;
import com.aliyun.iot.ilop.page.mine.view.MineLoadingDialog;
import com.aliyun.iot.ilop.page.mine.view.MineModifyNikeame;
import com.aliyun.iot.link.ui.component.LinkToast;

import java.util.HashMap;
import java.util.Map;

public class ModifyNikeNameActivity extends MineBaseActivity implements View.OnClickListener {
    String TAG = "ModifyNikeNameActivity";
    private ImageView mTitlebarBack;
    private TextView mTitlebarSubmit;
    private EditText mInput;
    private MineLoadingDialog mineLoadingDialog;
    private long lastTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ilop_mine_activity_modify_nike_name);
        mineLoadingDialog=new MineLoadingDialog(this);

    }

    @Override
    protected void initView() {
        mTitlebarBack = findViewById(R.id.mine_modify_nk_titlebar_back);
        mTitlebarSubmit = findViewById(R.id.mine_modify_nk_titlebar_submit);
        MineModifyNikeame inputBox = findViewById(R.id.mine_modify_nk_inputBox);
        mInput = inputBox.getInput();
    }

    @Override
    protected void initData() {
        String nikeName = getIntent().getStringExtra("nikeName");
        if (!TextUtils.isEmpty(nikeName))
            mInput.setText(nikeName);
    }

    @Override
    protected void initEvent() {
        mTitlebarBack.setOnClickListener(this);
        mTitlebarSubmit.setOnClickListener(this);
    }

    @Override
    protected void initHandler() {

    }

    @Override
    public void onClick(View v) {
        if (System.currentTimeMillis()-lastTime<300){
            return;
        }
        lastTime=System.currentTimeMillis();
        if (v.getId() == R.id.mine_modify_nk_titlebar_back) {
            finish();
        } else if (v.getId() == R.id.mine_modify_nk_titlebar_submit) {
            String nikeName = mInput.getText().toString().trim();
            mineLoadingDialog.show();
            Map<String, Object> map = new HashMap<>();
            map.put("displayName", nikeName);
            OpenAccountUIService var2 = OpenAccountSDK.getService(OpenAccountUIService.class);
            var2.updateProfile(getApplicationContext(), map, new LoginCallback() {
                @Override
                public void onSuccess(OpenAccountSession openAccountSession) {
                    if (isFinishing()){
                        return;
                    }
                    mineLoadingDialog.dismiss();
                    Intent intent = new Intent();
                    intent.putExtra("nikeName", openAccountSession.getNick());
                    setResult(RESULT_OK, intent);
                    finish();
                }

                @Override
                public void onFailure(int i, String s) {
                    if (isFinishing()){
                        return;
                    }
                    mineLoadingDialog.dismiss();
                    LinkToast.makeText(ModifyNikeNameActivity.this, s, Toast.LENGTH_SHORT).show();
                }
            });
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mineLoadingDialog.isShowing()){
            mineLoadingDialog.dismiss();
        }
    }
}
