package com.aliyun.iot.ilop.page.mine.base;

/**
 * Created by nht on 2018/6/14.
 */

public interface BasePresenter {
}
