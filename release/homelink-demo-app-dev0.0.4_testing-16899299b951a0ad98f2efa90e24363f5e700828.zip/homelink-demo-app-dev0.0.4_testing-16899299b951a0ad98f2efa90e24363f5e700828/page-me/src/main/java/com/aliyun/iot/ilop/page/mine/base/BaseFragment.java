package com.aliyun.iot.ilop.page.mine.base;

import android.app.Dialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.base.activity.IDialogControl;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;

/**
 * Created by nht on 2018/6/14.
 */

public abstract class BaseFragment extends Fragment implements BaseFragmentPresenter {

    protected BaseFragmentView mBaseView;

    protected BaseFragment fragment;
    protected Handler mHandler;

    private RequestManager mImgLoader;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initBundle(getArguments());
        fragment = this;
        mHandler = new Handler(Looper.getMainLooper());
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (mBaseView == null) {
            mBaseView = setView(getContext(), inflater, container, savedInstanceState);
            setRefreshLayoutColor();
            mBaseView.setPresenter(this);
            mBaseView.initView();
            mBaseView.bindEvent();
            loadData();
        }
        return mBaseView.getContentView();
    }

    private void setRefreshLayoutColor() {
//        SwipeRefreshLayout refreshLayout = (SwipeRefreshLayout) mBaseView.getContentView().findViewById(R.id.recycleview);
//        if (refreshLayout != null) {
//            refreshLayout.setColorSchemeColors(getResources().getColor(R.color.myColorPrimary));
//        }
    }

    /**
     * 获取一个图片加载管理器
     *
     * @return RequestManager
     */
    public synchronized RequestManager getImgLoader() {
        if (mImgLoader == null)
            mImgLoader = Glide.with(this);
        return mImgLoader;
    }

    /**
     * 显示加载等待视图,显示"加载中..."
     *
     * @return
     */
    protected Dialog showWaitDialog() {
        return showWaitDialog(R.string.common_loading);
    }

    /**
     * 显示加载等待视图,显示传入字符串资源值
     *
     * @param resid
     * @return
     */
    protected Dialog showWaitDialog(int resid) {
        FragmentActivity activity = getActivity();
        if (activity instanceof IDialogControl) {
            return ((IDialogControl) activity).showWaitDialog(resid);
        }
        return null;
    }

    /**
     * 显示加载等待视图,显示传入字符串
     *
     * @param message
     * @return
     */
    protected Dialog showWaitDialog(String message) {
        FragmentActivity activity = getActivity();
        if (activity instanceof IDialogControl) {
            return ((IDialogControl) activity).showWaitDialog(message);
        }
        return null;
    }

    /**
     * 隐藏加载等待视图
     */
    protected void hideWaitDialog() {
        FragmentActivity activity = getActivity();
        if (activity instanceof IDialogControl) {
            ((IDialogControl) activity).hideWaitDialog();
        }
    }

}
