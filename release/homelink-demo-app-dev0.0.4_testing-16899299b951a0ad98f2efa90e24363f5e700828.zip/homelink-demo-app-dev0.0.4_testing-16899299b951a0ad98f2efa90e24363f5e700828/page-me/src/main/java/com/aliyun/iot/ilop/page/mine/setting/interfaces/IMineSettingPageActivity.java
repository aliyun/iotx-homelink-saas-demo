package com.aliyun.iot.ilop.page.mine.setting.interfaces;


import java.util.List;

import android.support.v4.app.Fragment;
import com.aliyun.iot.ilop.page.mine.setting.bean.OTADeviceSimpleInfo;

/**
 * Created by david on 2018/4/8.
 *
 * @author david
 * @date 2018/04/08
 */
public interface IMineSettingPageActivity {
    void setTitle(String title);

    void forwardToFragment(Fragment targetFragment);

    List<OTADeviceSimpleInfo> getDeviceList();

    void setDeviceList(List<OTADeviceSimpleInfo> list);
}
