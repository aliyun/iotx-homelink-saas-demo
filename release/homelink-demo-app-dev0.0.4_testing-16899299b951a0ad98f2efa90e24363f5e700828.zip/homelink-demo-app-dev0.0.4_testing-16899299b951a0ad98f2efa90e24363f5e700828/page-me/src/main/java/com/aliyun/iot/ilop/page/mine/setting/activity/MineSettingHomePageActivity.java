package com.aliyun.iot.ilop.page.mine.setting.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.ilop.page.mine.MineConstants;
import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.base.MineBaseActivity;
import com.aliyun.iot.ilop.page.mine.setting.handler.MineSettingHomeActivityHandler;
import com.aliyun.iot.ilop.page.mine.setting.interfaces.IMineSettingHomeActivity;
import com.aliyun.iot.ilop.page.mine.view.MineNotifyItem;
import com.aliyun.iot.ilop.page.mine.view.SimpleTopbar;
import com.aliyun.iot.ilop.page.mine.view.SimpleTopbar.onBackClickListener;

/**
 * Created by david on 2018/4/8.
 *
 * @author david
 * @date 2018/04/08
 */
public class MineSettingHomePageActivity extends MineBaseActivity implements IMineSettingHomeActivity, OnClickListener,
        onBackClickListener {


    private MineNotifyItem mOTA;
    private MineNotifyItem mLanguage;
    // 添加选择地区按钮
    private MineNotifyItem mCountry;
    private SimpleTopbar mTopbar;

    private MineSettingHomeActivityHandler mHandler;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.ilop_mine_setting_home_activity);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (null == mHandler) {
            return;
        }
        mHandler.refreshData();

    }

    @Override
    protected void onDestroy() {
        if (null != mHandler) {
            mHandler.destroy();
        }
        super.onDestroy();
    }

    @Override
    protected void initView() {
        mTopbar = findViewById(R.id.mine_topbar);
        mOTA = findViewById(R.id.mine_setting_home_ota_minenotifyitem);
        mLanguage = findViewById(R.id.mine_setting_home_language_minenotifyitem);
        mCountry = findViewById(R.id.mine_setting_home_country_minenotifyitem);
    }

    @Override
    protected void initEvent() {
        mOTA.setOnClickListener(this);

        mLanguage.setOnClickListener(this);

        mCountry.setOnClickListener(this);

        mTopbar.setOnBackClickListener(this);

    }

    @Override
    protected void initData() {
        mOTA.setTitle(getString(R.string.mine_ota));
        mLanguage.setTitle(getString(R.string.mine_language));
        mCountry.setTitle(getString(R.string.mine_setting_choose_country));
        mTopbar.setTitle(getString(R.string.mine_setting));

        mOTA.showUnderLine(true);
        mLanguage.showUnderLine(true);
        mCountry.showUnderLine(false);


    }

    @Override
    protected void initHandler() {
        mHandler = new MineSettingHomeActivityHandler(this);
    }

    @Override
    public void showOTANotify(boolean shouldNotify) {
        if (isFinishing()) {
            return;
        }

        if (null != mOTA) {
            mOTA.showNotify(shouldNotify);
        }
    }

    @Override
    public void showNetWorkError() {
        if (isFinishing()) {
            return;
        }

        Toast.makeText(this, getString(R.string.mine_network_error), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onClick(View v) {
        if (isFinishing()) {
            return;
        }
        if (v.getId() == R.id.mine_setting_home_ota_minenotifyitem) {
            Router.getInstance().toUrl(this, "hld://firmware");
        } else if (v.getId() == R.id.mine_setting_home_language_minenotifyitem) {
            Router.getInstance().toUrl(this,"hld://mine_setting_language");
        } else if (v.getId() == R.id.mine_setting_home_country_minenotifyitem) {
            // 选择地区跳转界面
            Bundle bundle=new Bundle();
            bundle.putString("entrance","app");
            Router.getInstance().toUrl(getApplicationContext(), MineConstants.MINE_URL_COUNTRY_LIST,bundle);
        }
    }

    @Override
    public void onBackClick() {
        if (isFinishing()) {
            return;
        }

        this.finish();
    }
}
