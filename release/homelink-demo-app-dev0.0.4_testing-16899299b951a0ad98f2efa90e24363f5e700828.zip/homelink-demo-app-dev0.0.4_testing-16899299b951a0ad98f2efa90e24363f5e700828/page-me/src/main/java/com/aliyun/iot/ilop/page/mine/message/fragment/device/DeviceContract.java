package com.aliyun.iot.ilop.page.mine.message.fragment.device;

import android.util.SparseArray;


import com.aliyun.iot.ilop.page.mine.base.BaseFragmentPresenter;
import com.aliyun.iot.ilop.page.mine.base.BaseFragmentView;
import com.aliyun.iot.ilop.page.mine.message.fragment.MessageList;

import java.util.List;

public class DeviceContract {
    interface View extends BaseFragmentView {

        void showRefresh();

        void hideRefresh();

        void refreshDeviceList(List<MessageList> datas);

        void loadMoreDeviceList(List<MessageList> datas);

        void hideLoadMore();

        void updateFloatingView(SparseArray<String> headerData);

        int getDataSize();

        String getPreItemDate();
    }

    interface Presenter extends BaseFragmentPresenter {

        void loadMoreData();

    }
}
