package com.aliyun.iot.ilop.page.mine.base;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.ViewGroup;


/**
 * Created by nht on 2018/6/14.
 */

public interface BaseFragmentPresenter extends BasePresenter {

    void initBundle(Bundle bundle);

    BaseFragmentView setView(Context ctx, LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState);

    void loadData();
}
