package com.aliyun.iot.ilop.page.mine.user.activity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.alibaba.sdk.android.openaccount.util.ResourceUtils;
import com.aliyun.iot.aep.Util.CountryUtils;
import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.base.MineBaseActivity;
import com.aliyun.iot.ilop.page.mine.user.handler.MineOARemoveAccountActivtyHandler;
import com.aliyun.iot.ilop.page.mine.user.interfaces.IMineOARemoveAccountActivityImp;
import com.aliyun.iot.ilop.page.mine.view.MineLoadingDialog;
import com.aliyun.iot.ilop.page.mine.view.RemoveSelectorDialogFragment;
import com.aliyun.iot.ilop.page.mine.view.SimpleTopbar;
import com.aliyun.iot.utils.AppWidgetHelper;
import com.aliyun.iot.utils.SpUtil;

public class OARemoveAccountActivity extends MineBaseActivity implements View.OnClickListener, IMineOARemoveAccountActivityImp {
    @Override
    public void onClick(View v) {

    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }

    @Override
    protected void initEvent() {

    }

    @Override
    protected void initHandler() {

    }

    @Override
    public void onFailed(String error) {

    }

    @Override
    public void onRemoveSuccess() {

    }
//
//    private static final String TAG = OARemoveAccountActivity.class.getSimpleName();
//    private RemoveSelectorDialogFragment dialogFragment;
//    private MineOARemoveAccountActivtyHandler mineOARemoveAccountActivtyHandler;
//    private SimpleTopbar titleBar;
//
//    private MineLoadingDialog mineLoadingDialog;
//
//    @Override
//    protected void onCreate(Bundle bundle) {
//        super.onCreate(bundle);
//        unTranparent();
//        setContentView(R.layout.ilop_mine_setting_account_remove);
//        dialogFragment = new RemoveSelectorDialogFragment();
//        dialogFragment.setOnClickListener(this);
//        mineLoadingDialog = new MineLoadingDialog(this);
//        mineLoadingDialog.setProgressMesssage(R.string.mine_account_loading_remove);
//    }
//
//
//    /**
//     * 取消主题透明栏状态
//     */
//    private final void unTranparent() {
//        Window window = getWindow();
//        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
//                | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
//    }
//
//    @Override
//    public void onClick(View v) {
//        if (v.getId() == R.id.btn_remove_sure) {
//            dialogFragment.dismissAllowingStateLoss();
//            mineLoadingDialog.show();
//            mineOARemoveAccountActivtyHandler.unRegisterAccount();
//        }
//    }
//
//
//    @Override
//    public void onBackPressed() {
//        super.onBackPressed();
//        setResult(RESULT_CANCELED);
//        finish();
//    }
//
//
//    @Override
//    protected void initView() {
//        titleBar = findViewById(R.id.mine_topbar);
//
//    }
//
//    @Override
//    protected void initData() {
//        titleBar.setTitle(getString(R.string.setting_remove_account));
//
//
//    }
//
//    @Override
//    protected void initEvent() {
//
//        titleBar.setOnBackClickListener(new SimpleTopbar.onBackClickListener() {
//            @Override
//            public void onBackClick() {
//                onBackPressed();
//            }
//        });
//        findViewById(R.id.btn_cancel).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                onBackPressed();
//            }
//        });
//        findViewById(R.id.next).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                dialogFragment.showAllowingStateLoss(getSupportFragmentManager(), "RemoveSelectorDialogFragment");
//            }
//        });
//    }
//
//    @Override
//    protected void initHandler() {
//        mineOARemoveAccountActivtyHandler = new MineOARemoveAccountActivtyHandler(this);
//    }
//
//    @Override
//    protected void onDestroy() {
//        super.onDestroy();
//        mineOARemoveAccountActivtyHandler.onDestory();
//        if (mineLoadingDialog.isShowing()) {
//            mineLoadingDialog.dismiss();
//        }
//        if (dialogFragment != null && dialogFragment.isAdded()) {
//            dialogFragment.dismissAllowingStateLoss();
//        }
//
//    }
//
//    @Override
//    public void onFailed(String error) {
//        mineLoadingDialog.dismiss();
//        Toast.makeText(this, error + "", Toast.LENGTH_SHORT).show();
//    }
//
//    @Override
//    public void onRemoveSuccess() {
//        //更新小组件
//        AppWidgetHelper.refreshDeviceWidget(this, "GETDEVICELIST_CLEAR_PROPERTY_MAP");
//        mineLoadingDialog.dismiss();
//        Toast.makeText(OARemoveAccountActivity.this, ResourceUtils.getString("mine_account_remove_success"), Toast.LENGTH_SHORT).show();
//        setResult(RESULT_OK);
//        finish();
//    }
}

