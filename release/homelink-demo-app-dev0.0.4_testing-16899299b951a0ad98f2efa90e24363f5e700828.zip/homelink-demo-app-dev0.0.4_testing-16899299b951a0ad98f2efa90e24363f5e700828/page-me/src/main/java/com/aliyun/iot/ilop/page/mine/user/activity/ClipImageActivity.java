package com.aliyun.iot.ilop.page.mine.user.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.base.MineBaseActivity;
import com.aliyun.iot.ilop.page.mine.user.handler.ClipImageActivityHandler;
import com.aliyun.iot.ilop.page.mine.user.interfaces.IClipImageActivityImp;
import com.aliyun.iot.ilop.page.mine.view.ClipViewLayout;
import com.aliyun.iot.ilop.page.mine.view.MineLoadingDialog;

public class ClipImageActivity extends MineBaseActivity implements View.OnClickListener, IClipImageActivityImp {

    private ClipViewLayout clipViewLayout;
    private ImageView mBtnBack;
    private TextView mTVClip;
    private ClipImageActivityHandler handler;
    private MineLoadingDialog mineLoadingDialog;
    private long lastTime=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ilop_mine_clip_image_activity);
        mineLoadingDialog=new MineLoadingDialog(this);
    }

    @Override
    protected void initView() {
        clipViewLayout = findViewById(R.id.cl);
        mBtnBack = findViewById(R.id.btn_back);
        mTVClip = findViewById(R.id.btn_clip);
    }


    @Override
    protected void initData() {
        //设置图片资源
        clipViewLayout.setImageSrc((Uri) getIntent().getParcelableExtra("uri"));
    }

    @Override
    protected void initEvent() {
        mBtnBack.setOnClickListener(this);
        mTVClip.setOnClickListener(this);
    }

    @Override
    protected void initHandler() {
        handler = new ClipImageActivityHandler(this);
    }

    @Override
    public void onClick(View v) {
        if (System.currentTimeMillis()-lastTime<300){
            return;
        }
        lastTime=System.currentTimeMillis();
        if (v.getId() == R.id.btn_back) {
            finish();
        }
        if (v.getId() == R.id.btn_clip) {
            mineLoadingDialog.show();
            Bitmap zoomedCropBitmap = clipViewLayout.clip();
            handler.updateImage(zoomedCropBitmap);
        }
    }


    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {
            onUserInteraction();
        }
        if (getWindow().superDispatchTouchEvent(ev)) {
            return true;
        }
        return onTouchEvent(ev);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.onDestory();
        if (mineLoadingDialog.isShowing()){
            mineLoadingDialog.dismiss();
        }
    }

    @Override
    public void onUpdateSuccess() {
        mineLoadingDialog.dismiss();
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();
    }

    @Override
    public void onUpdateError(String error) {
        mineLoadingDialog.dismiss();
        Toast.makeText(this, error, Toast.LENGTH_SHORT).show();
    }


}
