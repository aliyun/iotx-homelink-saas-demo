package com.aliyun.iot.ilop.page.mine.home;

import android.support.annotation.Nullable;
import android.view.View;

import com.aliyun.iot.ilop.page.mine.R;
import com.aliyun.iot.ilop.page.mine.entity.MineItem;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;

import java.util.List;

/**
 * Created by ZhuBingYang on 2019-04-18.
 */
public class MineAdapter extends BaseQuickAdapter<MineItem, BaseViewHolder> {

    public MineAdapter(@Nullable List<MineItem> data) {
        super(R.layout.ilop_mine_list_item_mine, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, MineItem item) {
        helper.setText(R.id.li_mine_title_tv, item.getText());
        helper.setText(R.id.li_mine_subtitle_tv, item.getSubtitle());

        View dot = helper.getView(R.id.li_mine_dot_iv);
        dot.setVisibility(item.isHasMessage() ? View.VISIBLE : View.GONE);
    }
}
