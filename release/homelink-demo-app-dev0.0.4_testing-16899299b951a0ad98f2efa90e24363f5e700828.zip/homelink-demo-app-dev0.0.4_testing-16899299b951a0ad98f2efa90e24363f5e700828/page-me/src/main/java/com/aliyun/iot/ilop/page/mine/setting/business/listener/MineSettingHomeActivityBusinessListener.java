package com.aliyun.iot.ilop.page.mine.setting.business.listener;

import com.alibaba.fastjson.JSON;

import android.os.Handler;
import android.os.Message;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.ilop.page.mine.MineAPIClientConstants;
import com.aliyun.iot.ilop.page.mine.MineConstants;
import com.aliyun.iot.ilop.page.mine.base.MineBaseBusinessListener;
import com.aliyun.iot.ilop.page.mine.home.bean.MineMessageCounter;

/**
 * Created by david on 2018/4/13.
 *
 * @author david
 * @date 2018/04/13
 */
public class MineSettingHomeActivityBusinessListener extends MineBaseBusinessListener {
    public MineSettingHomeActivityBusinessListener(Handler handler) {
        super(handler);
    }

    @Override
    protected void onResponseSuccess(IoTRequest ioTRequest, String ioTResponse) {
        if (null == mHandler) {
            return;
        }

        if (MineAPIClientConstants.APICLIENT_PATH_QUERYSYSTEMREMINDINGSTATE.equals(ioTRequest.getPath())) {
            onRequestNotifySuccess(ioTRequest, ioTResponse);
        }
    }

    @Override
    protected void onResponseFailure(IoTRequest ioTRequest, String ioTResponse) {
        if (null == mHandler) {
            return;
        }

        if (MineAPIClientConstants.APICLIENT_PATH_QUERYSYSTEMREMINDINGSTATE.equals(ioTRequest.getPath())) {
            onRequestNotifyFailed(ioTRequest, ioTResponse);
        }
    }

    @Override
    protected void onRequestFailure(IoTRequest ioTRequest, Exception e) {
        if (null == mHandler) {
            return;
        }

        Message.obtain(mHandler, MineConstants.MINE_MESSAGE_NETWORK_ERROR).sendToTarget();
    }

    //--------------------------------------------------------------------------------

    private void onRequestNotifySuccess(IoTRequest ioTRequest, String ioTResponse) {
        if (null == mHandler) {
            return;
        }

        MineMessageCounter msg = JSON.parseObject(ioTResponse, MineMessageCounter.class);

        Message.obtain(mHandler, MineConstants.MINE_MESSAGE_RESPONSE_MESSAGE_COUNT_SUCCESS, msg).sendToTarget();
    }

    private void onRequestNotifyFailed(IoTRequest ioTRequest, String ioTResponse) {
        if (null == mHandler) {
            return;
        }

        Message.obtain(mHandler, MineConstants.MINE_MESSAGE_RESPONSE_MESSAGE_COUNT_FAILED).sendToTarget();
    }
}
