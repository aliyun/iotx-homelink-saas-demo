## HomeLink-Demo-App

#### 工程分布

app 目录为主工程

其他均为业务子工程

page-device

page-index

page-my

page-share

具体说明请参考各个子工程内部的说明文档



#### SDK 初始化流程相关 

##### 依赖描述文件： 

app/sdk_dependencies.gradle

#####sdk 初始化配置：

app/src/main/assets/sdk_config.json

##### sdk 初始化相关代码：

sdk 初始化 

app/src/main/java/com/aliyun/iot/aep/sdk/init

多个sdk关联相关的胶水代码，如长连接账号绑定；

app/src/main/java/com/aliyun/iot/aep/sdk/glue

##### 执行初始化化

 Application 继承 AApplication 在 AApplication 中的onCreate中会根据sdk初始化配置进行sdk 的相关初始化。 

#### 使用流程

将自己的安全图片替换掉原有的安全图片  app/src/main/drawable/yw_1222_114d.jpg

执行编译 ./gradlew clean assembleDebug     



