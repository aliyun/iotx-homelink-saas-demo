# page-ota模块

> 固件升级列表/固件升级

## 包说明

- activity 固件列表和固件升级页面
- adapter  适配器
- base     基类
- bean     实体类
- business   请求方法
  - listener  监听状态回调接口
- executor WiFi实现 蓝牙暂时未实现
- handler 通信
- interfaces 业务接口
- manager 控制器
- view 视图

