package com.aliyun.iot.ilop.component.deviceadd;

import com.alibaba.fastjson.JSON;
import com.aliyun.alink.linksdk.tools.ALog;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientFactory;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTCallback;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTResponse;
import com.aliyun.iot.aep.sdk.apiclient.emuns.Scheme;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequestBuilder;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;
import com.aliyun.iot.ilop.component.deviceadd.listener.OnGetCategoryCompletedListener;
import com.aliyun.iot.ilop.component.deviceadd.listener.OnGetProductCompletedListener;
import com.aliyun.iot.ilop.component.deviceadd.module.Category;
import com.aliyun.iot.ilop.component.deviceadd.module.Product;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 品类列表/产品列表的获取业务封装
 *
 * @author guikong on 18/4/8.
 */
public class SelectProductBusiness {

    private static final String TAG = "SelectProductBusiness";

    public void getCategories(int page, int pageSize, final OnGetCategoryCompletedListener listener) {
        if (0 > page) {
            throw new IllegalArgumentException("page must >= 0");
        }

        if (0 > pageSize) {
            throw new IllegalArgumentException("pageSize must >= 0");
        }

        if (null == listener) {
            throw new IllegalArgumentException("listener can not be null");

        }

        IoTRequest request = new IoTRequestBuilder()
                .setPath("/home/app/category/query")
                .setScheme(Scheme.HTTPS)
                .setAuthType("iotAuth")
                .setApiVersion("1.0.0")
                .addParam("pageNo", page)
                .addParam("pageSize", pageSize)
                .addParam("superId", -1)
                .build();

        new IoTAPIClientFactory().getClient().send(request, new IoTCallback() {
            @Override
            public void onFailure(IoTRequest ioTRequest, final Exception e) {
                ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            listener.onFailed(e);
                        } catch (Exception ex) {
                            ALog.e(TAG, "exception happen when call listener.onFailed", ex);
                            ex.printStackTrace();
                        }
                    }
                });
            }

            @Override
            public void onResponse(final IoTRequest ioTRequest, final IoTResponse ioTResponse) {
                if (200 != ioTResponse.getCode()) {
                    ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                listener.onFailed(ioTResponse.getCode(), ioTResponse.getMessage(), ioTResponse.getLocalizedMsg());
                            } catch (Exception ex) {
                                ALog.e(TAG, "exception happen when call listener.onFailed", ex);
                                ex.printStackTrace();
                            }
                        }
                    });
                    return;
                }

                if (!(ioTResponse.getData() instanceof JSONObject)) {
                    return;
                }

                int totalNum;
                List<Category> categories = new ArrayList<>();

                JSONObject data = (JSONObject) ioTResponse.getData();
                totalNum = data.optInt("total");

                JSONArray items = data.optJSONArray("data");

                if (null != items
                        && items.length() > 0) {
                    String jsonStr = items.toString();
                    categories = JSON.parseArray(jsonStr, Category.class);
                }

                final int finalTotalNum = totalNum;
                final List<Category> finalCategories = categories;
                ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            listener.onSuccess(finalTotalNum, finalCategories);
                        } catch (Exception ex) {
                            ALog.e(TAG, "exception happen when call listener.onSuccess", ex);
                            ex.printStackTrace();
                        }
                    }
                });
            }
        });
    }

    @SuppressWarnings("unused")
    public void getProductsByCategory(String categoryKey, int page, int pageSize, final OnGetProductCompletedListener listener) {
        if (0 > page) {
            throw new IllegalArgumentException("page must >= 0");
        }

        if (0 > pageSize) {
            throw new IllegalArgumentException("pageSize must >= 0");
        }

        if (null == listener) {
            throw new IllegalArgumentException("listener can not be null");
        }

        IoTRequest request = new IoTRequestBuilder()
                .setPath("/home/app/product/query")
                .setApiVersion("1.0.0")
                .setScheme(Scheme.HTTPS)
                .setAuthType("iotAuth")
                .addParam("categoryKey", categoryKey)
                .addParam("pageNo", page)
                .addParam("pageSize", pageSize)
                .addParam("superId", -1)
                .build();

        new IoTAPIClientFactory().getClient().send(request, new IoTCallback() {
            @Override
            public void onFailure(IoTRequest request, final Exception e) {
                ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            listener.onFailed(e);
                        } catch (Exception ex) {
                            ALog.e(TAG, "exception happen when call listener.onFailed", ex);
                            ex.printStackTrace();
                        }
                    }
                });
            }

            @Override
            public void onResponse(final IoTRequest request, final IoTResponse response) {
                if (200 != response.getCode()) {
                    ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                        @Override
                        public void run() {

                            try {
                                listener.onFailed(response.getCode(), response.getMessage(), response.getLocalizedMsg());
                            } catch (Exception ex) {
                                ALog.e(TAG, "exception happen when call listener.onFailed", ex);
                                ex.printStackTrace();
                            }
                        }
                    });
                    return;
                }

                if (!(response.getData() instanceof JSONObject)) {
                    return;
                }

                int totalNum;
                List<Product> products = new ArrayList<>();

                JSONObject data = (JSONObject) response.getData();
                totalNum = data.optInt("total");

                JSONArray items = data.optJSONArray("data");

                if (null != items
                        && items.length() > 0) {
                    String jsonStr = items.toString();
                    products = JSON.parseArray(jsonStr, Product.class);
                }

                final int finalTotalNum = totalNum;
                final List<Product> finalProducts = products;
                ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                    @Override
                    public void run() {

                        try {
                            listener.onSuccess(finalTotalNum, finalProducts);
                        } catch (Exception ex) {
                            ALog.e(TAG, "exception happen when call listener.onSuccess", ex);
                            ex.printStackTrace();
                        }
                    }
                });
            }
        });
    }
}
