package com.aliyun.iot.ilop.page.deviceadd.external.router;

import android.app.Activity;
import android.app.Application;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.aliyun.alink.linksdk.tools.ALog;
import com.aliyun.iot.aep.component.router.IUrlHandler;
import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.ilop.page.deviceadd.bind.DeviceBindActivity;
import com.aliyun.iot.ilop.page.deviceadd.category.CategoryDeviceActivity;
import com.aliyun.iot.ilop.page.deviceadd.product.ProductListActivity;
import com.aliyun.iot.ilop.page.deviceadd.search.SearchActivity;


public class AddDeviceRouterHelper {

    /**
     * 注册路由
     */
    public static void registerPage() {
        IUrlHandler iUrlHandler = new DevicesUrlHandler();
        Router.getInstance().registerRegexUrlHandler(".*?" + ProductListActivity.CODE, iUrlHandler);
        Router.getInstance().registerRegexUrlHandler(".*?" + DeviceBindActivity.CODE, iUrlHandler);
        Router.getInstance().registerRegexUrlHandler(".*?" + CategoryDeviceActivity.CODE, iUrlHandler);
        Router.getInstance().registerRegexUrlHandler(".*?" + SearchActivity.CODE_SEARCH, iUrlHandler);
    }


    private static final class DevicesUrlHandler implements IUrlHandler {

        private static final String TAG = "DevicesUrlHandler";

        @Override
        public void onUrlHandle(Context context, String url, Bundle bundle, boolean startActForResult, int reqCode) {
            ALog.e(TAG, "onUrlHandle: " + url);
            Intent intent = new Intent();
            if (ProductListActivity.CODE.equalsIgnoreCase(url)) {
                intent.setClass(context, ProductListActivity.class);
            } else if (DeviceBindActivity.CODE.equalsIgnoreCase(url)) {
                intent.setClass(context, DeviceBindActivity.class);
            } else if (CategoryDeviceActivity.CODE.equals(url)) {
                intent.setClass(context, CategoryDeviceActivity.class);
            } else if (SearchActivity.CODE_SEARCH.equals(url)) {
                intent.setClass(context, SearchActivity.class);
            }
            startActivity(context, intent, bundle, startActForResult, reqCode);
        }

        private void startActivity(Context context, Intent intent, Bundle bundle, boolean startActForResult, int reqCode) {
            if (null == context || null == intent)
                return;
            if (intent.resolveActivity(context.getPackageManager()) == null) {
                return;
            }

            if (null != bundle) {
                intent.putExtras(bundle);
            }
            /* startActivityForResult() 场景，只能被 Activity 调用 */
            if (startActForResult) {
                if (false == (context instanceof Activity))
                    return;

                ((Activity) context).startActivityForResult(intent, reqCode);

                return;
            }

            /* startActivity 被 Application 调用时的处理 */
            if (context instanceof Application) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
            /* startActivity 被 Activity、Service 调用时的处理 */
            else if (context instanceof Activity || context instanceof Service) {
                context.startActivity(intent);
            }
            /* startActivity 被其他组件调用时的处理 */
            else {
                // 暂不支持
            }
        }
    }

}
