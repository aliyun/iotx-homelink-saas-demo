package com.aliyun.iot.ilop.page.deviceadd.product.viewholder;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * @author guikong on 18/5/14.
 */

public class HeaderViewHolder extends RecyclerView.ViewHolder {

    public HeaderViewHolder(View itemView) {
        super(itemView);
    }
}
