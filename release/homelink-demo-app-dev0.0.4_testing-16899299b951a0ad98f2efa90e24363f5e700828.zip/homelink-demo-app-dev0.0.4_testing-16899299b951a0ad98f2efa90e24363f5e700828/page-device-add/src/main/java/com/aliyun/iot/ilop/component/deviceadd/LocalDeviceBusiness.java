package com.aliyun.iot.ilop.component.deviceadd;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.os.Looper;

import com.alibaba.fastjson.JSON;
import com.aliyun.alink.business.devicecenter.api.add.DeviceInfo;
import com.aliyun.alink.business.devicecenter.api.discovery.DiscoveryType;
import com.aliyun.alink.business.devicecenter.api.discovery.IDeviceDiscoveryListener;
import com.aliyun.alink.business.devicecenter.api.discovery.LocalDeviceMgr;
import com.aliyun.alink.linksdk.alcs.lpbs.api.AlcsPalConst;
import com.aliyun.alink.linksdk.tmp.TmpSdk;
import com.aliyun.alink.linksdk.tmp.api.DeviceBasicData;
import com.aliyun.alink.linksdk.tmp.api.DeviceManager;
import com.aliyun.alink.linksdk.tmp.api.IDiscoveryFilter;
import com.aliyun.alink.linksdk.tmp.api.OutputParams;
import com.aliyun.alink.linksdk.tmp.listener.IDevListener;
import com.aliyun.alink.linksdk.tmp.utils.ErrorInfo;
import com.aliyun.alink.linksdk.tmp.utils.GsonUtils;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientFactory;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTCallback;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTResponse;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequestBuilder;
import com.aliyun.iot.aep.sdk.framework.AApplication;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;
import com.aliyun.iot.ilop.component.deviceadd.listener.OnDeviceFilterCompletedListener;
import com.aliyun.iot.ilop.component.deviceadd.module.BleDevice;
import com.aliyun.iot.ilop.component.deviceadd.module.FoundDevice;
import com.aliyun.iot.ilop.component.deviceadd.module.LocalDevice;
import com.aliyun.iot.ilop.component.deviceadd.module.Product;
import com.aliyun.iot.ilop.util.BreezeUtil;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 本地设备过滤逻辑的封装
 *
 * @author guikong on 18/4/19.
 */
public class LocalDeviceBusiness {

    private static final String TAG = "LocalDeviceBusiness";

    private List<FoundDevice> discoveredDevices;
    private List<FoundDevice> cacheDevices;

    private OnDeviceFilterCompletedListener listener;
    private boolean mScanBle;

    private android.os.Handler mHandler;
    private Activity mActivity;

    private static final int TIME_SCAN_DELAY_MS = 300;
    private boolean mScanStarted = false;

    private static final int TIME_TO_CLEAR_CACHE = 10*1000; //ms

    public LocalDeviceBusiness(boolean scanBle, OnDeviceFilterCompletedListener listener) {
        mScanBle = scanBle;
        this.listener = listener;
        discoveredDevices = new ArrayList<>();
        cacheDevices = new ArrayList<>();
        mHandler = new android.os.Handler(Looper.getMainLooper());
    }

    public void setCacheDevices(List<FoundDevice> devices) {
        cacheDevices.clear();
        cacheDevices.addAll(devices);
        ALog.d(TAG, "setCacheDevices:" + JSON.toJSONString(cacheDevices));
    }

    private Runnable clearCacheRunnable = new Runnable() {
        @Override
        public void run() {
            // remove duplicated data
            List<FoundDevice> containedDevices = new ArrayList<>();
            ALog.d(TAG, "clear cache from discoveredDevices:" + JSON.toJSONString(cacheDevices));
            synchronized (discoveredDevices) {//同步
                for (FoundDevice device : cacheDevices) {
                    if (device == null) break;
                    for (FoundDevice disDevice : discoveredDevices) {
                        if (disDevice == null) break;
                        if (disDevice instanceof LocalDevice) {
                            if (((LocalDevice) disDevice).isSame(device)) {
                                containedDevices.add(disDevice);
                                ALog.d(TAG, "clear cache from discoveredDevices found:" + JSON.toJSONString(disDevice));

                            }
                        }
                    }
                }

                discoveredDevices.removeAll(containedDevices);

                notifyListener();
            }

        }
    };




    public void reset() {
        ALog.d(TAG, "device search reset");
        discoveredDevices.clear();
    }

    public void add(List<FoundDevice> localDevices) {
        if (null == localDevices || localDevices.isEmpty()) {
            return;
        }

        // remove duplicated data
        List<FoundDevice> availableDevice = new ArrayList<>();
        synchronized (discoveredDevices) {//同步
            for (FoundDevice localDevice : localDevices) {
                //已发现设备列表（包含蓝牙设备）
                boolean invalid = discoveredDevices.contains(localDevice);
                if (!invalid) {//不在已发现列表
                    availableDevice.add(localDevice);
                } else {
                    ALog.d(TAG, "add nothing, dup device:" + JSON.toJSONString(localDevice));
                }
            }
            if (availableDevice.isEmpty()) {
                return;
            }

            // cache devices
            // discoveredDevices.addAll(availableDevice);
        }
        // do filter
        filterDevice(availableDevice);
    }


    /**
     * 过滤本地设备
     *
     * @param localDevices 本地设备，未区分已配网/待配网
     */
    private void filterDevice(List<FoundDevice> localDevices) {
//
//        List<FoundDevice> localDevicesNeedBind = new ArrayList<>();
//        List<FoundDevice> localDevicesNeedEnroll = new ArrayList<>();
//
//        for (FoundDevice localDevice : localDevices) {
//            if (localDevice instanceof BleDevice) {//蓝牙设备
//                BleDevice bleDevice = (BleDevice) localDevice;
//                if ("2".equalsIgnoreCase(bleDevice.getModelType())) {
//                    localDevicesNeedBind.add(localDevice);//蓝牙设备都要过滤
//                }
//            } else if (localDevice instanceof LocalDevice) {
//                LocalDevice device = (LocalDevice) localDevice;//wifi等设备
//
//                if (LocalDevice.NEED_BIND.equalsIgnoreCase(device.deviceStatus)) {
//                    localDevicesNeedBind.add(localDevice);
//
//                } else if (LocalDevice.NEED_CONNECT.equalsIgnoreCase(device.deviceStatus)) {
//                    localDevicesNeedEnroll.add(localDevice);
//                }
//            }
//        }
//
//        if (!localDevicesNeedEnroll.isEmpty()) {
//            notifyListener(localDevicesNeedEnroll);
//        }
//
//        if (!localDevicesNeedBind.isEmpty()) {
//            filterLocalDeviceNeedBind(localDevices);
//        }
        filterLocalDeviceNeedBind(localDevices);
    }

    /**
     * 过滤待配网设备

     */
    private void notifyListener() {

        if (null != listener) {
            try {
                ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                    @Override
                    public void run() {
                        ALog.d(TAG, "notifyListener:" + JSON.toJSONString(discoveredDevices));

                        listener.onDeviceFilterCompleted(discoveredDevices);
                    }
                });
            } catch (Exception e) {
                ALog.e(TAG, "exception happens when call onDeviceFilterCompleted:");
                e.printStackTrace();
            }
        }
    }

    private void addToDiscovered(final List<FoundDevice> localDevices) {
        ALog.d(TAG, "addToDiscovered localDevices start:" + JSON.toJSONString(localDevices));
        ALog.d(TAG, "addToDiscovered discoveredDevices start:" + JSON.toJSONString(discoveredDevices));

        // remove duplicated data
        List<FoundDevice> containedDevices = new ArrayList<>();
        synchronized (discoveredDevices) {//同步
            for (FoundDevice localDevice : localDevices) {
                if (localDevice == null) break;
                for (FoundDevice disDevice : discoveredDevices) {
                    if (disDevice == null) break;
                    if (disDevice instanceof LocalDevice && localDevice instanceof LocalDevice) {
                        if (((LocalDevice) disDevice).isSame(localDevice)) {
                            containedDevices.add(localDevice);
                            ALog.d(TAG, "addToDiscovered discoveredDevices found dup:" + JSON.toJSONString(localDevice));

                            ((LocalDevice) disDevice).copyFrom((LocalDevice)localDevice);
                        }
                    }
                }
            }

            localDevices.removeAll(containedDevices);
            ALog.d(TAG, "addToDiscovered localDevices end:" + JSON.toJSONString(localDevices));


            // cache devices
            discoveredDevices.addAll(localDevices);
        }
        ALog.d(TAG, "addToDiscovered discoveredDevices end:" + JSON.toJSONString(discoveredDevices));


    }

    /**
     * 过滤已配网设备
     *
     * @param localDevices 已配网的设备
     */
    private void filterLocalDeviceNeedBind(final List<FoundDevice> localDevices) {

        List<Map<String, String>> devices = new ArrayList<>(localDevices.size());
        for (FoundDevice localDevice : localDevices) {
            Map<String, String> device = new HashMap<>(2);
            device.put("productKey", localDevice.productKey);
            device.put("deviceName", localDevice.deviceName);
            devices.add(device);
        }

        IoTRequest request = new IoTRequestBuilder()
                .setPath("/awss/enrollee/product/filter")
                .setApiVersion("1.0.2")
                .addParam("iotDevices", devices)
                .setAuthType("iotAuth")
                .build();

        new IoTAPIClientFactory().getClient().send(request, new IoTCallback() {
            @Override
            public void onFailure(IoTRequest ioTRequest, final Exception e) {
                // nothing to do
                //如果过滤失败，删除已保存过滤设备，以便可以继续被发现
                //discoveredDevices.removeAll(localDevices);
            }

            @Override
            public void onResponse(final IoTRequest ioTRequest, final IoTResponse ioTResponse) {
                if (200 != ioTResponse.getCode()) {
                    //discoveredDevices.removeAll(localDevices);
                    return;
                }

                if (!(ioTResponse.getData() instanceof JSONArray)) {
                    //discoveredDevices.removeAll(localDevices);
                    return;
                }

                final List<FoundDevice> availableDevices = new ArrayList<>();
                List<LocalDevice> filteredLocalDevices = new ArrayList<>();
                JSONArray items = (JSONArray) ioTResponse.getData();
                ALog.d(TAG, "--过滤请求--" + GsonUtils.toJson(ioTResponse.getData()));
                if (null != items && items.length() > 0) {
                    String jsonStr = items.toString();
                    filteredLocalDevices.addAll(JSON.parseArray(jsonStr, LocalDevice.class));
                }
                //append token & addDeviceFrom & deviceStatus
                for (FoundDevice localDevice : localDevices) {

                    boolean available = false;
                    for (LocalDevice filteredLocalDevice : filteredLocalDevices) {
                        if (filteredLocalDevice.productKey.equals(localDevice.productKey)) {
                            available = true;
                            localDevice.productName = filteredLocalDevice.productName;
                            localDevice.type = Product.getNetTypeString(filteredLocalDevice.netType);
                            localDevice.netType = filteredLocalDevice.netType;
                            break;
                        }
                    }
                    if (available) {
                        availableDevices.add(localDevice);
                        FoundDevice cacheDevice = null;
                        synchronized (cacheDevices) {
                            for (FoundDevice device : cacheDevices) {
                                if (device == null) break;
                                if (device instanceof LocalDevice &&
                                        ((LocalDevice) device).isSame(localDevice)) {
                                    cacheDevice = device;
                                }
                            }
                            if (cacheDevice != null) {
                                cacheDevices.remove(cacheDevice);
                                ALog.d(TAG, "remove from cache:" + JSON.toJSONString(cacheDevice));
                            }
                        }
                    }
                }
                addToDiscovered(availableDevices);
                notifyListener();
            }
        });
    }

    private String[] permissions = new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.BLUETOOTH_ADMIN};

    public void startScan(final Activity activity) {
        mActivity = activity;


        mHandler.removeCallbacks(startScanRunnable);
        mHandler.postDelayed(startScanRunnable, TIME_SCAN_DELAY_MS);
    }

    private Runnable startScanRunnable = new Runnable() {
        @Override
        public void run() {
            mScanStarted = true;
            reset();
            ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                @Override
                public void run() {
                    startScanInternal(mActivity);
                }
            });
        }
    };


    private void startScanInternal(Activity activity) {
        ALog.d(TAG, "device search startScan");

        addToDiscovered(cacheDevices);
        notifyListener();
        mHandler.postDelayed(clearCacheRunnable, TIME_TO_CLEAR_CACHE);

        Context context = AApplication.getInstance().getApplicationContext();
        //发现局域网内设备以及WiFi热点设备
        EnumSet<DiscoveryType> discoveryTypes = EnumSet.of(DiscoveryType.CLOUD_ENROLLEE_DEVICE, DiscoveryType.SOFT_AP_DEVICE, DiscoveryType.LOCAL_ONLINE_DEVICE);
        LocalDeviceMgr.getInstance().startDiscovery(context, discoveryTypes, null, new IDeviceDiscoveryListener() {
            @Override
            public void onDeviceFound(DiscoveryType discoveryType, List<DeviceInfo> list) {
                ALog.d(TAG, "onDeviceFound() called with: discoveryType = [" + discoveryType + "], ProductList = [" + list + "]");
                //要配网
                List<FoundDevice> localDevices = new ArrayList<>();
                for (DeviceInfo deviceInfo : list) {
                    LocalDevice localDevice = new LocalDevice();
                    localDevice.deviceStatus = LocalDevice.NEED_BIND;
                    localDevice.productKey = deviceInfo.productKey;
                    localDevice.deviceName = deviceInfo.deviceName;
                    localDevice.addDeviceFrom = deviceInfo.addDeviceFrom;
                    localDevice.token = deviceInfo.token;
                    localDevice.id = deviceInfo.id;

                    ALog.d(TAG, "onEnrolleeDeviceFound:pk=" + localDevice.productKey + ";dn=" + localDevice.deviceName + ";id=" + localDevice.id + "    status:" + localDevice.deviceStatus + "   from:" + localDevice.addDeviceFrom);
                    localDevices.add(localDevice);

                }
                add(localDevices);

            }
        });

        if (!mScanBle) {
            // do not scan ble device as below
            return;
        }

        //设备发现（2分钟发现不了设备就停止扫描）
        TmpSdk.getDeviceManager().discoverDevices("scan_ble", false, 2 * 60 * 1000, new IDiscoveryFilter() {
            /**
             * 是否过滤
             * @param deviceBasicData
             * @return
             */
            @Override
            public boolean doFilter(DeviceBasicData deviceBasicData) {
                ALog.d(TAG, "the filter of discover device --- doFilter: " + JSON.toJSONString(deviceBasicData));

                if (deviceBasicData != null) {
                    return AlcsPalConst.MODEL_TYPE_ALI_BREEZE.equals(deviceBasicData.getModelType());
                }
                return false;
            }
        }, new IDevListener() {
            @Override
            public void onSuccess(Object tag, OutputParams outputParams) {
                if (outputParams != null) {
                    ALog.d(TAG, "discover device outputParams Successful: " + "tag：" + JSON.toJSONString(tag) + "outputParams：" + JSON.toJSONString(outputParams));
                    //发现所有的设备
                    List<DeviceBasicData> deviceDataList = DeviceManager.getInstance().getAllDeviceDataList();
                    ALog.d(TAG, "discover device Successful: " + JSON.toJSONString(deviceDataList));

                    String dn = (String) outputParams.get("device_name").getValue();
                    String pk = (String) outputParams.get("product_key").getValue();
                    String mt = (String) outputParams.get("model_type").getValue();

                    List<FoundDevice> localDevices = new ArrayList<>();
                    for (DeviceBasicData deviceInfo : deviceDataList) {
                        if (dn.equals(deviceInfo.getDeviceName()) && pk.equals(deviceInfo.getProductKey()) && mt.equals(deviceInfo.getModelType())) {
                            BleDevice device = new BleDevice();
                            device.copyDeviceBasicData(deviceInfo);
                            localDevices.add(device);
                        }
                    }
                    add(localDevices);
                }
            }

            @Override
            public void onFail(Object tag, ErrorInfo errorInfo) {
                ALog.e(TAG, "discover device failed: " + errorInfo);
            }
        });
    }

    public void stopScan(final Activity activity) {
        mHandler.removeCallbacks(startScanRunnable);
        mHandler.removeCallbacks(clearCacheRunnable);

        if (!mScanStarted) {
            return;
        }
        mScanStarted = false;
        //关闭设备发现
        LocalDeviceMgr.getInstance().stopDiscovery();
        if (!mScanBle) {
            return;
        }
        if (!BreezeUtil.getInstance().checkBreezePer(activity, permissions)) {
            BreezeUtil.getInstance().addCheckBreezePer(activity, permissions, 0x2222);
        } else {
            TmpSdk.getDeviceManager().stopDiscoverDevices();
        }
    }
}
