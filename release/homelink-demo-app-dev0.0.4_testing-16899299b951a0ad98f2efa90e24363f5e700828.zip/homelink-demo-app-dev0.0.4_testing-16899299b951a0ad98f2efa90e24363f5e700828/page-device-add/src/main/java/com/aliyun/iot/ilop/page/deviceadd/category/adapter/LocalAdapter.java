package com.aliyun.iot.ilop.page.deviceadd.category.adapter;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.aliyun.alink.linksdk.tmp.extbone.BoneSubDeviceService;
import com.aliyun.alink.linksdk.tmp.service.DevService;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientFactory;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTCallback;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTResponse;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequestBuilder;
import com.aliyun.iot.aep.sdk.credential.IotCredentialManager.IoTCredentialManageImpl;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.ilop.component.deviceadd.listener.BlueToothConnectListener;
import com.aliyun.iot.ilop.component.deviceadd.listener.OnConnectStatusListener;
import com.aliyun.iot.ilop.component.deviceadd.module.BleDevice;
import com.aliyun.iot.ilop.component.deviceadd.module.FoundDevice;
import com.aliyun.iot.ilop.component.deviceadd.module.LocalDevice;
import com.aliyun.iot.ilop.page.device.add.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import static com.aliyun.iot.homelink.demo.commons.util.Util.getApplication;
import static com.aliyun.iot.ilop.util.Constant.FLAG;


public class LocalAdapter extends RecyclerView.Adapter<LocalAdapter.LocalDeviceViewHolder> {

    private static final String TAG = "LocalAdapter";
    List<Object> data;
    private HashSet<FoundDevice> set;

    private List<LocalDevice> mLCADevices = new ArrayList<>();

    public LocalAdapter() {
        data = new ArrayList<>();
        set = new HashSet<>();
    }

    void addLocalDevice(FoundDevice localDevice) {
        if (set.add(localDevice)) {
            data.add(localDevice.clone());
            notifyDataSetChanged();
        }
    }

    /**
     * @param localDevice
     */
    public void addAllLocalDevice(List<FoundDevice> localDevice) {
//        if (localDevice == null || localDevice.size() <= 0) {
//            return;
//        }
//        for (int i = 0; i < localDevice.size(); i++) {
//            if (!data.contains(localDevice.get(i))) {
//                data.addAll(localDevice);
//            }
//        }
//        for (int m = 0; m < data.size() - 1; m++) {
//            LocalDevice local1 = (LocalDevice) data.get(m);
//            for (int n = 0; n < data.size() - 1 - m; n++) {
//                LocalDevice local2 = (LocalDevice) data.get(n);
//                if (local1.id.equals(local2.id) && local1.productKey.equals(local2.productKey)) {
//                    local1 = local2;
//                    data.remove(local2);
//                }
//            }
//        }
        data.clear();
        set.clear();
        data.addAll(localDevice);
        data.addAll(mLCADevices);

        notifyDataSetChanged();
    }


    public void clearLocalDevices() {
        // maybe no local device
        set.clear();
        data.clear();
        mLCADevices.clear();
        notifyDataSetChanged();
    }


    @Override
    public LocalDeviceViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (null == parent) {
            return null;
        }
        Context context = parent.getContext();
        View view = LayoutInflater.from(context).inflate(R.layout.deviceadd_category_list_local_device_recycle_item, parent, false);
        return new LocalDeviceViewHolder(view);
    }

    @Override
    public void onBindViewHolder(LocalDeviceViewHolder holder, int position) {
        Object item = data.get(position);
        ALog.d(TAG, "LocalDeviceData：" + JSON.toJSONString(item));
        holder.setData(item, position, data.size());

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    private OnClickLocalListener localListener;

    public void setOnLocalItemListener(OnClickLocalListener localItemListener) {
        this.localListener = localItemListener;
    }

    public void addLCADevice(LocalDevice localDevice) {
        for (LocalDevice device : mLCADevices) {
            if (device.productKey.equals(localDevice.productKey)) {
                return;
            }
        }
        mLCADevices.add(localDevice);
        data.add(localDevice);
        notifyDataSetChanged();
    }


    class LocalDeviceViewHolder extends RecyclerView.ViewHolder {

        TextView name, nameSame;
        View action, arrow;
        ImageView mImageBg;

        public LocalDeviceViewHolder(View view) {
            super(view);
            name = view.findViewById(R.id.deviceadd_category_list_local_device_name_tv);
            nameSame = view.findViewById(R.id.deviceadd_category_list_local_device_name_tv_same);
            action = view.findViewById(R.id.deviceadd_category_list_local_device_add_fl);
            arrow = view.findViewById(R.id.deviceadd_category_list_local_device_add_fl1);
            mImageBg = view.findViewById(R.id.deviceadd_iv_bleadd_bg);
        }

        public void setData(Object object, int position, int count) {
            if (object instanceof LocalDevice) {
                final LocalDevice localDevice = (LocalDevice) object;
                ALog.d(TAG, "LocalDeviceataD：" + JSON.toJSONString(localDevice));
                String showName = localDevice.productName;
                if (!TextUtils.isEmpty(localDevice.deviceName)) {
                    showName += ' ' + localDevice.deviceName;
                }
                if (!TextUtils.isEmpty(localDevice.id)) {
                    showName += ' ' + localDevice.id;
                }

                arrow.setVisibility(View.GONE);
                name.setText(showName);

                mImageBg.setImageResource(R.drawable.deviceadd_add_circle);
                action.setVisibility(View.VISIBLE);
                action.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Bundle bundle = new Bundle();
                        if(!TextUtils.isEmpty(localDevice.modelType)){
                            bundle.putString("groupId", IoTCredentialManageImpl.getInstance(getApplication()).getIoTIdentity());
                            bundle.putString("productKey", localDevice.productKey);
                            bundle.putString("deviceName", localDevice.deviceName);
                            bundle.putString("model", localDevice.modelName);
                            bundle.putString("modelName", localDevice.modelName);
                            bundle.putString("modelType", localDevice.modelType);
                            bundle.putString("gatewayName", localDevice.gatewayName);
                            bundle.putString("gatewayIotId", localDevice.gatewayIotId);
                        }else {
                            bundle.putString("productKey", localDevice.productKey);
                            bundle.putString("deviceName", localDevice.deviceName);
                            bundle.putString("token", localDevice.token);
                            bundle.putString("addDeviceFrom", localDevice.addDeviceFrom);
                            bundle.putString("id", localDevice.id);
                            bundle.putString("netType", localDevice.type);
                        }

                        ALog.d(TAG, "local device  ---- localDevice: " + JSON.toJSONString(localDevice));
                        Activity activity = (Activity) v.getContext();
                        ALog.d(FLAG, "--LocalDeviceViewHolder跳配网插件--" + "pk:" + localDevice.productKey + " dn:" + localDevice.deviceName + "token：" + localDevice.token + "iotId: " + localDevice.id);
                        //打开插件
                        //Router.getInstance().toUrlForResult(activity, Constants.PLUGIN_ID_DEVICE_CONFIG, CategoryDeviceActivity.REQUEST_CODE_LOCAL_DEVICE_ADD, bundle);
                        //checkPro(activity, bundle);
                        localListener.onLocalItem(activity, bundle);
                    }
                });
            } else if (object instanceof BleDevice) {
                final BleDevice localDevice = (BleDevice) object;
                String showName = localDevice.productName;
                if (!TextUtils.isEmpty(localDevice.deviceName)) {
                    showName += ' ' + localDevice.deviceName;
                }
                if (!TextUtils.isEmpty(localDevice.id)) {
                    showName += ' ' + localDevice.id;
                }
                name.setText(showName);
                mImageBg.setImageResource(R.drawable.deviceadd_add_circle);
                action.setVisibility(View.VISIBLE);
                action.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mImageBg.setImageResource(R.drawable.deviceadd_add_rotate);
                        action.setClickable(false);
                        Animation animation = AnimationUtils.loadAnimation(v.getContext(), R.anim.deviceadd_add_rotate);
                        mImageBg.startAnimation(animation);
                        breezeSubDevLogin(localDevice);
                    }
                });
                nameSame.setText(localDevice.productName);
                arrow.setVisibility(View.GONE);
                arrow.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ALog.d(TAG, "start enter device detail --- localDevice: " + localDevice.toString());
                        Bundle bundle = new Bundle();
                        bundle.putString("iotId", localDevice.getIotId());
                        String url = "link://router/" + localDevice.productKey;
                        bundle.putString("netType", localDevice.type);
                        localListener.onLocalBleItem(url, bundle);
                        //Router.getInstance().toUrlForResult((Activity) v.getContext(), url, CategoryDeviceActivity.DEVICE_DETAIL_REQUEST_CODE, bundle);
                        //PluginUnitUtils.OpenPluginUnit((Activity) v.getContext(), url, CategoryDeviceActivity.DEVICE_DETAIL_REQUEST_CODE, bundle, "device-panel-custom");
                    }
                });
            }
        }


    //蓝牙设备上线
    private void breezeSubDevLogin(final BleDevice localDevice) {
        final BlueToothConnectListener blueToothConnectListener = new BlueToothConnectListener(LocalDeviceViewHolder.this);
        DevService.breezeSubDevLogin(localDevice.productKey, localDevice.deviceName, new DevService.ServiceListener() {
            @Override
            public void onComplete(boolean b, Object o) {
                ALog.d(TAG, "bluetooth device connect result: status:" + b + " bundle:" + o);
                if (b && o instanceof Map) {
                    Map<String, Object> bundle = (Map<String, Object>) o;
                    String deviceName = bundle.get(DevService.BUNDLE_KEY_DEVICENAME).toString();
                    String productKey = bundle.get(DevService.BUNDLE_KEY_PRODUCTKEY).toString();
                    localDevice.deviceName = deviceName;
                    localDevice.productKey = productKey;
                    ALog.d(TAG, "bluetooth device login -----localDevice: " + localDevice.toString());
                    userBindByTimeWindow(localDevice, blueToothConnectListener);
                } else {
                    //error
                    blueToothConnectListener.onConnectFailed("");
                }
            }
        });
    }

    //蓝牙绑定
    private void userBindByTimeWindow(final BleDevice bleDevice, final OnConnectStatusListener onConnectStatusListener) {
        Map<String, Object> device = new HashMap<>(2);
        device.put("productKey", bleDevice.productKey);
        device.put("deviceName", bleDevice.deviceName);
        final IoTRequest request = new IoTRequestBuilder()
                .setPath("/awss/time/window/user/bind")
                .setApiVersion("1.0.3")
                .setParams(device)
                .setAuthType("iotAuth")
                .build();
        new IoTAPIClientFactory().getClient().send(request, new IoTCallback() {
            @Override
            public void onFailure(IoTRequest ioTRequest, Exception e) {
                ALog.e(TAG, "bluetooth bind --- onFailure: " + e);
                if (onConnectStatusListener != null) {
                    onConnectStatusListener.onConnectFailed("");
                }
            }

            @Override
            public void onResponse(IoTRequest ioTRequest, IoTResponse ioTResponse) {
                if (ioTResponse.getCode() == 200) {
                    if (onConnectStatusListener != null) {
                        onConnectStatusListener.onConnectSuccess();
                    }
                    bleDevice.iotId = ioTResponse.getData().toString();
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("deviceName", bleDevice.deviceName);
                        jsonObject.put("productKey", bleDevice.productKey);
                        jsonObject.put("iotId", bleDevice.iotId);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    ALog.d(TAG, "notifySubDeviceBinded: " + jsonObject);
                    //通知sdk
                    new BoneSubDeviceService().notifySubDeviceBinded(jsonObject, null);
                } else {
                    if (onConnectStatusListener != null) {
                        onConnectStatusListener.onConnectFailed(ioTResponse.getMessage());
                    }
                }

            }
        });

    }
}


public interface OnClickLocalListener {

    void onLocalItem(Activity activity, Bundle bundle);

    void onLocalBleItem(String url, Bundle bundle);
}
}

