package com.aliyun.iot.ilop.component.deviceadd.module;

/**
 * @author guikong on 18/4/8.
 */
public class Category {
    public long id;
    public String image;

    public String categoryName;
    public String categoryKey;

    @SuppressWarnings("unused")
    public long gmtCreate;
    @SuppressWarnings("unused")
    public long gmtModified;

    @SuppressWarnings("unused")
    public long superId;
    @SuppressWarnings("unused")
    public String panelTemplateId;
}
