package com.aliyun.iot.ilop.page.deviceadd.search;

import java.util.List;

public interface GlobalCallBack {

    void onSuccess(List<Object> list);

    void onFailed(String msg);
}
