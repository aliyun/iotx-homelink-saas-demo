package com.aliyun.iot.ilop.component.deviceadd.listener;

public interface OnConnectStatusListener {
    void onConnectSuccess();


    void onConnectFailed(String message);


}
