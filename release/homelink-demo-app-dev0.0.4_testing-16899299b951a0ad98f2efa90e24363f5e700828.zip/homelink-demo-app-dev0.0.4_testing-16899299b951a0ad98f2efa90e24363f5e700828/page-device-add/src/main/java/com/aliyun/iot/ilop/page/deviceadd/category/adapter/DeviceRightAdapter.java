package com.aliyun.iot.ilop.page.deviceadd.category.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.aliyun.iot.ilop.component.deviceadd.module.Product;
import com.aliyun.iot.ilop.page.device.add.R;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;
import java.util.List;

public class DeviceRightAdapter extends RecyclerView.Adapter<DeviceRightAdapter.DeviceRightViewHolder> {

    private List<Product> data;

    public DeviceRightAdapter() {
        data = new ArrayList<>();
    }

    public void addProduct(List<Product> products) {
        data.addAll(products);
        notifyDataSetChanged();
    }

    @Override
    public DeviceRightViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new DeviceRightViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.deviceadd_device_item_right, parent, false));
    }

    @Override
    public void onBindViewHolder(DeviceRightViewHolder holder, int position) {
        holder.onBindViewHolder(position);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public void cleanList() {
        data.clear();
    }


    public class DeviceRightViewHolder extends RecyclerView.ViewHolder {

        View action;
        TextView tvTitle;
        ImageView iv_icon;

        public DeviceRightViewHolder(View itemView) {
            super(itemView);
            action = itemView;
            tvTitle = itemView.findViewById(R.id.tv_title);
            iv_icon = itemView.findViewById(R.id.iv_icon);
        }

        public void onBindViewHolder(final int position) {
            tvTitle.setText(data.get(position).productName);
            RequestOptions options = new RequestOptions()
                    .placeholder(R.drawable.deviceadd_icon_default)
                    .error(R.drawable.deviceadd_icon_default);
            Glide.with(itemView.getContext())
                    .load(data.get(position).image)
                    .apply(options)
                    .into(iv_icon);
            action.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onRightItem.onRightItem(data.get(position));
                }
            });
        }

//        public void setData(Object object, int position, int count) {
//            if (object instanceof Product) {
//                final Product product = (Product) object;
//                tvTitle.setText(product.productName);
//                action.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        onRightItem.onRightItem(product);
//                    }
//                });
//            }
//        }
    }

    private OnRightItem onRightItem;

    public void setOnRightItem(OnRightItem onRightItem) {
        this.onRightItem = onRightItem;
    }

    public interface OnRightItem {
        void onRightItem(Product product);
    }
}