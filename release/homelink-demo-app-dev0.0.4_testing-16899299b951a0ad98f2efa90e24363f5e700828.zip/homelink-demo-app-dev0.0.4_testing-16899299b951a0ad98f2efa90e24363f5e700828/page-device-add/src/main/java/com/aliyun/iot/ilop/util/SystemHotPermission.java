package com.aliyun.iot.ilop.util;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import com.aliyun.iot.aep.sdk.log.ALog;

/**
 * 手机热点权限
 */
public class SystemHotPermission {
    private static SystemHotPermission instance;

    public static SystemHotPermission getInstance() {
        if (instance == null)
            instance = new SystemHotPermission();
        return instance;
    }

    /**
     * 是否有手机热点权限
     *
     * @param context
     * @return
     */
    public boolean isHotPermission(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ALog.d("--权限--", "**开启**" + Settings.System.canWrite(context));
            if (!Settings.System.canWrite(context)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                intent.setData(Uri.parse("package:" + context.getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            } else {
                //有了权限，具体的动作
                return true;
            }
        } else {
            return true;
        }
        return false;
    }
}
