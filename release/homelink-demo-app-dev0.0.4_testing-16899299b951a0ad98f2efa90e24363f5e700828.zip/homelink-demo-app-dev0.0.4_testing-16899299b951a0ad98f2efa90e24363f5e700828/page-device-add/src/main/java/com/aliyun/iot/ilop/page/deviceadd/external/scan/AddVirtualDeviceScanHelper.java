package com.aliyun.iot.ilop.page.deviceadd.external.scan;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.aliyun.alink.linksdk.tmp.device.panel.PanelDevice;
import com.aliyun.alink.linksdk.tmp.device.panel.data.PanelMethodExtraData;
import com.aliyun.alink.linksdk.tmp.device.panel.listener.IPanelCallback;
import com.aliyun.alink.linksdk.tmp.utils.TmpEnum;
import com.aliyun.iot.aep.routerexternal.RouterExternal;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClient;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientFactory;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTCallback;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTResponse;
import com.aliyun.iot.aep.sdk.apiclient.emuns.Scheme;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequestBuilder;
import com.aliyun.iot.aep.sdk.credential.IotCredentialManager.IoTCredentialManageImpl;
import com.aliyun.iot.aep.sdk.framework.AApplication;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;
import com.aliyun.iot.ilop.util.PluginUnitUtils;

import java.util.HashMap;
import java.util.Map;

import static com.aliyun.iot.ilop.page.deviceadd.category.CategoryDeviceActivity.DEVICE_DETAIL_REQUEST_CODE;

/**
 * 扫码添加虚拟设备
 */
public class AddVirtualDeviceScanHelper {

    private static final String TAG = "AddVirtualDeviceScanHelper";
    private String url = "/living/virtual/qrcode/bind";
    private Activity activity;

    public AddVirtualDeviceScanHelper(Activity activity, String pk, String locale) {
        this.activity = activity;
        addVirtualDevice(pk, locale);
    }

    /**
     * 获取Identity
     *
     * @return
     */
    private String getIdentity() {
        IoTCredentialManageImpl ioTCredentialManage = IoTCredentialManageImpl.getInstance(AApplication.getInstance());
        if (null == ioTCredentialManage) {
            return null;
        }
        return ioTCredentialManage.getIoTIdentity();
    }


    /**
     * 添加虚拟设备
     */
    private void addVirtualDevice(String pk, String locale) {
        String identity = getIdentity();
        if (TextUtils.isEmpty(identity)) return;
        Map<String, Object> params = new HashMap<>();
        params.put("productKey", pk);
        params.put("identityId", identity);

        IoTRequest request = buildRequest(params, url);
        IoTAPIClient mIoTAPIClient = new IoTAPIClientFactory().getClient();
        mIoTAPIClient.send(request, new IoTCallback() {
            @Override
            public void onFailure(IoTRequest ioTRequest, final Exception e) {
                ALog.e(TAG, "onFail " + this, e);
                ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(activity, e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }

            @Override
            public void onResponse(IoTRequest ioTRequest, final IoTResponse ioTResponse) {
                if (200 != ioTResponse.getCode()) {
                    ALog.e(TAG, "code：" + ioTResponse.getCode() + "message：" + ioTResponse.getMessage() + "LocalizedMsg：" + ioTResponse.getLocalizedMsg());
                    ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(activity, ioTResponse.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                    return;
                }
                ScanVirtualData device = JSON.parseObject(ioTResponse.getData().toString(), ScanVirtualData.class);
                ALog.d(TAG, "device：" + JSON.toJSONString(device));
                Bundle bundle = new Bundle();

                bundle.putString("iotId", device.iotId);
                String url = "link://router/" + device.productKey;
                //扫码体验，每次都刷新缓存
//                RouterExternal.getInstance().removeRouterCache(url);
                bundle.putBoolean("forceRefresh", true);
                //打开插件
                gotoDevicePanel(url, bundle, device.iotId);

                //不刷新设备列表，TMP有2秒同步状态时间，此时刷新会导致显示未激活
                //BroadcastHelper.sendBroadcast(activity, Constant.REFRESH_ACTION);
//                activity.finish();
            }
        });
    }

    /**
     * 请求体
     *
     * @param params
     * @param url
     * @return
     */
    public IoTRequest buildRequest(Map params, String url) {
        IoTRequestBuilder builder = new IoTRequestBuilder();
        builder.setApiVersion("1.0.0");
        builder.setScheme(Scheme.HTTPS);
        builder.setPath(url);
        builder.setParams(params);
        builder.setAuthType("iotAuth");
        IoTRequest request = builder.build();
        return request;
    }

    // 打开控制面板插件
    private void gotoDevicePanel(final String url, final Bundle bundle, final String iotId) {
        //打开插件
        PluginUnitUtils.OpenPluginUnit(activity, url, DEVICE_DETAIL_REQUEST_CODE, bundle, "device-panel-custom");

        //数据预加载，加快面板打开速度
        ThreadPool.DefaultThreadPool.getInstance().submit(new Runnable() {
            @Override
            public void run() {
                PanelDevice panelDevice = new PanelDevice(iotId);
                PanelMethodExtraData data = new PanelMethodExtraData(TmpEnum.ChannelStrategy.LOCAL_CHANNEL_FIRST);
                panelDevice.cacheProperties(new IPanelCallback() {
                    @Override
                    public void onComplete(boolean b, Object o) {
                        if (o != null) {
                            ALog.d(TAG, "--耗时操作检查--" + "boolean：" + b + "--对象--" + JSON.toJSONString(o));
                        }
                    }
                }, data);

            }
        });
    }

}
