package com.aliyun.iot.ilop.page.deviceadd.external.scan;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.aliyun.alink.linksdk.tools.ALog;
import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.ilop.page.device.add.R;
import com.aliyun.iot.ilop.page.deviceadd.Constants;
import com.aliyun.iot.ilop.util.PluginUnitUtils;
import com.aliyun.iot.link.ui.component.LinkToast;
import static com.aliyun.iot.ilop.util.Constant.FLAG;

/**
 * Created by zgb on 18/1/16.
 */

public class AddDeviceScanHelper {
    public static final String TAG = "AddDeviceScanHelper";

    public static final int REQUEST_CODE_START_SCAN = 1000;
    public static final int REQUEST_CODE_ADD_DEVICE_BY_SCAN = 1001;
    public static final int REQUEST_CODE_DEVICE_BIND = 1002;

    public static final int REQUEST_CODE_CONFIG_WIFI = 0x1002;
    public static final int REQUEST_CODE_SCAN = 0x012;

    public void onActivityResult(Activity context, int requestCode, int resultCode, Intent data) {
        ALog.d(TAG, "onActivityResult:requestCode=" + requestCode + ";resultCode=" + resultCode);
        ALog.d(FLAG, "扫一扫配网" + JSON.toJSONString(data));
        if (REQUEST_CODE_START_SCAN == requestCode
                && (Activity.RESULT_OK == resultCode || 100 == resultCode)) {
            String text = data.getStringExtra("data");
            if (TextUtils.isEmpty(text)) {
                text = data.getStringExtra("barCode");
            }
            if (TextUtils.isEmpty(text)) {
                return;
            }
            dealCode(context, text);
        }
    }

    public static void wiFiConfig(Activity context, Intent data, String groupId) {
        String url = data.getStringExtra("data");
        if (TextUtils.isEmpty(url)) {
            LinkToast.makeText(context,
                    R.string.deviceadd_scan_plugin_invalid_qrcode, Toast.LENGTH_LONG).show();
            return;
        }
        try {
            Uri uri = Uri.parse(url);
            String productKey = uri.getQueryParameter("pk");
            String deviceName = uri.getQueryParameter("dn");
            if (TextUtils.isEmpty(productKey) || TextUtils.isEmpty(groupId)) {
                LinkToast.makeText(context, "配网失败", Toast.LENGTH_SHORT).show();
                return;
            }
            String code = Constants.PLUGIN_ID_DEVICE_CONFIG;
            Bundle bundle = new Bundle();
            bundle.putString("groupId", groupId);
            bundle.putString("productKey", productKey);
            bundle.putString("deviceName", deviceName);
            Router.getInstance().toUrlForResult(context, code, REQUEST_CODE_CONFIG_WIFI, bundle);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void dealCode(Activity context, String s) {

        try {
            Uri uri = Uri.parse(s);
            //扫码配网
            String productKey = uri.getQueryParameter("pk");
            String deviceName = uri.getQueryParameter("dn");
            //虚拟设备
            String locale = uri.getQueryParameter("locale");
            String experience_pk = uri.getQueryParameter("experience_pk");

            ALog.d(TAG, "--扫码配网--productKey：" + productKey + "deviceName：" + deviceName);
            ALog.d(TAG, "--扫码创建虚拟设备--locale：" + locale + "experience_pk：" + experience_pk);

            if (!TextUtils.isEmpty(experience_pk)) {
                //创建虚拟设备
                new AddVirtualDeviceScanHelper(context, experience_pk, locale);
            } else {
                if (TextUtils.isEmpty(productKey)) {
                    Toast.makeText(context, R.string.deviceadd_scan_plugin_invalid_qrcode, Toast.LENGTH_LONG).show();
                    return;
                } else {
                    Bundle bundle = new Bundle();
                    bundle.putString("productKey", productKey);
                    if (!TextUtils.isEmpty(deviceName)) {
                        bundle.putString("deviceName", deviceName);
                    }
                    //扫码配网
                    bundle.putBoolean("isRouter", true);
                    bundle.putString("routeUrl", "page/device_bind");
                    //打开配网插件
                    PluginUnitUtils.OpenPluginUnit(context, Constants.PLUGIN_ID_DEVICE_CONFIG, bundle);
                    ALog.d(TAG, "--扫码进入配网插件routeUrl：" + bundle.getString("routeUrl") + "--isRouter：" + bundle.getBoolean("isRouter"));
                }
            }
        } catch (Exception e) {
            ALog.e(TAG, "exception happens when dealCode:" + s);
            e.printStackTrace();
        }
    }

}
