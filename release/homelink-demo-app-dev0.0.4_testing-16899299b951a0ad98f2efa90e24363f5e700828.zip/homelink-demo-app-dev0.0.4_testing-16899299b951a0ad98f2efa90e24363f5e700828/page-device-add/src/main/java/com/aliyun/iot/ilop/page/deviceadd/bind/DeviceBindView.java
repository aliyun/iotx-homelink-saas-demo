package com.aliyun.iot.ilop.page.deviceadd.bind;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.support.annotation.StringRes;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;
import com.aliyun.iot.ilop.page.device.add.R;
import com.aliyun.iot.ilop.util.DensityUtil;

public class DeviceBindView extends LinearLayout {

    private static final String TAG = "DeviceBindView";
    //标题栏
    private RelativeLayout rl_background;
    //返回
    private ImageView ivBack;
    //头部title,中部title,底部title
    private TextView tvDesc, tvBottomTitle;
    //整体布局
    private LinearLayout llContent;
    private RelativeLayout rlContent;
    //加载框
    private ProgressBar progressBar;
    //绑定失败视图
    private ImageView ivLoadingFail;
    private ImageView ivHintFail;
    //重试
    private Button btnReUse;
    //文本加载动画
    private String[] dotText = {" . ", " . . ", " . . ."};
    ValueAnimator valueAnimator;

    public DeviceBindView(Context context) {
        super(context);
        init(context);
    }

    public DeviceBindView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public DeviceBindView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        LayoutInflater.from(context).inflate(R.layout.deviceadd_device_bind_view, this, true);

        rl_background = findViewById(R.id.rl_background);
        ivBack = findViewById(R.id.iv_back);
        llContent = findViewById(R.id.ll_content);
        rlContent = findViewById(R.id.rl_content);
        progressBar = findViewById(R.id.pb_loading);
        tvDesc = findViewById(R.id.tv_desc);
        ivLoadingFail = findViewById(R.id.iv_loading_fail);
        ivHintFail = findViewById(R.id.iv_hint_fail);
        tvBottomTitle = findViewById(R.id.tv_bottom_title);
        btnReUse = findViewById(R.id.deviceadd_device_bind_reuse_btn);
        //设置蓝屏高度
        LayoutParams layoutParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        int height = DensityUtil.getRealWidth(context) - DensityUtil.dip2px(context, 44);
        layoutParams.height = height;
        llContent.setLayoutParams(layoutParams);
        //设置圆形位置
        LayoutParams params = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        params.topMargin = ((height - DensityUtil.dip2px(context, 44) - DensityUtil.dip2px(context, 185)) / 2);
        rlContent.setLayoutParams(params);
    }

    public Button getBtnReUse() {
        return btnReUse;
    }

    /**
     * 设置绑定视图属性
     *
     * @param activity
     * @param isBind
     */
    private void setBindViewProperty(final Activity activity, boolean isBind) {
        if (isBind) {
            rl_background.setBackgroundColor(getResources().getColor(R.color.deviceadd_bind_connect_success));
            llContent.setBackgroundColor(getResources().getColor(R.color.deviceadd_bind_connect_success));
            ivBack.setVisibility(GONE);
            ivHintFail.setVisibility(GONE);
            btnReUse.setVisibility(GONE);
        } else {
            rl_background.setBackgroundColor(getResources().getColor(R.color.deviceadd_bind_connect_fail));
            llContent.setBackgroundColor(getResources().getColor(R.color.deviceadd_bind_connect_fail));
            ivBack.setVisibility(VISIBLE);
            ivHintFail.setVisibility(VISIBLE);
            btnReUse.setVisibility(VISIBLE);
            ivHintFail.setImageResource(R.drawable.device_add_fail_hint);
            ivBack.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    activity.finish();
                }
            });
        }
    }

    /**
     * 是否绑定，更新ui线程
     *
     * @param isBind
     * @param loadingTxt
     */
    public void setIsBind(final Activity activity, final boolean isBind, @StringRes final int loadingTxt) {
        ALog.d(TAG, "--是否绑定--" + isBind + "--描述--" + loadingTxt);
        ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
            @Override
            public void run() {
                setBindViewProperty(activity, isBind);
                if (isBind) {
                    startProgress(loadingTxt);
                } else {
                    stopProgress(loadingTxt);
                }
            }
        });
    }

    /**
     * 开始动画
     *
     * @param loadingTxt
     */
    private void startProgress(@StringRes final int loadingTxt) {
//        if (valueAnimator == null) {
//            valueAnimator = ValueAnimator.ofInt(0, 3).setDuration(1000);
//            valueAnimator.setRepeatCount(ValueAnimator.INFINITE);
//            valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
//                @Override
//                public void onAnimationUpdate(ValueAnimator animation) {
//                    int i = (int) animation.getAnimatedValue();
//                    tvDesc.setText(loadingTxt + dotText[i % dotText.length]);
//                    tvBottomTitle.setText(loadingTxt + dotText[i % dotText.length]);
//                }
//            });
//        }
//        valueAnimator.start();
        tvDesc.setText(loadingTxt);
        tvBottomTitle.setText(loadingTxt);
        ivLoadingFail.setVisibility(GONE);
        progressBar.setVisibility(VISIBLE);
        progressBar.setIndeterminateDrawable(getResources().getDrawable(
                R.drawable.deviceadd_bind_loading));
        progressBar.setProgressDrawable(getResources().getDrawable(
                R.drawable.deviceadd_bind_loading));

    }

    /**
     * 停止动画
     *
     * @param loadingTxt
     */
    private void stopProgress(@StringRes final int loadingTxt) {
//        //销毁动画
//        valueAnimator.cancel();
        tvDesc.setText(loadingTxt);
        tvBottomTitle.setText(loadingTxt);
        progressBar.setVisibility(GONE);
        ivLoadingFail.setVisibility(VISIBLE);
    }
}
