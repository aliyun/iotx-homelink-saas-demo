package com.aliyun.iot.ilop.page.deviceadd.category.module;

/**
 * @author guikong on 18/4/8.
 */
public class LocalDeviceSearcher {
    // well, no field
}
