package com.aliyun.iot.ilop.component.deviceadd.listener;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;
import com.aliyun.iot.ilop.page.device.add.R;
import com.aliyun.iot.link.ui.component.LinkToast;

public class BlueToothConnectListener implements OnConnectStatusListener {

    private static final String TAG = BlueToothConnectListener.class.getSimpleName();
    private Context context;
    private ImageView imageView;
    private RecyclerView.ViewHolder viewHolder;
    private View action, arrow;


    public BlueToothConnectListener(RecyclerView.ViewHolder viewHolder) {
        this.viewHolder = viewHolder;
        imageView = viewHolder.itemView.findViewById(R.id.deviceadd_iv_bleadd_bg);
        action = viewHolder.itemView.findViewById(R.id.deviceadd_category_list_local_device_add_fl);
        arrow = viewHolder.itemView.findViewById(R.id.deviceadd_category_list_local_device_add_fl1);
        context = imageView.getContext();
    }

    @Override
    public void onConnectSuccess() {
        ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
            @Override
            public void run() {
                ALog.d(TAG, "onConnectSuccess: " + imageView);
                if (imageView != null) {
                    LinkToast.makeText(context, R.string.deviceadd_bind_bt_success, Toast.LENGTH_SHORT).show();
                    imageView.clearAnimation();
                    imageView.setImageResource(R.drawable.deviceadd_add_circle);
                    action.setClickable(true);
                    action.setVisibility(View.GONE);
                    arrow.setVisibility(View.VISIBLE);
                }
            }
        });

    }

    @Override
    public void onConnectFailed(final String message) {
        ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
            @Override
            public void run() {
                ALog.e(TAG, "onConnectFailed: " + message);
                if (imageView != null) {
                    LinkToast.makeText(context, R.string.deviceadd_bind_bt_failed, Toast.LENGTH_SHORT).show();
                    imageView.clearAnimation();
                    imageView.setImageResource(R.drawable.deviceadd_add_circle);
                    action.setClickable(true);
                }


            }
        });
    }
}

