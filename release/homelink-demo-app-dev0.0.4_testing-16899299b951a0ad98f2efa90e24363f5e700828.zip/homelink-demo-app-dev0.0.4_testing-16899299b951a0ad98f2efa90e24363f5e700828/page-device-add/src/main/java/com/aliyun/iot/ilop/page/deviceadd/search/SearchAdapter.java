package com.aliyun.iot.ilop.page.deviceadd.search;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.aliyun.iot.ilop.component.deviceadd.module.Product;
import com.aliyun.iot.ilop.page.device.add.R;
import com.aliyun.iot.ilop.page.deviceadd.category.viewholder.SettableViewHolder;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;
import java.util.List;

public class SearchAdapter extends RecyclerView.Adapter<SettableViewHolder> {

    private List<Product> productList;

    public SearchAdapter() {
        productList = new ArrayList<>();
    }

    public void addProduct(List<Product> products) {
        productList.clear();
        productList.addAll(products);
        notifyDataSetChanged();
    }

    @Override
    public SettableViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (null == parent) {
            return null;
        }
        Context context = parent.getContext();
        View view = LayoutInflater.from(context).inflate(R.layout.deviceadd_device_item_search, parent, false);
        return new DeviceRightViewHolder(view);

    }

    @Override
    public void onBindViewHolder(SettableViewHolder holder, int position) {
        Object item = productList.get(position);
        holder.setData(item, position, productList.size());
    }


    @Override
    public int getItemCount() {
        return productList.size();
    }


    public class DeviceRightViewHolder extends SettableViewHolder {

        View action;
        TextView tvTitle;
        ImageView im_img;
        View deviceadd_search_lin_view;

        public DeviceRightViewHolder(View itemView) {
            super(itemView);
            action = itemView;
            tvTitle = itemView.findViewById(R.id.tv_title);
            im_img = itemView.findViewById(R.id.im_img);
            deviceadd_search_lin_view = itemView.findViewById(R.id.deviceadd_search_lin_view);
        }

        public void setData(Object object, int position, int count) {
            if (object instanceof Product) {
                if (position == productList.size() - 1) {
                    deviceadd_search_lin_view.setVisibility(View.GONE);
                } else {
                    deviceadd_search_lin_view.setVisibility(View.VISIBLE);
                }
                final Product product = (Product) object;
                tvTitle.setText(product.productName);
                RequestOptions options = new RequestOptions()
                        .placeholder(R.drawable.deviceadd_icon_default)
                        .error(R.drawable.deviceadd_icon_default);
                Glide.with(itemView.getContext())
                        .load(product.categoryUrl)
                        .apply(options)
                        .into(im_img);
                action.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onRightItem.onRightItem(product);
                    }
                });
            }
        }
    }

    private OnRightItem onRightItem;

    public void setOnRightItem(OnRightItem onRightItem) {
        this.onRightItem = onRightItem;
    }

    public interface OnRightItem {
        void onRightItem(Product product);
    }
}
