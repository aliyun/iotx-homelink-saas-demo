package com.aliyun.iot.ilop.page.deviceadd.category.viewholder;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.aliyun.alink.linksdk.tmp.extbone.BoneSubDeviceService;
import com.aliyun.alink.linksdk.tmp.service.DevService;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientFactory;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTCallback;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTResponse;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequestBuilder;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.ilop.component.deviceadd.listener.BlueToothConnectListener;
import com.aliyun.iot.ilop.component.deviceadd.listener.OnConnectStatusListener;
import com.aliyun.iot.ilop.component.deviceadd.module.BleDevice;
import com.aliyun.iot.ilop.component.deviceadd.module.LocalDevice;
import com.aliyun.iot.ilop.page.device.add.R;
import com.aliyun.iot.ilop.page.deviceadd.Constants;
import com.aliyun.iot.ilop.page.deviceadd.category.CategoryDeviceActivity;
import com.aliyun.iot.ilop.util.PluginUnitUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.aliyun.iot.ilop.util.Constant.FLAG;


/**
 * @author guikong on 18/4/8.
 */
public class LocalDeviceViewHolder extends SettableViewHolder {
    private static final String TAG = "ViewHolder";

    TextView name, nameSame;
    View action, arrow;
    ImageView mImageBg;


    public LocalDeviceViewHolder(View view) {
        super(view);
        name = view.findViewById(R.id.deviceadd_category_list_local_device_name_tv);
        nameSame = view.findViewById(R.id.deviceadd_category_list_local_device_name_tv_same);
        action = view.findViewById(R.id.deviceadd_category_list_local_device_add_fl);
        arrow = view.findViewById(R.id.deviceadd_category_list_local_device_add_fl1);
        mImageBg = view.findViewById(R.id.deviceadd_iv_bleadd_bg);
    }

    @Override
    public void setData(Object object, int position, int count) {
        if (object instanceof LocalDevice) {
            final LocalDevice localDevice = (LocalDevice) object;
            ALog.d(TAG, "LocalDeviceataD：" + JSON.toJSONString(object));
            String showName = localDevice.productName;
            if (!TextUtils.isEmpty(localDevice.deviceName)) {
                showName += ' ' + localDevice.deviceName;
            }
            if (!TextUtils.isEmpty(localDevice.id)) {
                showName += ' ' + localDevice.id;
            }

            arrow.setVisibility(View.GONE);
            name.setText(showName);

            mImageBg.setImageResource(R.drawable.deviceadd_add_circle);
            action.setVisibility(View.VISIBLE);
            action.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("productKey", localDevice.productKey);
                    bundle.putString("deviceName", localDevice.deviceName);
                    bundle.putString("token", localDevice.token);
                    bundle.putString("addDeviceFrom", localDevice.addDeviceFrom);
                    bundle.putString("id", localDevice.id);
                    ALog.d(TAG, "local device  ---- localDevice: " + JSON.toJSONString(localDevice));
                    Activity activity = (Activity) v.getContext();
                    ALog.d(FLAG, "--LocalDeviceViewHolder跳配网插件--" + "pk:" + localDevice.productKey + " dn:" + localDevice.deviceName + "token：" + localDevice.token + "iotId: " + localDevice.id);
                    //打开插件
                    //Router.getInstance().toUrlForResult(activity, Constants.PLUGIN_ID_DEVICE_CONFIG, CategoryDeviceActivity.REQUEST_CODE_LOCAL_DEVICE_ADD, bundle);
                    checkPro(activity, bundle);

                }
            });
        } else if (object instanceof BleDevice) {
            final BleDevice localDevice = (BleDevice) object;
            name.setText(localDevice.productName);
            mImageBg.setImageResource(R.drawable.deviceadd_add_circle);
            action.setVisibility(View.VISIBLE);
            action.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mImageBg.setImageResource(R.drawable.deviceadd_add_rotate);
                    action.setClickable(false);
                    Animation animation = AnimationUtils.loadAnimation(v.getContext(), R.anim.deviceadd_add_rotate);
                    mImageBg.startAnimation(animation);
                    breezeSubDevLogin(localDevice);
                }
            });
            nameSame.setText(localDevice.productName);
            arrow.setVisibility(View.GONE);
            arrow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ALog.d(TAG, "start enter device detail --- localDevice: " + localDevice.toString());
                    Bundle bundle = new Bundle();
                    bundle.putString("iotId", localDevice.getIotId());
                    String url = "link://router/" + localDevice.productKey;
                    //Router.getInstance().toUrlForResult((Activity) v.getContext(), url, CategoryDeviceActivity.DEVICE_DETAIL_REQUEST_CODE, bundle);
                    PluginUnitUtils.OpenPluginUnit((Activity) v.getContext(), url, CategoryDeviceActivity.DEVICE_DETAIL_REQUEST_CODE, bundle, "device-panel-custom");
                }
            });
        }
    }

    //热点系统设置的权限开启
    private void checkPro(Activity context, Bundle bundle) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.System.canWrite(context)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
                intent.setData(Uri.parse("package:" + context.getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            } else {
                //有了权限，具体的动作
                PluginUnitUtils.OpenPluginUnit(context, Constants.PLUGIN_ID_DEVICE_CONFIG, CategoryDeviceActivity.REQUEST_CODE_LOCAL_DEVICE_ADD, bundle);
            }
        } else {
            PluginUnitUtils.OpenPluginUnit(context, Constants.PLUGIN_ID_DEVICE_CONFIG, CategoryDeviceActivity.REQUEST_CODE_LOCAL_DEVICE_ADD, bundle);
        }
    }


    //蓝牙设备上线
    private void breezeSubDevLogin(final BleDevice localDevice) {
        final BlueToothConnectListener blueToothConnectListener = new BlueToothConnectListener(LocalDeviceViewHolder.this);
        DevService.breezeSubDevLogin(localDevice.productKey, localDevice.deviceName, new DevService.ServiceListener() {
            @Override
            public void onComplete(boolean b, Object o) {
                ALog.d(TAG, "bluetooth device connect result: status:" + b + " bundle:" + o);
                if (b && o instanceof Map) {
                    Map<String, Object> bundle = (Map<String, Object>) o;
                    String deviceName = bundle.get(DevService.BUNDLE_KEY_DEVICENAME).toString();
                    String productKey = bundle.get(DevService.BUNDLE_KEY_PRODUCTKEY).toString();
                    localDevice.deviceName = deviceName;
                    localDevice.productKey = productKey;
                    ALog.d(TAG, "bluetooth device login -----localDevice: " + localDevice.toString());
                    userBindByTimeWindow(localDevice, blueToothConnectListener);
                } else {
                    //error
                    blueToothConnectListener.onConnectFailed("");
                }
            }
        });
    }

    //蓝牙绑定
    private void userBindByTimeWindow(final BleDevice bleDevice, final OnConnectStatusListener onConnectStatusListener) {
        Map<String, Object> device = new HashMap<>(2);
        device.put("productKey", bleDevice.productKey);
        device.put("deviceName", bleDevice.deviceName);
        final IoTRequest request = new IoTRequestBuilder()
                .setPath("/awss/time/window/user/bind")
                .setApiVersion("1.0.3")
                .setParams(device)
                .setAuthType("iotAuth")
                .build();
        new IoTAPIClientFactory().getClient().send(request, new IoTCallback() {
            @Override
            public void onFailure(IoTRequest ioTRequest, Exception e) {
                ALog.e(TAG, "bluetooth bind --- onFailure: " + e);
                if (onConnectStatusListener != null) {
                    onConnectStatusListener.onConnectFailed("");
                }
            }

            @Override
            public void onResponse(IoTRequest ioTRequest, IoTResponse ioTResponse) {
                if (ioTResponse.getCode() == 200) {
                    if (onConnectStatusListener != null) {
                        onConnectStatusListener.onConnectSuccess();
                    }
                    bleDevice.iotId = ioTResponse.getData().toString();
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("deviceName", bleDevice.deviceName);
                        jsonObject.put("productKey", bleDevice.productKey);
                        jsonObject.put("iotId", bleDevice.iotId);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    ALog.d(TAG, "notifySubDeviceBinded: " + jsonObject);
                    //通知sdk
                    new BoneSubDeviceService().notifySubDeviceBinded(jsonObject, null);
                } else {
                    if (onConnectStatusListener != null) {
                        onConnectStatusListener.onConnectFailed(ioTResponse.getMessage());
                    }
                }

            }
        });

    }


}
