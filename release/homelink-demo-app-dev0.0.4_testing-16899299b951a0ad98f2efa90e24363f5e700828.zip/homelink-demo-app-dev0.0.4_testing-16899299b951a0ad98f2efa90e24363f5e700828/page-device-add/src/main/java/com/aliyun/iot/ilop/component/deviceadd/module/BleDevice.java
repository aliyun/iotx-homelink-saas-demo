package com.aliyun.iot.ilop.component.deviceadd.module;

import android.text.TextUtils;

import com.aliyun.alink.linksdk.tmp.api.DeviceBasicData;


public class BleDevice extends FoundDevice {

    public String modelType;

    public String desc;
    public String addr;
    public String deviceModelJson;
    public String iotId;
    public int port;
    public boolean isLocal;


    public String getModelType() {
        return modelType;
    }

    public void setModelType(String modelType) {
        this.modelType = modelType;
    }

    public String getProductKey() {
        return productKey;
    }

    public void setProductKey(String productKey) {
        this.productKey = productKey;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getDeviceModelJson() {
        return deviceModelJson;
    }

    public void setDeviceModelJson(String deviceModelJson) {
        this.deviceModelJson = deviceModelJson;
    }

    public String getIotId() {
        return iotId;
    }

    public void setIotId(String iotId) {
        this.iotId = iotId;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public boolean isLocal() {
        return isLocal;
    }

    public void setLocal(boolean local) {
        isLocal = local;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!super.equals(o)) return false;

        if (!(o instanceof BleDevice)) return false;
        BleDevice that = (BleDevice) o;
        return TextUtils.equals(modelType, that.modelType) &&
                TextUtils.equals(desc, that.desc) &&
                TextUtils.equals(addr, that.addr) &&
                TextUtils.equals(deviceModelJson, that.deviceModelJson) &&
                TextUtils.equals(iotId, that.iotId) &&
                (port == that.port) &&
                (isLocal == that.isLocal);
    }


    @Override
    public String toString() {
        return "BleDevice{" +
                "modelType='" + modelType + '\'' +
                ", productKey='" + productKey + '\'' +
                ", deviceName='" + deviceName + '\'' +
                ", desc='" + desc + '\'' +
                ", addr='" + addr + '\'' +
                ", deviceModelJson='" + deviceModelJson + '\'' +
                ", iotId='" + iotId + '\'' +
                ", port=" + port +
                ", isLocal=" + isLocal +
                '}';
    }


    public void copyDeviceBasicData(DeviceBasicData deviceBasicData) {
        productKey = deviceBasicData.getProductKey();
        deviceName = deviceBasicData.getDeviceName();
        modelType = deviceBasicData.getModelType();
        desc = deviceBasicData.getDesc();
        addr = deviceBasicData.getAddr();
        deviceModelJson = deviceBasicData.getDeviceModelJson();
        iotId = deviceBasicData.getIotId();
        port = deviceBasicData.getPort();
        isLocal = deviceBasicData.isLocal();
    }
}
