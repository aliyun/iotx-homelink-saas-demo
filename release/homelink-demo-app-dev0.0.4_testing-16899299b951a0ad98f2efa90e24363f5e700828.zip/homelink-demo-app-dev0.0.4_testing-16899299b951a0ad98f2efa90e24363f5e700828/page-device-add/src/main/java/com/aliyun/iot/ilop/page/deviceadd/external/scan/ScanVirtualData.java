package com.aliyun.iot.ilop.page.deviceadd.external.scan;

public class ScanVirtualData {

    public String iotId;
    public String deviceName;
    public String productKey;
}
