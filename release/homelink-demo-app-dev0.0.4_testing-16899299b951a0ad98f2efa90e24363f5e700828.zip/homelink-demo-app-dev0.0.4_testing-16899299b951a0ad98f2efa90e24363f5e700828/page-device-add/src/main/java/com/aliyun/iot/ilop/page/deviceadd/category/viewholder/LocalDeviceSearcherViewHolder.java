package com.aliyun.iot.ilop.page.deviceadd.category.viewholder;

import android.view.View;
import android.widget.TextView;

import com.aliyun.iot.ilop.page.device.add.R;

/**
 * @author guikong on 18/4/8.
 */

public class LocalDeviceSearcherViewHolder extends SettableViewHolder {

    public LocalDeviceSearcherViewHolder(View view) {
        super(view);

        final TextView textView = view.findViewById(R.id.deviceadd_category_list_local_device_searcher_tv);
        final String text = textView.getText().toString();
        textView.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {

            int index = 0;
            boolean visible = false;

            Runnable animationRunnable = new Runnable() {
                @Override
                public void run() {
                    if (!visible) {
                        return;
                    }

                    index++;

                    if (index > 3) {
                        index = 0;
                    }

                    String currentText = text;
                    for (int i = 0; i < index; i++) {
                        currentText += ".";
                    }

                    textView.setText(currentText);

                    textView.postDelayed(
                            animationRunnable,
                            index == 3 ? 1000 : 500);
                }
            };

            @Override
            public void onViewAttachedToWindow(View v) {
                visible = true;
                index = 0;
                textView.postDelayed(animationRunnable, 500);
            }

            @Override
            public void onViewDetachedFromWindow(View v) {
                visible = false;
            }

        });
    }

    @Override
    public void setData(Object object, int position, int count) {

    }
}
