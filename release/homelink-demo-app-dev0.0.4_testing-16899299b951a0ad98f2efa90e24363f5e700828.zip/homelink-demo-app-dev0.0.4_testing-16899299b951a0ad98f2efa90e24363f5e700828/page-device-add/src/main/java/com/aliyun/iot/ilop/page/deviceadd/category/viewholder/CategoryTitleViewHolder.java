package com.aliyun.iot.ilop.page.deviceadd.category.viewholder;

import android.view.View;

/**
 * @author guikong on 18/4/8.
 */

public class CategoryTitleViewHolder extends SettableViewHolder {

    public CategoryTitleViewHolder(View view) {
        super(view);
    }

    @Override
    public void setData(Object object, int position, int count) {

    }
}
