package com.aliyun.iot.ilop.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;

import java.io.Serializable;

/**
 * 广播工具类
 */
public class BroadcastHelper {

    public interface OnReceiveBroadcast {
        void onReceive(Context context, Intent intent);
    }

    private static class CustomBroadcastReceiver extends BroadcastReceiver {
        private OnReceiveBroadcast onReceiveBroadcast;

        public CustomBroadcastReceiver(OnReceiveBroadcast onReceiveBroadcast) {
            this.onReceiveBroadcast = onReceiveBroadcast;
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            if (onReceiveBroadcast != null) {
                onReceiveBroadcast.onReceive(context, intent);
            }
        }
    }

    /**
     * 广播注册
     *
     * @param context
     * @param filters
     * @param onReceiveBroadcast
     * @return
     */
    public static BroadcastReceiver registerBroadcastReceiver(Context context, String[] filters, OnReceiveBroadcast onReceiveBroadcast) {
        BroadcastReceiver broadcastReceiver = new CustomBroadcastReceiver(onReceiveBroadcast);
        IntentFilter filter = new IntentFilter();
        for (String filterStr : filters) {
            filter.addAction(filterStr);
        }
        LocalBroadcastManager.getInstance(context).registerReceiver(broadcastReceiver, filter);
        return broadcastReceiver;
    }

    public static void sendBroadcast(Context context, String filter) {
        if (context == null) {
            return;
        }
        Intent intent = new Intent();
        intent.setAction(filter);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    public static void sendBroadcast(Context context, String filter, Bundle bundle) {
        if (context == null) {
            return;
        }
        Intent intent = new Intent();
        intent.setAction(filter);
        intent.putExtras(bundle);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    public static void sendBroadcast(Context context, String filter, String bundleName, Bundle bundle) {
        if (context == null) {
            return;
        }
        Intent intent = new Intent();
        intent.setAction(filter);
        intent.putExtra(bundleName, bundle);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    public static void sendBroadcast(Context context, String filter, String name, Serializable serializable) {
        Intent intent = new Intent();
        intent.putExtra(name, serializable);
        intent.setAction(filter);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    public static void sendBroadcast(Context context, String filter, String name, String value) {
        Intent intent = new Intent();
        intent.putExtra(name, value);
        intent.setAction(filter);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    public static void sendBroadcast(Context context, String filter, String name, long value) {
        Intent intent = new Intent();
        intent.putExtra(name, value);
        intent.setAction(filter);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    public static void sendBroadcast(Context context, String filter, String name, int value) {
        Intent intent = new Intent();
        intent.putExtra(name, value);
        intent.setAction(filter);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    public static void sendBroadcast(Context context, String filter, String name, String value, String name1, String value1) {
        Intent intent = new Intent();
        intent.putExtra(name, value);
        intent.putExtra(name1, value1);
        intent.setAction(filter);
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
    }

    /**
     * 取消注册
     *
     * @param context
     * @param broadcastReceiver
     */
    public static void unRegisterBroadcastReceiver(Context context, BroadcastReceiver broadcastReceiver) {
        if (context != null && broadcastReceiver != null) {
            LocalBroadcastManager.getInstance(context).unregisterReceiver(broadcastReceiver);
        }
    }
}