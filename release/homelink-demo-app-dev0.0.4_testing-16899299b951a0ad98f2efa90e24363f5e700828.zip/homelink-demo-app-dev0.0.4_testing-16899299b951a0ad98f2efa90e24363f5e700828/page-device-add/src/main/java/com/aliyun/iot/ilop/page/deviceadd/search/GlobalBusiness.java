package com.aliyun.iot.ilop.page.deviceadd.search;

import android.content.Context;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClient;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientFactory;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTCallback;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTResponse;
import com.aliyun.iot.aep.sdk.apiclient.emuns.Scheme;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequestBuilder;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;
import com.aliyun.iot.ilop.component.deviceadd.module.Product;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class GlobalBusiness {

    //用于存储全局搜索内容
    public static List<Object> globalProductList = new ArrayList<>();

    private static String TAG = "GlobalBusiness";
    private List<Product> productList;
    private Context context;

    public GlobalBusiness(Context context) {
        this.context = context;
    }

    public void allProductRequest(final GlobalCallBack callBack) {
        IoTRequestBuilder builder = new IoTRequestBuilder()
                .setPath("/home/app/product/query")
                .setScheme(Scheme.HTTPS)
                .setApiVersion("1.0.0")
                .setAuthType("iotAuth")
                .addParam("pageNo", 1)
                .addParam("pageSize", 99);

        final IoTAPIClient client = new IoTAPIClientFactory().getClient();

        client.send(builder.build(), new IoTCallback() {
            @Override
            public void onFailure(IoTRequest request, Exception e) {
                ALog.d(TAG, "onFailure：" + e.toString());
                callBack.onFailed(e.getMessage());
            }

            @Override
            public void onResponse(IoTRequest request, IoTResponse response) {
                if (response.getCode() != 200) {
                    callBack.onFailed(response.getMessage());
                }
                JSONObject data = (JSONObject) response.getData();
                if (!data.has("data")) {
                    callBack.onSuccess(globalProductList);
                    return;
                }
                JSONArray items = data.optJSONArray("data");
                for (int i = 0; i < items.length(); i++) {
                    try {
                        Product product = new Product();
                        JSONObject object = items.getJSONObject(i);
                        if (object.has("productKey")) {
                            product.productKey = object.getString("productKey");
                        }
                        if (object.has("productName")) {
                            product.productName = object.getString("productName");
                        }
                        if (object.has("categoryKey")) {
                            product.categoryKey = object.getString("categoryKey");
                        }
                        if (object.has("netType")) {
                            product.netType = object.getString("netType");
                        }
                        if (object.has("categoryUrl")) {
                            product.categoryUrl = object.getString("categoryUrl");
                        }
                        if (object.has("productName")) {
                            product.productName = object.getString("productName");
                        }
                        if (object.has("image")) {
                            product.image = object.getString("image");
                        }
                        globalProductList.add(product);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                callBack.onSuccess(globalProductList);
            }
        });
    }


    public void searchRequset(String word, final SearchCallBack searchCallBack) {
        if (productList == null) {
            return;
        }
        if (searchCallBack == null) {
            return;
        }

        final List<Product> newProduct = new ArrayList<>();
        if (TextUtils.isEmpty(word)) {
            newProduct.clear();
        } else {
            for (int i = 0; i < productList.size(); i++) {
                if (productList.get(i).productName.contains(word) || productList.get(i).productName.toLowerCase().contains(word.toLowerCase())) {
                    newProduct.add(productList.get(i));
                }
            }
        }
        ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
            @Override
            public void run() {
                try {
                    searchCallBack.onSearchSuccess(newProduct);
                } catch (Exception ex) {
                    ALog.e(TAG, "exception happen when call listener.onSuccess", ex);
                    ex.printStackTrace();
                }
            }
        });

    }

    public void getAllProduct(List<Product> productList) {
        this.productList = productList;
    }
}
