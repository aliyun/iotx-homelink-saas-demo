package com.aliyun.iot.ilop.page.deviceadd.category;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.aliyun.alink.linksdk.tmp.api.DevFoundOutputParams;
import com.aliyun.alink.linksdk.tmp.api.DeviceBasicData;
import com.aliyun.alink.linksdk.tmp.api.DeviceManager;
import com.aliyun.alink.linksdk.tmp.api.IDiscoveryFilter;
import com.aliyun.alink.linksdk.tmp.api.OutputParams;
import com.aliyun.alink.linksdk.tmp.data.cloud.CloudLcaRequestParams;
import com.aliyun.alink.linksdk.tmp.listener.IDevListener;
import com.aliyun.alink.linksdk.tmp.utils.ErrorInfo;
import com.aliyun.alink.linksdk.tmp.utils.TmpConstant;
import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.aep.sdk.credential.IotCredentialManager.IoTCredentialManageImpl;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;
import com.aliyun.iot.ilop.component.deviceadd.LocalDeviceBusiness;
import com.aliyun.iot.ilop.component.deviceadd.SelectProductBusiness;
import com.aliyun.iot.ilop.component.deviceadd.listener.OnDeviceFilterCompletedListener;
import com.aliyun.iot.ilop.component.deviceadd.listener.OnGetCategoryCompletedListener;
import com.aliyun.iot.ilop.component.deviceadd.listener.OnGetProductCompletedListener;
import com.aliyun.iot.ilop.component.deviceadd.module.Category;
import com.aliyun.iot.ilop.component.deviceadd.module.FoundDevice;
import com.aliyun.iot.ilop.component.deviceadd.module.LocalDevice;
import com.aliyun.iot.ilop.component.deviceadd.module.Product;
import com.aliyun.iot.ilop.page.device.add.R;
import com.aliyun.iot.ilop.page.deviceadd.Constants;
import com.aliyun.iot.ilop.page.deviceadd.category.adapter.DeviceLeftAdapter;
import com.aliyun.iot.ilop.page.deviceadd.category.adapter.DeviceRightAdapter;
import com.aliyun.iot.ilop.page.deviceadd.category.adapter.LocalAdapter;
import com.aliyun.iot.ilop.page.deviceadd.external.scan.AddDeviceScanHelper;
import com.aliyun.iot.ilop.util.BreezeUtil;
import com.aliyun.iot.ilop.util.BroadcastHelper;
import com.aliyun.iot.ilop.util.Constant;
import com.aliyun.iot.ilop.util.PluginUnitUtils;
import com.aliyun.iot.ilop.util.SystemHotPermission;
import com.aliyun.iot.link.ui.component.RefreshRecycleViewLayout;
import com.aliyun.iot.link.ui.component.simpleLoadview.LinkSimpleLoadView;

import java.util.List;

import static com.aliyun.iot.ilop.page.deviceadd.search.SearchActivity.CODE_SEARCH;

public class CategoryDeviceActivity extends AppCompatActivity {

    static final String TAG = "CategoryDeviceActivity";
    public static final int DEVICE_DETAIL_REQUEST_CODE = 1005;

    @SuppressWarnings("unused")
    public final static String CODE = "page/categoryList";

    public final static int REQUEST_CODE_LOCAL_DEVICE_ADD = 2000;
    public final static int REQUEST_CODE_LOCAL_DEVICE_BIND = 2001;
    public final static int REQUEST_CODE_PRODUCT_LIST = 2100;
    public final static int REQUEST_CODE_BLE_DEVICE_ADD = 2200;

    public final static int REQUEST_CODE_PRODUCT_ADD = 11000;
    public final static int REQUEST_CODE_DEVICE_BIND = 11001;

    LinkSimpleLoadView loadView;

    int currentLeftPage = 1;
    int currentRightPage = 1;
    int pageSize = 99;

    int loadedLeftNumber = 0;
    boolean isLoadingLeftMore = false;

    LocalDeviceBusiness localDeviceBusiness;

    private List<FoundDevice> list;

    private LinearLayout llLocalDevice, llDevice;

    private RecyclerView rlLoaclDevice;
    private LocalAdapter adapterLocal;

    private RefreshRecycleViewLayout leftRecycle;

    private RefreshRecycleViewLayout rightRecycle;
    private DeviceLeftAdapter leftAdapter;
    private DeviceRightAdapter rightAdapter;
    private String categoryKey = "";
    //默认第一次加载
    private int index = 1;
    private String[] permissions = new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.BLUETOOTH_ADMIN};

    private Product mSelectedProduct;
    private String netType;
    private BroadcastReceiver broadcastReceiver;

    private final IDevListener deviceDiscoveryCallback = new IDevListener() {
        @Override
        public void onSuccess(Object o, OutputParams outputParams) {
            if (outputParams == null || outputParams.isEmpty()) {
                // quickly fail
                toastDiscoveryResult("LCA success, outputParams are null or empty");
                return;
            }
            Log.d("LCA outputParams", JSON.toJSONString(outputParams));
            try {
                String productKey = safeGet(outputParams, DevFoundOutputParams.PARAMS_PRODUCT_KEY);
                String modelName = safeGet(outputParams, DevFoundOutputParams.PARAMS_MODEL_NAME);
                String deviceName = safeGet(outputParams, DevFoundOutputParams.PARAMS_DEVICE_NAME);
                String modelType = safeGet(outputParams, DevFoundOutputParams.PARAMS_MODEL_TYPE);
                String gatewayIotId = safeGet(outputParams, DevFoundOutputParams.PARAMS_GATEWAY_IOTID);
                String gatewayName = safeGet(outputParams, DevFoundOutputParams.PARAMS_GATEWAY_NAME);
                LocalDevice localDevice = new LocalDevice();
                localDevice.productKey = productKey;
                localDevice.deviceName = deviceName;
                localDevice.productName = gatewayName;
//                addLCADevice(localDevice.toLCA(modelName, modelType, gatewayIotId, gatewayName));
                addLCADevice(localDevice.toLCA(modelName, modelType, gatewayIotId, gatewayName));
                toastDiscoveryResult("LCA success, " + JSON.toJSONString(localDevice));
            } catch (NullPointerException e) {
                e.printStackTrace();
                toastDiscoveryResult("LCA success, error = " + e.getMessage());
            }

        }

        @Override
        public void onFail(Object o, ErrorInfo errorInfo) {
            toastDiscoveryResult("LCA failed, " + JSON.toJSONString(errorInfo));
        }
    };

    private String safeGet(OutputParams outputParams, String name) {
        if (outputParams.get(name) != null) {
            return (String) outputParams.get(name).getValue();
        }
        return null;
    }

    private void addLCADevice(final LocalDevice localDevice) {
        ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
            @Override
            public void run() {
                if (adapterLocal != null) {
                    adapterLocal.addLCADevice(localDevice);
                }
            }
        });
    }

    private void toastDiscoveryResult(final String message) {
        Log.d("LCA设备", message);
    }

    /**
     * 查找LCA设备并且显示
     */
    private void startFindingLCADevices() {

//        IoTRequestBuilder builder = new IoTRequestBuilder()
//                .setAuthType("iotAuth")
//                .setPath("/uc/listBindingByAccount")
//                .setScheme(Scheme.HTTPS)
//                .setApiVersion("1.0.6");
//
//        HashMap<String, Object> map = new HashMap<>();
//        map.put("pageNo", 1);
//        map.put("pageSize", pageSize);
//        map.put("groupId", IoTCredentialManageImpl.getInstance(getApplication()).getIoTIdentity());
//        builder.setParams(map);
//
//        new IoTAPIClientFactory().getClient().send(builder.build(), new IotCallbackMainThread(this) {
//            @Override
//            protected void onSuccess(IoTRequest request, IoTResponse response) {
//                if (response.getCode() == 200 && response.getData() != null && response.getData() instanceof JSONObject) {
//                    List<AccountDevice> devices = null;
//                    try {
//                        devices = JSON.parseArray(((JSONObject) response.getData()).getString("data"), AccountDevice.class);
//                        String iotId = null;
//                        for (AccountDevice device : devices) {
//                            ALog.d(TAG, device.toString());
//                            if (device.isIsEdgeGateway()) {
//                                iotId = device.getIotId();
//                                break;
//                            }
//                        }
//
//                        if (iotId != null) {
        CloudLcaRequestParams params = new CloudLcaRequestParams();
        ALog.d(TAG, "startFindingLCADevices");
        params.groupId = IoTCredentialManageImpl.getInstance(getApplication()).getIoTIdentity();
//                            params.gatewayIotId = iotId;
        DeviceManager.getInstance().discoverDevices(null, false, 5000, params,
                new IDiscoveryFilter() {
                    @Override
                    public boolean doFilter(DeviceBasicData data) {
                        Log.d(TAG, "LCA filter");
                        Log.d(TAG, data.toString());
                        return TmpConstant.MODEL_TYPE_ALI_LCA_CLOUD.equals(data.getModelType());
                    }
                }, deviceDiscoveryCallback);
//                        }
//                    } catch (JSONException e) {
//                        e.printStackTrace();
//                    }
//                }
//            }
//        });

    }


    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.deviceadd_device_add_activity);
        //申请定位、蓝牙权限
        if (!BreezeUtil.getInstance().checkBreezePer(this, permissions)) {
            BreezeUtil.getInstance().addCheckBreezePer(this, permissions, 0x0000);
        }
        //关闭当前activity
        broadcastReceiver = BroadcastHelper.registerBroadcastReceiver(this, new String[]{Constant.FINISH_ACTION}, new BroadcastHelper.OnReceiveBroadcast() {
            @Override
            public void onReceive(Context context, Intent intent) {
                ALog.d(TAG, "--接收广播关闭当前CategoryDeviceActivity--");
                CategoryDeviceActivity.this.finish();
            }
        });
    }


    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // top_bar
        TextView title = findViewById(R.id.deviceadd_top_bar_title_tv);
        title.setText(R.string.deviceadd_device_add);
        View backView = findViewById(R.id.deviceadd_top_bar_back_fl);
        backView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //扫一扫(手机热点权限)
        findViewById(R.id.deviceadd_iv_scan).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (SystemHotPermission.getInstance().isHotPermission(CategoryDeviceActivity.this)) {
                    PluginUnitUtils.OpenPluginUnit(CategoryDeviceActivity.this, "page/scan", AddDeviceScanHelper.REQUEST_CODE_START_SCAN);
                }
//
//                Router.getInstance().toUrlForResult(CategoryDeviceActivity.this,"page/scan",
//                        AddDeviceScanHelper.REQUEST_CODE_START_SCAN);
            }
        });
        //蓝牙
        findViewById(R.id.deviceadd_iv_bluetooth).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ALog.e(TAG, "onClick: ");
                //蓝牙方式添加设备
                if (!BreezeUtil.getInstance().checkBreezePer(CategoryDeviceActivity.this, permissions)) {
                    BreezeUtil.getInstance().addCheckBreezePer(CategoryDeviceActivity.this, permissions, 0x3333);
                } else {
                    openBle();
                }
            }
        });

        EditText etName = findViewById(R.id.et_name);
        etName.setCursorVisible(false);
        etName.setFocusable(false);
        etName.setFocusableInTouchMode(false);

        //搜索
        etName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.getInstance().toUrl(CategoryDeviceActivity.this, CODE_SEARCH);
            }
        });

        // load view
        loadView = findViewById(R.id.deviceadd_category_list_link_simple_load_view);
        loadView.setLoadViewLoacation(1);
        loadView.setTipViewLoacation(1);
        loadView.showLoading(getString(R.string.deviceadd_loading));

        //init recyclerView
        //本地发现
        llLocalDevice = findViewById(R.id.ll_local_device);
        rlLoaclDevice = findViewById(R.id.rl_local_device);
        //网络获取
        llDevice = findViewById(R.id.ll_device);
        leftRecycle = findViewById(R.id.rl_device_left);
        rightRecycle = findViewById(R.id.rl_device_right);

        initAdapter();

        // init LocalDeviceBusiness
        Intent intent = getIntent();
        if (intent != null) {
            list = (List<FoundDevice>) intent.getSerializableExtra("LocalDevice");
            //delLocalDevice(globalProductList);
            if (localDeviceBusiness != null && list != null) {
                localDeviceBusiness.setCacheDevices(list);
                delLocalDevice(list);
            }
        }
    }

    /**
     * 处理本地发现设备
     *
     * @param localDevices
     */
    private void delLocalDevice(List<FoundDevice> localDevices) {
        adapterLocal.addAllLocalDevice(localDevices);

        if (adapterLocal.getItemCount() > 0) {
            llLocalDevice.setVisibility(View.VISIBLE);
        } else {
            llLocalDevice.setVisibility(View.GONE);
        }
    }

    private void initAdapter() {
        // init adapterLocal
        adapterLocal = new LocalAdapter();
        rlLoaclDevice.setLayoutManager(new LinearLayoutManager(this));
        rlLoaclDevice.setAdapter(adapterLocal);
        adapterLocal.setOnLocalItemListener(new LocalAdapter.OnClickLocalListener() {
            @Override
            public void onLocalItem(Activity activity, Bundle bundle) {
                netType = bundle.getString("netType");
                ALog.d(TAG, "--Local netType--" + netType);
                bundle.putBoolean("isRouter", true);
                bundle.putString("routeUrl", "page/device_bind");
                if (SystemHotPermission.getInstance().isHotPermission(CategoryDeviceActivity.this)) {
                    PluginUnitUtils.OpenPluginUnit(activity, Constants.PLUGIN_ID_DEVICE_CONFIG, CategoryDeviceActivity.REQUEST_CODE_LOCAL_DEVICE_ADD, bundle);
                }
            }

            @Override
            public void onLocalBleItem(String url, Bundle bundle) {
                netType = bundle.getString("netType");
                ALog.d(TAG, "--LocalBle netType--" + netType);
                PluginUnitUtils.OpenPluginUnit(CategoryDeviceActivity.this, url, CategoryDeviceActivity.DEVICE_DETAIL_REQUEST_CODE, bundle, "device-panel-custom");
            }
        });
        localDeviceBusiness = new LocalDeviceBusiness(true, new OnDeviceFilterCompletedListener() {
            @Override
            public void onDeviceFilterCompleted(List<FoundDevice> localDevices) {
                ALog.e("---FoundDevice---", localDevices.size() + "");
                delLocalDevice(localDevices);
            }
        });

        leftRecycle.setLayoutManager(new LinearLayoutManager(this));
        rightRecycle.setLayoutManager(new GridLayoutManager(this, 3));
        rightRecycle.addItemDecoration(new CategirtDeviceSpacesItemDecoration((int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 8, getResources().getDisplayMetrics())));
        leftAdapter = new DeviceLeftAdapter();
        leftRecycle.setEnabled(false);
        leftRecycle.setAdapter(leftAdapter);


        rightAdapter = new DeviceRightAdapter();
        rightRecycle.setAdapter(rightAdapter);
        //第一次加载左边
        loadLeft(index);
        leftAdapter.setOnLeftItem(new DeviceLeftAdapter.OnLeftItem() {
            @Override
            public void onLeftItem(Category category, int position) {
                categoryKey = category.categoryKey;
                leftAdapter.setPosition(position);
                loadView.showLoading(getString(R.string.deviceadd_loading));
                // reset
                rightAdapter.cleanList();
                currentRightPage = 1;
                loadRight(categoryKey);
                rightRecycle.setOnLoadMoreListener(new RefreshRecycleViewLayout.OnLoadMoreListener() {
                    @Override
                    public void onLoadMore() {
                        loadRight(categoryKey);
                    }
                });
            }
        });

        leftRecycle.setOnLoadMoreListener(new RefreshRecycleViewLayout.OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                ALog.d("--leftRecycle--", "all：" + isLoadingLeftMore);
                if (!isLoadingLeftMore) {
                    index = 2;
                    loadLeft(index);
                }
            }
        });

        rightRecycle.setEnabled(false);
        rightAdapter.setOnRightItem(new DeviceRightAdapter.OnRightItem() {
            @Override
            public void onRightItem(Product product) {
                Bundle bundle = new Bundle();
                bundle.putString("productKey", product.productKey);
                bundle.putString("deviceName", product.productName);
                mSelectedProduct = product;
                ALog.d(TAG, "--rightAdapter netType--" + mSelectedProduct.netType);
                if (product.netType.equals("NET_CELLULAR")) { // Cellular device，蜂窝网设备，打开扫码页面
                    if (SystemHotPermission.getInstance().isHotPermission(CategoryDeviceActivity.this)) {
                        PluginUnitUtils.OpenPluginUnit(CategoryDeviceActivity.this, "page/scan", AddDeviceScanHelper.REQUEST_CODE_START_SCAN);
                    }
                } else {
                    //已有产品配网
                    bundle.putBoolean("isRouter", true);
                    bundle.putString("routeUrl", "page/device_bind");
                    if (SystemHotPermission.getInstance().isHotPermission(CategoryDeviceActivity.this)) {
                        PluginUnitUtils.OpenPluginUnit(CategoryDeviceActivity.this, Constants.PLUGIN_ID_DEVICE_CONFIG, bundle);
                    }
                }
            }
        });
    }


    //打开蓝牙
    private void openBle() {
        ThreadPool.DefaultThreadPool.getInstance().submit(new Runnable() {
            @Override
            public void run() {
                BreezeUtil.enable();
                ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
                    @Override
                    public void run() {
                        //蓝牙添加
                        Bundle bundle = new Bundle();
                        bundle.putString("productKey", "Bluetooth");
                        //Router.getInstance().toUrlForResult(CategoryDeviceActivity.this, Constants.PLUGIN_ID_DEVICE_CONFIG, CategoryDeviceActivity.REQUEST_CODE_BLE_DEVICE_ADD, bundle);
                        //打开插件
                        PluginUnitUtils.OpenPluginUnit(CategoryDeviceActivity.this, Constants.PLUGIN_ID_DEVICE_CONFIG, CategoryDeviceActivity.REQUEST_CODE_BLE_DEVICE_ADD, bundle);
                    }
                });
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        //发现局域网内设备以及蓝牙发现
        adapterLocal.clearLocalDevices();
        localDeviceBusiness.startScan(this);
        startFindingLCADevices();

    }

    @Override
    protected void onPause() {
        super.onPause();
        //关闭设备发现
        localDeviceBusiness.stopScan(this);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 0x3333) {
            if ((permissions[0].equalsIgnoreCase(Manifest.permission.ACCESS_FINE_LOCATION) && grantResults[0] == PackageManager.PERMISSION_GRANTED) && (permissions[1].equalsIgnoreCase(Manifest.permission.BLUETOOTH_ADMIN) && grantResults[1] == PackageManager.PERMISSION_GRANTED)) {
                openBle();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        ALog.d(TAG, "CategoryDeviceActivity onActivityResult" + "requestCode：" + requestCode + "resultCode：" + resultCode + "data:" + JSON.toJSONString(data));
        //只有扫码配网才会有返回值，此返回是为了拿二维码pk、dn，进行配网
        if (Activity.RESULT_OK != resultCode) {
            return;
        }
        if (REQUEST_CODE_LOCAL_DEVICE_ADD == requestCode) {
//            String productKey = data.getStringExtra("productKey");
//            String deviceName = data.getStringExtra("deviceName");
//            String token = data.getStringExtra("token");
//            String iotId = data.getStringExtra("iotId");
//
//            ILog.d(TAG, "local device add ---- onActivityResult--- pk:" + productKey + " dn:" + deviceName + "   token:" + token + "     iotId: " + iotId);
//            if (TextUtils.isEmpty(productKey) || TextUtils.isEmpty(deviceName)) {
//                return;
//            }
//            Bundle bundle = new Bundle();
//            bundle.putString(DeviceBindActivity.ARGS_KEY_PK, productKey);
//            bundle.putString(DeviceBindActivity.ARGS_KEY_DN, deviceName);
//            bundle.putString(DeviceBindActivity.ARGS_KEY_TOKEN, token);
//            bundle.putString(DeviceBindActivity.ARGS_KEY_IOT_ID, iotId);
//            if (!TextUtils.isEmpty(netType)) {
//                bundle.putString(DeviceBindActivity.ARGS_KEY_NETTYPE, netType);
//                ALog.d(TAG, "local device netType：" + netType);
//            }
//            ILog.d(FLAG, "--CategoryDeviceActivity配网成功回调--" + "pk:" + productKey + " dn:" + deviceName + "token：" + token + "iotId: " + iotId);
//            Router.getInstance().toUrl(this, DeviceBindActivity.CODE, bundle);
        } else if (REQUEST_CODE_LOCAL_DEVICE_BIND == requestCode
                || REQUEST_CODE_PRODUCT_LIST == requestCode
                || AddDeviceScanHelper.REQUEST_CODE_DEVICE_BIND == requestCode) {

//            String pk = data.getStringExtra(DeviceBindActivity.ARGS_KEY_PK);
//            String iotId = data.getStringExtra(DeviceBindActivity.ARGS_KEY_IOT_ID);
//
//            ILog.d(TAG, "local device bind ---- onActivityResult --- pk:" + pk + "   iotId:" + iotId);
//            Intent bundle = new Intent();
//            bundle.putExtra("iotId", iotId);
//            bundle.putExtra("pk", pk);
//            setResult(Activity.RESULT_OK, bundle);
//            finish();
//            return;
        } else if (requestCode == REQUEST_CODE_BLE_DEVICE_ADD) {
            boolean result = data.getBooleanExtra("isExit", false);
            if (result) {//跳到首页
                finish();
            }
        } else if (REQUEST_CODE_PRODUCT_ADD == requestCode) {
//            String productKey = data.getStringExtra("productKey");
//            String deviceName = data.getStringExtra("deviceName");
//            String token = data.getStringExtra("token");
//            String iotId = data.getStringExtra("iotId");
//
//            Bundle bundle = new Bundle();
//            bundle.putString(DeviceBindActivity.ARGS_KEY_PK, productKey);
//            bundle.putString(DeviceBindActivity.ARGS_KEY_DN, deviceName);
//            bundle.putString(DeviceBindActivity.ARGS_KEY_TOKEN, token);
//            bundle.putString(DeviceBindActivity.ARGS_KEY_IOT_ID, iotId);
//            if (mSelectedProduct != null && mSelectedProduct.productKey.equals(productKey)) {
//                bundle.putString(DeviceBindActivity.ARGS_KEY_NETTYPE, Product.getNetTypeString(mSelectedProduct.netType));
//                ALog.d(TAG, "device netType：" + Product.getNetTypeString(mSelectedProduct.netType));
//            }
//
//            Router.getInstance().toUrlForResult(this, DeviceBindActivity.CODE, REQUEST_CODE_DEVICE_BIND, bundle);
        } else if (REQUEST_CODE_DEVICE_BIND == requestCode) {
//            setResult(Activity.RESULT_OK, data);
//            finish();
        }
        //扫码后要处理onActivityResult,获取pk、dn
        new AddDeviceScanHelper().onActivityResult(this, requestCode, resultCode, data);

    }

    /**
     * 左侧列表
     */
    private void loadLeft(final int index) {
        isLoadingLeftMore = true;
        new SelectProductBusiness().getCategories(currentLeftPage, pageSize, new OnGetCategoryCompletedListener() {
            @Override
            public void onSuccess(int count, List<Category> categories) {
                rightAdapter.cleanList();
                currentRightPage = 1;
                if (index == 1) {
                    if (categories != null && categories.size() > 0) {
                        llDevice.setVisibility(View.VISIBLE);
                        categoryKey = categories.get(0).categoryKey;
                        loadRight(categoryKey);
                    } else {
                        llDevice.setVisibility(View.GONE);
                    }
                }
                isLoadingLeftMore = false;
                // show categories
                leftAdapter.addCategory(categories);

                // if first page, adapterLocal
                // so empty view will dismiss
                if (currentLeftPage == 1) {
                    loadView.hide();
                }

                // increase counters
                loadedLeftNumber += categories.size();
                currentLeftPage++;

                // load finish
                if (loadedLeftNumber >= count) {
                    leftRecycle.fullLoad();
                }
            }

            @Override
            public void onFailed(Exception e) {
                isLoadingLeftMore = false;
                loadView.hide();
                Toast.makeText(CategoryDeviceActivity.this, R.string.deviceadd_load_failed, Toast.LENGTH_LONG).show();
                ALog.e(TAG, "load categories failed", e);
                e.printStackTrace();
            }

            @Override
            public void onFailed(int code, String message, String localizedMsg) {
                isLoadingLeftMore = false;
                loadView.hide();
                Toast.makeText(CategoryDeviceActivity.this, localizedMsg, Toast.LENGTH_LONG).show();
                ALog.e(TAG, "load categories failed:" + message);
            }
        });
    }

    /**
     * 右侧列表
     *
     * @param categoryKey
     */
    private void loadRight(String categoryKey) {
        new SelectProductBusiness().getProductsByCategory(categoryKey, currentRightPage, pageSize, new OnGetProductCompletedListener() {
            @Override
            public void onSuccess(int count, List<Product> products) {
                loadView.hide();
                if (products == null || products.isEmpty()) {
                    rightRecycle.fullLoad();
                } else {
                    Log.d("sinyuk", "onSuccess: ");
                    // show categories
                    rightAdapter.addProduct(products);
                    currentRightPage++;
                    ALog.d(TAG, JSON.toJSONString(products));
                }
            }

            @Override
            public void onFailed(Exception e) {
                loadView.hide();
                Toast.makeText(CategoryDeviceActivity.this, R.string.deviceadd_load_failed, Toast.LENGTH_LONG).show();
                ALog.e(TAG, "load products failed", e);
                rightRecycle.setOnLoadMoreListener(null);
                e.printStackTrace();
            }

            @Override
            public void onFailed(int code, String message, String localizedMsg) {
                loadView.hide();
                Toast.makeText(CategoryDeviceActivity.this, localizedMsg, Toast.LENGTH_LONG).show();
                ALog.e(TAG, "load products failed:" + message);
                rightRecycle.setOnLoadMoreListener(null);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        BroadcastHelper.unRegisterBroadcastReceiver(this, broadcastReceiver);
    }

}
