package com.aliyun.iot.ilop.page.deviceadd.category;

import android.graphics.Rect;
import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * 作者：wb-zxq412979 on 2019/2/12.
 * Good luck
 */
public class CategirtDeviceSpacesItemDecoration extends RecyclerView.ItemDecoration {
    private int space;

    public CategirtDeviceSpacesItemDecoration(int space) {
        this.space = space;
    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        outRect.left = space;
        outRect.right = space;

    }
}
