package com.aliyun.iot.ilop.page.deviceadd;

/**
 * @author guikong on 18/4/9.
 */
public class Constants {
//    public final static String PLUGIN_ID_DEVICE_CONFIG = "link://plugin/a1231HjhvD1Qrihx";//日常
    public final static String PLUGIN_ID_DEVICE_CONFIG = "link://router/connectConfig";//线上/预发
}