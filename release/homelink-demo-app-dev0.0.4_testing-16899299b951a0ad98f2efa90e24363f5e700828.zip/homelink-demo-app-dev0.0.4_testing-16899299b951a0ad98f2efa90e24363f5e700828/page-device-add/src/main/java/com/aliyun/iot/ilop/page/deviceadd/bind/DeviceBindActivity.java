package com.aliyun.iot.ilop.page.deviceadd.bind;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.aliyun.alink.linksdk.tmp.device.panel.PanelDevice;
import com.aliyun.alink.linksdk.tmp.device.panel.data.PanelMethodExtraData;
import com.aliyun.alink.linksdk.tmp.device.panel.listener.IPanelCallback;
import com.aliyun.alink.linksdk.tmp.utils.TmpEnum;
import com.aliyun.alink.linksdk.tools.ALog;
import com.aliyun.iot.aep.sdk.credential.IotCredentialManager.IoTCredentialManageImpl;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;
import com.aliyun.iot.homelink.demo.commons.util.Util;
import com.aliyun.iot.ilop.component.deviceadd.DeviceBindBusiness;
import com.aliyun.iot.ilop.component.deviceadd.listener.OnBindDeviceCompletedListener;
import com.aliyun.iot.ilop.component.deviceadd.module.Device;
import com.aliyun.iot.ilop.page.device.add.R;
import com.aliyun.iot.ilop.util.BroadcastHelper;
import com.aliyun.iot.ilop.util.PluginUnitUtils;

import static com.aliyun.iot.ilop.util.Constant.FINISH_ACTION;
import static com.aliyun.iot.ilop.util.Constant.FLAG;

/**
 * @author guikong on 18/4/8.
 */
public class DeviceBindActivity extends AppCompatActivity {

    public final static String CODE = "page/device_bind";

    public final static String ARGS_KEY_PK = "productKey";
    public final static String ARGS_KEY_DN = "deviceName";
    public final static String ARGS_KEY_TOKEN = "token";
    public final static String ARGS_KEY_IOT_ID = "iotId";
    public final static String ARGS_KEY_GROUP_ID = "groupId";
    public final static String ARGS_KEY_NETTYPE = "netType";
    private static final String TAG = "DeviceBindActivity";
    public static final int REQUEST_CODE = 0x898;

    private int mBindTimesDns;
    private int mBindTimesOthers;

    private final static int BIND_RETRY_TIMES_DNS = 10;
    private final static int BIND_RETRY_TIMES_OTHERS = 3;
    private static final int DEVICE_DETAIL_REQUEST_CODE = 1004;

    String groupId;
    private DeviceBindBusiness deviceBindBusiness;
    private OnBindDeviceCompletedListener listener;
    private Device mDevice;
    private boolean bindOnGoing;
    private DeviceBindView deviceBindView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ALog.i("PerformanceTag", "{\"mod\":\"android\",\"id\":\"\",\"event\":\"pageinit\",\"params\":{\"pagename\":\"device_bind\"}}");
        ALog.d(TAG, "onCreate");
        setContentView(R.layout.deviceadd_device_bind_activity);
        if (deviceBindBusiness == null) {
            deviceBindBusiness = new DeviceBindBusiness();
        }
        if (mDevice == null) {
            mDevice = new Device();
        }
        if (listener == null) {
            listener = new OnBindDeviceCompletedListener() {
                @Override
                public void onSuccess(String iotId) {
                    ALog.d(TAG, "onSuccess");
//                    Intent intent = new Intent();
//                    intent.putExtra(ARGS_KEY_PK, mDevice.pk);
//                    intent.putExtra(ARGS_KEY_DN, mDevice.dn);
//                    intent.putExtra(ARGS_KEY_TOKEN, mDevice.token);
//                    intent.putExtra(ARGS_KEY_IOT_ID, iotId);
//                    setResult(Activity.RESULT_OK, intent);

                    Bundle bundle = new Bundle();
                    bundle.putString("iotId", iotId);
                    ALog.d(FLAG, "--DeviceBindActivity绑定成功--" + "pk:" + mDevice.pk + " dn:" + mDevice.dn + "token：" + mDevice.token + "iotId: " + iotId);
                    resetBindTimes();
                    //进入插件面板，发出广播关闭CategoryDeviceActivity
                    ALog.d(TAG, "--发出关闭activity广播--");
                    BroadcastHelper.sendBroadcast(DeviceBindActivity.this, FINISH_ACTION);
                    gotoDevicePanel("link://router/" + mDevice.pk, bundle, iotId);
                    finish();
                }

                @Override
                public void onFailed(Exception e, String msg) {
                    // 对于RuntimeException这类的错误不重试
                    if ((e != null) && (e.getClass() != null) && (e.getClass().toString().contains("java.lang.RuntimeException"))) {
                        // do not retry for RuntimeException
                    }
                    // 对于UnknownHostException这类的错误增加重试机制，重试10次
                    else if ((e != null) && (e.getClass() != null) && (e.getClass().toString().contains("java.net.UnknownHostException"))) {
                        if (mBindTimesDns < BIND_RETRY_TIMES_DNS) {
                            mBindTimesDns++;
                            ALog.d(TAG, "retry for dns error:" + mBindTimesDns);
                            retryBindDevice();
                            return;
                        }
                    }
                    // 其他错误重试3次
                    else {
                        if (mBindTimesOthers < BIND_RETRY_TIMES_OTHERS) {
                            mBindTimesOthers++;
                            ALog.d(TAG, "retry for other error:" + mBindTimesOthers);
                            retryBindDevice();
                            return;
                        }
                    }
                    ALog.d(TAG, "onFailed exception:" + e + " errorMessage:" + msg);
                    ALog.i("PerformanceTag", "{\"mod\":\"android\",\"event\":\"bindResult\",\"id\":\"\",\"params\":{\"result\":\"fail\",\"alinkid\":\"\"}}");
                    deviceBindView.setIsBind(DeviceBindActivity.this, false, R.string.deviceadd_add_fail);
                    if (TextUtils.isEmpty(msg)) {
                        Toast.makeText(DeviceBindActivity.this, R.string.deviceadd_bind_failed, Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(DeviceBindActivity.this, msg, Toast.LENGTH_LONG).show();

                    }
                    resetBindTimes();
                }

            };
        }
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        ALog.d(TAG, "onPostCreate");

        // read args
        String pk = "", dn = "", token = "", iotId = "", netType = "";
        {

            Intent intent = getIntent();
            if (null != intent) {
                pk = intent.getStringExtra("productKey");
                dn = intent.getStringExtra("deviceName");
                token = intent.getStringExtra(ARGS_KEY_TOKEN);
                iotId = intent.getStringExtra(ARGS_KEY_IOT_ID);
                netType = intent.getStringExtra("netType");
//                groupId = intent.getStringExtra(ARGS_KEY_GROUP_ID);
                groupId = IoTCredentialManageImpl.getInstance(Util.getApplication()).getIoTIdentity();
            }
            ALog.d(TAG, "--dn--" + dn + "--pk--" + pk + "--netType--" + netType + "  groupId:" + groupId);
            // should not happen
            if (TextUtils.isEmpty(pk)
                    || TextUtils.isEmpty(dn)) {
                ALog.e(TAG, "pk & dn can not be empty");
                finish();
                return;
            }
        }

        mDevice.pk = pk;
        mDevice.dn = dn;
        mDevice.token = token;
        mDevice.iotId = iotId;
        mDevice.netType = netType;
        deviceBindBusiness.setDevice(mDevice);
        deviceBindBusiness.setGroupId(groupId);
        //当netType为空 就去查询信息获取netType
        ALog.d(TAG, "--netType--" + netType);
        if (TextUtils.isEmpty(netType)) {
            deviceBindBusiness.gotoStepQuery();
        }

        deviceBindView = findViewById(R.id.device_bind_view);
        deviceBindView.setIsBind(DeviceBindActivity.this, true, R.string.deviceadd_adding);
        bindDevice();
        //重试
        deviceBindView.getBtnReUse().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deviceBindView.setIsBind(DeviceBindActivity.this, true, R.string.deviceadd_adding);
                bindDevice();
            }
        });
    }

    private void bindDevice() {
        ALog.d(TAG, "bindDevice this : " + this + " mBindTimesDns:" + mBindTimesDns
                + " mBindTimesOthers:" + mBindTimesOthers);
        cancelBind();
        deviceBindBusiness = new DeviceBindBusiness();
        deviceBindBusiness.setDevice(mDevice);
        deviceBindBusiness.setGroupId(groupId);
        deviceBindBusiness.bindDevice(listener);
        bindOnGoing = true;
    }


    private void retryBindDevice() {
        ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
            @Override
            public void run() {
                bindDevice();
            }
        }, 1000);
    }

    private void resetBindTimes() {
        mBindTimesOthers = 0;
        mBindTimesDns = 0;
        bindOnGoing = false;
    }

    private void cancelBind() {
        ALog.d(TAG, "cancelBind :" + deviceBindBusiness);
        if (deviceBindBusiness != null) {
            deviceBindBusiness.setCancelled(true);
        }
    }

    @Override
    protected void onDestroy() {
        ALog.d(TAG, "onDestroy :" + deviceBindBusiness);
        super.onDestroy();
        cancelBind();
    }

    @Override
    public void onBackPressed() {
        ALog.d(TAG, "onBackPressed :" + deviceBindBusiness);
        if (bindOnGoing) {
            // do nothing, can not go back
        } else {
            super.onBackPressed();
            cancelBind();
        }
    }


    // 打开控制面板插件
    private void gotoDevicePanel(final String url, final Bundle bundle, final String iotId) {
        //打开插件
        PluginUnitUtils.OpenPluginUnit(this, url, DEVICE_DETAIL_REQUEST_CODE, bundle, "device-bind-activity");
        //数据预加载，加快面板打开速度
        ThreadPool.DefaultThreadPool.getInstance().submit(new Runnable() {
            @Override
            public void run() {
                //本地
                PanelDevice panelDevice = new PanelDevice(iotId);
                PanelMethodExtraData data = new PanelMethodExtraData(TmpEnum.ChannelStrategy.LOCAL_CHANNEL_FIRST);
                panelDevice.cacheProperties(new IPanelCallback() {
                    @Override
                    public void onComplete(boolean b, Object o) {
                        ALog.d(TAG, "--耗时操作检查--" + "boolean：" + b + "--对象--" + JSON.toJSONString(o));
                    }
                }, data);

            }
        });
    }

}
