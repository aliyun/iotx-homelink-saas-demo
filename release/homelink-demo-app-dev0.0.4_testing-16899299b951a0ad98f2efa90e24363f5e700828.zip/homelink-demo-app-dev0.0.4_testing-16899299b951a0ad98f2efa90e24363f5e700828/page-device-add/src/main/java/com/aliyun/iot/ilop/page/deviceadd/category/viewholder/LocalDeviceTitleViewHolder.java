package com.aliyun.iot.ilop.page.deviceadd.category.viewholder;

import android.view.View;

/**
 * @author guikong on 18/4/8.
 */

public class LocalDeviceTitleViewHolder extends SettableViewHolder {

    public LocalDeviceTitleViewHolder(View view) {
        super(view);
    }

    @Override
    public void setData(Object object, int position, int count) {

    }
}
