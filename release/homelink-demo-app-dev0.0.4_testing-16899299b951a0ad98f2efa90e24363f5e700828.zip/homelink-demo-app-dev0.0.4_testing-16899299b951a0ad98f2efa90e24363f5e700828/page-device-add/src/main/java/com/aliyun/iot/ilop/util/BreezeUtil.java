package com.aliyun.iot.ilop.util;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;

public class BreezeUtil {

    private static BreezeUtil instance = null;

    public static BreezeUtil getInstance() {
        if (instance == null) {
            synchronized (BreezeUtil.class) {
                if (instance == null) {
                    instance = new BreezeUtil();
                }
            }
        }
        return instance;
    }


    public boolean checkBreezePer(Context context, String[] permissions) {
        for (int i = 0; i < permissions.length; i++) {
            if (ActivityCompat.checkSelfPermission(context, permissions[i]) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    public void addCheckBreezePer(Activity activity, String[] permissions, int requestCode) {
        ActivityCompat.requestPermissions(activity, permissions, requestCode);
    }


    /**
     * 是否支持蓝牙并且已打开
     *
     * @return
     */
    public static boolean isEnable() {
        final BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            return false;
        }
        return mBluetoothAdapter.isEnabled();
    }

    /**
     * 打开蓝牙
     *
     * @return
     */
    public static boolean enable() {
        final BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            return false;
        }
        if (!mBluetoothAdapter.isEnabled()) {
            return mBluetoothAdapter.enable();
        } else {
            return true;
        }

    }


}
