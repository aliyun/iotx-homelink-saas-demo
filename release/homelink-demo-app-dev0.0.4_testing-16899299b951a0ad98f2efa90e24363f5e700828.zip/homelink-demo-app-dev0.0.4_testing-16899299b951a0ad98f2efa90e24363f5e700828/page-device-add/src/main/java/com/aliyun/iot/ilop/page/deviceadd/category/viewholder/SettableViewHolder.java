package com.aliyun.iot.ilop.page.deviceadd.category.viewholder;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * @author guikong on 18/4/8.
 */
public abstract class SettableViewHolder extends RecyclerView.ViewHolder {

    public SettableViewHolder(View itemView) {
        super(itemView);
    }

    public abstract void setData(Object object, int position, int count);
}
