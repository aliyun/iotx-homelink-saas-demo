package com.aliyun.iot.ilop.page.deviceadd.category.viewholder;

import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.aliyun.iot.ilop.component.deviceadd.module.Category;
import com.aliyun.iot.ilop.page.device.add.R;

import java.util.Locale;

public class DeviceLeftViewHolder extends SettableViewHolder {

    TextView tvTitle;
    View action;

    public DeviceLeftViewHolder(View itemView) {
        super(itemView);
        action = itemView;
        tvTitle = itemView.findViewById(R.id.tv_title);
    }

    @Override
    public void setData(Object object, int position, int count) {
        if (!(object instanceof Category)) {
            return;
        }

        final Category category = (Category) object;
        String language = getSysLocale(itemView.getContext().getApplicationContext()).getLanguage();
        if (!TextUtils.isEmpty(category.categoryName)) {
            tvTitle.setText(category.categoryName);
        } else {
            tvTitle.setText(category.categoryKey);
        }

        action.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }

    //7.0以上获取方式需要特殊处理一下
    public Locale getSysLocale(Context context) {
        if (Build.VERSION.SDK_INT < 24) {
            return context.getResources().getConfiguration().locale;
        } else {
            return context.getResources().getConfiguration().getLocales().get(0);
        }
    }
}
