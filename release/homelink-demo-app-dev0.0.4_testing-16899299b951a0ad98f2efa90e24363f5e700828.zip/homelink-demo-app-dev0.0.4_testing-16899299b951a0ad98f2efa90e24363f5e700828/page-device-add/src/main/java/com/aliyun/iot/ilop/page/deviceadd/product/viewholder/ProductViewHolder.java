package com.aliyun.iot.ilop.page.deviceadd.product.viewholder;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.aliyun.iot.ilop.component.deviceadd.module.Product;
import com.aliyun.iot.ilop.page.device.add.R;
import com.aliyun.iot.ilop.page.deviceadd.Constants;
import com.aliyun.iot.ilop.page.deviceadd.product.ProductListActivity;
import com.aliyun.iot.ilop.util.PluginUnitUtils;

/**
 * @author guikong on 18/4/8.
 */
public class ProductViewHolder extends RecyclerView.ViewHolder {

    private View action, divideLine;
    private TextView title;

    public ProductViewHolder(View view) {
        super(view);

        action = view;
        title = view.findViewById(R.id.deviceadd_product_list_product_title_tv);
        divideLine = view.findViewById(R.id.deviceadd_product_list_divide_line);
    }

    public void setProduct(final Product product, int position, int count) {
        title.setText(product.productName);

        final String pk = product.productKey;
        action.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("productKey", pk);
                bundle.putString("deviceName", product.productName);
                Activity activity = (Activity) v.getContext();
                //Router.getInstance().toUrlForResult(activity, Constants.PLUGIN_ID_DEVICE_CONFIG, ProductListActivity.REQUEST_CODE_PRODUCT_ADD, bundle);
                //打开插件
                PluginUnitUtils.OpenPluginUnit(activity, Constants.PLUGIN_ID_DEVICE_CONFIG, ProductListActivity.REQUEST_CODE_PRODUCT_ADD, bundle);
            }
        });

        if (position == count - 1) {
            divideLine.setVisibility(View.GONE);
        }
    }
}
