package com.aliyun.iot.ilop.page.deviceadd.category.module;

/**
 * Created by ZhuBingYang on 2019/4/3.
 * 从 /uc/listBindingByAccount 获取的设备列表
 */
public class AccountDevice {

    /**
     * gmtModified : 1554255760000
     * categoryImage : http://iotx-paas-admin.oss-cn-shanghai.aliyuncs.com/publish/image/1526474600174.png
     * netType : NET_WIFI
     * productKey : a1bIKrOzWeM
     * nodeType : DEVICE
     * isEdgeGateway : false
     * deviceName : iFX6PTs725YIPoaqfWO8
     * identityAlias : 15757126393
     * productName : 全屋测试灯全屋
     * iotId : iFX6PTs725YIPoaqfWO8000100
     * categoryUrl : http://iotx-paas-admin.oss-cn-shanghai.aliyuncs.com/publish/image/1526474600174.png
     * owned : 1
     * identityId : 5060opaba9f8caf09ff2614f45c68bfacee60674
     * thingType : DEVICE
     * status : 0
     */

    private long gmtModified;
    private String categoryImage;
    private String netType;
    private String productKey;
    private String nodeType;
    private boolean isEdgeGateway;
    private String deviceName;
    private String identityAlias;
    private String productName;
    private String iotId;
    private String productImage;
    private int owned;
    private String identityId;
    private String thingType;
    private int status;

    public long getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(long gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getCategoryImage() {
        return categoryImage;
    }

    public void setCategoryImage(String categoryImage) {
        this.categoryImage = categoryImage;
    }

    public String getNetType() {
        return netType;
    }

    public void setNetType(String netType) {
        this.netType = netType;
    }

    public String getProductKey() {
        return productKey;
    }

    public void setProductKey(String productKey) {
        this.productKey = productKey;
    }

    public String getNodeType() {
        return nodeType;
    }

    public void setNodeType(String nodeType) {
        this.nodeType = nodeType;
    }

    public boolean isIsEdgeGateway() {
        return isEdgeGateway;
    }

    public void setIsEdgeGateway(boolean isEdgeGateway) {
        this.isEdgeGateway = isEdgeGateway;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getIdentityAlias() {
        return identityAlias;
    }

    public void setIdentityAlias(String identityAlias) {
        this.identityAlias = identityAlias;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getIotId() {
        return iotId;
    }

    public void setIotId(String iotId) {
        this.iotId = iotId;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public int getOwned() {
        return owned;
    }

    public void setOwned(int owned) {
        this.owned = owned;
    }

    public String getIdentityId() {
        return identityId;
    }

    public void setIdentityId(String identityId) {
        this.identityId = identityId;
    }

    public String getThingType() {
        return thingType;
    }

    public void setThingType(String thingType) {
        this.thingType = thingType;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "AccountDevice{" +
                "gmtModified=" + gmtModified +
                ", categoryImage='" + categoryImage + '\'' +
                ", netType='" + netType + '\'' +
                ", productKey='" + productKey + '\'' +
                ", nodeType='" + nodeType + '\'' +
                ", isEdgeGateway=" + isEdgeGateway +
                ", deviceName='" + deviceName + '\'' +
                ", identityAlias='" + identityAlias + '\'' +
                ", productName='" + productName + '\'' +
                ", iotId='" + iotId + '\'' +
                ", categoryUrl='" + productImage + '\'' +
                ", owned=" + owned +
                ", identityId='" + identityId + '\'' +
                ", thingType='" + thingType + '\'' +
                ", status=" + status +
                '}';
    }
}
