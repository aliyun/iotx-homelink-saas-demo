package com.aliyun.iot.ilop.page.deviceadd.search;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.aliyun.alink.linksdk.tools.ALog;
import com.aliyun.iot.aep.sdk.threadpool.ThreadPool;
import com.aliyun.iot.ilop.component.deviceadd.module.Product;
import com.aliyun.iot.ilop.page.device.add.R;
import com.aliyun.iot.ilop.page.deviceadd.Constants;
import com.aliyun.iot.ilop.page.deviceadd.external.scan.AddDeviceScanHelper;
import com.aliyun.iot.ilop.util.BroadcastHelper;
import com.aliyun.iot.ilop.util.Constant;
import com.aliyun.iot.ilop.util.PluginUnitUtils;
import com.aliyun.iot.ilop.util.SystemHotPermission;
import com.aliyun.iot.link.ui.component.simpleLoadview.LinkSimpleLoadView;

import java.util.ArrayList;
import java.util.List;

import static com.aliyun.iot.ilop.page.deviceadd.search.GlobalBusiness.globalProductList;

public class SearchActivity extends AppCompatActivity implements GlobalCallBack, SearchCallBack {

    public final static String CODE_SEARCH = "page/categorySearch";
    private static String TAG = "SearchActivity";

    private GlobalBusiness business;
    private SearchAdapter adapter;
    private String keyWord;
    private LinkSimpleLoadView loadView;
    private Product mSelectedProduct;

    private BroadcastReceiver broadcastReceiver;

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.deviceadd_device_seatch_activity);
        //绑定成功后，关闭当前SearchActivity
        broadcastReceiver = BroadcastHelper.registerBroadcastReceiver(this, new String[]{Constant.FINISH_ACTION}, new BroadcastHelper.OnReceiveBroadcast() {
            @Override
            public void onReceive(Context context, Intent intent) {
                ALog.d(TAG, "--接收广播关闭当前SearchActivity--");
                SearchActivity.this.finish();
            }
        });

        business = new GlobalBusiness(this);
        //init recyclerView
        adapter = new SearchAdapter();
        initData();
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        TextView title = findViewById(R.id.deviceadd_top_bar_title_tv);
        title.setText(R.string.deviceadd_device_add);
        View backView = findViewById(R.id.deviceadd_top_bar_back_fl);
        backView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        EditText etName = findViewById(R.id.et_name);
        etName.setFocusable(true);
        etName.setCursorVisible(true);
        etName.setFocusableInTouchMode(true);
        etName.requestFocus();
        loadView = findViewById(R.id.load_view);
        loadView.setLoadViewLoacation(1);
        loadView.setTipViewLoacation(1);
        //edit listener
        etName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                ALog.d(TAG, "beforeTextChanged：" + s.toString());
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ALog.d(TAG, "onTextChanged：" + s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
                ALog.d(TAG, "afterTextChanged：" + s.toString());
                keyWord = s.toString();
                business.searchRequset(keyWord, SearchActivity.this);
            }
        });

        RecyclerView rlSearch = findViewById(R.id.rl_search);
        rlSearch.setLayoutManager(new LinearLayoutManager(this));
        rlSearch.setAdapter(adapter);
        adapter.setOnRightItem(new SearchAdapter.OnRightItem() {
            @Override
            public void onRightItem(Product product) {
                mSelectedProduct = product;
                ALog.d(TAG, "--search netType--" + mSelectedProduct.netType);
                Bundle bundle = new Bundle();
                bundle.putString("productKey", product.productKey);
                bundle.putString("deviceName", product.productName);
                //Cellular device，蜂窝网设备，打开扫码页面
                if (product.netType.equals("NET_CELLULAR")) {
                    //扫码后要处理onActivityResult,获取pk、dn
                    if (SystemHotPermission.getInstance().isHotPermission(SearchActivity.this)) {
                        PluginUnitUtils.OpenPluginUnit(SearchActivity.this, "page/scan", AddDeviceScanHelper.REQUEST_CODE_START_SCAN);
                    }
                } else {
                    //已有产品配网
                    bundle.putBoolean("isRouter", true);
                    bundle.putString("routeUrl", "page/device_bind");
                    if (SystemHotPermission.getInstance().isHotPermission(SearchActivity.this)) {
                        PluginUnitUtils.OpenPluginUnit(SearchActivity.this, Constants.PLUGIN_ID_DEVICE_CONFIG, bundle);
                    }
                }
            }
        });
    }

    private void initData() {
        if (globalProductList.size() == 0) {
            business.allProductRequest(this);
        } else {
            addAllProduct(globalProductList);
        }
    }


    @Override
    public void onSuccess(final List<Object> list) {
        ThreadPool.MainThreadHandler.getInstance().post(new Runnable() {
            @Override
            public void run() {
                addAllProduct(list);
            }
        });
    }

    /**
     * 处理list
     *
     * @param list
     */
    private void addAllProduct(List<Object> list) {
        if (list != null && list.size() > 0) {
            List<Product> productList = new ArrayList<>();
            for (int i = 0; i < list.size(); i++) {
                if (list.get(i) instanceof Product) {
                    Product product = (Product) list.get(i);
                    productList.add(product);
                }
            }
            adapter.addProduct(productList);
            business.getAllProduct(productList);
        }
    }

    @Override
    public void onFailed(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onSearchSuccess(List<Product> productList) {
        loadView.hide();
        adapter.addProduct(productList);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        BroadcastHelper.unRegisterBroadcastReceiver(this, broadcastReceiver);
    }

    @Override
    public void onSearchFailed() {
        loadView.hide();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (Activity.RESULT_OK != resultCode) {
            return;
        }
        new AddDeviceScanHelper().onActivityResult(this, requestCode, resultCode, data);
//        if (CategoryDeviceActivity.REQUEST_CODE_PRODUCT_ADD == requestCode) {
//            String productKey = data.getStringExtra("productKey");
//            String deviceName = data.getStringExtra("deviceName");
//            String token = data.getStringExtra("token");
//            String iotId = data.getStringExtra("iotId");
//
//            Bundle bundle = new Bundle();
//            bundle.putString(DeviceBindActivity.ARGS_KEY_PK, productKey);
//            bundle.putString(DeviceBindActivity.ARGS_KEY_DN, deviceName);
//            bundle.putString(DeviceBindActivity.ARGS_KEY_TOKEN, token);
//            bundle.putString(DeviceBindActivity.ARGS_KEY_IOT_ID, iotId);
//            if (mSelectedProduct != null && mSelectedProduct.productKey.equals(productKey)) {
//                bundle.putString(DeviceBindActivity.ARGS_KEY_NETTYPE, Product.getNetTypeString(mSelectedProduct.netType));
//            }
//
//            Router.getInstance().toUrlForResult(this, DeviceBindActivity.CODE, REQUEST_CODE_DEVICE_BIND, bundle);
//        } else if (REQUEST_CODE_DEVICE_BIND == requestCode) {
//            setResult(Activity.RESULT_OK, data);
//            finish();
//        }
    }
}
