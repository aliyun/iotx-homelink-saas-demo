package com.aliyun.iot.ilop.component.deviceadd.module;

import android.text.TextUtils;

import com.aliyun.alink.linksdk.tools.ALog;

import java.io.Serializable;

public class FoundDevice implements Cloneable, Serializable {

    public String id;
    public String productKey;
    public String productName;
    public String deviceName;
    public String type;
    public int netType;

    @Override
    public FoundDevice clone() {
        try {
            return (FoundDevice) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return this;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (o == null) return false;
        if (this == o) return true;

        if (!(o instanceof FoundDevice)) return false;
        FoundDevice that = (FoundDevice) o;
        boolean ss = TextUtils.equals(productKey, that.productKey) &&
                TextUtils.equals(deviceName, that.deviceName) &&
                TextUtils.equals(productName, that.productName) &&
                TextUtils.equals(type, that.type) &&
                TextUtils.equals(id, that.id);
        ALog.d("LocalAdapter", "ss：" + ss);
        return ss;

    }

    @Override
    public String toString() {
        return "FoundDevice{" +
                "id='" + id + '\'' +
                ", productKey='" + productKey + '\'' +
                ", productName='" + productName + '\'' +
                ", deviceName='" + deviceName + '\'' +
                ", type='" + type + '\'' +
                ", netType=" + netType +
                '}';
    }
}
