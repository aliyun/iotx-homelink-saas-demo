package com.aliyun.iot.ilop.component.deviceadd.listener;

/**
 * @author guikong on 18/4/12.
 */
public interface OnBindDeviceCompletedListener {
    void onSuccess(String iotId);

    void onFailed(Exception e, String localizedMsg);
}
