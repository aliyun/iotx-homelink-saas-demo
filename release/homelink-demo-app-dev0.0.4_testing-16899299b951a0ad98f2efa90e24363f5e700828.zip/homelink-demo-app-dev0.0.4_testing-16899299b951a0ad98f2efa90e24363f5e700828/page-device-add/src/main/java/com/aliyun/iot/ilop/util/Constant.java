package com.aliyun.iot.ilop.util;

public class Constant {
    public static final String FLAG = "flag_bind";

    public static final String REFRESH_ACTION = "com.aliyun.iot.ilop.page.device.refresh";
    public static final String FINISH_ACTION = "com.aliyun.iot.ilop.page.category.finish";
}
