package com.aliyun.iot.ilop.util;

import android.app.Activity;
import android.os.Bundle;

import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.aep.sdk.log.ALog;

public class PluginUnitUtils {

    /**
     * 打开插件
     *
     * @param context
     * @param url
     * @param bundle
     */
    public static void OpenPluginUnit(Activity context, String url, Bundle bundle) {
        Router.getInstance().toUrl(context, url, bundle);
        ALog.i("PerformanceTag", "{\"mod\":\"android\",\"event\":\"pageopen\", \"id\":\"\", \"params\":{\"pagename\":\"" + url + "\"}}");
    }

    public static void OpenPluginUnit(Activity context, String url, Integer code, Bundle bundle) {
        Router.getInstance().toUrlForResult(context, url, code, bundle);
        ALog.i("PerformanceTag", "{\"mod\":\"android\",\"event\":\"pageopen\", \"id\":\"\", \"params\":{\"pagename\":\"" + url + "\"}}");
    }

    public static void OpenPluginUnit(Activity context, String url, Integer code) {
        Router.getInstance().toUrlForResult(context, url, code);
        ALog.i("PerformanceTag", "{\"mod\":\"android\",\"event\":\"pageopen\", \"id\":\"\", \"params\":{\"pagename\":\"" + url + "\"}}");
    }

    public static void OpenPluginUnit(Activity context, String url, Integer code, Bundle bundle, String pagename) {

        Router.getInstance().toUrlForResult(context, url, code, bundle);
        ALog.i("PerformanceTag", "{\"mod\":\"android\",\"event\":\"pageopen\", \"id\":\"\", params:{\"pagename\":\"" + pagename + "\"}}");
    }

}
