package com.aliyun.iot.ilop.page.deviceadd.category.adapter;

import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.aliyun.iot.ilop.component.deviceadd.module.Category;
import com.aliyun.iot.ilop.page.device.add.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DeviceLeftAdapter extends RecyclerView.Adapter<DeviceLeftAdapter.DeviceLeftViewHolder> {

    List<Category> data;
    private int pos;
    Context context;

    public DeviceLeftAdapter() {
        data = new ArrayList<>();
    }

    public void addCategory(List<Category> categories) {
        data.addAll(categories);
        notifyDataSetChanged();
    }

    @Override
    public DeviceLeftViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (null == parent) {
            return null;
        }
        context = parent.getContext();
        View view = LayoutInflater.from(context).inflate(R.layout.deviceadd_device_item_left, parent, false);
        return new DeviceLeftViewHolder(view);
    }

    @Override
    public void onBindViewHolder(DeviceLeftViewHolder holder, final int position) {
        final Category category = data.get(position);
        holder.setData(category, position);
        if (pos == position) {
            holder.tvTitle.setBackgroundColor(Color.WHITE);
            holder.tvTitle.setTextColor(Color.parseColor("#1FC88b"));
        } else {
            holder.tvTitle.setBackgroundColor(Color.parseColor("#f6f6f6"));
            holder.tvTitle.setTextColor(Color.parseColor("#999999"));
        }
    }

    public void setPosition(int position) {
        this.pos = position;
        notifyDataSetChanged();
    }


    @Override
    public int getItemCount() {
        return data.size();
    }

    class DeviceLeftViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle;
        View action;

        public DeviceLeftViewHolder(View itemView) {
            super(itemView);
            action = itemView;
            tvTitle = itemView.findViewById(R.id.tv_title);
        }

        public void setData(final Category category, final int position) {
            String language = getSysLocale(itemView.getContext().getApplicationContext()).getLanguage();
            if (!TextUtils.isEmpty(category.categoryName)) {
                tvTitle.setText(category.categoryName);
            } else {
                tvTitle.setText(category.categoryKey);
            }
            action.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onLeftItem.onLeftItem(category, position);
                }
            });
        }

        //7.0以上获取方式需要特殊处理一下
        public Locale getSysLocale(Context context) {
            if (Build.VERSION.SDK_INT < 24) {
                return context.getResources().getConfiguration().locale;
            } else {
                return context.getResources().getConfiguration().getLocales().get(0);
            }
        }
    }

    private OnLeftItem onLeftItem;

    public void setOnLeftItem(OnLeftItem onLeftItem) {
        this.onLeftItem = onLeftItem;
    }

    public interface OnLeftItem {
        void onLeftItem(Category category, int position);
    }
}
