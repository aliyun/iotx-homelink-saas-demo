package com.aliyun.iot.ilop.component.deviceadd.module;

/**
 * @author guikong on 18/4/12.
 */
public class Device {
    public String pk;
    public String dn;
    public String token;
    public String iotId;
    public String netType;
}
