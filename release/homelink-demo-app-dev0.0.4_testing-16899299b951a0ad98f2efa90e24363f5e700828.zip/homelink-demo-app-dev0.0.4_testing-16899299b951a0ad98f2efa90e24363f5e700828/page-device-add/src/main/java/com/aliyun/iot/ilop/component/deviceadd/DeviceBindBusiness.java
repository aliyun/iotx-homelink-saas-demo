package com.aliyun.iot.ilop.component.deviceadd;

import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.aliyun.alink.business.devicecenter.api.discovery.IOnDeviceTokenGetListener;
import com.aliyun.alink.business.devicecenter.api.discovery.LocalDeviceMgr;
import com.aliyun.alink.linksdk.tools.ALog;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClient;
import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientFactory;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTCallback;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTResponse;
import com.aliyun.iot.aep.sdk.apiclient.emuns.Scheme;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequestBuilder;
import com.aliyun.iot.aep.sdk.framework.AApplication;
import com.aliyun.iot.ilop.component.deviceadd.listener.OnBindDeviceCompletedListener;
import com.aliyun.iot.ilop.component.deviceadd.module.Device;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 设备绑定业务的封装
 * <br/>
 * 支持以下设备类型绑定: <br/>
 * 1. WiFi/以太网 类型
 * 2. GPRS 类型
 * 3. Zigbee 子设备入网（无需绑定）
 * 4. BLE 设备入网
 *
 * @author guikong on 18/4/8.
 */
public class DeviceBindBusiness {

    private static final String TAG = "DeviceBindBusiness";

    private static final int MESSAGE_STEP_1_QUERY = 1;
    private static final int MESSAGE_STEP_2_BIND = 2;
    private static final int MESSAGE_STEP_3_FINISH = 3;

    private Device mDevice;

    private String groupId;

    private boolean doBind = false;

    private String errorMessage;
    private Exception exception;

    private boolean mCancelled;
    private OnBindDeviceCompletedListener onBindDeviceCompletedListener;
    private android.os.Handler mHandler = new android.os.Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case MESSAGE_STEP_1_QUERY:
                    if (isCancelled()) {
                        return;
                    }
                    queryProductInfo();
                    break;
                case MESSAGE_STEP_2_BIND:
                    if (isCancelled()) {
                        return;
                    }
                    if (doBind) {
                        bindDeviceWithType();
                    }
                    break;
                case MESSAGE_STEP_3_FINISH:
                    if (isCancelled()) {
                        return;
                    }
                    onFinish();
                    break;
                default:
                    break;

            }
        }
    };

    public DeviceBindBusiness() {
    }

    public boolean isCancelled() {
        return mCancelled;
    }

    public void setCancelled(boolean mCancelled) {
        this.mCancelled = mCancelled;
    }

    public void setDevice(Device device) {
        this.mDevice = device;
    }

    public DeviceBindBusiness setGroupId(String groupId) {
        this.groupId = groupId;
        return this;
    }


    public void gotoStepQuery() {
        ALog.d(TAG, "gotoStepQuery" + this);
        if (mHandler != null) {
            mHandler.sendEmptyMessage(MESSAGE_STEP_1_QUERY);
        }
    }

    private void gotoStepBind() {
        ALog.d(TAG, "gotoStepBind" + this);
        if (mHandler != null) {
            mHandler.sendEmptyMessage(MESSAGE_STEP_2_BIND);
        }
    }

    private void gotoStepFinish() {
        ALog.d(TAG, "gotoStepFinish" + this);
        if (mHandler != null) {
            mHandler.sendEmptyMessage(MESSAGE_STEP_3_FINISH);
        }
    }

    private void resetStatus() {
        ALog.d(TAG, "resetStatus" + this);
        doBind = false;
        exception = null;
        errorMessage = "";

    }

    /**
     * 查询产品信息
     */
    private void queryProductInfo() {
        ALog.d(TAG, "queryProductInfo" + this);
        if (null == mDevice) {
            throw new IllegalArgumentException("device can not be null");
        }
        if (!TextUtils.isEmpty(mDevice.netType)) {
            ALog.d(TAG, "queryProductInfo already got netType:" + mDevice.netType);
            gotoStepBind();
            return;
        }

        //noinspection unused
        IoTRequest homeLinkRequest = new IoTRequestBuilder()
                .setPath("/home/app/product/query")
                .setScheme(Scheme.HTTPS)
                .setApiVersion("1.0.0")
                .setAuthType("iotAuth")
                .addParam("productKey", mDevice.pk)
                .addParam("pageNo", 1)
                .addParam("pageSize", 1)
                .build();

        IoTRequest iLopRequest = new IoTRequestBuilder()
                .setScheme(Scheme.HTTPS)
                .setPath("/thing/detailInfo/queryProductInfoByProductKey")
                .setApiVersion("1.1.1")
                .addParam("productKey", mDevice.pk)
                .setAuthType("iotAuth")
                .build();

        IoTAPIClient client = new IoTAPIClientFactory().getClient();

        client.send(iLopRequest, new IoTCallback() {
            @Override
            public void onFailure(IoTRequest ioTRequest, final Exception e) {
                onFail(e);
            }

            @Override
            public void onResponse(final IoTRequest ioTRequest, final IoTResponse ioTResponse) {
                if (200 != ioTResponse.getCode() || !(ioTResponse.getData() instanceof JSONObject)) {
                    onFail(ioTResponse.getCode(), ioTResponse.getMessage(), ioTResponse.getLocalizedMsg());
                    return;
                }
                String netType = null;
                JSONObject data = (JSONObject) ioTResponse.getData();
                if (data.has("data")) {
                    JSONArray array = data.optJSONArray("data");
                    if (array == null || array.length() == 0 || array.isNull(0)) {
                        onFail(ioTResponse.getCode(), ioTResponse.getMessage(), ioTResponse.getLocalizedMsg());
                        return;
                    }
                    try {
                        if (array.getJSONObject(0).has("netType"))
                            netType = array.getJSONObject(0).optString("netType");
                    } catch (JSONException | NullPointerException e) {
                        ALog.e(TAG, "queryProductInfo()", e);
                    }
                } else {
                    if (data.has("netType"))
                        netType = data.optString("netType");
                }
                if (null != netType) {
                    mDevice.netType = netType;
                    ALog.d(TAG, "net:" + mDevice.netType);
                    gotoStepBind();

                } else {
                    onFailure(ioTRequest, new IllegalArgumentException("netType required can't be null"));
                }
            }
        });
    }

    private void bindDeviceWithType() {
        ALog.d(TAG, "bindDeviceWithType: " + mDevice.netType);

        final String netType = mDevice.netType;
        // WiFi and ethernet is same
        if ("NET_WIFI".equalsIgnoreCase(netType)
                || "NET_ETHERNET".equalsIgnoreCase(netType)) {
            bindWithWiFi();

        } else if ("NET_CELLULAR".equalsIgnoreCase(netType)
                || "NET_ZIGBEE".equalsIgnoreCase(netType)
                || "NET_OTHER".equalsIgnoreCase(netType)
                || "NET_BT".equalsIgnoreCase(netType)) {

            bindDeviceInternal();
        } else {
            onFail(new IllegalArgumentException("unsupported net type"));
        }
    }

    //绑定设备
    private void bindDeviceInternal() {
        ALog.d(TAG, "bindDeviceInternal" + this);
        if (isCancelled()) {
            return;
        }

        ALog.d(TAG, "groupId:" + groupId);

        String path = getPathByDevice(mDevice);
        if (TextUtils.isEmpty(path)) {
            onBindDeviceCompletedListener.onFailed(new UnsupportedOperationException("ble bind is not support at present@" + mDevice.toString()), "");
            return;
        }
        Map<String, Object> maps = new HashMap<>();
        maps.put("productKey", mDevice.pk);
        maps.put("deviceName", mDevice.dn);
        if (!TextUtils.isEmpty(mDevice.token)) {
            maps.put("token", mDevice.token);
        }

        if (!TextUtils.isEmpty(groupId)) {
            List<String> groupIds = new ArrayList<>(1);
            groupIds.add(groupId);
            maps.put("groupIds", groupIds);
        }


        IoTRequestBuilder builder = new IoTRequestBuilder()
                .setPath(path)
                .setApiVersion("1.0.2")
                .setAuthType("iotAuth")
                .setParams(maps);

        IoTRequest request = builder.build();

        IoTAPIClient ioTAPIClient = new IoTAPIClientFactory().getClient();
        ALog.i("PerformanceTag", "{\"mod\":\"android\",\"id\":\"\",\"event\":\"bind\",\"params\":{\"method\":\"\",\"pagename\":\"device_bind\"}}");
        ioTAPIClient.send(request, new IoTCallback() {
            @Override
            public void onFailure(IoTRequest ioTRequest, final Exception e) {
                ALog.d(TAG, "onFailure");

                onFail(e);

            }

            @Override
            public void onResponse(IoTRequest ioTRequest, final IoTResponse ioTResponse) {
                ALog.d(TAG, "onResponse bindWithWiFi ok" + DeviceBindBusiness.this);
                ALog.i("PerformanceTag", "{\"mod\":\"android\",\"event\":\"bindResult\",\"id\":\"\",\"params\":{\"result\":\"success\",\"alinkid\":\"\"}}");
                if (200 != ioTResponse.getCode() || !(ioTResponse.getData() instanceof String)) {

                    onFail(ioTResponse.getCode(), ioTResponse.getMessage(), ioTResponse.getLocalizedMsg());

                    return;
                }


                final String iotId = (String) ioTResponse.getData();
                onSuccess(iotId);
            }
        });

    }


    public void bindDevice(final OnBindDeviceCompletedListener listener) {
        setOnBindDeviceCompletedListener(listener);
        ALog.d(TAG, "bindDevice doBind:" + doBind);
        if (doBind) {
            listener.onFailed(new IllegalStateException("bindStatus = BIND_STATUS_DOING"), "");
            return;
        }
        ALog.d(TAG, "bindDevice go" + this);
        doBind = true;
        gotoStepQuery();
        //gotoStepTimeoutLater();
    }


    private void bindWithWiFi() {
        ALog.d(TAG, "bindWithWiFi");
        ALog.i("PerformanceTag", "{\"mod\":\"android\",\"id\":\"\",\"event\":\"req\",\"params\":{\"method\":\"queryDeviceToken\",\"pagename\":\"device_bind\"}}");
        LocalDeviceMgr.getInstance().getDeviceToken(
                AApplication.getInstance().getApplicationContext(),
                mDevice.pk, mDevice.dn, 60 * 1000, 2000, new IOnDeviceTokenGetListener() {
                    @Override
                    public void onSuccess(String token) {

                        ALog.d(TAG, "getDeviceToken onSuccess token = " + token);
                        ALog.i("PerformanceTag", "{\"mod\":\"android\",\"id\":\"\",\"event\":\"res\",\"params\":{\"method\":\"queryDeviceToken\",\"pagename\":\"device_bind\"}}");
                        if (TextUtils.isEmpty(token)) {
                            DeviceBindBusiness.this.onFail(0, "", "device token is empty");
                            return;
                        }
                        mDevice.token = token;
                        bindDeviceInternal();
                    }

                    @Override
                    public void onFail(final String s) {
                        ALog.e(TAG, "getDeviceToken onFail s = " + s);
                        ALog.i("PerformanceTag", "{\"mod\":\"android\",\"id\":\"\",\"event\":\"res\",\"params\":{\"method\":\"queryDeviceToken\",\"pagename\":\"device_bind\"}}");
                        DeviceBindBusiness.this.onFail(new RuntimeException(s));

                    }
                });
    }


    private String getPathByDevice(Device device) {
        String netType = device.netType.toUpperCase();
        switch (netType) {
            case "NET_WIFI":
            case "NET_ETHERNET":
                return "/awss/enrollee/user/bind";
            case "NET_CELLULAR":
                return "/awss/gprs/user/bind";
            case "NET_ZIGBEE":
            case "NET_OTHER":
                return "/awss/subdevice/bind";
            case "NET_BT":
            default:
                return null;

        }


    }

    private void onFail(final Exception e) {
        ALog.e(TAG, "onFail " + this, e);
        exception = e;
        gotoStepFinish();

    }

    private void onFail(final int code, final String message, final String localizedMsg) {
        ALog.e(TAG, "onFail " + this + code + message + localizedMsg);
        errorMessage = localizedMsg;
        gotoStepFinish();

    }


    private void onSuccess(final String iotId) {
        ALog.d(TAG, "onSuccess to go" + this);
        mDevice.iotId = iotId;

        gotoStepFinish();

    }

    private void onFinish() {
        ALog.d(TAG, "onFinish to go: this :" + this);
        ALog.d(TAG, "onFinish to go: mDevice:" + JSON.toJSONString(mDevice));
        ALog.d(TAG, "onFinish to go: onBindDeviceCompletedListener :" + onBindDeviceCompletedListener);
        ALog.d(TAG, "onFinish to go: exception:" + exception);
        ALog.d(TAG, "onFinish to go: errormsg:" + errorMessage);


        if (onBindDeviceCompletedListener != null) {
            if (!TextUtils.isEmpty(mDevice.iotId)) {
                onBindDeviceCompletedListener.onSuccess(mDevice.iotId);
            } else {
                onBindDeviceCompletedListener.onFailed(exception, errorMessage);
            }
        }
        bindFinish();
    }

    private void bindFinish() {
        ALog.d(TAG, "bindFinish" + this);

        resetStatus();
        //cancelStepTimeout();
        setOnBindDeviceCompletedListener(null);
    }

    public void setOnBindDeviceCompletedListener(OnBindDeviceCompletedListener listener) {
        ALog.d(TAG, "setOnBindDeviceCompletedListener : " + listener);
        this.onBindDeviceCompletedListener = listener;
    }
}
