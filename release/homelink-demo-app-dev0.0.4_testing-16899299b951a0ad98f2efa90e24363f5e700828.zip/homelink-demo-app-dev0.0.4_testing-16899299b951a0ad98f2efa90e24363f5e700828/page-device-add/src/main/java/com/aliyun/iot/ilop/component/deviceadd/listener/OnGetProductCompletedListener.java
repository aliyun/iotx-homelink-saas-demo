package com.aliyun.iot.ilop.component.deviceadd.listener;

import com.aliyun.iot.ilop.component.deviceadd.module.Product;

import java.util.List;

/**
 * @author guikong on 18/4/8.
 */
public interface OnGetProductCompletedListener {
    void onSuccess(int count, List<Product> categories);

    void onFailed(Exception e);

    void onFailed(int code, String message, String localizedMsg);
}
