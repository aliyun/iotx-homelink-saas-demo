package com.aliyun.iot.ilop.page.deviceadd.search;

import com.aliyun.iot.ilop.component.deviceadd.module.Product;

import java.util.List;

public interface SearchCallBack {

    void onSearchSuccess(List<Product> productList);

    void onSearchFailed();
}