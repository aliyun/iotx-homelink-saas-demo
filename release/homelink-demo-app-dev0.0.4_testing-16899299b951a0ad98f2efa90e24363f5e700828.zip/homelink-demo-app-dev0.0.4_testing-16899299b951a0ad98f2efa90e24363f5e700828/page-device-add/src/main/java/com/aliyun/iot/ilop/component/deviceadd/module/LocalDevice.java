package com.aliyun.iot.ilop.component.deviceadd.module;

import android.text.TextUtils;

import java.io.Serializable;

/**
 * @author guikong on 18/4/8.
 */

public class LocalDevice extends FoundDevice implements Serializable {
    public static final String NEED_CONNECT = "need_connect";
    public static final String NEED_BIND = "need_bind";

    public String deviceStatus;
    public String token;
    public String addDeviceFrom;

    // Optional value for LCA

    public String modelType;
    public String modelName;
    public String gatewayIotId;
    public String gatewayName;

    public LocalDevice toLCA(String modelName, String modelType, String gatewayIotId, String gatewayName) {
        this.modelName = modelName;
        this.modelType = modelType;
        this.gatewayIotId = gatewayIotId;
        this.gatewayName = gatewayName;
        return this;
    }

    public boolean isSame(FoundDevice o) {
        if (o == null) return false;
        if (!TextUtils.equals(productKey, o.productKey)) return false;
        if (!TextUtils.isEmpty(deviceName) &&
                TextUtils.equals(deviceName, o.deviceName)) return true;
        if (!TextUtils.isEmpty(id) &&
                TextUtils.equals(id, o.id)) return true;
        return false;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!super.equals(o)) return false;

        if (!(o instanceof LocalDevice)) return false;
        LocalDevice that = (LocalDevice) o;
        return TextUtils.equals(deviceStatus, that.deviceStatus) &&
                TextUtils.equals(token, that.token) &&
                TextUtils.equals(addDeviceFrom, that.addDeviceFrom);
    }

    @Override
    public String toString() {
        return "LocalDevice{" +
                "deviceStatus='" + deviceStatus + '\'' +
                ", token='" + token + '\'' +
                ", addDeviceFrom='" + addDeviceFrom + '\'' +
                ", netType=" + netType +
                '}';
    }

    public void copyFrom(LocalDevice from) {
        this.deviceName = from.deviceName;
        this.id = from.id;
        this.productName = from.productName;
        this.productKey = from.productKey;
        this.token = from.token;
        this.addDeviceFrom = from.addDeviceFrom;
        this.type = from.type;
        this.netType = from.netType;
        this.deviceStatus = from.deviceStatus;
    }
}
