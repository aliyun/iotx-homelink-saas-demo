package com.aliyun.iot.ilop.component.deviceadd.module;

import java.io.Serializable;

/**
 * @author guikong on 18/4/8.
 */
public class Product implements Serializable {
    public long id;

    public String productKey;
    public String productName;
    public String description;
    @SuppressWarnings("unused")
    public String productModel;

    @SuppressWarnings("unused")
    public long gmtCreate;
    @SuppressWarnings("unused")
    public long gmtModified;

    @SuppressWarnings("unused")
    public Long categoryId;
    @SuppressWarnings("unused")
    public String categoryKey;
    @SuppressWarnings("unused")
    public String categoryName;
    //图标
    public String image = "";
    public String categoryUrl = "";

    /**
     * 入网类型:
     * <br/>
     * 取值范围:
     * 0:Lora
     * 3:WiFi
     * 4:Zigbee
     * 5:BT
     * 6:Cellular(GPRS,NB-IoT)
     * 7:Ethernet
     */
    @SuppressWarnings("unused")
    public String netType;
    /**
     * 节点类型:
     * <br/>
     * 取值范围:0:Device, 1:Gateway
     */
    @SuppressWarnings("unused")
    public int nodeType;

    /**
     * 租户的唯一标识符
     */
    @SuppressWarnings("unused")
    public String tenantId;


    public static String getNetTypeString(int netType) {

        switch (netType) {
            case 3:
                return "NET_WIFI";
            case 4:
                return "NET_ZIGBEE";
            case 5:
                return "NET_BT";
            case 6:
                return "NET_CELLULAR";
            case 7:
                return "NET_ETHERNET";
            case 0:
                return "NET_OTHER";
        }
        return "";
    }
}
