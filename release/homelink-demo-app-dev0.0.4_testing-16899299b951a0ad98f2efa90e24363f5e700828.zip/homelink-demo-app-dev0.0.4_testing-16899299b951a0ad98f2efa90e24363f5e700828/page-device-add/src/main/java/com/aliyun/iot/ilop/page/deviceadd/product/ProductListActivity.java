package com.aliyun.iot.ilop.page.deviceadd.product;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.aep.sdk.log.ALog;
import com.aliyun.iot.ilop.component.deviceadd.SelectProductBusiness;
import com.aliyun.iot.ilop.component.deviceadd.listener.OnGetProductCompletedListener;
import com.aliyun.iot.ilop.component.deviceadd.module.Product;
import com.aliyun.iot.ilop.page.device.add.R;
import com.aliyun.iot.ilop.page.deviceadd.bind.DeviceBindActivity;
import com.aliyun.iot.link.ui.component.RefreshRecycleViewLayout;
import com.aliyun.iot.link.ui.component.simpleLoadview.LinkSimpleLoadView;

import java.util.List;
import java.util.Locale;

/**
 * @author guikong on 18/4/8.
 */
public class ProductListActivity extends AppCompatActivity {

    public final static String CODE = "page/productList";

    public final static int REQUEST_CODE_PRODUCT_ADD = 1000;
    public final static int REQUEST_CODE_DEVICE_BIND = 1001;

    public final static String ARGS_KEY_CATEGORY_NAME = "args_key_category_name";
    public final static String ARGS_KEY_CATEGORY_KEY = "args_key_category_key";

    static final String TAG = "ProductListActivity";

    LinkSimpleLoadView loadView;
    RefreshRecycleViewLayout recyclerView;
    ProductListAdapter adapter;

    int currentPage = 1;
    int pageSize = 20;
    int loadedNumber = 0;

    boolean isLoadingMore = false;

    String categoryName;
    String categoryKey;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.deviceadd_product_list_activity);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        // read args
        Intent intent = getIntent();
        if (null != intent) {
            categoryKey = intent.getStringExtra(ARGS_KEY_CATEGORY_KEY);
            categoryName = getIntent().getStringExtra(ARGS_KEY_CATEGORY_NAME);
        }

        // well, it should not happen
        if (TextUtils.isEmpty(categoryKey)) {
            Toast.makeText(this, "invalid category key", Toast.LENGTH_LONG).show();
            return;
        }

        // top_bar
        TextView title = findViewById(R.id.deviceadd_top_bar_title_tv);
       String language =getSysLocale(this).getLanguage();
       if ("zh".equalsIgnoreCase(language)){
           title.setText(categoryName);
       }else{
           title.setText(categoryKey);
       }

        View backView = findViewById(R.id.deviceadd_top_bar_back_fl);
        backView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // load view
        loadView = findViewById(R.id.deviceadd_product_list_link_simple_load_view);
        loadView.setLoadViewLoacation(1);
        loadView.setTipViewLoacation(1);
        String loading = getString(R.string.deviceadd_loading);
        loadView.showLoading(loading);

        // swipe refresh layout
        recyclerView = findViewById(R.id.deviceadd_product_list_swipe_refresh_layout);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setEnabled(false);
        recyclerView.setOnLoadMoreListener(new RefreshRecycleViewLayout.OnLoadMoreListener() {
            @Override
            public void onLoadMore() {
                if (!isLoadingMore) {
                    loadNextPage();
                }
            }
        });

        // init adapter
        adapter = new ProductListAdapter();
        loadNextPage();
    }

    //7.0以上获取方式需要特殊处理一下
    public Locale getSysLocale(Context context) {
        if (Build.VERSION.SDK_INT < 24) {
            return context.getResources().getConfiguration().locale;
        } else {
            return context.getResources().getConfiguration().getLocales().get(0);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (Activity.RESULT_OK != resultCode) {
            return;
        }

        if (REQUEST_CODE_PRODUCT_ADD == requestCode) {
            String productKey = data.getStringExtra("productKey");
            String deviceName = data.getStringExtra("deviceName");
            String token = data.getStringExtra("token");
            String iotId = data.getStringExtra("iotId");

            Bundle bundle = new Bundle();
            bundle.putString(DeviceBindActivity.ARGS_KEY_PK, productKey);
            bundle.putString(DeviceBindActivity.ARGS_KEY_DN, deviceName);
            bundle.putString(DeviceBindActivity.ARGS_KEY_TOKEN, token);
            bundle.putString(DeviceBindActivity.ARGS_KEY_IOT_ID, iotId);

            Router.getInstance().toUrlForResult(this, DeviceBindActivity.CODE, REQUEST_CODE_DEVICE_BIND, bundle);
        } else if (REQUEST_CODE_DEVICE_BIND == requestCode) {
            setResult(Activity.RESULT_OK, data);
            finish();
        }
    }

    private void loadNextPage() {
        isLoadingMore = true;
        new SelectProductBusiness().getProductsByCategory(categoryKey, currentPage, pageSize, new OnGetProductCompletedListener() {
            @Override
            public void onSuccess(int count, List<Product> products) {
                isLoadingMore = false;

                // show categories
                adapter.addCategory(products);

                // if first page, adapter
                // so empty view will dismiss
                if (currentPage == 1) {
                    recyclerView.setAdapter(adapter);
                    loadView.hide();
                }

                // increase counters
                loadedNumber += products.size();
                currentPage++;

                // load finish
                if (loadedNumber >= count) {
                    recyclerView.fullLoad();
                }
            }

            @Override
            public void onFailed(Exception e) {
                isLoadingMore = false;

                Toast.makeText(ProductListActivity.this, R.string.deviceadd_load_failed, Toast.LENGTH_LONG).show();
                ALog.e(TAG, "load products failed", e);
                e.printStackTrace();
            }

            @Override
            public void onFailed(int code, String message, String localizedMsg) {
                isLoadingMore = false;

                Toast.makeText(ProductListActivity.this, localizedMsg, Toast.LENGTH_LONG).show();
                ALog.d(TAG, "load products failed:" + message);
            }
        });
    }
}
