package com.aliyun.iot.ilop.component.deviceadd.listener;

import com.aliyun.iot.ilop.component.deviceadd.module.FoundDevice;

import java.util.List;

/**
 * @author guikong on 18/4/19.
 */
public interface OnDeviceFilterCompletedListener {
    void onDeviceFilterCompleted(List<FoundDevice> localDevices);
}
