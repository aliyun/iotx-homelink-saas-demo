package com.aliyun.iot.ilop.component.deviceadd.listener;

import com.aliyun.iot.ilop.component.deviceadd.module.Category;

import java.util.List;

/**
 * @author guikong on 18/4/8.
 */
public interface OnGetCategoryCompletedListener {
    void onSuccess(int count, List<Category> categories);

    void onFailed(Exception e);

    void onFailed(int code, String message, String localizedMsg);
}
