package com.aliyun.iot.homelink.demo.PageIndexNew.base;

import android.support.v4.widget.SwipeRefreshLayout;

/**
 * Created by ZhuBingYang on 2019/3/27.
 */
public interface SwipeRefreshable extends SwipeRefreshLayout.OnRefreshListener {
    void refreshComplete();
}
