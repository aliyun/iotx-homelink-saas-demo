package com.aliyun.iot.homelink.demo.PageIndexNew.view.main;

import com.aliyun.iot.homelink.demo.PageIndexNew.entity.AccountDevice;
import com.aliyun.iot.homelink.demo.commons.base.BaseView;

import java.util.List;

/**
 * Created by ZhuBingYang on 2019/3/25.
 */
public class IndexContract {
    public interface IndexView extends BaseView {
        void refreshData(List<AccountDevice> deviceList);

        void appendData(List<AccountDevice> list);

        void allLoaded();

        void refreshComplete();

        void togglePower(String iotId,boolean powerOn);

        void showNetError();
    }

    public interface IndexPresenter {
        void getDeviceList();

        void loadMore();

        void powerSwitch(String iotId,boolean powerOn);
    }
}
