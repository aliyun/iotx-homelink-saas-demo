package com.aliyun.iot.homelink.demo.PageIndexNew.view.main;

import android.content.Context;

import com.aliyun.iot.aep.sdk.apiclient.callback.IoTResponse;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequest;
import com.aliyun.iot.aep.sdk.credential.IotCredentialManager.IoTCredentialManageImpl;
import com.aliyun.iot.homelink.demo.PageIndexNew.entity.AccountDevice;
import com.aliyun.iot.homelink.demo.PageIndexNew.entity.DeviceTSL;
import com.aliyun.iot.homelink.demo.PageIndexNew.network.Api;
import com.aliyun.iot.homelink.demo.commons.network.IoTCallbackAdapter;
import com.aliyun.iot.homelink.demo.commons.network.IotCallbackMainThread;
import com.aliyun.iot.homelink.demo.commons.network.Response;
import com.aliyun.iot.homelink.demo.commons.util.Util;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by ZhuBingYang on 2019/3/25.
 */
public class IndexPresenterImpl implements IndexContract.IndexPresenter {
    private Context mContext;
    private IndexContract.IndexView mIndexView;

    private int pageNo = 1;
    private int pageSize = 20;

    public IndexPresenterImpl(Context context, IndexContract.IndexView indexView) {
        mContext = context;
        mIndexView = indexView;
    }

    @Override
    public void getDeviceList() {
        pageNo = 1;
        fetchDeviceList(false);
    }

    @Override
    public void loadMore() {
        pageNo++;
        fetchDeviceList(true);
    }

    @Override
    public void powerSwitch(final String iotId, final boolean powerOn) {
        Api.getInstance().getThingTSL(iotId, new IoTCallbackAdapter<DeviceTSL>(mContext) {

            @Override
            protected void onSuccess(IoTRequest request, DeviceTSL response) {
                for (DeviceTSL.Property property : response.getProperties()) {
                    if (property.getName().contains("开关") || property.getIdentifier().contains("Switch")) {
                        for (Map.Entry<String, Object> entry : property.getDataType().getSpecs().entrySet()) {
                            if (entry.getValue().equals(powerOn ? "开启" : "关闭")) {
                                Map<String, Object> map = new HashMap<>();
                                map.put(property.getIdentifier(), Integer.parseInt(entry.getKey()));
                                Api.getInstance().setThingProperties(iotId, map, new IotCallbackMainThread(mContext) {
                                    @Override
                                    protected void onSuccess(IoTRequest request, IoTResponse response) {
                                        mIndexView.togglePower(iotId, powerOn);
                                    }
                                });
                                return;
                            }
                        }
                    }
                }
            }
        });
    }

    private void fetchDeviceList(final boolean loadMore) {

        Api.getInstance().getDeviceListByAccount(pageNo, pageSize, IoTCredentialManageImpl.getInstance(Util.getApplication()).getIoTIdentity(), new IoTCallbackAdapter<Response<List<AccountDevice>>>(mContext) {
            @Override
            protected void onSuccess(IoTRequest request, Response<List<AccountDevice>> response) {
                if (response.hasData()) {
                    if (loadMore) {
                        mIndexView.appendData(response.getData());
                    } else {
                        mIndexView.refreshData(response.getData());
                    }
                }

                if (pageNo * pageSize >= response.getTotal()) {
                    mIndexView.allLoaded();
                }
                mIndexView.refreshComplete();
            }

            @Override
            public void onFailureOverrideThis(IoTRequest request, Exception e) {
                super.onFailureOverrideThis(request, e);
                mIndexView.refreshComplete();

                if (e instanceof IOException) {
                    mIndexView.showNetError();
                }
            }
        });
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
}
