package com.aliyun.iot.homelink.demo.PageIndexNew.entity;

import com.alibaba.fastjson.annotation.JSONField;

import java.util.List;

/**
 * Created by ZhuBingYang on 2019/3/25.
 * 从 /home/paas/device/list 获取的设备列表
 */
public class Device {
    /**
     * {
     * "iotId": "tMbycP1picrKhT0HQDCk001034b510",
     * "spaceNamePath": "/根节点1/",
     * "attributeList": [
     * ...{@link Attribute}
     * ],
     * "thingType": "DEVICE",
     * "productKey": "a1mB9mXoz0q",
     * "deviceName": "fordev",
     * "productName": "带服务的灯_qw",
     * "status": 1,
     * "productImage": "https://img.alicdn.com/tps/TB1_I0aPXXXXXajXpXXXXXXXXXX-100-82.png",
     * "nickName": "dev1",
     * "lastOnlineTime": "2019-01-01 12:00:00"
     * }
     */

    private String iotId;
    private String spaceNamePath;
    private String thingType;
    private String productKey;
    private String deviceName;
    private String productName;
    private List<Attribute> attributeList;
    private int status;
    private String productImage;
    @JSONField(name = "nickName")
    private String nickname;
    private String lastOnlineTime;

    public String getIotId() {
        return iotId;
    }

    public void setIotId(String iotId) {
        this.iotId = iotId;
    }

    public String getSpaceNamePath() {
        return spaceNamePath;
    }

    public void setSpaceNamePath(String spaceNamePath) {
        this.spaceNamePath = spaceNamePath;
    }

    public String getThingType() {
        return thingType;
    }

    public void setThingType(String thingType) {
        this.thingType = thingType;
    }

    public String getProductKey() {
        return productKey;
    }

    public void setProductKey(String productKey) {
        this.productKey = productKey;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public List<Attribute> getAttributeList() {
        return attributeList;
    }

    public void setAttributeList(List<Attribute> attributeList) {
        this.attributeList = attributeList;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getLastOnlineTime() {
        return lastOnlineTime;
    }

    public void setLastOnlineTime(String lastOnlineTime) {
        this.lastOnlineTime = lastOnlineTime;
    }

    public class Attribute {

        /**
         * {
         * "iotId": "tMbycP1picrKhT0HQDCk001034b510",
         * "gmtModified": 1547797068655,
         * "attribute": "LightMode",
         * "batchId": "ce354176212c47448b6a7e97e2c85705",
         * "value": 0
         * }
         */

        private String iotId;
        private long gmtModified;
        private String attribute;
        private String batchId;
        private String value;

        public String getIotId() {
            return iotId;
        }

        public void setIotId(String iotId) {
            this.iotId = iotId;
        }

        public long getGmtModified() {
            return gmtModified;
        }

        public void setGmtModified(long gmtModified) {
            this.gmtModified = gmtModified;
        }

        public String getAttribute() {
            return attribute;
        }

        public void setAttribute(String attribute) {
            this.attribute = attribute;
        }

        public String getBatchId() {
            return batchId;
        }

        public void setBatchId(String batchId) {
            this.batchId = batchId;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return "Attribute{" +
                    "iotId='" + iotId + '\'' +
                    ", gmtModified=" + gmtModified +
                    ", attribute='" + attribute + '\'' +
                    ", batchId='" + batchId + '\'' +
                    ", value=" + value +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "Device{" +
                "iotId='" + iotId + '\'' +
                ", spaceNamePath='" + spaceNamePath + '\'' +
                ", thingType='" + thingType + '\'' +
                ", productKey='" + productKey + '\'' +
                ", deviceName='" + deviceName + '\'' +
                ", productName='" + productName + '\'' +
                ", attributeList=" + attributeList +
                ", status=" + status +
                ", productImage='" + productImage + '\'' +
                ", nickname='" + nickname + '\'' +
                ", lastOnlineTime='" + lastOnlineTime + '\'' +
                '}';
    }
}
