package com.aliyun.iot.homelink.demo.PageIndexNew.view.main;

import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.aliyun.iot.drawableview.DrawableView;
import com.aliyun.iot.homelink.demo.PageIndexNew.R;
import com.aliyun.iot.homelink.demo.PageIndexNew.entity.AccountDevice;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;

import java.util.List;

/**
 * Created by ZhuBingYang on 2019/3/26.
 */
public class PageIndexDeviceAdapter extends BaseQuickAdapter<AccountDevice, BaseViewHolder> {
    private static final int COLOR_POWER_ON = 0xFF3CC88B;
    private static final int COLOR_POWER_OFF = 0xFFCCCCCC;
    private static final int COLOR_OFFLINE = 0xFFEDEDED;

    PageIndexDeviceAdapter(@Nullable List<AccountDevice> data) {
        super(R.layout.index_list_item_index_device, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, AccountDevice device) {
        ImageView iconIV = helper.getView(R.id.li_index_device_icon_iv);
        ImageView typeIV = helper.getView(R.id.li_index_device_type_iv);
        TextView typeTv = helper.getView(R.id.li_index_device_type_tv);
        DrawableView dot = helper.getView(R.id.li_index_device_dot_v);
        ImageView powerIv = helper.getView(R.id.li_index_device_switch_iv);
        TextView statusTv = helper.getView(R.id.li_index_device_status_tv);
        TextView nameTv = helper.getView(R.id.li_index_device_name_tv);

        helper.addOnClickListener(R.id.li_index_device_switch_iv);

//        DefaultDrawableBackground background = dot.getDrawableBackground();
//        if (device.getStatus() == 1) {
//            statusTv.setText(R.string.online);
//            background.solidColor = 0xff86ed19;
//        } else if (device.getStatus() == 3) {
//            statusTv.setText(R.string.offline);
//            background.solidColor = 0xffff3838;
//        } else if (device.getStatus() == 8) {
//            statusTv.setText(R.string.forbidden);
//            background.solidColor = 0xffff3838;
//        } else {
//            statusTv.setText(R.string.not_active);
//            background.solidColor = 0xffff3838;
//        }
//        background.invalidate();

        nameTv.setText(device.getProductName());

        if (device.getStatus() == 1) {
            statusTv.setText(R.string.online);
            dot.getDrawableBackground().solidColor = 0xff86ed19;
            nameTv.setTextColor(0xff333333);
        } else {
            statusTv.setText(R.string.offline);
            dot.getDrawableBackground().solidColor = 0xffEDEDED;
            nameTv.setTextColor(0xff999999);
        }
        dot.getDrawableBackground().invalidate();

        typeTv.setVisibility(device.getOwned() == 0 ? View.VISIBLE : View.GONE);

        Glide.with(iconIV).load(device.getProductImage())
                .apply(new RequestOptions()
                        .placeholder(R.mipmap.deviceadd_icon_default)
                        .error(R.mipmap.deviceadd_icon_default))
                .into(iconIV);

        int imgRes = 0;
        switch (device.getNetType()) {
            case "NET_WIFI":
                imgRes = R.mipmap.wifi;
                break;
            case "BLUETOOTH":
            case "NET_BT":
                imgRes = R.mipmap.bluetooth;
                break;
            case "NET_ETHERNET":
            case "NET_CELLULAR":
            case "NET_ZIGBEE":
            case "NET_OTHER":
                //todo
            default:

        }
        if (imgRes != 0) {
            typeIV.setVisibility(View.VISIBLE);
            typeIV.setImageResource(imgRes);
        } else {
            typeIV.setVisibility(View.GONE);
        }

        powerIv.setVisibility(View.GONE);
//        switch (device.getStatus()) {
//            case 0:
//                powerIv.setColorFilter(COLOR_POWER_OFF);
//                break;
//            case 1:
//                powerIv.setColorFilter(COLOR_POWER_ON);
//                break;
//            default:
//                powerIv.setColorFilter(COLOR_OFFLINE);
//
//        }
    }
}