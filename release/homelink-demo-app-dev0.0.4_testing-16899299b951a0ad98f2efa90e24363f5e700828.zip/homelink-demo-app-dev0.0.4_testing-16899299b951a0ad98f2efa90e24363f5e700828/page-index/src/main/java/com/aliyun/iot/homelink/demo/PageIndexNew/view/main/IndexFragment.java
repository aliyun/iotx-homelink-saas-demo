package com.aliyun.iot.homelink.demo.PageIndexNew.view.main;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.aliyun.iot.aep.component.router.Router;
import com.aliyun.iot.homelink.demo.PageIndexNew.R;
import com.aliyun.iot.homelink.demo.PageIndexNew.base.SwipeRefreshFragment;
import com.aliyun.iot.homelink.demo.PageIndexNew.entity.AccountDevice;
import com.aliyun.iot.homelink.demo.commons.util.NetUtil;
import com.aliyun.iot.link.ui.component.RefreshRecycleViewLayout;
import com.chad.library.adapter.base.BaseQuickAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ZhuBingYang on 2019/3/25.
 */
public class IndexFragment extends SwipeRefreshFragment implements IndexContract.IndexView, View.OnClickListener {
    private IndexPresenterImpl mIndexPresenter;

    private RecyclerView mRecyclerView;
    private PageIndexDeviceAdapter mAdapter;
    private ArrayList<AccountDevice> mDeviceList = new ArrayList<>();

    private ImageView mAddImageView;

    @Override
    protected int getLayoutId() {
        return R.layout.index_fragment_page_index;
    }

    @Override
    protected void initView(View view) {
        super.initView(view);
        mRecyclerView = ((RefreshRecycleViewLayout) mRefreshLayout).getTargetView();
        mAddImageView = view.findViewById(R.id.page_index_add_iv);
        view.findViewById(R.id.page_index_ble).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Router.getInstance().toUrl(v.getContext(), "hld://ble");
            }
        });
        mAddImageView.setOnClickListener(this);

        mRecyclerView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        mIndexPresenter = new IndexPresenterImpl(getMActivity(), this);
        mAdapter = new PageIndexDeviceAdapter(mDeviceList);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getMActivity()));
        mRecyclerView.setAdapter(mAdapter);
        mAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {

                if (!NetUtil.isNetworkConnected(getMActivity())) {
                    toast(getString(R.string.net_error_please_check));
                    return;
                }

                AccountDevice device = mDeviceList.get(position);
                Bundle bundle = new Bundle();
                bundle.putString("iotId", device.getIotId());
                Router.getInstance().toUrl(getActivity(), "link://router/" + device.getProductKey(), bundle);
            }
        });
        mAdapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
            @Override
            public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
                AccountDevice device = mDeviceList.get(position);
                mIndexPresenter.powerSwitch(device.getIotId(), device.getStatus() == 0);
            }
        });
        mAdapter.setEnableLoadMore(true);
        mAdapter.setOnLoadMoreListener(new BaseQuickAdapter.RequestLoadMoreListener() {
            @Override
            public void onLoadMoreRequested() {
                mIndexPresenter.loadMore();
            }
        }, mRecyclerView);
        mAdapter.setEmptyView(R.layout.index_empty);
        mAdapter.getEmptyView().findViewById(R.id.index_empty_add_iv).setOnClickListener(this);

        mRefreshLayout.setRefreshing(true);
        mIndexPresenter.getDeviceList();
    }

    @Override
    public void refreshData(List<AccountDevice> deviceList) {
        mDeviceList.clear();
        mAdapter.getEmptyView().findViewById(R.id.index_empty_add_device_ll).setVisibility(View.VISIBLE);
        mDeviceList.addAll(deviceList);
        mAdapter.notifyDataSetChanged();
        mAdapter.setEnableLoadMore(true);
        refreshComplete();
    }

    @Override
    public void appendData(List<AccountDevice> list) {
        mDeviceList.addAll(list);
        mAdapter.notifyDataSetChanged();
        mAdapter.loadMoreComplete();
    }

    @Override
    public void allLoaded() {
        mAdapter.setEnableLoadMore(false);
        refreshComplete();
//        mAdapter.setFooterView(LayoutInflater.from(getContext()).inflate(R.layout.v_data_all_loaded,null));
    }

    @Override
    public void showNetError() {
        mAdapter.getEmptyView().findViewById(R.id.index_empty_add_device_ll).setVisibility(View.GONE);
        mDeviceList.clear();
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void togglePower(String iotId, boolean powerOn) {
        for (int i = 0; i < mDeviceList.size(); i++) {
            AccountDevice device = mDeviceList.get(i);
            if (device.getIotId().equals(iotId)) {
                device.setStatus(powerOn ? 1 : 0);
                mAdapter.notifyItemChanged(i);
                break;
            }
        }
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.page_index_add_iv || id == R.id.index_empty_add_iv) {
            if (!NetUtil.isNetworkConnected(getMActivity())) {
                toast(getString(R.string.net_error_please_check));
                return;
            }

            Bundle bundle = new Bundle();
            bundle.putString("groupId", "HOMELINK_AQUARIUS");
            Router.getInstance().toUrlForResult(getActivity(), "page/categoryList", 0x012, bundle);
        }
    }

    @Override
    public void onRefresh() {
        mIndexPresenter.getDeviceList();
    }
}
