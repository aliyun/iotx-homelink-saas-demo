package com.aliyun.iot.homelink.demo.PageIndexNew.network;

import com.aliyun.iot.aep.sdk.apiclient.IoTAPIClientFactory;
import com.aliyun.iot.aep.sdk.apiclient.callback.IoTCallback;
import com.aliyun.iot.aep.sdk.apiclient.emuns.Scheme;
import com.aliyun.iot.aep.sdk.apiclient.request.IoTRequestBuilder;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by ZhuBingYang on 2019/3/26.
 */
public class Api {
    private static class Holder {
        static final Api INSTANCE = new Api();
    }

    private Api() {

    }

    public static Api getInstance() {
        return Holder.INSTANCE;
    }

    public void getDeviceList(int pageNo, int pageSize, IoTCallback callback) {
        HashMap<String, Object> map = new HashMap<>();

        HashMap<String, Object> queryMap = new HashMap<>();
        queryMap.put("pageNo", pageNo);
        queryMap.put("pageSize", pageSize);
        map.put("pageInfo", queryMap);

        call("/home/paas/device/list", "1.0.0", map, callback);
    }

    public void getDeviceListByAccount(int pageNo, int pageSize, String id,IoTCallback callback) {
        HashMap<String, Object> map = new HashMap<>();
        map.put("pageNo", pageNo);
        map.put("pageSize", pageSize);
        map.put("groupId",id);
        call("/uc/listBindingByAccount", "1.0.5", map, callback);
    }

    public void bindDevice(String productKey, String deviceName, IoTCallback callback) {
        HashMap<String, Object> map = new HashMap<>();
        map.put("productKey", productKey);
        map.put("deviceName", deviceName);
        call("/awss/enrollee/user/bind", "1.0.2", map, callback);
    }

    public void  unbind(IoTCallback callback){
        HashMap<String, Object> map = new HashMap<>();
        map.put("iotId", "hRjLpbIPRE07ZILlyNZ40010bb0700");
        call("/uc/unbindAccountAndDev","1.0.2",map,callback);
    }

    public void getThingTSL(String iotId,IoTCallback callback){
        HashMap<String, Object> map = new HashMap<>();
        map.put("iotId", iotId);
        call("/thing/tsl/get", "1.0.2", map, callback);
    }

    /**
     * @param iotId      物的唯一标识符
     * @param properties 设置物的参数
     * @param callback
     */
    public void setThingProperties(String iotId, Map<String, Object> properties, IoTCallback callback) {
        HashMap<String, Object> map = new HashMap<>();
        map.put("iotId", iotId);
        map.put("items", properties);
        call("/thing/properties/set", "1.0.2", map, callback);
    }

    /**
     * 绑定淘宝id 天猫精灵绑定  使用淘宝账号体系
     *
     * @param authCode 淘宝授权页面登录后授权码
     * @param callback
     */
    public void bindTaoBaoAccount(String authCode, IoTCallback callback) {
        HashMap<String, Object> map = new HashMap<>();
        map.put("authCode", authCode);
        call("/account/taobao/bind", "1.0.5", map, callback);
    }

    /**
     * 解绑淘宝id（天猫精灵）
     *
     * @param callback
     */
    public void unbindTaoBaoAccount(IoTCallback callback) {
        HashMap<String, Object> map = new HashMap<>();
        map.put("accountType", "TAOBAO");
        call("/account/thirdparty/unbind", "1.0.5", map, callback);
    }

    /**
     * @param path     接口地址
     * @param version  接口版本
     * @param params   传给后台的参数列表
     * @param callback 数据返回回调接口
     */
    private void call(String path, String version, Map<String, Object> params, IoTCallback callback) {
        IoTRequestBuilder builder = new IoTRequestBuilder()
                .setAuthType("iotAuth")
                .setPath(path)
                .setScheme(Scheme.HTTPS)
                .setApiVersion(version);

        if (params != null)
            builder.setParams(params);

        new IoTAPIClientFactory().getClient().send(builder.build(), callback);
    }
}
