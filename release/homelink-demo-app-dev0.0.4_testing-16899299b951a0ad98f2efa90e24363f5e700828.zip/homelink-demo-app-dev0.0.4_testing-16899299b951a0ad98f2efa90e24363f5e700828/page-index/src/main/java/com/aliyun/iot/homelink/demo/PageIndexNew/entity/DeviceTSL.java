package com.aliyun.iot.homelink.demo.PageIndexNew.entity;

import java.util.HashMap;
import java.util.List;

/**
 * Created by ZhuBingYang on 2019/4/15.
 */
public class DeviceTSL {
    private String schema;
    private Profile profile;
    private String link;

    private List<Attribute> services;
    private List<Property> properties;
    private List<Attribute> events;

    public String getSchema() {
        return schema;
    }

    public void setSchema(String schema) {
        this.schema = schema;
    }

    public Profile getProfile() {
        return profile;
    }

    public void setProfile(Profile profile) {
        this.profile = profile;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public List<Attribute> getServices() {
        return services;
    }

    public void setServices(List<Attribute> services) {
        this.services = services;
    }

    public List<Property> getProperties() {
        return properties;
    }

    public void setProperties(List<Property> properties) {
        this.properties = properties;
    }

    public List<Attribute> getEvents() {
        return events;
    }

    public void setEvents(List<Attribute> events) {
        this.events = events;
    }

    public static class Profile {
        private String productKey;
        private String deviceName;

        public String getProductKey() {
            return productKey;
        }

        public void setProductKey(String productKey) {
            this.productKey = productKey;
        }

        public String getDeviceName() {
            return deviceName;
        }

        public void setDeviceName(String deviceName) {
            this.deviceName = deviceName;
        }

        @Override
        public String toString() {
            return "Profile{" +
                    "productKey='" + productKey + '\'' +
                    ", deviceName='" + deviceName + '\'' +
                    '}';
        }
    }

    public static class Attribute{
        private List<String> inputData;
        private List<Property> outputData;
        private String identifier;
        private String method;
        private String name;
        private boolean required;
        private String callType;
        private String desc;

        public List<String> getInputData() {
            return inputData;
        }

        public void setInputData(List<String> inputData) {
            this.inputData = inputData;
        }

        public List<Property> getOutputData() {
            return outputData;
        }

        public void setOutputData(List<Property> outputData) {
            this.outputData = outputData;
        }

        public String getIdentifier() {
            return identifier;
        }

        public void setIdentifier(String identifier) {
            this.identifier = identifier;
        }

        public String getMethod() {
            return method;
        }

        public void setMethod(String method) {
            this.method = method;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public boolean isRequired() {
            return required;
        }

        public void setRequired(boolean required) {
            this.required = required;
        }

        public String getCallType() {
            return callType;
        }

        public void setCallType(String callType) {
            this.callType = callType;
        }

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }

        @Override
        public String toString() {
            return "Attribute{" +
                    "inputData=" + inputData +
                    ", outputData=" + outputData +
                    ", identifier='" + identifier + '\'' +
                    ", method='" + method + '\'' +
                    ", name='" + name + '\'' +
                    ", required=" + required +
                    ", callType='" + callType + '\'' +
                    ", desc='" + desc + '\'' +
                    '}';
        }
    }

    public static class Property {

        /**
         * identifier : LightSwitch
         * dataType : {"specs":{"0":"关闭","1":"开启"},"type":"bool"}
         * name : 主灯开关
         * accessMode : rw
         * required : true
         */

        private String identifier;
        private DataType dataType;
        private String name;
        private String accessMode;
        private boolean required;

        public String getIdentifier() {
            return identifier;
        }

        public void setIdentifier(String identifier) {
            this.identifier = identifier;
        }

        public DataType getDataType() {
            return dataType;
        }

        public void setDataType(DataType dataType) {
            this.dataType = dataType;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getAccessMode() {
            return accessMode;
        }

        public void setAccessMode(String accessMode) {
            this.accessMode = accessMode;
        }

        public boolean isRequired() {
            return required;
        }

        public void setRequired(boolean required) {
            this.required = required;
        }

        public static class DataType {

            private HashMap<String, Object> specs;
            private String type;

            public HashMap<String, Object> getSpecs() {
                return specs;
            }

            public void setSpecs(HashMap<String, Object> specs) {
                this.specs = specs;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }
        }

        @Override
        public String toString() {
            return "Property{" +
                    "identifier='" + identifier + '\'' +
                    ", dataType=" + dataType +
                    ", name='" + name + '\'' +
                    ", accessMode='" + accessMode + '\'' +
                    ", required=" + required +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "DeviceTSL{" +
                "schema='" + schema + '\'' +
                ", profile=" + profile +
                ", link='" + link + '\'' +
                ", services=" + services +
                ", properties=" + properties +
                ", events=" + events +
                '}';
    }
}
