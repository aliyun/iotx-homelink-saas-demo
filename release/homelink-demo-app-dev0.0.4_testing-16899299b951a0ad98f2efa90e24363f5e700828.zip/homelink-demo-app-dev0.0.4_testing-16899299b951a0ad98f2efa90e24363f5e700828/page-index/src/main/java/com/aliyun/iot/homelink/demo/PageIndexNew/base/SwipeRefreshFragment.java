package com.aliyun.iot.homelink.demo.PageIndexNew.base;

import android.support.annotation.CallSuper;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.View;

import com.aliyun.iot.homelink.demo.PageIndexNew.R;
import com.aliyun.iot.homelink.demo.commons.base.BaseFragment;

/**
 * Created by ZhuBingYang on 2019/3/27.
 */
public abstract class SwipeRefreshFragment extends BaseFragment implements SwipeRefreshable {
    protected SwipeRefreshLayout mRefreshLayout;

    @CallSuper
    @Override
    protected void initView(View view) {
        mRefreshLayout = view.findViewById(R.id.refresh_layout);

        if (mRefreshLayout != null) {
            mRefreshLayout.setColorSchemeColors(getResources().getColor(R.color.colorAccent));
            mRefreshLayout.setOnRefreshListener(this);
        }
    }

    @Override
    public void refreshComplete() {
        if (mRefreshLayout!=null){
            mRefreshLayout.setRefreshing(false);
        }
    }
}
