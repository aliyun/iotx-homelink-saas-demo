//
//  AppDelegate.m
//  IMSHomeLinkApp
//
//  Created by 冯君骅 on 2018/5/29.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "AppDelegate.h"

#import <IMSLaunchKit/IMSLaunchKit.h>
#import <IMSInitCode/IMSOpenAccount.h>
#import <IMSOpenAccountBase/IMSOpenAccountBase.h>
#import <IMSGlueCode/IMSAlicloudPushIoTGlue.h>
#import <IMSGlueCode/IMSBaseSDKGlue.h>

#if __has_include(<IMSBoneKitDebug/BoneLocalDebug.h>)
#import <IMSBoneKitDebug/BoneLocalDebug.h>
#endif

#import <IMSHomeLink/IMSHomeLink.h>
#import <IMSDevice/IMSDevice.h>
#import <IMSCategory/IMSCategory.h>
#import <IMSHomeLinkApiClient/IMSHomeLinkApiClient.h>

@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
	// Override point for customization after application launch.
	self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
	[self.window makeKeyAndVisible];
	
	[[IMSLauncher defaultLauncher] application:application didFinishLaunchingWithOptions:launchOptions];
	
	if ([[IMSOpenAccount sharedInstance] isLogin]) {
		[self switchRootViewControllerToTabbarVC];
	} else {
		[[IMSAccountManager sharedManager] resetRootViewControllerWithLoginSuccess:^(UIViewController *viewController){
			[self switchRootViewControllerToTabbarVC];
		}];
	}
	
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(willLoginOut) name:IMSOpenAccountNotificationUserLoggedOut object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginOut) name:ALBBOpenAccountNotificationUserLoggedOut object:nil];
	
	return YES;
}

- (void)switchRootViewControllerToTabbarVC {
	[UIApplication sharedApplication].delegate.window.rootViewController = [[IMSHomeTabBarViewController alloc] init];
	[self configNavigationAppearance];
	[self configTextFieldAppearance];
}

- (void)willLoginOut {
	//解绑推送
	[IMSAlicloudPushIoTGlue unbindAPNSChannel];
	//解绑长连接
	[IMSBaseSDKGlue requestUnbindMobileChannelWithAccount];
}

- (void)loginOut {
	[[IMSAccountManager sharedManager] resetRootViewControllerWithLoginSuccess:^(UIViewController *viewController){
		[self switchRootViewControllerToTabbarVC];
	}];
}

- (void)configNavigationAppearance {
	UINavigationBar *navigationBar = [UINavigationBar appearance];
	navigationBar.translucent = NO;
	UIImage *image = [IMSLinkImageNamed(@"IMSLink_back") imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)];
	navigationBar.backIndicatorImage = image;
	navigationBar.backIndicatorTransitionMaskImage = image;
	
	UIBarButtonItem *barItem = [UIBarButtonItem appearance];
	[barItem setBackButtonTitlePositionAdjustment:UIOffsetMake(-500, 0) forBarMetrics:(UIBarMetricsDefault)];
}

- (void)configTextFieldAppearance {
	[[UITextField appearance] setTintColor:[UIColor ims_systemMaticColor]];
}

#pragma mark - PUSH
	
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
	[[IMSLauncher defaultLauncher] application:application didReceiveRemoteNotification:userInfo];
}
	
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
	[[IMSLauncher defaultLauncher] application:application didRegisterForRemoteNotificationsWithDeviceToken:deviceToken];
}
	
- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
	[[IMSLauncher defaultLauncher] application:application didFailToRegisterForRemoteNotificationsWithError:error];
}

@end
