//
//  AppDelegate.h
//  IMSHomeLinkApp
//
//  Created by 冯君骅 on 2018/5/29.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

