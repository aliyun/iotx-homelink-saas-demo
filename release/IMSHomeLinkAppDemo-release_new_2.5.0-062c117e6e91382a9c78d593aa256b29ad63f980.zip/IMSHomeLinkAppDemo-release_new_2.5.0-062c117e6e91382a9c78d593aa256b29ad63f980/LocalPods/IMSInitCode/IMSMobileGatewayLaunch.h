//
//  IMSMobileGatewayLaunch.h
//  IMSInitCode
//
//  Created by 冯君骅 on 2019/8/9.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface IMSMobileGatewayLaunch : NSObject <UIApplicationDelegate>

@end

NS_ASSUME_NONNULL_END
