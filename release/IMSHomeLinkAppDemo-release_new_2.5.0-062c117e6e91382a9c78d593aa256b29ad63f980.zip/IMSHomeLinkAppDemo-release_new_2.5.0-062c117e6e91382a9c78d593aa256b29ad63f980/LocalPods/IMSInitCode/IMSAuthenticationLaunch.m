//
//  IMSAuthenticationLaunch.m
//  
//
//  Created by Aliyun on 2018/6/11.
//  Copyright © 2018年 Alibaba. All rights reserved.
//

#import "IMSAuthenticationLaunch.h"

@implementation IMSAuthenticationLaunch

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    return TRUE;
}

@end
