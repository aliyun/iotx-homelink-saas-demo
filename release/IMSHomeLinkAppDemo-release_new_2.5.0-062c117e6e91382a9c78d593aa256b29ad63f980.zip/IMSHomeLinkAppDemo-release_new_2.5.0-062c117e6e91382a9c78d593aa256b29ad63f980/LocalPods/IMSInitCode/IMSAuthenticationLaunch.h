//
//  IMSAuthenticationLaunch.h
//  
//
//  Created by Aliyun on 2018/6/11.
//  Copyright © 2018年 Alibaba. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IMSAuthenticationLaunch : NSObject <UIApplicationDelegate>

@end
