//
//  IMSThingCapabilityLaunch.h
//  
//
//  Created by Aliyun on 2018/6/12.
//  Copyright © 2018年 Alibaba. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IMSThingCapabilityLaunch : NSObject <UIApplicationDelegate>

@end
