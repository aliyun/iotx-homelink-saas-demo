//
//  IMSProfileSettingCell.h
//  IMSLife
//
//  Created by chuntao.wang1 on 2018/4/18.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IMSHomeLinkSettingCell : UITableViewCell

//标题
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
//右侧红点
@property (weak, nonatomic) IBOutlet UIView *badgeView;
//右侧箭头
@property (weak, nonatomic) IBOutlet UIButton *arrowRightView;
//分割线是否隐藏
@property (weak,nonatomic) IBOutlet UIView *lineView;

@end
