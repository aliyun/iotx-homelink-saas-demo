//
//  IMSHomeTabBarViewController.h
//  IMSHomeLink
//
//  Created by 冯君骅 on 2018/6/1.
//

#import <UIKit/UIKit.h>

@interface IMSHomeTabBarViewController : UITabBarController

@end
