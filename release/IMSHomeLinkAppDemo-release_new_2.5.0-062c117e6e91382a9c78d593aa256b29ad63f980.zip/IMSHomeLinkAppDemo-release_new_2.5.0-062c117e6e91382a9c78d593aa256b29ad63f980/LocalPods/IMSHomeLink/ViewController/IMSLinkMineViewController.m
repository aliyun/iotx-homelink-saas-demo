//
//  IMSMineViewController.m
//  IMSHomeLink
//
//  Created by X i n long Li on 2018/5/30.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSLinkMineViewController.h"

#import "IMSLinkUntil.h"
#import "IMSUserSettingViewController.h"
#import "IMSHomeLinkSettingCell.h"

#import <ALBBOpenAccountCloud/ALBBOpenAccountSDK.h>
#import <IMSRefresh/IMSRefresh.h>
#import <IMSHUD/IMSHUD.h>
#import <IMSHomeLinkApiClient/IMSHomeLinkApiClientHeader.h>
#import <IMSCategory/IMSCategory.h>
#import <IMSDevice/IMSDevice.h>
#import <IMSSmartSpeakerAccess/IMSSmartSpeakerAccess.h>
#import <sys/utsname.h>
#import <IMSApiClient/IMSApiClient.h>

static NSString *const IMSHomeLinkSetting = @"IMSHomeLinkSettingCell";

@interface IMSLinkMineViewController () <UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomLayout;

@property (weak, nonatomic) IBOutlet UIImageView *headerImageView;
@property (weak, nonatomic) IBOutlet UILabel *headerLabel;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic, strong) NSArray <IMSHomelinkHouseModel *>* houses;

@property (nonatomic, assign) BOOL needsUpate;

@end

@implementation IMSLinkMineViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self initView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:YES animated:animated];
}

#pragma mark - Init

- (instancetype)init {
    return [self initWithNibName:NSStringFromClass([self class]) bundle:IMSLinkPrivateBundle()];
}

- (void)initView {
    [self.tableView registerNib:[UINib nibWithNibName:@"IMSHomeLinkSettingCell" bundle:IMSLinkPrivateBundle()] forCellReuseIdentifier:IMSHomeLinkSetting];
    ALBBOpenAccountUser *user = [[ALBBOpenAccountSession sharedInstance] getUser];
	self.headerLabel.text = 	user.displayName.length > 0 ? user.displayName : user.mobile;

    if (@available(iOS 11.0, *)) {
        self.tableView.contentInsetAdjustmentBehavior = UIApplicationBackgroundFetchIntervalNever;
    } else {
        self.automaticallyAdjustsScrollViewInsets = false;
    }
    self.tableView.backgroundColor = [UIColor ims_colorWithHexRGB:0xF6F6F6];
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 1) {
        return 1;
    }
    return self.houses.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    IMSHomeLinkSettingCell *cell = [tableView dequeueReusableCellWithIdentifier:IMSHomeLinkSetting];
    cell.badgeView.hidden = YES;
    cell.arrowRightView.hidden = NO;
    cell.titleLabel.textColor = IMSLinkColorRGB(51, 51, 51);
    cell.lineView.hidden = (indexPath.row == (self.houses.count - 1))||(indexPath.section != 0 && indexPath.row == 1) ? YES : NO;
    if (indexPath.section == 0) {
		IMSHomelinkHouseModel *item = self.houses[indexPath.row];
        cell.titleLabel.text = item.houseName;
        return cell;
    } else {
		if (indexPath.row == 0) {
            cell.titleLabel.text = @"天猫精灵";
			cell.badgeView.hidden = YES;
		}
//        else {
//			cell.titleLabel.text = @"固件升级";
//			cell.badgeView.hidden = YES;
//		}
        return cell;
    }
}

#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (self.houses.count == 0) {
        return 10.0f;
    } else {
        return 20.0f;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.01;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
		
    } else {
		if (indexPath.row == 0) {
			IMSThirdPartyDetailViewController *vc = [[IMSThirdPartyDetailViewController alloc] init];
			vc.hidesBottomBarWhenPushed = YES;
			[self.navigationController pushViewController:vc animated:YES];
		} else if (indexPath.row == 1) {
			IMSOTAUpgradeDeviceListViewController *otavc = [[IMSOTAUpgradeDeviceListViewController alloc] init];
			otavc.hidesBottomBarWhenPushed = YES;
			[self.navigationController pushViewController:otavc animated:YES];
		}
    }
}

#pragma mark - Public
- (void)setNeedsUpdateList {
    self.needsUpate = YES;
}

- (IBAction)accountSettingClick:(UITapGestureRecognizer *)sender {
	IMSUserSettingViewController *userSettingVC = [[IMSUserSettingViewController alloc] init];
	[self.navigationController pushViewController:userSettingVC animated:YES];
}

@end
