//
//  IMSModifyUserNameViewController.m
//  IMSHomeLink
//
//  Created by 冯君骅 on 2019/4/9.
//

#import "IMSModifyUserNameViewController.h"
#import "IMSLinkUntil.h"
#import <IMSHUD/IMSHUD.h>
#import <IMSCategory/IMSCategory.h>

#import <ALBBOpenAccountCloud/ALBBOpenAccountService.h>
#import <ALBBOpenAccountCloud/ALBBOpenAccountSDK.h>

@interface IMSModifyUserNameViewController ()

@property (weak, nonatomic) IBOutlet UITextField *nameTextField;

@end

@implementation IMSModifyUserNameViewController

- (instancetype)init {
	return [[UIStoryboard storyboardWithName:NSStringFromClass([IMSModifyUserNameViewController class]) bundle:IMSLinkPrivateBundle()] instantiateInitialViewController];
}

- (void)viewDidLoad {
    [super viewDidLoad];
	[self.nameTextField becomeFirstResponder];
	if (self.name.length > 0) {
		self.nameTextField.text = self.name;
	}
	UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithTitle:@"完成" style:UIBarButtonItemStyleDone target:self action:@selector(finishButtonClick:)];
	[rightItem setTintColor:[UIColor ims_systemMaticColor]];
	rightItem.width = 45;
	self.navigationItem.rightBarButtonItem = rightItem;

}

- (IBAction)delButtonClick:(UIButton *)sender {
	self.nameTextField.text = @"";
}

- (void)finishButtonClick:(UIBarButtonItem *)item {
	__weak typeof(self) weakSelf = self;
	[self ims_showHUDWithIndicator];
	[ALBBService(ALBBOpenAccountService) updateAccountProfile:@{@"displayName" : self.nameTextField.text} Callback:^(NSError *error) {
		[weakSelf ims_hideHUD];
		if (error == nil) {
			[weakSelf ims_showHUDWithMessage:@"保存成功"];
			dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
				[weakSelf.navigationController popViewControllerAnimated:YES];
			});
		} else {
			[weakSelf ims_showHUDWithMessage:error.userInfo[NSLocalizedDescriptionKey]];
		}
	}];
	
}

@end
