//
//  IMSHomeTabBarViewController.m
//  IMSHomeLink
//
//  Created by 冯君骅 on 2018/6/1.
//

#import "IMSHomeTabBarViewController.h"
#import <IMSDevice/IMSDeviceHomeViewController.h>
#import <IMSHomeLinkApiClient/IMSHomeLinkApiClient.h>
#import "UITabBarItem+IMSHomeLink.h"
#import "IMSLinkUntil.h"

#import "IMSLinkMineViewController.h"
@interface IMSHomeTabBarViewController ()

@end

@implementation IMSHomeTabBarViewController

- (instancetype)init {
	if (self = [super init]) {
		
        IMSDeviceHomeViewController *mainvc = [[IMSDeviceHomeViewController alloc] init];
        UINavigationController *mainNavi = [[UINavigationController alloc] initWithRootViewController:mainvc];
		
        mainNavi.tabBarItem = [UITabBarItem ims_tabBarItemWithTitle:@"设备" image:IMSLinkImageNamed(@"IMSHomeLink_device") selectedImage:IMSLinkImageNamed(@"IMSHomeLink_device_selected")];;
        [self addChildViewController:mainNavi];

		IMSLinkMineViewController *minevc = [[IMSLinkMineViewController alloc] init];
        UINavigationController *mineNavi = [[UINavigationController alloc] initWithRootViewController:minevc];
        mineNavi.navigationBar.translucent = NO;
		mineNavi.tabBarItem = [UITabBarItem ims_tabBarItemWithTitle:@"我的" image:IMSLinkImageNamed(@"IMSHomeLink_profile") selectedImage:IMSLinkImageNamed(@"IMSHomeLink_profile_selected")];;
		[self addChildViewController:mineNavi];
		
	}
	return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
	
}


@end
