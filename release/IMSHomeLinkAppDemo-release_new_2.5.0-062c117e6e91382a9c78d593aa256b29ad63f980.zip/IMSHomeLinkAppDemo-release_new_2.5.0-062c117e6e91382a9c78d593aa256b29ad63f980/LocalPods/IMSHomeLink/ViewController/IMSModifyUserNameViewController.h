//
//  IMSModifyUserNameViewController.h
//  IMSHomeLink
//
//  Created by 冯君骅 on 2019/4/9.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface IMSModifyUserNameViewController : UITableViewController

@property (copy, nonatomic) NSString *name;

@end

NS_ASSUME_NONNULL_END
