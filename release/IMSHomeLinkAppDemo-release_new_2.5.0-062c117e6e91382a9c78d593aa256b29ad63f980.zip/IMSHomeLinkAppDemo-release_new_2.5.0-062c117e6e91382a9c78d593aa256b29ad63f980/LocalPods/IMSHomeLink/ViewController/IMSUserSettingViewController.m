//
//  IMSUserSettingViewController.m
//  IMSHomeLink
//
//  Created by 冯君骅 on 2019/4/9.
//

#import "IMSUserSettingViewController.h"
#import "IMSLinkUntil.h"
#import "IMSModifyUserNameViewController.h"
#import <IMSOpenAccountBase/IMSOpenAccountBase.h>
#import <IMSCategory/IMSCategory.h>

#import <ALBBOpenAccountCloud/ALBBOpenAccountSDK.h>
#import <ALBBOpenAccountCloud/ALBBOpenAccountUser.h>
#import <IMSAccount/IMSAccountService.h>

typedef NS_ENUM(NSUInteger,IMSUserSettingModule) {
	IMSUserSettingModuleModifyName = 2,
	IMSUserSettingModuleModifyPassword = 5,
	IMSUserSettingModuleModifyLogout = 7
};

@interface IMSUserSettingViewController ()
@property (weak, nonatomic) IBOutlet UILabel *displayNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *accountIdLabel;

@end

@implementation IMSUserSettingViewController

- (instancetype)init {
	return [[UIStoryboard storyboardWithName:NSStringFromClass([IMSUserSettingViewController class]) bundle:IMSLinkPrivateBundle()] instantiateInitialViewController];
}

- (void)viewDidLoad {
    [super viewDidLoad];
	
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	self.navigationController.navigationBarHidden = NO;
	
	ALBBOpenAccountUser *user = [[ALBBOpenAccountSession sharedInstance] getUser];
	self.displayNameLabel.text = 	user.displayName.length > 0 ? user.displayName : @"点击设置";
	self.accountIdLabel.text = user.mobile;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	
	if (indexPath.row == IMSUserSettingModuleModifyName) {
		
		IMSModifyUserNameViewController *vc = [[IMSModifyUserNameViewController alloc] init];
		ALBBOpenAccountUser *user = [[ALBBOpenAccountSession sharedInstance] getUser];
		vc.name = user.displayName;
		
		[self.navigationController pushViewController:vc animated:YES];
		
	} else if (indexPath.row == IMSUserSettingModuleModifyPassword) {
		
		[[IMSOpenAccountUICustom sharedInstance] pushFindPwdViewControllerWithNavigationController:self.navigationController];
		
	} else if (indexPath.row == IMSUserSettingModuleModifyLogout) {
		[self logoutWithAlert];
	}
}

- (void)logoutWithAlert {
	UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:@"是否要退出当前账号" preferredStyle:UIAlertControllerStyleActionSheet];
	
	UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * action) {
	}];
	UIAlertAction *logoutAction = [UIAlertAction actionWithTitle:@"退出登录" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * action) {
		
		//发送一个退出登通知，便于其他业务处理退出时候需要执行的操作
		[[NSNotificationCenter defaultCenter] postNotificationName:@"IMS_OPENACCOUNT_USER_LOGOUT_OUT" object:self];
		dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
			[[IMSAccountService sharedService] logout];
		});
	}];
	
	[alert ims_addAction:cancelAction];
	[alert ims_changeColorWithAction:logoutAction color:[UIColor ims_negativeColor]];
	[alert ims_addAction:logoutAction];
	[self presentViewController:alert animated:YES completion:nil];
}

@end
