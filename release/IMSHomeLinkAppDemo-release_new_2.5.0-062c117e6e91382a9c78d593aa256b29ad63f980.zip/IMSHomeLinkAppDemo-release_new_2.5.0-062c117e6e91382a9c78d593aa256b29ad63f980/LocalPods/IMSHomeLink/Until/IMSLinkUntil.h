//
//  IMSLinkUntil.h
//  IMSHomeLink
//
//  Created by X i n long Li on 2018/5/30.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#ifndef IMSLinkUntil_h
#define IMSLinkUntil_h

static NSString *IMSLinkBundleName = @"IMSHomeLink";

static inline NSBundle *IMSLinkPrivateBundle() {
    NSString *bundlePath = [[NSBundle mainBundle] pathForResource:IMSLinkBundleName ofType:@"bundle"];
    return [NSBundle bundleWithPath:bundlePath];
}

static inline UIImage *IMSLinkImageNamed(NSString *imageName) {
    UIImage *image = [UIImage imageNamed:imageName inBundle:IMSLinkPrivateBundle() compatibleWithTraitCollection:nil];
    return [image imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)];
}

static inline UIColor *IMSLinkColorRGB(CGFloat red, CGFloat green, CGFloat blue) {
    return [UIColor colorWithRed:red / 255.0 green:green / 255.0 blue:blue / 255.0 alpha:1.0];
}

#endif /* IMSLinkUntil_h */
