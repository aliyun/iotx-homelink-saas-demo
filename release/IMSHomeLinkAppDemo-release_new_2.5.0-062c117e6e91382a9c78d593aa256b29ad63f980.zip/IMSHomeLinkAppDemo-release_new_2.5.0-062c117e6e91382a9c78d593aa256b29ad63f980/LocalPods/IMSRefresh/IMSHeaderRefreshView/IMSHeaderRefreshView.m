//
//  IMSHeaderRefreshView.h
//  Pods
//
//  Created by Cai Xiaomin on 2018/3/22.
//  Modify by 冯君骅 on 2018/3/20
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSHeaderRefreshView.h"
#import <Masonry/Masonry.h>
@interface IMSHeaderRefreshView ()
@property (nonatomic, strong) UIImageView *headerImageView;
@end

@implementation IMSHeaderRefreshView

#pragma mark - 重写方法
#pragma mark 在这里做一些初始化配置（比如添加子控件）
- (void)prepare {
	[super prepare];
	// 设置控件的高度
	self.mj_h = 50;
	[self headerImageView];
}

- (UIImageView*)headerImageView {
	if (_headerImageView == nil) {
		UIImageView *imageView = [[UIImageView alloc] init];
//		imageView.backgroundColor = [UIColor clearColor];
		imageView.image = [UIImage imageNamed:@"IMSRefresh.bundle/Oval"];
		[self addSubview:imageView];

		[imageView mas_makeConstraints:^(MASConstraintMaker *make) {
		    make.center.mas_equalTo(self);
		    make.width.mas_equalTo(@20);
		    make.height.mas_equalTo(@20);
		}];
		_headerImageView = imageView;

	}
	return _headerImageView;
}

- (void)setState:(MJRefreshState)state {
	MJRefreshState oldState = self.state; \
	if (state == oldState) return; \
	[super setState:state];

	// 根据状态做事情
	if (state == MJRefreshStateIdle) {
		if (oldState == MJRefreshStateRefreshing) {
			dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
				[self.headerImageView.layer removeAllAnimations];
			});
		}
	} else if (state == MJRefreshStatePulling) {
	} else if (state == MJRefreshStateRefreshing) {
		CABasicAnimation* animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
		animation.fromValue = [NSNumber numberWithFloat:0.0f];
		animation.toValue = [NSNumber numberWithFloat: 2*M_PI];
		animation.duration = 1;
		animation.repeatCount = INFINITY;
		animation.removedOnCompletion = NO;
		[self.headerImageView.layer addAnimation:animation forKey:@"SpinAnimation"];
	}
}
@end
