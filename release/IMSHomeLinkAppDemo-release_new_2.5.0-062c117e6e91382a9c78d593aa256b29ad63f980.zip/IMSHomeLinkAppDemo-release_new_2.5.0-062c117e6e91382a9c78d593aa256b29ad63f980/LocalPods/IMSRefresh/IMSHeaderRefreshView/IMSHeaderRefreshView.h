//
//  IMSHeaderRefreshView.h
//  Pods
//
//  Created by Cai Xiaomin on 2018/3/22.
//  Modify by 冯君骅 on 2018/3/20
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//
//

#import <MJRefresh/MJRefresh.h>

@interface IMSHeaderRefreshView : MJRefreshHeader

@end
