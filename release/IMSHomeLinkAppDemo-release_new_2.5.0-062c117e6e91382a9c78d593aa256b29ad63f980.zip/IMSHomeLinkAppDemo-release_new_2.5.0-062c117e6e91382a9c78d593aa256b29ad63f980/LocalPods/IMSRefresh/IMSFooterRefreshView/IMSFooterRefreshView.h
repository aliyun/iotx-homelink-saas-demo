//
//  IMSFooterRefreshView.h
//  Pods
//
//  Created by Cai Xiaomin on 2017/6/16.
//  Modify by 冯君骅 on 2018/3/20
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//
//

#import <MJRefresh/MJRefresh.h>

@interface IMSFooterRefreshView : MJRefreshAutoFooter
@end
