//
//  IMSFooterRefreshView.m
//  Pods
//
//  Created by Cai Xiaomin on 2017/6/16.
//  Modify by 冯君骅 on 2018/3/20
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//
//

#import "IMSFooterRefreshView.h"
#import <Masonry/Masonry.h>
@interface IMSFooterRefreshView()
@property (strong, nonatomic) UIImageView *headerImageView;
/** 所有状态对应的文字 */
@end

@implementation IMSFooterRefreshView

#define kFontName1 @"PingFangSC-Regular"

- (UIImageView *)headerImageView {
	if (!_headerImageView) {

		UIImageView *imageView = [[UIImageView alloc] init];
		imageView.image = [UIImage imageNamed:@"IMSRefresh.bundle/Oval"];
		[self addSubview:imageView];

		[imageView mas_makeConstraints:^(MASConstraintMaker *make) {
		    make.centerY.mas_equalTo(self);
		    make.centerX.mas_equalTo(self);
		    make.width.mas_equalTo(@20);
		    make.height.mas_equalTo(@20);
		}];

		_headerImageView = imageView;
	}
	return _headerImageView;
}

#pragma mark - 重写父类的方法
- (void)prepare {
	[super prepare];
	[self headerImageView];
	self.automaticallyHidden = YES;
}

- (void)setState:(MJRefreshState)state {
    MJRefreshCheckState
	
	if (state == MJRefreshStateRefreshing) {
		self.headerImageView.hidden = NO;
		CABasicAnimation* animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
		animation.fromValue = [NSNumber numberWithFloat:0.0f];
		animation.toValue = [NSNumber numberWithFloat: 2*M_PI];
		animation.duration = 1;
		animation.repeatCount = INFINITY;
		animation.removedOnCompletion = NO;
		[self.headerImageView.layer addAnimation:animation forKey:@"SpinAnimation"];
	} else {
		[self.headerImageView.layer removeAllAnimations];
		self.headerImageView.hidden = YES;
	}
}

@end
