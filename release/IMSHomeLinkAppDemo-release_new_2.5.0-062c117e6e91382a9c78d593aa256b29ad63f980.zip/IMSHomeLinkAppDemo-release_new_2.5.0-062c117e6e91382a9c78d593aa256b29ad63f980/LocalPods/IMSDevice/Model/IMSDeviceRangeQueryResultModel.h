//
//  IMSDeviceRangeQueryResultModel.h
//  CocoaAsyncSocket
//
//  Created by jinstr520 on 2018/4/12.
//

#import <Mantle/Mantle.h>

@interface IMSDeviceRangeQueryResultModel : MTLModel<MTLJSONSerializing>

/**
 数据总数
 */
@property (nonatomic, assign) NSInteger totalNum;

/**
 数据列表
 */
@property (nonatomic, copy) NSArray *items;

@end























