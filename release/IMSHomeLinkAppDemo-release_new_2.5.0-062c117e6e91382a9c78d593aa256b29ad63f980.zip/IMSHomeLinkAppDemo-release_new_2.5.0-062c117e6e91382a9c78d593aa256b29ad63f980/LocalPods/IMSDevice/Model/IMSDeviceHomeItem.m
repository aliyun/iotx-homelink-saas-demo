//
//  IMSDeviceHomeItem.m
//  IMSScene
//
//  Created by X i n long Li on 2018/4/14.
//

#import "IMSDeviceHomeItem.h"

@implementation IMSDeviceHomeItem

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
    return @{@"identityId":@"identityId",
             @"iotId":@"iotId",
             @"productKey":@"productKey",
             @"isOwned":@"owned",
             @"status":@"status",
             @"productName":@"productName",
             @"productImage":@"productImage",
             @"netType":@"netType",
             @"nodeType":@"nodeType",
             @"thingType":@"thingType",
             @"nickName":@"nickName",
             @"deviceName":@"deviceName",
             @"propertyDTOList":@"propertyDTOList"
             };
}

+ (NSValueTransformer *)propertyDTOListJSONTransformer {
    return [MTLJSONAdapter arrayTransformerWithModelClass:IMSDevicePropertyItem.class];
}

+ (NSValueTransformer *)statusJSONTransformer {
    return [MTLValueTransformer transformerUsingForwardBlock:^id(id value, BOOL *success, NSError *__autoreleasing *error) {
        if ([value isKindOfClass:[NSNumber class]]) {
            if ([value isEqual:@(1)]) {
                return @(IMSDeviceHomeStatusOnlined);
            } else if ([value isEqual:@(3)]) {
                return @(IMSDeviceHomeStatusOffline);
            } else if ([value isEqual:@(8)]) {
                return @(IMSDeviceHomeStatusDisable);
            } else if ([value isEqual:@(1000)]) {
                return @(IMSDeviceHomeStatusLocalOnlined);
            } else{
                return @(IMSDeviceHomeStatusNormal);
            }
        }
        return @(IMSDeviceHomeStatusNormal);
    }];
}

@end


@implementation IMSDevicePropertyItem

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
    return @{
             @"identifier" : @"identifier",
             @"name" : @"name",
             @"value" : @"value",
             @"dataType" : @"dataType"
             };
}

@end
