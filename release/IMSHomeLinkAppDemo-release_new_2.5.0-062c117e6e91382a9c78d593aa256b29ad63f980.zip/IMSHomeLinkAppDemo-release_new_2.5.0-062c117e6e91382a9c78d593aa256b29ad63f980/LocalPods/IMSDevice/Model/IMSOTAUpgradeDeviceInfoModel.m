//
//  IMSOTAUpgradeDeviceInfoModel.m
//  CocoaAsyncSocket
//
//  Created by jinstr520 on 2018/4/16.
//

#import "IMSOTAUpgradeDeviceInfoModel.h"

@implementation IMSOTAUpgradeDeviceInfoModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
    return @{
             @"iotId" : @"iotId",
             @"image" : @"image",
             @"deviceName" : @"deviceName",
             };
}

@end
