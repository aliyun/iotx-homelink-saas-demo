//
//  IMSDeviceRangeQueryResultModel.m
//  CocoaAsyncSocket
//
//  Created by jinstr520 on 2018/4/12.
//

#import "IMSDeviceRangeQueryResultModel.h"

@implementation IMSDeviceRangeQueryResultModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
    return @{
             @"totalNum":@"total",
             @"items":@"data"
             };
}

@end





















