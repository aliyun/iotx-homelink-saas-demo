//
//  IMSDeviceGroupInfoModel.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/6/4.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSDeviceGroupInfoModel.h"

@implementation IMSDeviceGroupInfoModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
    return @{
             @"houseId" : @"houseId",
             @"roomId" : @"roomId",
             @"name" : @"roomName",
             @"deviceCount" : @"deviceCount",
             @"deviceCount" : @"deviceCount"
             };
}

@end
