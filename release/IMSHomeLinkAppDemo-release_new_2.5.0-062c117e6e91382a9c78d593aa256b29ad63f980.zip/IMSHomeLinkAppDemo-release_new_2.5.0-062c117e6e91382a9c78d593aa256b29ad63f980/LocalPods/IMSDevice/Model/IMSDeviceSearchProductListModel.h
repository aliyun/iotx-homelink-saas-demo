//
//  IMSDeviceSearchProductListModel.h
//  Bolts
//
//  Created by chuntao.wang1 on 2018/12/14.
//

#import <Mantle/Mantle.h>

NS_ASSUME_NONNULL_BEGIN

@interface IMSDeviceSearchProductListModel : MTLModel<MTLJSONSerializing,NSCoding>
//产品PK
@property (nonatomic, copy) NSString *productKey;
//产品DN
@property (nonatomic, copy) NSString *productName;
// 图片
@property (nonatomic, copy) NSString *productImage;
@end


NS_ASSUME_NONNULL_END
