//
//  IMSOTAUpgradeDeviceInfoModel.h
//  CocoaAsyncSocket
//
//  Created by jinstr520 on 2018/4/16.
//

#import <Mantle/Mantle.h>

@interface IMSOTAUpgradeDeviceInfoModel : MTLModel<MTLJSONSerializing>

/**
 设备id
 */
@property (nonatomic, copy) NSString *iotId;

/**
 设备图标
 */
@property (nonatomic, copy) NSString *image;

/**
 设备名称
 */
@property (nonatomic, copy) NSString *deviceName;

@end















