//
//  IMSDeviceLocalProductInfoModel.m
//  CocoaAsyncSocket
//
//  Created by jinstr520 on 2018/4/19.
//

#import "IMSDeviceProductInfoModel.h"

@implementation IMSDeviceProductInfoModel

- (void)setNilValueForKey:(NSString *)key{
    if ([key isEqualToString:@"netType"]) {
        self.netType = IMSDeviceCategoryProductNetTypeLORA;
    } else if ([key isEqualToString:@"nodeType"]) {
        self.nodeType = IMSDeviceCategoryProductNodeTypeDEVICE;
    } else {
        [super setNilValueForKey:key];
    }
}

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
    return @{
             @"categoryId": @"categoryId",
             @"categoryKey": @"categoryKey",
             @"categoryName": @"categoryName",
             @"productName": @"productName",
             @"productKey": @"productKey",
             @"productId": @"productId",
             @"netType": @"netType",
             @"nodeType": @"nodeType",
             @"image":@"image",
             @"categoryUrl":@"categoryUrl",
             };
}

+ (NSValueTransformer *)netTypeJSONTransformer {
    return [MTLValueTransformer transformerUsingForwardBlock:^id(id value, BOOL *success, NSError *__autoreleasing *error) {
        if ([value isKindOfClass:[NSString class]]) {
            if ([value isEqualToString:@"NET_WIFI"]) {
                return @(IMSDeviceCategoryProductNetTypeWIFI);
            } else if ([value isEqualToString:@"NET_BT"]) {
                return @(IMSDeviceCategoryProductNetTypeBT);
            } else if ([value isEqualToString:@"NET_ZIGBEE"]) {
                return @(IMSDeviceCategoryProductNetTypeZIGBEE);
            } else if ([value isEqualToString:@"NET_CELLULAR"]) {
                return @(IMSDeviceCategoryProductNetTypeCELLULAR);
            } else if ([value isEqualToString:@"NET_ETHERNET"]) {
                return @(IMSDeviceCategoryProductNetTypeETHERNET);
            } else if ([value isEqualToString:@"NET_OTHER"]) {
                return @(IMSDeviceCategoryProductNetTypeOTHER);
            } else {
                return value;
            }
        }
        
        return value;
    }];
}

+ (NSValueTransformer *)nodeTypeJSONTransformer {
    return [MTLValueTransformer transformerUsingForwardBlock:^id(id value, BOOL *success, NSError *__autoreleasing *error) {
        if ([value isKindOfClass:[NSString class]]) {
            if ([value isEqualToString:@"DEVICE"]) {
                return @(IMSDeviceCategoryProductNodeTypeDEVICE);
            } else if ([value isEqualToString:@"GATEWAY"]) {
                return @(IMSDeviceCategoryProductNodeTypeGATEWAY);
            } else {
                return value;
            }
        }
        
        return value;
    }];
}

@end























