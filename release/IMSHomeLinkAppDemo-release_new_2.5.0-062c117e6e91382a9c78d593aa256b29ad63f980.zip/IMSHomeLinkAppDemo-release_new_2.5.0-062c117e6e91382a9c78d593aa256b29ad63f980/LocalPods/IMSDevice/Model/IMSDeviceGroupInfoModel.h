//
//  IMSDeviceGroupInfoModel.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/6/4.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Mantle/Mantle.h>

@interface IMSDeviceGroupInfoModel : MTLModel<MTLJSONSerializing>

@property (nonatomic, copy) NSString *houseId;

@property (nonatomic, copy) NSString *roomId;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, strong) NSNumber *deviceCount;

@property (nonatomic, strong) NSNumber *roomOrder;

@end


