//
//  IMSDeviceSearchProductListModel.m
//  Bolts
//
//  Created by chuntao.wang1 on 2018/12/14.
//

#import "IMSDeviceSearchProductListModel.h"

@implementation IMSDeviceSearchProductListModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
    return @{
             @"productKey":@"productKey",
             @"productName":@"productName",
             @"productImage":@"productImage"
             };
}

- (void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:_productKey forKey:@"productKey"];
    [aCoder encodeObject:_productName forKey:@"productName"];
    [aCoder encodeObject:_productImage forKey:@"productImage"];
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    if (self = [super init]) {
        _productKey = [aDecoder decodeObjectForKey:@"productKey"];
        _productName = [aDecoder decodeObjectForKey:@"productName"];
        _productImage = [aDecoder decodeObjectForKey:@"productImage"];
    }
    return self;
}

@end
