//
//  IMSDeviceHomeItem.h
//  IMSScene
//
//  Created by X i n long Li on 2018/4/14.
//

#import "IMSDeviceProductInfoModel.h"

typedef NS_ENUM(NSUInteger, IMSDeviceHomeStatus) {
    IMSDeviceHomeStatusNormal,  /**< 未激活*/
    IMSDeviceHomeStatusOnlined, /**< 在线*/
    IMSDeviceHomeStatusOffline, /**< 离线*/
    IMSDeviceHomeStatusDisable,  /**< 无效*/
    IMSDeviceHomeStatusLocalOnlined, /**< 本地在线*/
};

@class IMSDevicePropertyItem;

@interface IMSDeviceHomeItem : IMSDeviceProductInfoModel

@property (nonatomic, assign) BOOL isOwned;             /**< 是否为分享设备*/
@property (nonatomic, copy) NSString *identityId;   /**< 用户身份id*/
@property (nonatomic, copy) NSString *iotId;        /**< 设备id*/
@property (nonatomic, copy) NSString *thingType;    /**< 设备类型*/
@property (nonatomic, copy) NSString *deviceName;   /**< 设备名称*/
@property (nonatomic, copy) NSString *nickName;     /**< 设备昵称*/
@property (nonatomic, copy) NSString *productImage; /**< 产品图片*/
@property (nonatomic, assign) IMSDeviceHomeStatus status; /**< 设备状态*/

@property (nonatomic, copy) NSArray <IMSDevicePropertyItem *>*propertyDTOList;
@end

@interface IMSDevicePropertyItem : MTLModel<MTLJSONSerializing>

@property (nonatomic, copy) NSString *identifier;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *value;
@property (nonatomic, copy) NSString *dataType;

@end
