//
//  IMSDeviceInfoModel.m
//  CloudApiSDK
//
//  Created by jinstr520 on 2018/5/9.
//

#import "IMSDeviceInfoModel.h"

@implementation IMSDeviceInfoModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
    NSMutableDictionary *keyPaths = [NSMutableDictionary dictionaryWithDictionary:[IMSDeviceProductInfoModel JSONKeyPathsByPropertyKey]];
    [keyPaths setObject:@"deviceName" forKey:@"deviceName"];
    [keyPaths setObject:@"productName" forKey:@"productName"];
    
    return keyPaths;
}

@end

#import <objc/runtime.h>

static void *IMSDeviceInfoIotIdKey = &IMSDeviceInfoIotIdKey;
static void *IMSDeviceInfoIsBindedKey = &IMSDeviceInfoIsBindedKey;

@implementation IMSDeviceInfoModel (LocalBluebooth)

- (void)setIotId:(NSString *)iotId {
    objc_setAssociatedObject(self, IMSDeviceInfoIotIdKey, iotId, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (NSString *)iotId {
    return objc_getAssociatedObject(self, IMSDeviceInfoIotIdKey);
}

- (void)setIsBinded:(BOOL)isBinded {
    objc_setAssociatedObject(self, IMSDeviceInfoIsBindedKey, @(isBinded), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (BOOL)isBinded {
    return [objc_getAssociatedObject(self, IMSDeviceInfoIsBindedKey) boolValue];
}

@end
