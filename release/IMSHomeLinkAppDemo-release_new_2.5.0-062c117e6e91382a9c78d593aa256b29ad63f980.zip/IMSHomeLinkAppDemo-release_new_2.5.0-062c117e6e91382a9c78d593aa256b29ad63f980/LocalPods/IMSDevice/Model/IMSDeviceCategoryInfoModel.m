//
//  IMSDeviceCategoryInfoModel.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/26.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSDeviceCategoryInfoModel.h"

@implementation IMSDeviceCategoryInfoModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
    return @{
             @"categoryId":@"id",
             @"categoryName":@"categoryName",
             @"categoryKey":@"categoryKey",
             @"superId":@"superId",
             @"image":@"imageUrl",
             };
}

@end
