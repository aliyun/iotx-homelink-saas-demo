//
//  IMSDeviceInfoModel.h
//  CloudApiSDK
//
//  Created by jinstr520 on 2018/5/9.
//

#import "IMSDeviceProductInfoModel.h"

@interface IMSDeviceInfoModel : IMSDeviceProductInfoModel

@property (nonatomic, copy) NSString *deviceName;

@end

@interface IMSDeviceInfoModel (LocalBluebooth)

@property (nonatomic, assign) BOOL isBinded;
@property (nonatomic, copy) NSString *iotId;

@end
