//
//  IMSDeviceCategoryInfoModel.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/26.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Mantle/Mantle.h>

@interface IMSDeviceCategoryInfoModel : MTLModel<MTLJSONSerializing>

/**
 类目id
 */
@property (nonatomic, copy) NSNumber *categoryId;

/**
 类目名称
 */
@property (nonatomic, copy) NSString *categoryName;

/**
 类目key
 */
@property (nonatomic, copy) NSString *categoryKey;

/**
 父类目id
 */
@property (nonatomic, copy) NSNumber *superId;

/**
 类目图标
 */
@property (nonatomic, copy) NSString *image;

@end











