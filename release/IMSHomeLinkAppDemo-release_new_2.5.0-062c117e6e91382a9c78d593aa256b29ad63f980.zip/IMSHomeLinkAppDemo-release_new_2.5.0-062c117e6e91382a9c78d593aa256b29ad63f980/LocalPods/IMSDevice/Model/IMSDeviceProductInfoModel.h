//
//  IMSDeviceLocalProductInfoModel.h
//  CocoaAsyncSocket
//
//  Created by jinstr520 on 2018/4/19.
//

#import <Mantle/Mantle.h>

typedef NS_ENUM(NSInteger, IMSDeviceCategoryProductNetType) {
    IMSDeviceCategoryProductNetTypeNone = 0,
    /**  */
    IMSDeviceCategoryProductNetTypeLORA = 1,
    /** WiFi */
    IMSDeviceCategoryProductNetTypeWIFI = 3,
    /** 局域网 */
    IMSDeviceCategoryProductNetTypeZIGBEE = 4,
    /** 蓝牙 */
    IMSDeviceCategoryProductNetTypeBT = 5,
    /** 移动网络 */
    IMSDeviceCategoryProductNetTypeCELLULAR = 6,
    /** 以太网 */
    IMSDeviceCategoryProductNetTypeETHERNET = 7,
    
    IMSDeviceCategoryProductNetTypeOTHER = 8,
};

typedef NS_ENUM(NSInteger, IMSDeviceCategoryProductNodeType) {
    /**  */
    IMSDeviceCategoryProductNodeTypeDEVICE,
    /**  */
    IMSDeviceCategoryProductNodeTypeGATEWAY,
};

@interface IMSDeviceProductInfoModel : MTLModel<MTLJSONSerializing>

/**
 类目id
 */
@property (nonatomic, copy) NSNumber *categoryId;

/**
 类目key
 */
@property (nonatomic, copy) NSString *categoryKey;

/**
 类目名称
 */
@property (nonatomic, copy) NSString *categoryName;

/**
 产品名称
 */
@property (nonatomic, copy) NSString *productName;

/**
 产品键
 */
@property (nonatomic, copy) NSString *productKey;

/**
 产品id
 */
@property (nonatomic, copy) NSNumber *productId;

/**
 入网类型
 */
@property (nonatomic, assign) IMSDeviceCategoryProductNetType netType;

/**
 节点类型
 */
@property (nonatomic, assign) IMSDeviceCategoryProductNodeType nodeType;

@property (nonatomic, copy) NSString *image;
@property (nonatomic, copy) NSString *categoryUrl;

@end






















