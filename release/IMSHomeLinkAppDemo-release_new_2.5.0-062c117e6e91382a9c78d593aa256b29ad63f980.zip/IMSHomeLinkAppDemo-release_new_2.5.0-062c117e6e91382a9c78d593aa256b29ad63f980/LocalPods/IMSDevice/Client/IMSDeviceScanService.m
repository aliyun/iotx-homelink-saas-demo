//
//  IMSDeviceScanService.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/6/5.
//  Copyright © 2018 Aliyun.com. All rights reserved.
//

#import "IMSDeviceScanService.h"
#import <IMSScanner/IMSScanner.h>
#import <IMSCategory/IMSCategory.h>
#import "IMSDeviceLog.h"

@implementation IMSDeviceScanService

+ (void)scanJudgeWithValue:(NSString *)value completionHandler:(IMSDeviceScanCallback)completion {
    BOOL handled = NO;
    
    NSString *productKey = nil;
    NSString *deviceName = nil;
    NSString *mockProductKey = nil;
    NSURL *url = [NSURL URLWithString:value];
    if ([url query]) {
        NSDictionary *params = [url ims_queryParams];
        // 查询配网对应的参数
        productKey = params[@"pk"];
        deviceName = params[@"dn"];
        mockProductKey = params[@"experience_pk"];
        IMSDeviceLogVerbose(@"scan Url:%@ productKey:%@ deviceName:%@, experienceKey:%@", url, productKey, deviceName, mockProductKey);
        if (productKey || mockProductKey) {
            handled = YES;
        }
    }
    
    NSError *error = nil;
    if (!handled) {
        error = [NSError errorWithDomain:@"IMSDeviceScanErrorHandlingErrorDomain" code:0 userInfo:@{NSLocalizedDescriptionKey : @"不支持的二维码"}];
    }
    
    if (productKey) {
        completion(productKey, deviceName, IMSDeviceProductTypeReal, error);
    } else {
        completion(mockProductKey, deviceName, IMSDeviceProductTypeVirtual, error);
    }
    
}

@end




