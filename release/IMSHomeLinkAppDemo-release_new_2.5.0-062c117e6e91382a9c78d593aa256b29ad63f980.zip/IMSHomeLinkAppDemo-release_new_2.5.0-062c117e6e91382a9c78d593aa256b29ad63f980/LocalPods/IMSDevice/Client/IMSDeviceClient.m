//
//  IMSDeviceClient.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/30.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSDeviceClient.h"
#import <IMSApiClient/IMSApiClient.h>
#import <IMSHomeLinkApiClient/IMSHomeLinkApiClient.h>

#import <IMSAuthentication/IMSAuthentication.h>
#import "IMSDeviceLog.h"
#import "IMSDeviceRangeQueryResultModel.h"
#import "IMSDeviceCategoryInfoModel.h"
#import "IMSOTAUpgradeDeviceInfoModel.h"
#import "IMSOTAFirmwareInfoModel.h"
#import "IMSOTAProgressInfoModel.h"
#import "IMSDeviceInfoModel.h"
#import "IMSDeviceGroupInfoModel.h"
#import "IMSDeviceSearchProductListModel.h"
#import "IMSDeviceHomeItem.h"

#import <ALBBOpenAccountSSO/ALBBOpenAccountSSOService.h>
#import <IMSAuthentication/IMSCredentialManager.h>

NSString *IMSDeviceServerErrorDomain = @"ServerErrorDomain";

@implementation IMSDeviceClient

+ (instancetype)sharedClient {
    static IMSDeviceClient *client = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        client = [[[self class] alloc] init];
    });
    
    return client;
}


- (id)init {
    if (self = [super init]) {
        [IMSLog registerTag:LOGTAG_DEVICE];
    }
    
    return self;
}

#pragma mark -

- (void)requestWithPath:(NSString *)path
                version:(NSString *)version
                 params:(NSDictionary *)params
      completionHandler:(void (^)(NSError *error, id data))completionHandler {
	[[IMSHomeLinkApiClient sharedClient] requestWithPath:path version:version params:params completoinHandler:^(id data, NSError *error) {
		if (completionHandler) {
			completionHandler(error, data);
		}
	}];
	
}

#pragma mark - 添加设备

- (void)queryProductInfoWithProductKey:(NSString *)key
                     completionHandler:(void (^)(IMSDeviceProductInfoModel *productInfo, NSError *error))completionHandler {
    NSString *path = @"/thing/detailInfo/queryProductInfoByProductKey";
    NSString *version = @"1.1.2";
    
    NSDictionary *params = @{
                             @"productKey": key ?: @"",
                             };
    
    [self requestWithPath:path version:version params:params completionHandler:^(NSError *error, id data) {
        if (completionHandler) {
            if (error) {
                completionHandler(nil, error);
            } else {
                IMSDeviceProductInfoModel *productInfo = [MTLJSONAdapter modelOfClass:[IMSDeviceProductInfoModel class] fromJSONDictionary:data error:&error];
                completionHandler(productInfo, nil);
            }
        }
    }];
}


- (void)queryProductInfoWithIotId:(NSString *)iotId
                completionHandler:(void (^)(IMSDeviceProductInfoModel *productInfo, NSError *error))completionHandler{
    NSString *path = @"/home/app/device/get";
    NSString *version = @"1.0.0";
    
    NSDictionary *params = @{
                             @"iotId": iotId ?: @""
                             };
    
    [self requestWithPath:path version:version params:params completionHandler:^(NSError *error, id data) {
        if (completionHandler) {
            if (error) {
                completionHandler(nil, error);
            } else {
                IMSDeviceProductInfoModel *productInfo = [MTLJSONAdapter modelOfClass:[IMSDeviceProductInfoModel class] fromJSONDictionary:data error:&error];
                completionHandler(productInfo, nil);
            }
        }
    }];
}


- (void)queryBlueToothDeviceMacWithIotId:(NSString *)iotId
                       completionHandler:(void (^)(NSString *mac, NSError *error))completionHandler {
    NSString *path = @"/thing/extended/property/get";
    NSString *version = @"1.0.2";
    
    NSDictionary *params = @{
                             @"iotId": iotId,
                             @"dataKey" : @"MAC"
                             };
    
    [self requestWithPath:path version:version params:params completionHandler:^(NSError *error, id data) {
        if (completionHandler) {
            if (error) {
                completionHandler(nil, error);
            } else {
                completionHandler(data, nil);
            }
        }
    }];
}


- (void)bindWifiDeviceWithProductKey:(NSString *)key
                          deviceName:(NSString *)name
                               token:(NSString *)token
                             roomIds:(NSArray *)roomIds
                   completionHandler:(void (^)(NSString *iotId, NSError *error))completionHandler {
    NSString *path = @"/awss/enrollee/user/bind";
    NSString *version = @"1.0.6";
    
    NSDictionary *params = @{
                             @"productKey" : key ?: @"",
                             @"deviceName": name ?: @"",
                             @"token": token ?: @""
                             };
    
    [self requestWithPath:path
                  version:version
                   params:params
        completionHandler:^(NSError *error, id data) {
            if (completionHandler) {
                completionHandler(data, error);
            }
        }];
}


- (void)bindGPRSDeviceWithProductKey:(NSString *)key
                          deviceName:(NSString *)name
                             roomIds:(NSArray *)roomIds
                   completionHandler:(void (^)(NSString *iotId, NSError *error))completionHandler {
    NSString *path = @"/awss/gprs/user/bind";
    NSString *version = @"1.0.6";
    
    NSDictionary *params = @{
                             @"productKey" : key ?: @"",
                             @"deviceName": name ?: @""
                             };
    
    [self requestWithPath:path
                  version:version
                   params:params
        completionHandler:^(NSError *error, id data) {
            if (completionHandler) {
                completionHandler(data, error);
            }
        }];
}

- (void)bindZIGBEEDeviceWithProductKey:(NSString *)key
                            deviceName:(NSString *)name
                               roomIds:(NSArray *)roomIds
                     completionHandler:(void (^)(NSString *iotId, NSError *error))completionHandler {
    NSString *path = @"/awss/subdevice/bind";
    NSString *version = @"1.0.6";
    
    NSDictionary *params = @{
                             @"productKey" : key ?: @"",
                             @"deviceName" : name ?: @""
                             };
    
    [self requestWithPath:path
                  version:version
                   params:params
        completionHandler:^(NSError *error, id data) {
            if (completionHandler) {
                completionHandler(data, error);
            }
        }];
}

- (void)bindBTDeviceWithProductKey:(NSString *)key
                        deviceName:(NSString *)name
                           roomIds:(NSArray *)roomIds
                 completionHandler:(void (^)(NSString *iotId, NSError *error))completionHandler {
    NSString *path = @"/awss/time/window/user/bind";
    NSString *version = @"1.0.6";
    
    NSDictionary *params = @{
                             @"productKey" : key ?: @"",
                             @"deviceName" : name ?: @""
                             };
    
    [self requestWithPath:path
                  version:version
                   params:params
        completionHandler:^(NSError *error, id data) {
            if (completionHandler) {
                completionHandler(data, error);
            }
        }];
}

- (void)homelinkUnbindDeviceWithIotId:(NSString *)iotId
                    completionHandler:(void (^)(NSError *error))completionHandler {
    NSString *path = @"/homelink/device/unbind";
    NSString *version = @"1.0.0";
    
    NSDictionary *params = @{
                             @"iotId" : iotId ?: @""
                             };
    
    [self requestWithPath:path
                  version:version
                   params:params
        completionHandler:^(NSError *error, id data) {
            if (completionHandler) {
                completionHandler(error);
            }
        }];
}

#pragma mark -

- (void)loadDeviceCategoryListWithPageNum:(NSInteger)pageNum
                                 pageSize:(NSInteger)pageSize
                        completionHandler:(void (^)(NSInteger totalNum, NSArray<IMSDeviceCategoryInfoModel *> *list, NSError *error))completionHandler {
    NSString *path = @"/home/app/category/query";
    NSString *version = @"1.0.0";
    
    NSDictionary *params = @{@"pageNo":@(pageNum),
                             @"pageSize":@(pageSize),
                             @"superId":@"-1"
    };
    
    [self requestWithPath:path
                  version:version
                   params:params
        completionHandler:^(NSError *error, id data) {
            if (completionHandler) {
                if (error) {
                    completionHandler(0, nil, error);
                } else {
                    IMSDeviceRangeQueryResultModel *mode = [MTLJSONAdapter modelOfClass:[IMSDeviceRangeQueryResultModel class] fromJSONDictionary:data error:nil];
                    NSArray *list = [MTLJSONAdapter modelsOfClass:[IMSDeviceCategoryInfoModel class] fromJSONArray:mode.items error:&error];
                    completionHandler(mode.totalNum, list, nil);
                }
            }
        }];
}

- (void)loadCategoryProductListWithPageNum:(NSInteger)pageNum
                                  pageSize:(NSInteger)pageSize
                               categoryKey:(NSString *)categoryKey
                         completionHandler:(void (^)(NSInteger totalNum, NSArray<IMSDeviceProductInfoModel *> *list, NSError *error))completionHandler {
    NSString *path = @"/home/app/product/query";
    NSString *version = @"1.0.0";
    
    NSDictionary *params = @{@"pageNo":@(pageNum), @"pageSize":@(pageSize), @"categoryKey":categoryKey?:@""};
    
    [self requestWithPath:path
                  version:version
                   params:params
        completionHandler:^(NSError *error, id data) {
            if (completionHandler) {
                if (error) {
                    completionHandler(0, nil, error);
                } else {
                    IMSDeviceRangeQueryResultModel *model = [MTLJSONAdapter modelOfClass:[IMSDeviceRangeQueryResultModel class] fromJSONDictionary:data error:nil];
                    NSArray *list = [MTLJSONAdapter modelsOfClass:[IMSDeviceProductInfoModel class] fromJSONArray:model.items error:&error];
                    completionHandler(model.totalNum, list, nil);
                }
            }
        }];
}

- (void)loadSearchDeviceListWithPageNum:(NSInteger)pageNum
                               pageSize:(NSInteger)pageSize
                            productName:(NSString *)productName
                      completionHandler:(void (^)(NSInteger totalNum, NSArray<IMSDeviceSearchProductListModel *> *list, NSError *error))completionHandler {
    NSString *path = @"/home/app/product/query";
    NSString *version = @"1.0.0";
    NSDictionary *params = @{@"productName":productName ?: @"",
                             @"pageSize":@(pageSize),
                             @"pageNo":@(pageNum)
    };
    [self requestWithPath:path
                  version:version
                   params:params
        completionHandler:^(NSError *error, id data) {
        if (completionHandler) {
            if (error || ![data isKindOfClass:[NSDictionary class]] || ![data[@"data"] isKindOfClass:[NSArray class]]) {
                completionHandler(0 ,nil ,error);
            } else {
                NSArray *list = [MTLJSONAdapter modelsOfClass:[IMSDeviceSearchProductListModel class] fromJSONArray:data[@"data"] error:&error];
                completionHandler([data[@"total"] integerValue] ,list ,nil);
            }
        }
    }];
}

- (void)filterLocalProductWithIotDevices:(NSArray<NSDictionary *> *)iotDevices
					   completionHandler:(void (^)(NSArray<IMSDeviceInfoModel *> *list, NSError *error))completionHandler {
    NSString *path = @"/awss/enrollee/product/filter";
    NSString *version = @"1.0.2";
	NSDictionary *params = @{@"iotDevices": iotDevices ?: @""};
    
    [self requestWithPath:path
                  version:version
                   params:params
        completionHandler:^(NSError *error, id data) {
            if (completionHandler) {
                if (error) {
                    completionHandler(nil, error);
                } else {
                    NSArray *list = [MTLJSONAdapter modelsOfClass:[IMSDeviceInfoModel class] fromJSONArray:data error:&error];
                    completionHandler(list, nil);
                }
            }
    }];
}

- (void)loadRoomListWithHouseId:(NSString *)houseId
                         pageNo:(NSNumber *)pageNo
                       pageSize:(NSNumber *)pageSize
              completionHandler:(void (^)(NSArray<IMSDeviceGroupInfoModel *> *list, NSError *error))completionHandler {
    NSString *path = @"/homelink/room/list";
    NSString *version = @"1.0.0";
    NSDictionary *params = @{@"houseId": houseId ?: @"", @"pageNo": pageNo, @"pageSize": pageSize};
    
    [self requestWithPath:path
                  version:version
                   params:params
        completionHandler:^(NSError *error, id data) {
            if (completionHandler) {
                if (error) {
                    completionHandler(nil, error);
                } else {
                    NSArray *list = [MTLJSONAdapter modelsOfClass:[IMSDeviceGroupInfoModel class] fromJSONArray:data[@"data"] error:&error];
                    completionHandler(list, nil);
                }
            }
        }];
}

- (void)loadOTAUpgradeDeviceListWithHouseId:(NSString *)houseId
                          completionHandler:(void (^)(NSArray<IMSOTAUpgradeDeviceInfoModel *> *list, NSError *error))completionHandler {
    NSString *path = @"/thing/ota/listByUser";
    NSString *version = @"1.0.2";
    
    NSMutableDictionary *params = @{}.mutableCopy;
    if (houseId.length > 0) {
        params[@"groupId"] = houseId;
    }
    
    [self requestWithPath:path
                  version:version
                   params:params
        completionHandler:^(NSError *error, id data) {
            if (completionHandler) {
                if (error) {
                    completionHandler(nil, error);
                } else {
                    NSArray *list = [MTLJSONAdapter modelsOfClass:[IMSOTAUpgradeDeviceInfoModel class] fromJSONArray:data error:&error];
                    completionHandler(list, nil);
                }
            }
    }];
}

- (void)loadOTAFirmwareDetailAndUpgradeStatusWithIotId:(NSString *)iotId
                                               houseId:(NSString *)houseId
                                     completionHandler:(void (^)(IMSOTAFirmwareInfoModel *firmwareInfo, IMSOTAProgressInfoModel *progressInfo, NSError *error))completionHandler {
    NSString *path = @"/thing/ota/info/progress/getByUser";
    NSString *version = @"1.0.2";
    
    NSMutableDictionary *params = @{@"iotId": iotId ?: @""}.mutableCopy;
    if (houseId.length > 0) {
        params[@"groupId"] = houseId;
    }
    
    [self requestWithPath:path
                  version:version
                   params:params
        completionHandler:^(NSError *error, id data) {
            if (completionHandler) {
                if (error) {
                    completionHandler(nil, nil, error);
                } else {
                    IMSOTAFirmwareInfoModel *firmwareInfo = [MTLJSONAdapter modelOfClass:[IMSOTAFirmwareInfoModel class] fromJSONDictionary:data[@"otaFirmwareDTO"] error:&error];
                    NSDictionary *dic = [MTLJSONAdapter JSONDictionaryFromModel:firmwareInfo error:nil];
                    NSLog(@"%@", dic);
                    IMSOTAProgressInfoModel *progressInfo = [MTLJSONAdapter modelOfClass:[IMSOTAProgressInfoModel class] fromJSONDictionary:data[@"otaUpgradeDTO"] error:&error];
                    completionHandler(firmwareInfo, progressInfo, nil);
                }
            }
        }];
}

- (void)upgradeWifiDeviceFirmwareWithIotIds:(NSArray<NSString *> *)iotIds
                                    houseId:(NSString *)houseId
                          completionHandler:(void (^)(NSDictionary *data, NSError *error))completionHandler {
    NSString *path = @"/thing/ota/batchUpgradeByUser";
    NSString *version = @"1.0.2";
    
    NSMutableDictionary *params = @{@"iotIds": iotIds ?: @[]}.mutableCopy;
    if (houseId.length > 0) {
        params[@"groupId"] = houseId;
    }
    
    [self requestWithPath:path
                  version:version
                   params:params
        completionHandler:^(NSError *error, id data) {
            if (completionHandler) {
                completionHandler(data, error);
            }
        }];
}

- (void)upgradeBluetoothDeviceFirmwareWithIotId:(NSString *)iotId
                                        houseId:(NSString *)houseId
                                firmwareVersion:(NSString *)firmwareVersion
                              completionHandler:(void (^)(NSDictionary *data, NSError *error))completionHandler {
    NSString *path = @"/thing/ota/upgradeByUser";
    NSString *version = @"1.0.1";

    NSMutableDictionary *params = @{@"iotId": iotId ?: @"", @"version": firmwareVersion ?: @""}.mutableCopy;
    if (houseId.length > 0) {
        params[@"groupId"] = houseId;
    }

    [self requestWithPath:path
                  version:version
                   params:params
        completionHandler:^(NSError *error, id data) {
            if (completionHandler) {
                completionHandler(data, error);
            }
        }];
}

static NSString *const kDeviceListPath = @"/uc/listBindingByAccount";
static NSString *const kDeviceSortPath = @"/uc/sortDevices";
static NSString *const kClientVersion = @"1.0.2";

- (void)fetchDeviceListWithPage:(NSInteger)page
                       pageSize:(NSInteger)pageSize
                       callback:(void(^)(NSError *error, NSInteger pageNo, NSArray <IMSDeviceHomeItem *>*items))callback {
    NSDictionary *params = @{@"pageNo":@(page),
                             @"pageSize":@(pageSize),
							 @"groupId":@"HOMELINK_AQUARIUS"
							 };
    [self requestWithPath:kDeviceListPath version:kClientVersion params:params completionHandler:^(NSError *error, id data) {
        NSArray *array = nil;
        NSInteger pageNo = 0;
        if (!error && [data isKindOfClass:[NSDictionary class]]) {
            NSDictionary *dic = data;
            pageNo = [dic[@"pageNo"] integerValue];
            NSArray *dataArray = dic[@"data"];
            array = [MTLJSONAdapter modelsOfClass:[IMSDeviceHomeItem class] fromJSONArray:dataArray error:nil];
        }
        if (callback) {
            callback(error, pageNo, array);
        }
    }];
}


static NSString *const kNewDeviceListPath = @"/living/productlist/account/query";
static NSString *const kNewClientVersion = @"1.0.0";

- (void)fetchDeviceListWithOffset:(NSInteger)offset
                            limit:(NSInteger)limit
                         callback:(void(^)(NSError *error, NSInteger offset, NSArray <IMSDeviceHomeItem *>*items))callback {
    NSDictionary *params = @{@"offset":@(offset),
                             @"limit":@(limit),
                             @"propertyIdentifier":@[@"LightSwitch",@"PowerSwitch",@"WorkSwitch"]};
    [self requestWithPath:kNewDeviceListPath version:kNewClientVersion params:params completionHandler:^(NSError *error, id data) {
        NSArray *array = nil;
        NSInteger pageNo = 0;
        // 此接口没有pageNo返回，自行处理，默认0
        if (!error && [data isKindOfClass:[NSDictionary class]]) {
            NSArray *dataArray = data[@"data"];
            array = [MTLJSONAdapter modelsOfClass:[IMSDeviceHomeItem class] fromJSONArray:dataArray error:nil];
        }
        if (callback) {
            callback(error, pageNo, array);
        }
    }];
}

@end
