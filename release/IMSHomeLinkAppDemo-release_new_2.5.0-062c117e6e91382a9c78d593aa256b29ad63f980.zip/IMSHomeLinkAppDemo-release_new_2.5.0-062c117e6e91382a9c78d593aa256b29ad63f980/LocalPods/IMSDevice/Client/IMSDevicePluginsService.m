//
//  IMSDeviceRouterManager.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/6/4.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSDevicePluginsService.h"
#import "IMSDeviceLog.h"
#import <IMSThingCapability/IMSThingCapability.h>

@implementation IMSDevicePluginsService

+ (void)showProvisionWithOptions:(NSDictionary *)options completionHandler:(void (^)(BOOL success))completion {
    NSURL *url = [NSURL URLWithString:@"link://router/connectConfig"];
    IMSLogDebug(@"PerformanceTag", @"{\"mod\":\"iOS\", \"event\":\"pageopen\", \"id\":\"\", \"params\":{\"pagename\":\"%@\"}}", url);
    [[IMSRouterService sharedService] openURL:url options:options completionHandler:^(BOOL success) {
        if (completion) {
            completion(success);
        }
    }];
}

+ (void)showProvisionWithProductKey:(NSString *)productKey
                         deviceName:(NSString *)deviceName
                              token:(NSString *)token
                      addDeviceFrom:(NSString *)addDeviceFrom
                            houseId:(NSString *)houseId
            routerCompletionHandler:(IMSRouterCallback)routerCompletionHandler
                  completionHandler:(void (^)(BOOL success))completion {
    if (productKey) {
        NSMutableDictionary *options = [@{@"productKey" : productKey} mutableCopy];
        options[@"deviceName"] = deviceName;
        options[@"token"] = token;
        options[@"addDeviceFrom"] = addDeviceFrom;
        options[@"groupId"] = houseId;
        options[@"isRouter"] = [NSNumber numberWithBool:YES];
        options[@"routeUrl"] = @"https://com.aliyun.iot.ilop/page/device_bind";
        //此isRouter 默认为YES, routeUrl和绑定页面Router地址一致
        options[AKRouterCompletionHandlerKey] = routerCompletionHandler;
        [IMSDevicePluginsService showProvisionWithOptions:[options copy] completionHandler:completion];
    }
}

+ (void)showDeviceControlPanelWithIotId:(NSString *)iotId
                             productKey:(NSString *)productKey
                      completionHandler:(void (^)(BOOL success))completion {
    NSDictionary *info = @{
                           @"iotId": iotId ?: @""
                           };
    [IMSDevicePluginsService showDeviceControlPanelWithProductKey:productKey options:info completionHandler:completion];
}

+ (void)showDeviceControlPanelWithProductKey:(NSString *)productKey
                                     options:(NSDictionary *)options
                           completionHandler:(void (^)(BOOL success))completion {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSString *url = [NSString stringWithFormat:@"link://router/%@", productKey ?: @""];
        IMSLogDebug(@"PerformanceTag", @"{\"mod\":\"iOS\", \"event\":\"pageopen\", \"id\":\"\", \"params\":{\"pagename\":\"device-panel-custom\"}}");
        [[IMSRouterService sharedService] openURL:[NSURL URLWithString:url] options:options completionHandler:completion];
    });
}



@end











