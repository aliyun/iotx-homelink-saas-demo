//
//  IMSDeviceClient.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/30.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@class IMSDeviceHomeItem, IMSDeviceCategoryInfoModel, IMSDeviceProductInfoModel, IMSOTAUpgradeDeviceInfoModel, IMSOTAFirmwareInfoModel, IMSOTAProgressInfoModel, IMSDeviceProductInfoModel, IMSDeviceInfoModel, IMSDeviceGroupInfoModel,IMSDeviceSearchProductListModel,IMSOTABlueToothProgressInfoModel;

@interface IMSDeviceClient : NSObject

+ (instancetype)sharedClient;

#pragma mark - 查询信息

/**
 通过ProductKey查询产品信息

 @param key key
 @param completionHandler 设备信息
 */
- (void)queryProductInfoWithProductKey:(NSString *)key
                     completionHandler:(void (^)(IMSDeviceProductInfoModel *productInfo, NSError *error))completionHandler;

/**
 通过iotId查询产品信息（netType）

 @param iotId iotId
 @param completionHandler 设备信息
 */
- (void)queryProductInfoWithIotId:(NSString *)iotId
                     completionHandler:(void (^)(IMSDeviceProductInfoModel *productInfo, NSError *error))completionHandler;

/**
 通过iotId查询产品信息（蓝牙设备Mac）

 @param iotId iotId
 @param completionHandler 设备信息
 */
- (void)queryBlueToothDeviceMacWithIotId:(NSString *)iotId
                completionHandler:(void (^)(NSString *mac, NSError *error))completionHandler;


#pragma mark - 绑定解绑

/**
 绑定wifi设备

 @param key 产品Key
 @param name 设备名称
 @param token token
 @param completionHandler 设备id
 */
- (void)bindWifiDeviceWithProductKey:(NSString *)key
                          deviceName:(NSString *)name
                               token:(NSString *)token
                             roomIds:(NSArray *)roomIds
                   completionHandler:(void (^)(NSString *iotId, NSError *error))completionHandler;

/**
 绑定GPRS设备

 @param key 产品Key
 @param name 设备名称
 @param completionHandler 设备id
 */
- (void)bindGPRSDeviceWithProductKey:(NSString *)key
                          deviceName:(NSString *)name
                             roomIds:(NSArray *)roomIds
                   completionHandler:(void (^)(NSString *iotId, NSError *error))completionHandler;

/**
 绑定ZIGBEE设备
 
 @param key 产品Key
 @param name 设备名称
 @param completionHandler 设备id
 */
- (void)bindZIGBEEDeviceWithProductKey:(NSString *)key
                            deviceName:(NSString *)name
                               roomIds:(NSArray *)roomIds
                     completionHandler:(void (^)(NSString *iotId, NSError *error))completionHandler;

/**
 绑定蓝牙设备

 @param key 产品Key
 @param name 设备名称
 @param roomIds 房间id（全屋使用）
 @param completionHandler 设备id
 */
- (void)bindBTDeviceWithProductKey:(NSString *)key
                        deviceName:(NSString *)name
                           roomIds:(NSArray *)roomIds
                 completionHandler:(void (^)(NSString *iotId, NSError *error))completionHandler;

/**
 全屋设备解绑
 
 @param iotId 设备id
 @param completionHandler <#completionHandler description#>
 */
- (void)homelinkUnbindDeviceWithIotId:(NSString *)iotId
                    completionHandler:(void (^)(NSError *error))completionHandler;


#pragma mark - 获取列表数据

/**
 获取品类列表

 @param pageNum 分页页数
 @param pageSize 分页大小
 @param completionHandler <#completionHandler description#>
 */
- (void)loadDeviceCategoryListWithPageNum:(NSInteger)pageNum
                                 pageSize:(NSInteger)pageSize
                        completionHandler:(void (^)(NSInteger totalNum, NSArray<IMSDeviceCategoryInfoModel *> *list, NSError *error))completionHandler;

/// 获取全量设备列表(搜索)
/// @param pageNum <#pageNum description#>
/// @param pageSize <#pageSize description#>
/// @param productName <#productName description#>
/// @param completionHandler <#completionHandler description#>
- (void)loadSearchDeviceListWithPageNum:(NSInteger)pageNum
                               pageSize:(NSInteger)pageSize
                            productName:(NSString *)productName
                      completionHandler:(void (^)(NSInteger totalNum, NSArray<IMSDeviceSearchProductListModel *> *list, NSError *error))completionHandler;

/**
 获取指定品类下当前支持的产品列表

 @param pageNum 分页页数
 @param pageSize 分页大小
 @param categoryKey 品类key
 @param completionHandler <#completionHandler description#>
 */
- (void)loadCategoryProductListWithPageNum:(NSInteger)pageNum
                                  pageSize:(NSInteger)pageSize
                               categoryKey:(NSString *)categoryKey
                         completionHandler:(void (^)(NSInteger totalNum, NSArray<IMSDeviceProductInfoModel *> *list, NSError *error))completionHandler;

/**
 本地发现设备过滤

 @param iotDevices 设备信息列表
 @param completionHandler 设备列表
 */
- (void)filterLocalProductWithIotDevices:(NSArray<NSDictionary *> *)iotDevices
					   completionHandler:(void (^)(NSArray<IMSDeviceInfoModel *> *list, NSError *error))completionHandler;

/**
 获取家的房间列表

 @param houseId 家id，必须
 @param completionHandler 房间列表
 */
- (void)loadRoomListWithHouseId:(NSString *)houseId
                         pageNo:(NSNumber *)pageNo
                       pageSize:(NSNumber *)pageSize
              completionHandler:(void (^)(NSArray<IMSDeviceGroupInfoModel *> *list, NSError *error))completionHandler;

/**
 查询升级设备信息列表

 @param houseId 房屋id
 @param completionHandler <#completionHandler description#>
 */
- (void)loadOTAUpgradeDeviceListWithHouseId:(NSString *)houseId
                          completionHandler:(void (^)(NSArray<IMSOTAUpgradeDeviceInfoModel *> *list, NSError *error))completionHandler;

#pragma mark - 固件升级

/**
 查询设备固件信息、升级进度

 @param iotId 设备id
 @param completionHandler <#completionHandler description#>
 */
- (void)loadOTAFirmwareDetailAndUpgradeStatusWithIotId:(NSString *)iotId
                                               houseId:(NSString *)houseId
                                     completionHandler:(void (^)(IMSOTAFirmwareInfoModel *firmwareInfo, IMSOTAProgressInfoModel *progressInfo, NSError *error))completionHandler;

/**
 wifi设备升级固件

 @param iotIds 设备id
 @param completionHandler 设备id
 */
- (void)upgradeWifiDeviceFirmwareWithIotIds:(NSArray<NSString *> *)iotIds
                                    houseId:(NSString *)houseId
                          completionHandler:(void (^)(NSDictionary *data, NSError *error))completionHandler;

/**
 蓝牙设备升级固件
 
 @param iotId 设备id
 @param completionHandler 设备id
 */
- (void)upgradeBluetoothDeviceFirmwareWithIotId:(NSString *)iotId
                                        houseId:(NSString *)houseId
                                firmwareVersion:(NSString *)firmwareVersion
                              completionHandler:(void (^)(NSDictionary *data, NSError *error))completionHandler;


#pragma mark - 首页Home数据

/**
 获取首页设备列表

 @param page 请求页码（1开始）
 @param pageSize 请求数量
 @param callback 回调
 */
- (void)fetchDeviceListWithPage:(NSInteger)page
                       pageSize:(NSInteger)pageSize
                       callback:(void(^)(NSError *error, NSInteger pageNo, NSArray <IMSDeviceHomeItem *>*items))callback;

/**
 获取首页设备列表
 
 @param offset 请求页码（0开始）
 @param limit 请求数量
 @param callback 回调
 */
- (void)fetchDeviceListWithOffset:(NSInteger)offset
                            limit:(NSInteger)limit
                         callback:(void(^)(NSError *error, NSInteger offset, NSArray <IMSDeviceHomeItem *>*items))callback;

@end










