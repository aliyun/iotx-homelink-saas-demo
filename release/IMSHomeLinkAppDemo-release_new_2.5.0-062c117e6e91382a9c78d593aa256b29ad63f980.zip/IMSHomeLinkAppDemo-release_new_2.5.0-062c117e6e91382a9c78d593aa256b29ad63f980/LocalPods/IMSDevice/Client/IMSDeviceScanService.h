//
//  IMSDeviceScanService.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/6/5.
//  Copyright © 2018 Aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, IMSDeviceProductType) {
    IMSDeviceProductTypeReal,
    IMSDeviceProductTypeVirtual
};

typedef void(^IMSDeviceScanCallback)(NSString * _Nullable productKey, NSString * _Nullable deviceName, IMSDeviceProductType type, NSError * _Nullable error);

NS_ASSUME_NONNULL_BEGIN

@interface IMSDeviceScanService : NSObject

/**
 解析扫码结果

 @param value 二维码内容
 @param completion 设备信息
 */
+ (void)scanJudgeWithValue:(NSString *)value completionHandler:(IMSDeviceScanCallback)completion;

@end

NS_ASSUME_NONNULL_END
