//
//  IMSDeviceBindService.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/6/1.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IMSDeviceProductInfoModel.h"

typedef void(^IMSBindCallback)(NSString *iotId, NSError *error);

@interface IMSDeviceBindService : NSObject

/**
 绑定设备（兼容全屋，全屋统一后删除）

 @param productKey 产品key，必传
 @param deviceName 设备名称，必传
 @param productInfo 产品信息，有则传
 @param roomIds 全屋房间id，有则传
 @param completion 绑定完成回调
 */
+ (void)bindDeviceWithProductKey:(NSString *)productKey
                      deviceName:(NSString *)deviceName
                     productInfo:(IMSDeviceProductInfoModel *)productInfo
                         roomIds:(NSArray *)roomIds
               completionHandler:(IMSBindCallback)completion;

+ (void)bindDeviceWithProductKey:(NSString *)productKey
                      deviceName:(NSString *)deviceName
                         netType:(IMSDeviceCategoryProductNetType)netType
                         roomIds:(NSArray *)roomIds
               completionHandler:(IMSBindCallback)completion;

/**
 全屋设备解绑
 
 @param iotId 设备id
 @param completion 错误信息
 */
+ (void)homelinkUnbindDeviceWithIotId:(NSString *)iotId
                    completionHandler:(void (^)(NSError *error))completion;

@end




















