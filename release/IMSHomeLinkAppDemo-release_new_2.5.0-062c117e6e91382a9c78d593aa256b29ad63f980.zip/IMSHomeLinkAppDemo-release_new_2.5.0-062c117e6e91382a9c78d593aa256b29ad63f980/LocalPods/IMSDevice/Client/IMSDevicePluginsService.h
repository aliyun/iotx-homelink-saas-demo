//
//  IMSDevicePluginsService.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/6/4.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <IMSRouter/IMSRouter.h>

@interface IMSDevicePluginsService : NSObject

/**
 打开配网插件

 @param productKey 产品key，必传
 @param deviceName 设备名称，有则传
 @param token 设备token，有则传
 @param addDeviceFrom 云端返回待配网设备来源：“ROUTER”--代表路由器发现，“ZERO_DEVICE”代表零配发现，有则传
 @param houseId 房屋id，有则传
 @param routerCompletionHandler 配网完成回调
 @param completion 打开配网插件回调
 */
+ (void)showProvisionWithProductKey:(NSString *)productKey
                         deviceName:(NSString *)deviceName
                              token:(NSString *)token
                      addDeviceFrom:(NSString *)addDeviceFrom
                            houseId:(NSString *)houseId
            routerCompletionHandler:(IMSRouterCallback)routerCompletionHandler
                  completionHandler:(void (^)(BOOL success))completion;

/**
 打开设备面板插件

 */
+ (void)showDeviceControlPanelWithIotId:(NSString *)iotId
                             productKey:(NSString *)productKey
                      completionHandler:(void (^)(BOOL success))completion;

+ (void)showDeviceControlPanelWithProductKey:(NSString *)productKey
                                     options:(NSDictionary *)options
                           completionHandler:(void (^)(BOOL success))completion;

@end
















