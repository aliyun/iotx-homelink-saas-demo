//
//  IMSDeviceCache.m
//  Bolts
//
//  Created by chuntao.wang1 on 2018/12/17.
//

#import "IMSDeviceCache.h"

#if __has_include(<IMSLocalize/IMSLocalizeConfiguration.h>)
#import <IMSLocalize/IMSLocalizeConfiguration.h>
static NSString *const kIMSSearchCurrentLanguageCodeCacheKey = @"IMSSearchCurrentLanguageCode";
#endif

static NSString *const kIMSSearchProductModelListCacheKey = @"IMSSearchProductModelListKey";
static NSString *const kIMSHomeBindDeviceListCacheKey = @"IMSHomeBindDeviceListKey";

@interface IMSDeviceCache ()

@end

@implementation IMSDeviceCache

/*
 缓存逻辑注意点:App切换系统语言，沙盒路径会改变，这时候的path，前缀不一致
 */
+ (instancetype)shareInstance {
    static id instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    
    return instance;
}

#pragma mark - 用户绑定设备
// 不用对语言处理
- (void)imsCacheHomeBindDeviceList:(NSArray<IMSDeviceHomeItem *> *)list {
    [self imsCacheHomeBindDeviceWithList:list];
}

- (void)imsCacheHomeBindDeviceAddList:(NSArray<IMSDeviceHomeItem *> *)list {
    NSMutableArray <IMSDeviceHomeItem *> *array = [[NSMutableArray alloc] init];
    NSArray <IMSDeviceHomeItem *> *oldArray = [self imsHomeBindDeviceListFromIMSdeviceCache];
    [array addObjectsFromArray:oldArray];
    [array addObjectsFromArray:list];
    [self imsCacheHomeBindDeviceWithList:list];
}

- (NSArray<IMSDeviceHomeItem *> *)imsHomeBindDeviceListFromIMSdeviceCache {
    NSData *data = [[NSUserDefaults standardUserDefaults] valueForKey:kIMSHomeBindDeviceListCacheKey];
    NSArray *array = [NSKeyedUnarchiver unarchiveObjectWithData:data];
    return array;
}

- (void)imsClearHomeBindDeviceListCache {
    [self imsCacheHomeBindDeviceWithList:nil];
}

- (void)imsCacheHomeBindDeviceWithList:(NSArray<IMSDeviceHomeItem *> *)list {
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:list];
    [[NSUserDefaults standardUserDefaults] setValue:data forKey:kIMSHomeBindDeviceListCacheKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

#pragma mark - 搜索

- (void)cacheIMSDeviceSearchAllProductModelList:(NSArray<IMSDeviceSearchProductListModel *> *)list {
    [self cacheObjectWithArray:list];
    
#if __has_include(<IMSLocalize/IMSLocalizeConfiguration.h>)
    [[NSUserDefaults standardUserDefaults] setValue:@([self cueentLanguageCode]) forKey:kIMSSearchCurrentLanguageCodeCacheKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
#endif
}

- (NSArray<IMSDeviceSearchProductListModel *> *)listFromIMSdeviceCache {
#if __has_include(<IMSLocalize/IMSLocalizeConfiguration.h>)
    if ([self isChangeSystemLanguage]) {
        return nil;
    }
#endif
    
    NSData *data = [[NSUserDefaults standardUserDefaults] valueForKey:kIMSSearchProductModelListCacheKey];
    NSArray *array = [NSKeyedUnarchiver unarchiveObjectWithData:data];
    return array;
}

- (void)clearIMSDeviceCache {
    [self cacheObjectWithArray:nil];
}

- (void)cacheObjectWithArray:(NSArray<IMSDeviceSearchProductListModel *> *)list {
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:list];
    [[NSUserDefaults standardUserDefaults] setValue:data forKey:kIMSSearchProductModelListCacheKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

#pragma mark - 语言处理

#if __has_include(<IMSLocalize/IMSLocalizeConfiguration.h>)

- (IMSLanguageCode)cueentLanguageCode {
    IMSLanguageCode code = [[IMSLocalizeConfiguration sharedInstance] languageCode];
    return code;
}

- (IMSLanguageCode)oldLanguageCode {
    IMSLanguageCode code = [[[NSUserDefaults standardUserDefaults] valueForKey:kIMSSearchCurrentLanguageCodeCacheKey] integerValue];
    return code;
}

- (BOOL)isChangeSystemLanguage {
    if ([self cueentLanguageCode] == [self oldLanguageCode]) {
        return NO;
    }
    
    return YES;
}

#endif

@end

