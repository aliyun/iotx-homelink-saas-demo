//
//  IMSBindViewModel.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/6/1.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSDeviceBindService.h"
#import <IMLDeviceCenter/IMLDeviceCenter.h>
#import "IMSDeviceLog.h"
#import "IMSDeviceClient.h"

@interface IMSDeviceBindService ()

@property (nonatomic, copy) NSString *productKey;

@property (nonatomic, copy) NSString *deviceName;

@property (nonatomic, assign) IMSDeviceCategoryProductNetType netType;

@property (nonatomic, copy) NSArray *roomIds;

@property (nonatomic, copy) IMSBindCallback bindCallback;

@end

@implementation IMSDeviceBindService
    
+ (void)bindDeviceWithProductKey:(NSString *)productKey
                      deviceName:(NSString *)deviceName
                     productInfo:(IMSDeviceProductInfoModel *)productInfo
                         roomIds:(NSArray *)roomIds
               completionHandler:(IMSBindCallback)completion
{
    IMSDeviceLogVerbose(@"绑定设备：开始绑定 pk=%@， dn=%@， productInfo=%ld, roomIds = %@",productKey, deviceName, productInfo, roomIds);
    
    IMSDeviceBindService *bindService = [[IMSDeviceBindService alloc] init];
    [bindService bindDeviceWithProductKey:productKey deviceName:deviceName netType:productInfo.netType roomIds:roomIds completionHandler:completion];
}

+ (void)bindDeviceWithProductKey:(NSString *)productKey
                      deviceName:(NSString *)deviceName
                         netType:(IMSDeviceCategoryProductNetType)netType
                         roomIds:(NSArray *)roomIds
               completionHandler:(IMSBindCallback)completion
{
    IMSDeviceLogVerbose(@"绑定设备：开始绑定 pk=%@， dn=%@， netType=%ld, roomIds = %@",productKey, deviceName, netType, roomIds);
    
    IMSDeviceBindService *bindService = [[IMSDeviceBindService alloc] init];
    [bindService bindDeviceWithProductKey:productKey deviceName:deviceName netType:netType roomIds:roomIds completionHandler:completion];
}

+ (void)homelinkUnbindDeviceWithIotId:(NSString *)iotId
                    completionHandler:(void (^)(NSError *error))completion {
    [[IMSDeviceClient sharedClient] homelinkUnbindDeviceWithIotId:iotId completionHandler:completion];
}

- (void)bindDeviceWithProductKey:(NSString *)productKey
                      deviceName:(NSString *)deviceName
                         netType:(IMSDeviceCategoryProductNetType)netType
                         roomIds:(NSArray *)roomIds
               completionHandler:(IMSBindCallback)completion {
    self.productKey = productKey;
    self.deviceName = deviceName;
    self.netType = netType;
    self.roomIds = roomIds;
    
    if (self.netType != IMSDeviceCategoryProductNetTypeNone) {
        self.bindCallback = completion;
        [self bindDeviceWithNetType:self.netType];
    } else if (self.productKey) {
        IMSDeviceLogVerbose(@"绑定设备：查询产品信息接口");
        
        [[IMSDeviceClient sharedClient] queryProductInfoWithProductKey:self.productKey completionHandler:^(IMSDeviceProductInfoModel *productInfo, NSError *error) {
            if (error) {
                IMSDeviceLogError(@"queryNetTypeWithProductKey error:%@", error);
                
                if (completion) {
                    completion(nil, error);
                }
            } else {
                IMSDeviceLogVerbose(@"productKey:%@ netType:%@", self.productKey, @(productInfo.netType));
                
                self.bindCallback = completion;
                [self bindDeviceWithNetType:productInfo.netType];
            }
        }];
    } else {
        IMSDeviceLogError(@"queryNetType error:缺少必传参数，productKey：%@", self.productKey);
        
        if (completion) {
            completion(nil, nil);
        }
    }
}

- (void)bindDeviceWithNetType:(IMSDeviceCategoryProductNetType)netType {
    if (self.productKey && self.deviceName) {
        if (netType == IMSDeviceCategoryProductNetTypeWIFI || netType == IMSDeviceCategoryProductNetTypeETHERNET) {
            [self bindWiFiTypeDevice];
        } else if (netType == IMSDeviceCategoryProductNetTypeCELLULAR) {
            [self bindGPRSTypeDevice];
        } else if (netType == IMSDeviceCategoryProductNetTypeZIGBEE || netType == IMSDeviceCategoryProductNetTypeOTHER) {
            [self bindZIGBEETypeDevice];
        } else if (netType == IMSDeviceCategoryProductNetTypeBT) {
            [self bindBTTypeDevice];
        } else {
            IMSDeviceLogError(@"error:没有匹配的netType");
            NSError *error = [NSError errorWithDomain:@"" code:0 userInfo:@{NSLocalizedDescriptionKey : @"绑定失败，请稍后再试"}];
            [self bindCompletionHandler:nil error:error];
        }
    } else {
        IMSDeviceLogError(@"error:缺少必传参数，productKey：%@，deviceName：%@", self.productKey, self.deviceName);
        
        NSError *error = [NSError errorWithDomain:@"" code:0 userInfo:@{NSLocalizedDescriptionKey : @"绑定失败，请稍后再试"}];
        [self bindCompletionHandler:nil error:error];
    }
}

#pragma mark - Request

- (void)getDeviceToken:(void(^)(NSString *token, BOOL boolSuccess))completion {
    IMSDeviceLogVerbose(@"绑定设备：开始获取设备token");
    
    [[IMLLocalDeviceMgr sharedMgr] getDeviceToken:self.productKey deviceName:self.deviceName timeout:30 interval:3 resultBlock:^(NSString *token, BOOL boolSuccess) {
        if (completion) {
            IMSDeviceLogVerbose(@"获取设备token结果：%@，boolSuccess：%d", token, boolSuccess);
            
            completion(token, boolSuccess);
        }
    }];
}

- (void)bindWiFiTypeDevice {
    [self getDeviceToken:^(NSString *token, BOOL boolSuccess) {
        if (boolSuccess && token) {
            IMSDeviceLogVerbose(@"绑定WIFI设备接口");
            
            [[IMSDeviceClient sharedClient] bindWifiDeviceWithProductKey:self.productKey deviceName:self.deviceName token:token roomIds:self.roomIds completionHandler:^(NSString *iotId, NSError *error) {
                [self bindCompletionHandler:iotId error:error];
            }];
        } else {
            IMSDeviceLogError(@"error:获取token失败，token:%@，boolSuccess:%d", token, boolSuccess);
            
            NSError *error = [NSError errorWithDomain:@"" code:0 userInfo:@{NSLocalizedDescriptionKey : @"绑定失败，请稍后再试"}];
            [self bindCompletionHandler:nil error:error];
        }
    }];
}

- (void)bindGPRSTypeDevice {
    IMSDeviceLogVerbose(@"绑定GPRS设备接口");
    
    [[IMSDeviceClient sharedClient] bindGPRSDeviceWithProductKey:self.productKey deviceName:self.deviceName roomIds:self.roomIds completionHandler:^(NSString *iotId, NSError *error) {
        [self bindCompletionHandler:iotId error:error];
    }];
}

- (void)bindZIGBEETypeDevice {
    IMSDeviceLogVerbose(@"绑定ZIGBEE设备接口");
    
    [[IMSDeviceClient sharedClient] bindZIGBEEDeviceWithProductKey:self.productKey deviceName:self.deviceName roomIds:self.roomIds completionHandler:^(NSString *iotId, NSError *error) {
        [self bindCompletionHandler:iotId error:error];
    }];
}

- (void)bindBTTypeDevice {
    IMSDeviceLogVerbose(@"绑定蓝牙设备接口");
    
    [[IMSDeviceClient sharedClient] bindBTDeviceWithProductKey:self.productKey deviceName:self.deviceName roomIds:self.roomIds completionHandler:^(NSString *iotId, NSError *error) {
        [self bindCompletionHandler:iotId error:error];
    }];
}

- (void)bindCompletionHandler:(NSString *)iotId error:(NSError *)error {
    IMSDeviceLogVerbose(@"绑定设备：完成绑定");
    
    if (self.bindCallback) {
        self.bindCallback(iotId, error);
    }
}

@end





















