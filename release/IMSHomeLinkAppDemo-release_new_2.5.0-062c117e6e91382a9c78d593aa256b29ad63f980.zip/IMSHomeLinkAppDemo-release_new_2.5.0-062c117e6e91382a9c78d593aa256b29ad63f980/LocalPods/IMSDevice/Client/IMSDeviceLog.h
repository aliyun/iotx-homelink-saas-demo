//
//  IMSDeviceLog.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/28.
//  Copyright © 2018年 alibaba. All rights reserved.
//

#ifndef IMSDeviceLog_h
#define IMSDeviceLog_h

#import <IMSLog/IMSLog.h>

#define LOGTAG_DEVICE @"IMSDevice"

#define IMSDeviceLogError(frmt, ...)       IMSLogError(LOGTAG_DEVICE, frmt, ##__VA_ARGS__)
#define IMSDeviceLogWarn(frmt, ...)        IMSLogWarn(LOGTAG_DEVICE, frmt, ##__VA_ARGS__)
#define IMSDeviceLogInfo(frmt, ...)        IMSLogInfo(LOGTAG_DEVICE, frmt, ##__VA_ARGS__)
#define IMSDeviceLogDebug(frmt, ...)       IMSLogDebug(LOGTAG_DEVICE, frmt, ##__VA_ARGS__)
#define IMSDeviceLogVerbose(frmt, ...)     IMSLogVerbose(LOGTAG_DEVICE, frmt, ##__VA_ARGS__)

#endif /* IMSDeviceLog_h */
