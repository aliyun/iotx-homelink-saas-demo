//
//  IMSDeviceCache.h
//  Bolts
//
//  Created by chuntao.wang1 on 2018/12/17.
//

#import <Foundation/Foundation.h>
#import "IMSDeviceSearchProductListModel.h"
#import "IMSDeviceHomeItem.h"

NS_ASSUME_NONNULL_BEGIN

@interface IMSDeviceCache : NSObject

+ (instancetype)shareInstance;

#pragma mark - 首页本地发现优化缓存

/**
 缓存用户绑定设备数据
 
 @param list 数组
 */
- (void)imsCacheHomeBindDeviceList:(NSArray<IMSDeviceHomeItem *> *)list;

/**
 增加用户绑定设备缓存数据
 
 @param list 数组
 */
- (void)imsCacheHomeBindDeviceAddList:(NSArray<IMSDeviceHomeItem *> *)list;

/**
 读取用户绑定设备缓存
 
 @return 数组
 */
- (NSArray<IMSDeviceHomeItem *> *)imsHomeBindDeviceListFromIMSdeviceCache;

/**
 清除用户绑定设备缓存
 */
- (void)imsClearHomeBindDeviceListCache;

#pragma mark - 搜索缓存

/**
 缓存搜索列表数据

 @param list 数组
 */
- (void)cacheIMSDeviceSearchAllProductModelList:(NSArray<IMSDeviceSearchProductListModel *> *)list;

/**
 读取搜索列表数据缓存

 @return 数组
 */
- (NSArray<IMSDeviceSearchProductListModel *> *)listFromIMSdeviceCache;

/**
 清除搜索列表数据缓存
 */
- (void)clearIMSDeviceCache;

@end

NS_ASSUME_NONNULL_END
