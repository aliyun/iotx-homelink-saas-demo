//
//  IMSHomeLinkBindCell.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/6/1.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSHomeLinkBindGroupCell.h"
#import <Masonry/Masonry.h>
#import <IMSCategory/IMSCategory.h>
#import "UIImage+IMSDeviceExtension.h"
#import "UIView+IMSDeviceExtension.h"

@interface IMSHomeLinkBindGroupCell ()

@property (nonatomic, strong) UIButton *selecteButton;

@end

@implementation IMSHomeLinkBindGroupCell {
    BOOL _choosed;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self configSelectButton];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self.selecteButton imsDevice_makeCircle];
}

- (void)setChoosed:(BOOL)choosed {
    if (_choosed != choosed) {
        _choosed = choosed;
        
        [self.selecteButton setImage:[UIImage imsDevice_imageNamed:_choosed ? @"IMSDevice_homelink_selected" : @"IMSDevice_homelink_unselected"] forState:UIControlStateNormal];
    }
}

- (UIButton *)selecteButton {
    if (!_selecteButton) {
        _selecteButton = [UIButton buttonWithType:UIButtonTypeCustom];
    }
    return _selecteButton;
}

- (void)configSelectButton {
    [self.selecteButton setImage:[UIImage imsDevice_imageNamed:@"IMSDevice_homelink_unselected"] forState:UIControlStateNormal];
    [self.selecteButton addTarget:self action:@selector(selectAction) forControlEvents:UIControlEventTouchUpInside];
    
    UIView *accessoryView = [[UIView alloc] init];
    self.accessoryView = accessoryView;
    [accessoryView addSubview:self.selecteButton];
    
    [self.selecteButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(0);
        make.right.mas_equalTo(-16);
        make.size.mas_equalTo(CGSizeMake(24, 24));
    }];
}

- (void)selectAction {
    if (self.chooseGroupClickedBlock) {
        self.chooseGroupClickedBlock(self);
    }
}

@end

#import <objc/runtime.h>
#import "IMSDeviceGroupInfoModel.h"

@implementation IMSHomeLinkBindGroupCell (IMSDeviceGroupInfoModel)

- (IMSDeviceGroupInfoModel *)groupInfo {
    return objc_getAssociatedObject(self, _cmd);
}

- (void)setGroupInfo:(IMSDeviceGroupInfoModel *)groupInfo {
    objc_setAssociatedObject(self, @selector(groupInfo), groupInfo, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    
    self.ims_textLabel.text = groupInfo.name;
}

@end








