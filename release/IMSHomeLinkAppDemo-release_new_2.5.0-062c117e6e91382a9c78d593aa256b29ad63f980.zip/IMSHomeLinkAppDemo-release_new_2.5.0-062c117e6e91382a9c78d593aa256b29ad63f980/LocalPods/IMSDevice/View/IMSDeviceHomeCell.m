//
//  IMSDeviceHomeCell.m
//  IMSDevice
//
//  Created by X i n long Li on 2018/3/30.
//

#import "IMSDeviceHomeCell.h"

#import "IMSDeviceHomeItem.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "UIColor+IMSDeviceExtension.h"
#import "UIView+IMSDeviceExtension.h"
#import <IMSCategory/IMSCategory.h>
#import "UIImage+IMSDeviceExtension.h"
#import "NSBundle+IMSDeviceExtension.h"

@interface IMSDeviceHomeCell()

@property (weak, nonatomic) IBOutlet UIImageView *deviceImageView;
@property (weak, nonatomic) IBOutlet UILabel *deviceNameLab;
@property (weak, nonatomic) IBOutlet UIView *shareBgView;
@property (weak, nonatomic) IBOutlet UILabel *shareLab;
@property (weak, nonatomic) IBOutlet UIView *virtualBgView;
@property (weak, nonatomic) IBOutlet UILabel *virtualLabel;
@property (weak, nonatomic) IBOutlet UIImageView *deviceTypeImageView;
@property (weak, nonatomic) IBOutlet UILabel *onlineStatusLab;
@property (weak, nonatomic) IBOutlet UIImageView *onlineStatusImageView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *deviceNameTopSpace;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *shareLeftSpace;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *deviceTypeSpace;
@property (assign, nonatomic) CGFloat defualtDeviceNameTopSpace;
@property (assign, nonatomic) CGFloat defualtShareLeftSpace;
@property (weak, nonatomic) IBOutlet UIButton *imsLightMaskBtn;

@end

@implementation IMSDeviceHomeCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.defualtDeviceNameTopSpace = self.deviceNameTopSpace.constant;
    self.defualtShareLeftSpace = self.shareLeftSpace.constant;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self.shareBgView imsDevice_makeCircle];
    [self.virtualBgView imsDevice_makeCircle];
}

- (IBAction)clickPropertyBlock:(id)sender {
    if (self.propertyBlock) {
        self.propertyBlock();
    }
}

- (void)setDeviceItem:(IMSDeviceHomeItem *)deviceItem {
    _deviceItem = deviceItem;
    
    [self.deviceImageView sd_setImageWithURL:[NSURL URLWithString:deviceItem.productImage] placeholderImage:[UIImage imsDevice_imageNamed:@"IMSDevice_placeholder"]];
    self.deviceNameLab.text = deviceItem.productName;
    if (deviceItem.nickName.length > 0) {
        self.deviceNameLab.text = deviceItem.nickName;
    }
    
    if (deviceItem.netType != IMSDeviceCategoryProductNetTypeBT && deviceItem.status != IMSDeviceHomeStatusOnlined && deviceItem.status != IMSDeviceHomeStatusLocalOnlined) {
        self.deviceNameLab.textColor = [UIColor ims_accessaryColor];
    } else {
        self.deviceNameLab.textColor = [UIColor ims_titleColor];
    }
    
    self.imsLightMaskBtn.hidden = YES;
    self.imsLightBtn.hidden = YES;
    if (deviceItem.netType == IMSDeviceCategoryProductNetTypeBT) {
        self.onlineStatusLab.hidden = YES;
        self.onlineStatusImageView.hidden = YES;
        self.deviceTypeImageView.hidden = NO;
        self.shareLeftSpace.constant = self.defualtShareLeftSpace;
    } else {
        self.deviceTypeImageView.hidden = YES;
        self.shareLeftSpace.constant = self.deviceTypeSpace.constant;
        self.onlineStatusLab.hidden = NO;
        self.onlineStatusLab.text = [self detailStringWithStatus:deviceItem.status];
        self.onlineStatusImageView.hidden = NO;
        self.onlineStatusImageView.image = [UIImage imsDevice_imageNamed:@"home_online_state_on"];
        
        // 1.6之前逻辑，在线离线有状态小点和文字，其他只有文字
        // 1.6之后增加逻辑：在线下属性设置开关,可控制设备开启关闭
        if (deviceItem.status == IMSDeviceHomeStatusOnlined || deviceItem.status == IMSDeviceHomeStatusLocalOnlined) {
            if (deviceItem.propertyDTOList.count != 0) {
                self.imsLightBtn.hidden = NO;
                IMSDevicePropertyItem *item = [deviceItem.propertyDTOList firstObject];
                if ([item.value isEqualToString:@"1"]) {
                    [self.imsLightBtn setImage:[UIImage imsDevice_imageNamed:@"home_device_state_open"] forState:UIControlStateNormal];
                    self.onlineStatusLab.text = @"开启";
                } else {
                    [self.imsLightBtn setImage:[UIImage imsDevice_imageNamed:@"home_device_state_close"] forState:UIControlStateNormal];
                    self.onlineStatusLab.text = @"关闭";
                    self.onlineStatusImageView.image = [UIImage imsDevice_imageNamed:@"home_online_state_off"];
                }
            }
        } else if (deviceItem.status == IMSDeviceHomeStatusOffline || deviceItem.status == IMSDeviceHomeStatusDisable) {
            self.imsLightBtn.hidden = NO;
            self.imsLightMaskBtn.hidden = NO;
            self.onlineStatusImageView.image = [UIImage imsDevice_imageNamed:@"home_online_state_off"];
            [self.imsLightBtn setImage:[UIImage imsDevice_imageNamed:@"home_device_state_offline"] forState:UIControlStateNormal];
        } else {
            self.onlineStatusImageView.hidden = YES;
        }
    }
    
    if ([deviceItem.thingType hasPrefix:@"VIRTUAL"] && !deviceItem.isOwned) {
        self.shareBgView.hidden = NO;
        self.virtualBgView.hidden = NO;
        self.shareLab.text = @"共享";
        self.virtualLabel.text = @"虚拟";

        if (!deviceItem.isOwned) {
            self.shareLab.text = @"共享";
        } else {
            self.shareLab.text = @"虚拟";
        }
    } else if (!deviceItem.isOwned) {
        self.shareBgView.hidden = NO;
        self.virtualBgView.hidden = YES;
        self.shareLab.text = @"共享";
    } else if ([deviceItem.thingType hasPrefix:@"VIRTUAL"]) {
        self.shareBgView.hidden = NO;
        self.virtualBgView.hidden = YES;
        self.shareLab.text = @"虚拟";
    } else {
        self.shareBgView.hidden = YES;
        self.virtualBgView.hidden = YES;
    }
    
    

    if (self.deviceTypeImageView.hidden && self.shareBgView.hidden) {
        self.deviceNameTopSpace.constant = self.imsDevice_height/2;
    } else {
        self.deviceNameTopSpace.constant = self.defualtDeviceNameTopSpace;
    }
}

- (NSString *)detailStringWithStatus:(IMSDeviceHomeStatus)status {
    switch (status) {
        case IMSDeviceHomeStatusOnlined:
            return @"在线";
        case IMSDeviceHomeStatusLocalOnlined:
            return @"本地在线";
        case IMSDeviceHomeStatusOffline:
            return @"离线";
        case IMSDeviceHomeStatusDisable:
            return @"禁用";
        default:
            return @"未激活";
    }
}

@end
