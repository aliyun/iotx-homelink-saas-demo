//
//  IMSHomeLinkBindCell.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/6/1.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSDeviceBasicCell.h"

@class IMSHomeLinkBindGroupCell;

typedef void(^ChooseGroupClickedBlock)(IMSHomeLinkBindGroupCell *cell);

@interface IMSHomeLinkBindGroupCell : IMSDeviceBasicCell

@property (nonatomic, copy) ChooseGroupClickedBlock chooseGroupClickedBlock;

- (void)setChoosed:(BOOL)choosed;

@end

@class IMSDeviceGroupInfoModel;

@interface IMSHomeLinkBindGroupCell (IMSDeviceGroupInfoModel)

- (IMSDeviceGroupInfoModel *)groupInfo;

- (void)setGroupInfo:(IMSDeviceGroupInfoModel *)groupInfo;

@end
