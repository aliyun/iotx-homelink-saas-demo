//
//  IMSDeviceLocalCell.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/26.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSDeviceBasicCell.h"

@class IMSDeviceLocalCell;

@interface IMSDeviceLocalCell : IMSDeviceBasicCell

@property (nonatomic, strong) UIButton *addDeviceButton;

- (void)startAddBTDeviceAnimation;
- (void)stopAddBTDeviceAnimation;

@end

@class IMSDeviceInfoModel;

@interface IMSDeviceLocalCell (IMSDeviceInfoModel)

- (IMSDeviceInfoModel *)device;

- (void)setDevice:(IMSDeviceInfoModel *)device;

- (void)updateLayout;

@end










