//
//  IMSDeviceBasicCell.m
//  CocoaAsyncSocket
//
//  Created by jinstr520 on 2018/4/15.
//

#import "IMSDeviceBasicCell.h"
#import <Masonry/Masonry.h>
#import <IMSCategory/IMSCategory.h>
#import "UIView+IMSDeviceExtension.h"
#import "UIImage+IMSDeviceExtension.h"

static CGFloat KDeviceLeftOffset = 16.0;

@implementation IMSDeviceBasicCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self configSubViews];
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    [self configSubViews];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self configAccessoryViewDefaultLayout];
}

#pragma mark - Property

- (UIImageView *)ims_imageView {
    if (!_ims_imageView) {
        _ims_imageView = [[UIImageView alloc] init];
    }
    return _ims_imageView;
}

- (UILabel *)ims_textLabel {
    if (!_ims_textLabel) {
        _ims_textLabel = [[UILabel alloc] init];
        _ims_textLabel.textColor = [UIColor ims_titleColor];
        _ims_textLabel.numberOfLines = 0;
		_ims_textLabel.font = [UIFont systemFontOfSize:14];
    }
    return _ims_textLabel;
}

- (UIView *)ims_separatorView {
    if (!_ims_separatorView) {
        _ims_separatorView = [self imsDevice_addBottomLineViewWithLeftOffset:24];
    }
    return _ims_separatorView;
}

#pragma mark - Layout

- (void)configSubViews {
    [self.contentView addSubview:self.ims_imageView];
    [self.contentView addSubview:self.ims_textLabel];
    [self addSubview:self.ims_separatorView];
    
    [self.ims_imageView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(KDeviceLeftOffset);
        make.centerY.mas_equalTo(0);
        make.size.mas_equalTo(CGSizeMake(36, 36));
    }];
    
    [self.ims_textLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(KDeviceLeftOffset);
        make.centerY.mas_equalTo(0);
        make.right.mas_lessThanOrEqualTo(-8);
        make.height.mas_equalTo(40);//限制最多显示两行
    }];
    
    [self configAccessoryViewForGrayArrow];
    
    [self.ims_imageView addObserver:self forKeyPath:@"image" options:NSKeyValueObservingOptionNew context:nil];
}

- (void)configAccessoryViewDefaultLayout {
    self.accessoryView.imsDevice_top = 0;
    self.accessoryView.imsDevice_size = CGSizeMake(1, self.imsDevice_height);
    self.accessoryView.imsDevice_right = self.imsDevice_right;
}

- (void)configAccessoryView {
    UIView *accessoryView = [[UIView alloc] init];
    self.accessoryView = accessoryView;
}

- (void)configAccessoryViewForGrayArrow {
    [self configAccessoryView];
    
    UIImage *image = [UIImage imsDevice_imageNamed:@"IMSDevice_shape"];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
    [self.accessoryView addSubview:imageView];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(0);
        make.right.mas_equalTo(-17);
    }];
    self.shapeImageView = imageView;
}

#pragma mark - KVO

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    id value = change[NSKeyValueChangeNewKey];
    if ([value isKindOfClass:[UIImage class]] ) {
        [self.ims_textLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.ims_imageView.mas_right).offset(KDeviceLeftOffset);
            make.centerY.mas_equalTo(0);
            make.right.mas_lessThanOrEqualTo(-8);
        }];
    }
}

- (void)dealloc {
    [self.ims_imageView removeObserver:self forKeyPath:@"image"];
}

@end




















