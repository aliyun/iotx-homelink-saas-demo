//
//  IMSDeviceSearchView.h
//  Bolts
//
//  Created by chuntao.wang1 on 2018/11/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface IMSDeviceSearchView : UIView

@property (unsafe_unretained, nonatomic) IBOutlet UITextField *searchTF;

+ (IMSDeviceSearchView *)initView;

@end

NS_ASSUME_NONNULL_END
