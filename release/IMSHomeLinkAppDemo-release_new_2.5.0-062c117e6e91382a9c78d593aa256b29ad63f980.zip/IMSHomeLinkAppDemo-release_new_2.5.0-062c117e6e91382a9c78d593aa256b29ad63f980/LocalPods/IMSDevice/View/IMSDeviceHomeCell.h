//
//  IMSDeviceHomeCell.h
//  IMSDevice
//
//  Created by X i n long Li on 2018/3/30.
//

#import <UIKit/UIKit.h>

typedef void(^ClickHomeDevicePropertyBlock)(void);
@class IMSDeviceHomeItem;
@interface IMSDeviceHomeCell : UICollectionViewCell

@property (nonatomic, strong) IMSDeviceHomeItem *deviceItem;
@property (weak, nonatomic) IBOutlet UIButton *imsLightBtn;
@property (nonatomic, copy) ClickHomeDevicePropertyBlock propertyBlock;

@end
