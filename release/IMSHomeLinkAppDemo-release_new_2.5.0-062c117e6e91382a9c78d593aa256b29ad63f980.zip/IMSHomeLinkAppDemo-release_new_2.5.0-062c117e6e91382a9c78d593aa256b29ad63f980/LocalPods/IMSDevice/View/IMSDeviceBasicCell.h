//
//  IMSDeviceBasicCell.h
//  CocoaAsyncSocket
//
//  Created by jinstr520 on 2018/4/15.
//

#import <UIKit/UIKit.h>

typedef void(^AddDeviceClickedBlock)(void);

@interface IMSDeviceBasicCell : UITableViewCell

@property (nonatomic, strong) UIImageView *ims_imageView;
@property (nonatomic, strong) UILabel *ims_textLabel;
@property (nonatomic, strong) UIView *ims_separatorView;
@property (nonatomic, strong) UIImageView *shapeImageView;
@property (nonatomic, copy) AddDeviceClickedBlock addDeviceClickedBlock;

@end




















