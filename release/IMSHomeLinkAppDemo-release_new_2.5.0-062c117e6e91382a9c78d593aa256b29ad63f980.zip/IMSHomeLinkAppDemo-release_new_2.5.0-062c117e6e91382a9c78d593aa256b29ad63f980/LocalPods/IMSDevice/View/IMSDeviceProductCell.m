//
//  IMSDeviceProductCell.m
//  Bolts
//
//  Created by chuntao.wang1 on 2019/1/9.
//

#import "IMSDeviceProductCell.h"
#import <Masonry/Masonry.h>
#import <IMSCategory/IMSCategory.h>
#import "UIImage+IMSDeviceExtension.h"

@implementation IMSDeviceProductCell

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self configureView];
    }
    
    return self;
}

#pragma mark - configureView

- (void)configureView {
    [self addSubview:self.ims_imageV];
     [self.ims_imageV mas_makeConstraints:^(MASConstraintMaker *make) {
         make.top.mas_offset(0);
         make.centerX.mas_offset(0);
         make.width.height.mas_offset(44);
     }];
    
    [self addSubview:self.ims_titleLabel];
    [self.ims_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.ims_imageV.mas_bottom).offset(8);
        make.left.right.mas_offset(0);
        make.height.lessThanOrEqualTo(@28);
    }];
}

#pragma mark - Lazy loaading

- (UIImageView *)ims_imageV {
    if (!_ims_imageV) {
        _ims_imageV = [[UIImageView alloc] initWithFrame:CGRectZero];
        _ims_imageV.image = [UIImage imsDevice_imageNamed:@"IMSDevice_placeholder"];
    }
    
    return _ims_imageV;
}

- (UILabel *)ims_titleLabel {
    if (!_ims_titleLabel) {
        _ims_titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _ims_titleLabel.textAlignment = NSTextAlignmentCenter;
        _ims_titleLabel.numberOfLines = 0;
        _ims_titleLabel.font = [UIFont systemFontOfSize:10];
        _ims_titleLabel.textColor = [UIColor ims_colorWithHexRGB:0x666666];
    }
    
    return _ims_titleLabel;
}

@end
