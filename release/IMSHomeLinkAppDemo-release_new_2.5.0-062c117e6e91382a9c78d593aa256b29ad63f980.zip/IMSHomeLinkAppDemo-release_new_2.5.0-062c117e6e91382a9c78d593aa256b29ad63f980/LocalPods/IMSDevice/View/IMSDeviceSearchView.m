//
//  IMSDeviceSearchView.m
//  Bolts
//
//  Created by chuntao.wang1 on 2018/11/27.
//

#import "IMSDeviceSearchView.h"
#import <Masonry/Masonry.h>
#import "UINib+IMSDeviceExtension.h"
#import "UIColor+IMSDeviceExtension.h"

@interface IMSDeviceSearchView ()

@property (weak, nonatomic) IBOutlet UIView *searchBGView;

@end

@implementation IMSDeviceSearchView

+ (IMSDeviceSearchView *)initView {
    UINib *nib = [UINib imsDevice_nibWithClass:[self class]];
    return [[nib instantiateWithOwner:self options:nil] firstObject];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.searchBGView.layer.borderWidth = 1.f;
    self.searchBGView.layer.borderColor = [UIColor imsDevice_colorWithHexString:@"cccccc"].CGColor;
    self.searchTF.placeholder = @"请输入设备的品牌型号等";
}

@end
