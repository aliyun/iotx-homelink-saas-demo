//
//  IMSDeviceLocalCell.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/26.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSDeviceLocalCell.h"
#import <Masonry/Masonry.h>
#import <IMSCategory/IMSCategory.h>
#import "UIImage+IMSDeviceExtension.h"
#import "UIView+IMSDeviceExtension.h"

@interface IMSDeviceLocalCell ()

@property (nonatomic, strong) UIImageView *addDeviceBgImageView;

@end

@implementation IMSDeviceLocalCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self configAddDeviceButton];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(addDeviceAction)];
        [self addGestureRecognizer:tap];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
//    [self.addDeviceButton imsDevice_makeCircle];
}

- (UIImageView *)addDeviceBgImageView {
    if (!_addDeviceBgImageView) {
        _addDeviceBgImageView = [[UIImageView alloc] initWithImage:[UIImage imsDevice_imageNamed:@"local_add_background"]];
    }
    return _addDeviceBgImageView;
}

- (UIButton *)addDeviceButton {
    if (!_addDeviceButton) {
        _addDeviceButton = [UIButton buttonWithType:UIButtonTypeCustom];
    }
    return _addDeviceButton;
}

- (void)configAddDeviceButton {
    self.accessoryView.hidden = YES;
    UIView *rightBGView = [[UIView alloc] init];
    CGSize rightBGViewSize = CGSizeMake(85, 85);
    [self addSubview:rightBGView];
    [rightBGView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.centerY.mas_equalTo(0);
        make.size.mas_equalTo(rightBGViewSize);
    }];

    CGSize buttonSize = CGSizeMake(50, 50);
    self.addDeviceButton.titleLabel.font = [UIFont ims_mediumFontOfSize:10];
    [self.addDeviceButton setImage:[UIImage imsDevice_imageNamed:@"IMSDevice_add_green"] forState:UIControlStateNormal];
    [self.addDeviceButton setTitleColor:[UIColor ims_systemMaticColor] forState:UIControlStateNormal];
    [self.addDeviceButton addTarget:self action:@selector(addDeviceAction) forControlEvents:UIControlEventTouchUpInside];
    [rightBGView addSubview:self.addDeviceButton];
    [self.addDeviceButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(0);
        make.size.mas_equalTo(buttonSize);
    }];
    
    [rightBGView addSubview:self.addDeviceBgImageView];
    [self.addDeviceBgImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(0);
        make.size.mas_equalTo(buttonSize);
    }];
}

- (void)addDeviceAction {
    if (self.addDeviceClickedBlock) {
        self.addDeviceClickedBlock();
    }
}

- (void)startAddBTDeviceAnimation {
    self.addDeviceButton.userInteractionEnabled = NO;
    self.addDeviceBgImageView.image = [UIImage imsDevice_imageNamed:@"local_add_bt_animation"];
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    animation.fromValue = [NSNumber numberWithFloat:0.f];
    animation.toValue = [NSNumber numberWithFloat:M_PI * 2];
    animation.duration = 1.5f;
    animation.autoreverses = NO;
    animation.fillMode = kCAFillModeForwards;
    animation.repeatCount = MAXFLOAT;
    [self.addDeviceBgImageView.layer addAnimation:animation forKey:nil];
}

- (void)stopAddBTDeviceAnimation {
    self.addDeviceButton.userInteractionEnabled = YES;
    self.addDeviceBgImageView.image = [UIImage imsDevice_imageNamed:@"local_add_background"];
    [self.addDeviceBgImageView.layer removeAllAnimations];
}

@end

#import <objc/runtime.h>
#import <IMSApiClient/IMSConfiguration.h>
#import "IMSDeviceInfoModel.h"

@implementation IMSDeviceLocalCell (IMSDeviceInfoModel)

- (IMSDeviceInfoModel *)device {
    return objc_getAssociatedObject(self, _cmd);
}

- (void)setDevice:(IMSDeviceInfoModel *)device {
    objc_setAssociatedObject(self, @selector(device), device, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    
    NSMutableString *name = [NSMutableString string];
    if (device.productName) {
        name = [NSMutableString stringWithFormat:@"%@ %@",name ,device.productName];
    }
    
    if (device.deviceName) {
        name = [NSMutableString stringWithFormat:@"%@ %@",name ,device.deviceName];
    }
    
    if (device.productId) {
        name = [NSMutableString stringWithFormat:@"%@ %@",name ,device.productId];
    }
    
    self.ims_textLabel.text = name;
}

- (void)updateLayout {
    [self.ims_textLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.right.mas_lessThanOrEqualTo(-60);
    }];
}

@end


















