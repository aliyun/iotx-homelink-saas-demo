//
//  IMSDevice.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/8.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for IMSDevice.
FOUNDATION_EXPORT double IMSDeviceVersionNumber;

//! Project version string for IMSDevice.
FOUNDATION_EXPORT const unsigned char IMSDeviceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IMSDevice/PublicHeader.h>

#import <IMSDevice/IMSDeviceHomeViewController.h>
#import <IMSDevice/IMSDeviceChooseTypeViewController.h>
#import <IMSDevice/IMSDeviceBindViewController.h>
#import <IMSDevice/IMSDevicePluginsService.h>
#import <IMSDevice/IMSDeviceBindService.h>
#import <IMSDevice/IMSOTAUpgradeDeviceListViewController.h>
#import <IMSDevice/IMSDeviceClient.h>
#import <IMSDevice/IMSDeviceCache.h>



