//
//  UIView+IMSDeviceExtension.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/22.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "UIView+IMSDeviceExtension.h"
#import <Masonry/Masonry.h>
#import <IMSCategory/IMSCategory.h>

@implementation UIView (IMSDeviceExtension)

- (CGFloat)imsDevice_left {
    return self.frame.origin.x;
}

- (void)setImsDevice_left:(CGFloat)imsDevice_left {
    CGRect frame = self.frame;
    frame.origin.x = imsDevice_left;
    self.frame = frame;
}

- (CGFloat)imsDevice_top {
    return self.frame.origin.y;
}

- (void)setImsDevice_top:(CGFloat)imsDevice_top {
    CGRect frame = self.frame;
    frame.origin.y = imsDevice_top;
    self.frame = frame;
}

- (CGFloat)imsDevice_right {
    return self.frame.origin.x + self.frame.size.width;
}

- (void)setImsDevice_right:(CGFloat)imsDevice_right {
    CGRect frame = self.frame;
    frame.origin.x = imsDevice_right - frame.size.width;
    self.frame = frame;
}

- (CGFloat)imsDevice_bottom {
    return self.frame.origin.y + self.frame.size.height;
}

- (void)setImsDevice_bottom:(CGFloat)imsDevice_bottom {
    CGRect frame = self.frame;
    frame.origin.y = imsDevice_bottom - frame.size.height;
    self.frame = frame;
}

- (CGFloat)imsDevice_width {
    return self.frame.size.width;
}

- (void)setImsDevice_width:(CGFloat)imsDevice_width {
    CGRect frame = self.frame;
    frame.size.width = imsDevice_width;
    self.frame = frame;
}

- (CGFloat)imsDevice_height {
    return self.frame.size.height;
}

- (void)setImsDevice_height:(CGFloat)imsDevice_height {
    CGRect frame = self.frame;
    frame.size.height = imsDevice_height;
    self.frame = frame;
}

- (CGFloat)imsDevice_centerX {
    return self.center.x;
}

- (void)setImsDevice_centerX:(CGFloat)imsDevice_centerX {
    self.center = CGPointMake(imsDevice_centerX, self.center.y);
}

- (CGFloat)imsDevice_centerY {
    return self.center.y;
}

- (void)setImsDevice_centerY:(CGFloat)imsDevice_centerY {
    self.center = CGPointMake(self.center.x, imsDevice_centerY);
}

- (CGPoint)imsDevice_origin {
    return self.frame.origin;
}

- (void)setImsDevice_origin:(CGPoint)imsDevice_origin {
    CGRect frame = self.frame;
    frame.origin = imsDevice_origin;
    self.frame = frame;
}

- (CGSize)imsDevice_size {
    return self.frame.size;
}

- (void)setImsDevice_size:(CGSize)imsDevice_size {
    CGRect frame = self.frame;
    frame.size = imsDevice_size;
    self.frame = frame;
}

- (void)imsDevice_makeCircle {
    [self layoutIfNeeded];
    self.layer.masksToBounds = YES;
    self.layer.cornerRadius = self.imsDevice_height/2;
}

- (UIView *)imsDevice_addBottomLineView {
    return [self imsDevice_addBottomLineViewWithLeftOffset:0];
}

- (UIView *)imsDevice_addBottomLineViewWithLeftOffset:(CGFloat)left {
    UIView *lineView = [[UIView alloc] init];
    lineView.backgroundColor = [UIColor ims_marginalColor];
    [self addSubview:lineView];
    [lineView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(left);
        make.right.mas_equalTo(0);
        make.bottom.mas_equalTo(0);
        make.height.mas_equalTo(1);
    }];
    return lineView;
}

@end




















