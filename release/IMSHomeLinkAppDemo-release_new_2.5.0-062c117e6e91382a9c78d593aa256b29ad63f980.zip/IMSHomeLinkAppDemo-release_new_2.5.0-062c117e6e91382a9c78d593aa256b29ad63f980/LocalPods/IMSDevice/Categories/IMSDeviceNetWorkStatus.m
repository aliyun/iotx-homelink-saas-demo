//
//  IMSDeviceNetWorkStatus.m
//  IMSScene
//
//  Created by 冯君骅 on 2018/4/4.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSDeviceNetWorkStatus.h"

@interface IMSDeviceNetWorkStatus ()
@property (nonatomic, strong) Reachability *reachability;
@end

@implementation IMSDeviceNetWorkStatus

+ (instancetype)shareInstace {
	static IMSDeviceNetWorkStatus *tool = nil;
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		tool = [[IMSDeviceNetWorkStatus alloc] init];
		
		//监听网络情况变化,值改变后会传给self的networkStatus属性,把这段代码放到appdelegate中也可以
		tool.reachability = Reachability.reachabilityForInternetConnection;
		tool.networkStatus = tool.reachability.currentReachabilityStatus;
		[[NSNotificationCenter defaultCenter] addObserver:tool selector:@selector(reachabilityChangedNotification:) name:kReachabilityChangedNotification object:nil];
		
		__weak typeof(tool) weakTool = tool;
		dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
			__strong typeof(weakTool) tool = weakTool;
			[tool.reachability startNotifier];
		});
	});
	return tool;
}

- (void)reachabilityChangedNotification:(NSNotification *)notification {
	self.networkStatus = [notification.object currentReachabilityStatus];
}

+ (BOOL)isReachable {
	return [IMSDeviceNetWorkStatus shareInstace].networkStatus != NotReachable;
}

@end
