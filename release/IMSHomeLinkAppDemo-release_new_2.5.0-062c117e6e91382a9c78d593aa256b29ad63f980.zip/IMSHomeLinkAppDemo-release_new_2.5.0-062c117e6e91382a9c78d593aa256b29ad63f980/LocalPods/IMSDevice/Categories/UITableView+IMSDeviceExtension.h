//
//  UITableView+IMSDeviceExtension.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/4.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class IMSDeviceBasicCell;

@interface UITableView (IMSDeviceExtension)

//只隐藏最后一行的底线
- (void)imsDevice_hiddenSectionLastCellOfSeparatorViewWithCell:(IMSDeviceBasicCell *)cell indexPath:(NSIndexPath *)indexPath;

//隐藏所有底线
- (void)imsDevice_hiddenAllCellOfSeparatorViewWithCell:(IMSDeviceBasicCell *)cell indexPath:(NSIndexPath *)indexPath;

@end

NS_ASSUME_NONNULL_END













