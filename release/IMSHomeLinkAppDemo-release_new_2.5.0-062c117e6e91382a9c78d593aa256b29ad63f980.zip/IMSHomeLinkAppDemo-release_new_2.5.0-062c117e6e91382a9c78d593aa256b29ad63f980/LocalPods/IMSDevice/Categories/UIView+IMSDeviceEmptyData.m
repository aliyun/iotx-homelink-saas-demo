//
//  UIView+IMSDeviceEmptyData.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/8.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "UIView+IMSDeviceEmptyData.h"
#import <objc/runtime.h>
#import <Masonry/Masonry.h>
#import <IMSCategory/IMSCategory.h>
#import "UIImage+IMSDeviceExtension.h"

@implementation UIView (IMSDeviceEmptyData)

- (UIView *)contentView {
    UIView *contentView = objc_getAssociatedObject(self, _cmd);
    if (!contentView) {
        contentView = [[UIView alloc] initWithFrame:self.bounds];
        contentView.backgroundColor = self.backgroundColor;
        [self addSubview:contentView];
        [self setContentView:contentView];
    }
    return contentView;
}

- (void)setContentView:(UIView *)contentView {
    objc_setAssociatedObject(self, @selector(contentView), contentView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (UIImageView *)emptyDataImageView {
    UIImageView *emptyDataImageView = objc_getAssociatedObject(self, _cmd);
    if (!emptyDataImageView) {
        emptyDataImageView = [[UIImageView alloc] init];
        if ([self contentView]) {
            [[self contentView] addSubview:emptyDataImageView];
            [emptyDataImageView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.mas_equalTo(120);
                make.centerX.mas_equalTo(0);
            }];
        }
        
        [self setEmptyDataImageView:emptyDataImageView];
    }
    return emptyDataImageView;
}

- (void)setEmptyDataImageView:(UIImageView * _Nullable)emptyDataImageView {
    objc_setAssociatedObject(self, @selector(emptyDataImageView), emptyDataImageView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (UILabel *)emptyDataMessageLabel {
    UILabel *emptyDataMessageLabel = objc_getAssociatedObject(self, _cmd);
    if (!emptyDataMessageLabel) {
        emptyDataMessageLabel = [[UILabel alloc] init];
        emptyDataMessageLabel.textColor = [UIColor ims_accessorialColor];
        emptyDataMessageLabel.font = [UIFont ims_regularFontOfSize:14];
        if ([self contentView]) {
            [[self contentView] addSubview:emptyDataMessageLabel];
            [emptyDataMessageLabel mas_makeConstraints:^(MASConstraintMaker *make) {
                if ([self emptyDataImageView]) {
                    make.top.equalTo([self emptyDataImageView].mas_bottom).offset(20);
                }
                make.centerX.mas_equalTo(0);
            }];
        }
        
        [self setEmptyDataMessageLabel:emptyDataMessageLabel];
    }
    return emptyDataMessageLabel;
}

- (void)setEmptyDataMessageLabel:(UILabel *)emptyDataMessageLabel {
    objc_setAssociatedObject(self, @selector(emptyDataMessageLabel), emptyDataMessageLabel, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (void)imsDevice_emptyDataDisplayWithMessage:(NSString *)message {
    [self imsDevice_emptyDataDisplayWithImage:[UIImage imsDevice_imageNamed:@"IMSOTA_icon_default"] message:message];
}

- (void)imsDevice_emptyDataDisplayWithImage:(UIImage *)image message:(NSString *)message {
    [self emptyDataImageView].image = image;
    [self emptyDataMessageLabel].text = message;
}

- (void)imsDevice_removeEmptyData {
    for (UIView *subView in [self contentView].subviews) {
        [subView removeFromSuperview];
    }
    [[self contentView] removeFromSuperview];
    [self setContentView:nil];
    [self setEmptyDataImageView:nil];
    [self setEmptyDataMessageLabel:nil];
}

@end























