//
//  NSValueTransformer+IMSDeviceExtension.h
//  CloudApiSDK
//
//  Created by jinstr520 on 2018/4/27.
//

#import <Foundation/Foundation.h>

@interface NSValueTransformer (IMSDeviceExtension)

+ (NSValueTransformer *)imsDevice_timestampTransformer;

@end
