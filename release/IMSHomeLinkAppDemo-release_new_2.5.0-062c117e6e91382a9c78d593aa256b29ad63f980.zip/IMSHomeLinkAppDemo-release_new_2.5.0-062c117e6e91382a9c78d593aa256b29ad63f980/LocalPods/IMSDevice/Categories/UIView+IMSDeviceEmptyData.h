//
//  UIView+IMSDeviceEmptyData.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/8.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (IMSDeviceEmptyData)

@property UIView *contentView;
@property UIImageView *emptyDataImageView;
@property UILabel *emptyDataMessageLabel;

- (void)imsDevice_emptyDataDisplayWithMessage:(NSString *)message;

- (void)imsDevice_emptyDataDisplayWithImage:(UIImage *)image message:(NSString *)message;

- (void)imsDevice_removeEmptyData;

@end










