//
//  IMSDeviceNetWorkStatus.h
//  IMSDevice
//
//  Created by 冯君骅 on 2018/4/4.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Reachability/Reachability.h>
@interface IMSDeviceNetWorkStatus : NSObject
@property (nonatomic, assign) NetworkStatus networkStatus;

+ (instancetype)shareInstace;
+ (BOOL)isReachable;
@end
