//
//  UINib+IMSDeviceExtension.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/26.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "UINib+IMSDeviceExtension.h"
#import "NSBundle+IMSDeviceExtension.h"

@implementation UINib (IMSDeviceExtension)

+ (UINib *)imsDevice_nibWithNibName:(NSString *)name {
    return [UINib nibWithNibName:name bundle:[NSBundle imsDevice_deviceBundleWithClass:NSClassFromString(name)]];
}

+ (UINib *)imsDevice_nibWithClass:(Class)cls {
    return [UINib imsDevice_nibWithNibName:NSStringFromClass(cls)];
}

@end
