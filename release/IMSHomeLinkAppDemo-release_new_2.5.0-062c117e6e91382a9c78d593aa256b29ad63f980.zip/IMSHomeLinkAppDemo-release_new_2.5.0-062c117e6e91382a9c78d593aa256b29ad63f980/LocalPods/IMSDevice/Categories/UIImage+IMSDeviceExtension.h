//
//  UIImage+IMSDeviceExtension.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/22.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (IMSDeviceExtension)

+ (nullable UIImage *)imsDevice_imageWithColor:(UIColor *)color;

+ (nullable UIImage *)imsDevice_imageNamed:(NSString *)name;

@end

NS_ASSUME_NONNULL_END





















