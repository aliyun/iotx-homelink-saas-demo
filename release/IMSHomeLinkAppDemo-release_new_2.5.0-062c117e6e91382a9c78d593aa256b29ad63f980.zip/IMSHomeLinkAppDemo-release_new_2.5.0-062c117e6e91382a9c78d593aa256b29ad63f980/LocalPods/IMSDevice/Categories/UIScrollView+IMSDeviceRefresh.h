//
//  UIScrollView+IMSDeviceRefresh.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/7.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIScrollView (IMSDeviceRefresh)

@property NSInteger pageNum;

- (BOOL)imsDevice_endRefreshingNoMoreDataWithItemCount:(NSInteger)itemCount totalNum:(NSInteger)totalNum;

- (void)imsDevice_endRefreshing;

@end

NS_ASSUME_NONNULL_END


















