//
//  UIColor+IMSDeviceExtension.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/29.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (IMSDeviceExtension)

+ (nullable UIColor *)imsDevice_colorWithHexString:(NSString *)hexStr;
+ (UIColor * _Nullable)imsDevice_colorWithRed:(CGFloat)r green:(CGFloat)g blue:(CGFloat)b alpha:(CGFloat)a;

@end

NS_ASSUME_NONNULL_END













