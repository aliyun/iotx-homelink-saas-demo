//
//  NSTimer+IMSDeviceBlock.m
//  CloudApiSDK
//
//  Created by jinstr520 on 2018/5/5.
//

#import "NSTimer+IMSDeviceBlock.h"

@implementation NSTimer (IMSDeviceBlock)

+ (NSTimer *)imsDevice_timerWithTimeInterval:(NSTimeInterval)interval repeats:(BOOL)repeats block:(void (^)(NSTimer *timer))block {
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:interval target:self selector:@selector(trigger:) userInfo:[block copy] repeats:YES];
    return timer;
}

+ (void)trigger:(NSTimer *)timer {
    void(^block)(NSTimer *timer) = [timer userInfo];
    if (block) {
        block(timer);
    }
}

@end


















