//
//  IMLCandDeviceModel+IMSDeviceInfo.m
//  CloudApiSDK
//
//  Created by jinstr520 on 2018/5/9.
//

#import "IMLCandDeviceModel+IMSDeviceInfo.h"

@implementation IMLCandDeviceModel (IMSDeviceInfo)

- (NSDictionary *)deviceInfo {
    NSMutableDictionary *info = [NSMutableDictionary dictionary];
    
    if (self.productKey) {
        info[@"productKey"] = self.productKey;
    }
    
    if (self.deviceName) {
        info[@"deviceName"] = self.deviceName;
    }
    
    if (self.regProductKey) {
        info[@"regProductKey"] = self.regProductKey;
    }
    
    if (self.regDeviceName) {
        info[@"regDeviceName"] = self.regDeviceName;
    }
    
    if (self.addDeviceFrom) {
        info[@"addDeviceFrom"] = self.addDeviceFrom;
    }
    
    if (self.token) {
        info[@"token"] = self.token;
    }
    
    if (self.devType) {
        info[@"devType"] = self.devType;
    }
    
    info[@"linkType"] = @(self.linkType);
    
    return info;
}

@end
