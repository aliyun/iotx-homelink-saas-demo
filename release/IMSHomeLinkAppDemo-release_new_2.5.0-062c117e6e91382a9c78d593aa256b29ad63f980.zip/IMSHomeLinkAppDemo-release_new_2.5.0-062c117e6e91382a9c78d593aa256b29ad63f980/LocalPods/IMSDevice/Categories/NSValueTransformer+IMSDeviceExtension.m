//
//  NSValueTransformer+IMSDeviceExtension.m
//  CloudApiSDK
//
//  Created by jinstr520 on 2018/4/27.
//

#import "NSValueTransformer+IMSDeviceExtension.h"
#import <Mantle/Mantle.h>
#import "NSString+IMSDeviceExtension.h"

@implementation NSValueTransformer (IMSDeviceExtension)

+ (NSValueTransformer *)imsDevice_timestampTransformer {
    return [MTLValueTransformer transformerUsingForwardBlock:^id(NSNumber *value, BOOL *success, NSError *__autoreleasing *error) {
        return [[value stringValue] dateString];
    } reverseBlock:^id(NSString *value, BOOL *success, NSError *__autoreleasing *error) {
        return [value timestamp];
    }];
}

@end


















