//
//  UIImageView+IMSDeviceWebCache.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/11.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "UIImageView+IMSDeviceWebCache.h"
#import <SDWebImage/UIImageView+WebCache.h>

@implementation UIImageView (IMSDeviceWebCache)

- (void)imsDevice_setImageWithURL:(nullable NSURL *)url {
    [self imsDevice_setImageWithURL:url placeholderImage:nil];
}

- (void)imsDevice_setImageWithURL:(nullable NSURL *)url
                 placeholderImage:(nullable UIImage *)placeholder {
    [self sd_setImageWithURL:url placeholderImage:placeholder];
}

@end
