//
//  IMLCandDeviceModel+IMSDeviceInfo.h
//  CloudApiSDK
//
//  Created by jinstr520 on 2018/5/9.
//

#import <IMLDeviceCenter/IMLDeviceCenter.h>

@interface IMLCandDeviceModel (IMSDeviceInfo)

- (NSDictionary *)deviceInfo;

@end
