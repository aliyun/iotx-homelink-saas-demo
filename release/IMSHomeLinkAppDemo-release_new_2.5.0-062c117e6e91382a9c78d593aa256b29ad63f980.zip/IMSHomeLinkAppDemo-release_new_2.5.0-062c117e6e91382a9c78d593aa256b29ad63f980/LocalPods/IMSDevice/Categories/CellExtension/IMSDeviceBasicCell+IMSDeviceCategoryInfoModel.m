//
//  IMSDeviceBasicCell+IMSDeviceCategoryInfoModel.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/2.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSDeviceBasicCell+IMSDeviceCategoryInfoModel.h"
#import "UIImageView+IMSDeviceWebCache.h"
#import "UIImage+IMSDeviceExtension.h"
#import "IMSDeviceCategoryInfoModel.h"
#import "UIView+IMSDeviceExtension.h"
#import <IMSCategory/IMSCategory.h>
#import "UIColor+IMSDeviceExtension.h"

@implementation IMSDeviceBasicCell (IMSDeviceCategoryInfoModel)

- (void)setCategoryInfo:(IMSDeviceCategoryInfoModel *)categoryInfo {
    if (categoryInfo.categoryName == nil) {
        self.ims_textLabel.text = categoryInfo.categoryKey;
    } else {
        self.ims_textLabel.text = categoryInfo.categoryName;
    }
    self.shapeImageView.hidden = YES;
    self.ims_separatorView.hidden = YES;
    self.backgroundColor = [UIColor imsDevice_colorWithHexString:@"F6F6F6"];
}

@end











