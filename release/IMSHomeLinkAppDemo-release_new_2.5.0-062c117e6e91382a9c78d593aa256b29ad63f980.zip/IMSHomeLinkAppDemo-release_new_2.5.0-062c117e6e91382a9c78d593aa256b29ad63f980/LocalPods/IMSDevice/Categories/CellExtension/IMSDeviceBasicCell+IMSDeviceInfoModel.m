//
//  IMSDeviceBasicCell+IMSDeviceInfoModel.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/10/25.
//  Copyright © 2018 Aliyun.com. All rights reserved.
//

#import "IMSDeviceBasicCell+IMSDeviceInfoModel.h"
#import <objc/runtime.h>
#import <IMSApiClient/IMSConfiguration.h>
#import "IMSDeviceInfoModel.h"

@implementation IMSDeviceBasicCell (IMSDeviceInfoModel)

- (IMSDeviceInfoModel *)device {
    return objc_getAssociatedObject(self, _cmd);
}

- (void)setDevice:(IMSDeviceInfoModel *)device {
    objc_setAssociatedObject(self, @selector(device), device, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    
    if ([IMSConfiguration sharedInstance].serverEnv == IMSServerDaily) {
        self.ims_textLabel.text = device.deviceName;
    } else {
        self.ims_textLabel.text = device.productName;
    }
}

@end
