//
//  IMSDeviceBasicCell+IMSOTAUpgradeDeviceInfoModel.h
//  CloudApiSDK
//
//  Created by jinstr520 on 2018/4/26.
//

#import "IMSDeviceBasicCell.h"

@class IMSOTAUpgradeDeviceInfoModel;

@interface IMSDeviceBasicCell (IMSOTAUpgradeDeviceInfoModel)

- (void)setUpgradeDeviceInfoModel:(IMSOTAUpgradeDeviceInfoModel *)upgradeDeviceInfoModel;

@end
