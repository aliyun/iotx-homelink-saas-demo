//
//  IMSDeviceBasicCell+IMSOTAUpgradeDeviceInfoModel.m
//  CloudApiSDK
//
//  Created by jinstr520 on 2018/4/26.
//

#import "IMSDeviceBasicCell+IMSOTAUpgradeDeviceInfoModel.h"
#import "UIImageView+IMSDeviceWebCache.h"
#import "UIImage+IMSDeviceExtension.h"
#import "IMSOTAUpgradeDeviceInfoModel.h"

@implementation IMSDeviceBasicCell (IMSOTAUpgradeDeviceInfoModel)

- (void)setUpgradeDeviceInfoModel:(IMSOTAUpgradeDeviceInfoModel *)upgradeDeviceInfoModel {
    [self.ims_imageView imsDevice_setImageWithURL:[NSURL URLWithString:upgradeDeviceInfoModel.image] placeholderImage:[UIImage imsDevice_imageNamed:@"IMSDevice_placeholder"]];
    self.ims_textLabel.text = upgradeDeviceInfoModel.deviceName;
}

@end





















