//
//  IMSDeviceBasicCell+IMSDeviceCategoryInfoModel.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/2.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSDeviceBasicCell.h"

@class IMSDeviceCategoryInfoModel;

@interface IMSDeviceBasicCell (IMSDeviceCategoryInfoModel)

- (void)setCategoryInfo:(IMSDeviceCategoryInfoModel *)categoryInfo;

@end
