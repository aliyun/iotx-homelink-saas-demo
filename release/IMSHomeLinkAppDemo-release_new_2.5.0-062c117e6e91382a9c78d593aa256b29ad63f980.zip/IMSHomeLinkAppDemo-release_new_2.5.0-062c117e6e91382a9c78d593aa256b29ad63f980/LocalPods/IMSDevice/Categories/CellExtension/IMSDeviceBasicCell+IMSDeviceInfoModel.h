//
//  IMSDeviceBasicCell+IMSDeviceInfoModel.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/10/25.
//  Copyright © 2018 Aliyun.com. All rights reserved.
//

#import "IMSDeviceBasicCell.h"

@class IMSDeviceInfoModel;

NS_ASSUME_NONNULL_BEGIN

@interface IMSDeviceBasicCell (IMSDeviceInfoModel)

@property (nonatomic) IMSDeviceInfoModel *device;

@end

NS_ASSUME_NONNULL_END
