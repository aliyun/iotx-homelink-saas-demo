//
//  IMSDeviceBasicCell+IMSDeviceProductInfoModel.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/11.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSDeviceBasicCell+IMSDeviceProductInfoModel.h"
#import "IMSDeviceProductInfoModel.h"

@implementation IMSDeviceBasicCell (IMSDeviceProductInfoModel)

- (void)setProductInfo:(IMSDeviceProductInfoModel *)productInfo {
    self.ims_textLabel.text = productInfo.productName;
    self.ims_separatorView.hidden = YES;
}

@end
