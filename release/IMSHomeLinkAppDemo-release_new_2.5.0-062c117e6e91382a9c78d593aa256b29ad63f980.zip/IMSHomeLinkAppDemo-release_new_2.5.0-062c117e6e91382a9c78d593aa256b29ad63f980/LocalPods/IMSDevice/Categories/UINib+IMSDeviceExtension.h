//
//  UINib+IMSDeviceExtension.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/26.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UINib (IMSDeviceExtension)

+ (UINib *)imsDevice_nibWithNibName:(NSString *)name;

+ (UINib *)imsDevice_nibWithClass:(Class)cls;

@end

NS_ASSUME_NONNULL_END
