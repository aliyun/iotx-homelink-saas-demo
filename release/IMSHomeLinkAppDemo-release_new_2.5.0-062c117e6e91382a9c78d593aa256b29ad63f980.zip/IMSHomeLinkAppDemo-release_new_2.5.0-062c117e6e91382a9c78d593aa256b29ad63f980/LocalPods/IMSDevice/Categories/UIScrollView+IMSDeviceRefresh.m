//
//  UIScrollView+IMSDeviceRefresh.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/7.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "UIScrollView+IMSDeviceRefresh.h"
#import <objc/runtime.h>
#import <IMSRefresh/IMSRefresh.h>

static int _RefreshPageIndexKey;

@implementation UIScrollView (IMSDeviceRefresh)

- (void)setPageNum:(NSInteger)pageNum {
    objc_setAssociatedObject(self, &_RefreshPageIndexKey, @(pageNum), OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (NSInteger)pageNum {
    NSNumber *pageNum = objc_getAssociatedObject(self, &_RefreshPageIndexKey);
    if (pageNum != nil) {
        return [pageNum integerValue];
    } else {
        return 1;
    }
}

- (BOOL)imsDevice_endRefreshingNoMoreDataWithItemCount:(NSInteger)itemCount totalNum:(NSInteger)totalNum {
    BOOL noMoreData = [self isNoMoreData:itemCount totalNum:totalNum];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.mj_footer) {
            if (noMoreData) {
                [self.mj_footer endRefreshingWithNoMoreData];
            } else {
                [self.mj_footer endRefreshing];
            }
        }
        
        if (self.mj_header.isRefreshing) {
            [self.mj_header endRefreshing];
        }
    });
    
    return noMoreData;
}

- (BOOL)isNoMoreData:(NSInteger)itemCount totalNum:(NSInteger)totalNum {
    return itemCount == totalNum;
}

- (void)imsDevice_endRefreshing {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.mj_header.isRefreshing) {
            [self.mj_header endRefreshing];
        }
        
        if (self.mj_footer.isRefreshing) {
            [self.mj_footer endRefreshing];
        }
    });
}

@end











