//
//  NSTimer+IMSDeviceBlock.h
//  CloudApiSDK
//
//  Created by jinstr520 on 2018/5/5.
//

#import <Foundation/Foundation.h>

@interface NSTimer (IMSDeviceBlock)

+ (NSTimer *)imsDevice_timerWithTimeInterval:(NSTimeInterval)interval repeats:(BOOL)repeats block:(void (^)(NSTimer *timer))block;

@end
