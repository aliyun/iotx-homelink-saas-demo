//
//  NSString+IMSDeviceExtension.m
//  CloudApiSDK
//
//  Created by jinstr520 on 2018/4/26.
//

#import "NSString+IMSDeviceExtension.h"

@implementation NSString (IMSDeviceExtension)

- (NSString *)stringValue {
    return self;
}

- (NSString *)dateString {
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:[self doubleValue] / 1000];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy/MM/dd"];
    NSString *dateString = [dateFormatter stringFromDate:date];
    
    return dateString;
}

- (NSNumber *)timestamp {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy/MM/dd"];
    NSDate *date = [dateFormatter dateFromString:self];
    NSNumber *timestamp = [NSNumber numberWithDouble:[date timeIntervalSince1970]];
    
    return timestamp;
}

@end


















