//
//  NSString+IMSDeviceExtension.h
//  CloudApiSDK
//
//  Created by jinstr520 on 2018/4/26.
//

#import <Foundation/Foundation.h>

@interface NSString (IMSDeviceExtension)

- (NSString *)stringValue;

- (NSString *)dateString;

- (NSNumber *)timestamp;

@end
