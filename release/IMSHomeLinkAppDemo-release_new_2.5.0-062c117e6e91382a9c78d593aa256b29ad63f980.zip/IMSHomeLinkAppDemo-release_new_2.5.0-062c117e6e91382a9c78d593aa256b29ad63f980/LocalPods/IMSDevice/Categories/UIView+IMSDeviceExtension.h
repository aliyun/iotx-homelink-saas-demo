//
//  UIView+IMSDeviceExtension.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/22.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (IMSDeviceExtension)

@property (nonatomic) CGFloat imsDevice_left;
@property (nonatomic) CGFloat imsDevice_top;
@property (nonatomic) CGFloat imsDevice_right;
@property (nonatomic) CGFloat imsDevice_bottom;
@property (nonatomic) CGFloat imsDevice_width;
@property (nonatomic) CGFloat imsDevice_height;
@property (nonatomic) CGFloat imsDevice_centerX;
@property (nonatomic) CGFloat imsDevice_centerY;
@property (nonatomic) CGPoint imsDevice_origin;
@property (nonatomic) CGSize  imsDevice_size;

- (void)imsDevice_makeCircle;

- (UIView *)imsDevice_addBottomLineView;

- (UIView *)imsDevice_addBottomLineViewWithLeftOffset:(CGFloat)left;

@end

NS_ASSUME_NONNULL_END














