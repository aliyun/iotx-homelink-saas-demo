//
//  NSBundle+IMSDeviceExtension.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/26.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "NSBundle+IMSDeviceExtension.h"
#import "IMSDevice.h"

@implementation NSBundle (IMSDeviceExtension)

+ (NSBundle *)imsDevice_deviceBundleWithClass:(Class)cls {
    NSBundle *bundle = [NSBundle bundleForClass:cls];
    NSURL *url = [bundle URLForResource:@"IMSDevice" withExtension:@".bundle"];
    if (!url) {
        url = [bundle bundleURL];
    }
    NSBundle *deviceBundle = [NSBundle bundleWithURL:url];
    return deviceBundle;
}

+ (NSBundle *)imsDevice_bundle {
    static NSBundle *bundle = nil;
    if (bundle == nil) {
        bundle = [self imsDevice_deviceBundleWithClass:[IMSDeviceHomeViewController class]];
    }
    return bundle;
}

@end
















