//
//  UITableView+IMSDeviceExtension.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/4.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "UITableView+IMSDeviceExtension.h"
#import "IMSDeviceBasicCell.h"

@implementation UITableView (IMSDeviceExtension)

- (void)imsDevice_hiddenSectionLastCellOfSeparatorViewWithCell:(IMSDeviceBasicCell *)cell indexPath:(NSIndexPath *)indexPath {
    if ([self.dataSource respondsToSelector:@selector(tableView:numberOfRowsInSection:)]) {
        NSInteger number = [self.dataSource tableView:self numberOfRowsInSection:indexPath.section];
        if (indexPath.row == number-1) {
            cell.ims_separatorView.hidden = YES;
        } else {
            cell.ims_separatorView.hidden = NO;
        }
    }
    
    
}

- (void)imsDevice_hiddenAllCellOfSeparatorViewWithCell:(IMSDeviceBasicCell *)cell indexPath:(NSIndexPath *)indexPath {
    if ([self.dataSource respondsToSelector:@selector(tableView:numberOfRowsInSection:)]) {
        cell.ims_separatorView.hidden = YES;
    }
}

@end

















