//
//  NSBundle+IMSDeviceExtension.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/26.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSBundle (IMSDeviceExtension)

+ (NSBundle *)imsDevice_deviceBundleWithClass:(Class)cls;

+ (NSBundle *)imsDevice_bundle;

@end

NS_ASSUME_NONNULL_END












