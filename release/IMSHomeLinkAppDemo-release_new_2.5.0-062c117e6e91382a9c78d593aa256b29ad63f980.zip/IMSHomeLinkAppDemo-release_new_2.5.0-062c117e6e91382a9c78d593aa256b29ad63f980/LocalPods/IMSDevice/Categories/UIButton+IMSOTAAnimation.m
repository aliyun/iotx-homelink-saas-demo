//
//  UIButton+IMSOTAAnimation.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/29.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "UIButton+IMSOTAAnimation.h"
#import <objc/runtime.h>
#import <IMSCategory/IMSCategory.h>
#import "UIImage+IMSDeviceExtension.h"

@implementation UIButton (IMSOTAAnimation)

- (UIView *)ims_maskView {
    UIView *maskView = objc_getAssociatedObject(self, _cmd);
    return maskView;
}

- (void)setIms_maskView:(UIView *)ims_maskView {
    objc_setAssociatedObject(self, @selector(ims_maskView), ims_maskView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (void)configUpgradeButtonOngoingState {
    if (![self ims_maskView]) {
        UIView *maskView = [[UIView alloc] initWithFrame:self.bounds];
        maskView.alpha = 0.2;
        maskView.backgroundColor = [UIColor blackColor];
        maskView.layer.cornerRadius = self.layer.cornerRadius;
        maskView.layer.masksToBounds = YES;
        [self setIms_maskView:maskView];
    }
    
    [self addSubview:[self ims_maskView]];
}

- (void)imsDevice_startUpgradeAnimation {
    [self configUpgradeButtonOngoingState];
    [self setImage:[UIImage imsDevice_imageNamed:@"IMSOTA_icon_loading"] forState:UIControlStateNormal];
    self.imageEdgeInsets = UIEdgeInsetsMake(0, -12, 0, 0);
    self.titleEdgeInsets = UIEdgeInsetsMake(0, 12, 0, 0);
    
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    animation.fromValue = [NSNumber numberWithFloat:0.f];
    animation.toValue = [NSNumber numberWithFloat:M_PI * 2];
    animation.duration = .5f;
    animation.autoreverses = NO;
    animation.fillMode = kCAFillModeForwards;
    animation.repeatCount = MAXFLOAT;
    [self.imageView.layer addAnimation:animation forKey:nil];
}

- (void)imsDevice_stopUpgradeAnimation {
    [self.imageView.layer removeAllAnimations];
    [self setImage:nil forState:UIControlStateNormal];
    [[self ims_maskView] removeFromSuperview];
    [self setIms_maskView:nil];
}

@end















