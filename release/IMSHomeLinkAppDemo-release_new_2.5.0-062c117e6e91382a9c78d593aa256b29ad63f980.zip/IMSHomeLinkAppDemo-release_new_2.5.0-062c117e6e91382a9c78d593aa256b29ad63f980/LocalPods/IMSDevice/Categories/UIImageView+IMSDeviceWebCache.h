//
//  UIImageView+IMSDeviceWebCache.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/11.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImageView (IMSDeviceWebCache)

- (void)imsDevice_setImageWithURL:(nullable NSURL *)url;

- (void)imsDevice_setImageWithURL:(nullable NSURL *)url
                 placeholderImage:(nullable UIImage *)placeholder;

@end

NS_ASSUME_NONNULL_END















