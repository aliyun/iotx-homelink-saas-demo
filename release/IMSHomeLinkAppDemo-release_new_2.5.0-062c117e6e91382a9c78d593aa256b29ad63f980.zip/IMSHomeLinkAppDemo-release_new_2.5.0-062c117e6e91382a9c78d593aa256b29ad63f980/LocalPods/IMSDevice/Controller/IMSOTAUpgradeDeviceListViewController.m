//
//  IMSOTAUpgradeDeviceListViewController.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/29.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSOTAUpgradeDeviceListViewController.h"
#import <IMSRouter/IMSRouter.h>
#import <IMSCategory/IMSCategory.h>
#import <IMSHUD/UIViewController+HUD.h>
#import "UIView+IMSDeviceEmptyData.h"
#import "UIImage+IMSDeviceExtension.h"
#import "UIImageView+IMSDeviceWebCache.h"
#import "UITableView+IMSDeviceExtension.h"
#import "IMSDeviceBasicCell+IMSOTAUpgradeDeviceInfoModel.h"
#import "IMSDeviceClient.h"
#import "IMSOTAFirmwareDetailViewController.h"
#import "IMSDeviceBasicCell.h"
#import "IMSOTAUpgradeDeviceInfoModel.h"

@interface IMSOTAUpgradeDeviceListViewController ()<IMSURLHandler>

@property (nonatomic, copy) NSArray<IMSOTAUpgradeDeviceInfoModel *> *deviceList;

@end

@implementation IMSOTAUpgradeDeviceListViewController

+ (void)load {
    NSURL *url = [NSURL URLWithString:@"https://com.aliyun.iot.ilop/page/ota/list"];
    [[IMSRouterService sharedService] registerURL:url withHandler:[self class]];
}

#pragma mark - AKURLHandler

+ (UIViewController *)controllerWithParams:(NSDictionary *)params {
    IMSOTAUpgradeDeviceListViewController *controller = [[self alloc] init];
    return controller;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"固件升级";
    self.view.backgroundColor = [UIColor ims_backgroundColor];
    [self configTableView];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    [self requestUpgradeDeviceList];
}

- (void)configTableView {
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.tableView registerClass:[IMSDeviceBasicCell class] forCellReuseIdentifier:@"cell"];
    self.tableView.rowHeight = 64.f;
    self.tableView.contentInset = UIEdgeInsetsMake(20, 0, 0, 0);
}

- (void)showIMSOTAFirmwareDetail:(IMSOTAUpgradeDeviceInfoModel *)model {
    IMSOTAFirmwareDetailViewController *vc = [[IMSOTAFirmwareDetailViewController alloc] init];
    vc.iotId = model.iotId;
    vc.productName = model.deviceName;
    vc.houseId = self.houseId;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - Request

- (void)requestUpgradeDeviceList {
    [self ims_showHUDWithIndicator];

    __weak typeof(self) weakSelf = self;
    [[IMSDeviceClient sharedClient] loadOTAUpgradeDeviceListWithHouseId:self.houseId completionHandler:^(NSArray<IMSOTAUpgradeDeviceInfoModel *> *list, NSError *error) {
        if (error) {
            [self ims_showHUDWithMessage:error.localizedDescription];
        } else {
            [weakSelf setDeviceList:list];

            [self ims_hideHUD];
            if ([weakSelf deviceList].count == 0) {
                [self.tableView imsDevice_emptyDataDisplayWithImage:[UIImage imsDevice_imageNamed:@"IMSOTA_icon_default"] message:@"全部是最新版本"];
            } else {
                [self.tableView imsDevice_removeEmptyData];
            }
        }

        [self.tableView reloadData];
    }];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.deviceList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    IMSDeviceBasicCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    IMSOTAUpgradeDeviceInfoModel *model = self.deviceList[indexPath.row];
    [cell setUpgradeDeviceInfoModel:model];
    
    [tableView imsDevice_hiddenSectionLastCellOfSeparatorViewWithCell:cell indexPath:indexPath];
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    IMSOTAUpgradeDeviceInfoModel *model = self.deviceList[indexPath.row];
    [self showIMSOTAFirmwareDetail:model];
}

@end
















