//
//  IMSDeviceBindViewController.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/28.
//  Copyright © 2018年 alibaba. All rights reserved.
//

#import <UIKit/UIKit.h>

FOUNDATION_EXTERN NSString *const IMSBoneRouterBindDeviceSuccessNoti;

@interface IMSDeviceBindViewController : UIViewController

/**
 产品键，必传
 */
@property (nonatomic, copy) NSString *productKey;

/**
 设备名称，必传
 */
@property (nonatomic, copy) NSString *deviceName;

/**
 设备入网类型，非必传(入网类型的字符串)
 */
@property (nonatomic, copy) NSString *netType;

/**
 房间id，y全屋必传
 */
@property (nonatomic, copy) NSString *roomId;

/**
 绑定成功回调
 */
@property (nonatomic, copy) void(^bindCallBack)(NSString *productKey, NSString *iotId);

@end









