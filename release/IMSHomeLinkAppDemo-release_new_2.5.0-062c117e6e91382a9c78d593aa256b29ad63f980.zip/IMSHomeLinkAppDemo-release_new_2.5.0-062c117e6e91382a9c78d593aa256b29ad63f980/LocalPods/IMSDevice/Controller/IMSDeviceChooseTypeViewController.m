//
//  ChooseDeviceTypeViewController1.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/2.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSDeviceChooseTypeViewController.h"
#import <Masonry/Masonry.h>
#import <IMSCategory/IMSCategory.h>
#import <IMSHUD/UIViewController+HUD.h>
#import <IMSRefresh/IMSRefresh.h>
#import <IMSScanner/IMSScanner.h>
#import <IMLDeviceCenter/IMLDeviceCenter.h>
#import <IMSThingCapability/IMSDiscoveryRegistry.h>
#import <IMSThingCapability/IMSSubDeviceService.h>
#import "UIImage+IMSDeviceExtension.h"
#import "UIColor+IMSDeviceExtension.h"
#import "UIScrollView+IMSDeviceRefresh.h"
#import "UITableView+IMSDeviceExtension.h"
#import "IMSDeviceLocalCell.h"
#import "IMSDeviceBasicCell+IMSDeviceInfoModel.h"
#import "IMSDeviceBasicCell+IMSDeviceCategoryInfoModel.h"
#import "IMSDeviceBasicCell+IMSDeviceProductInfoModel.h"
#import "IMLCandDeviceModel+IMSDeviceInfo.h"
#import "IMSDeviceLog.h"
#import "IMSDeviceClient.h"
#import "IMSDevicePluginsService.h"
#import "IMSDeviceBindService.h"
#import "IMSDeviceBindViewController.h"
#import "IMSDeviceCategoryInfoModel.h"
#import "IMSDeviceInfoModel.h"
#import "IMSDeviceScanService.h"
#import "IMSDeviceSearchViewController.h"
#import "IMSDeviceSearchView.h"
#import "UIImageView+IMSDeviceWebCache.h"
#import "IMSDeviceProductCell.h"
#import <IMSPackage/IMSPackageManager.h>
#import <CoreLocation/CoreLocation.h>

static CGFloat kSearchViewHeight = 68.f;
static CGFloat kLocalTableViewSectionViewHegiht = 36.f;
static CGFloat kLocalDistanceCellHeight = 84.f;
static CGFloat kCategotyCellHeight = 54.f;
static CGFloat kProductCollectionViewCellWidth = 70.f;
static CGFloat kProductCollectionViewCellHeight = 80.f;

static NSString * const KCellReuseIdentifierDeviceLocalCell = @"DeviceLocalCell";
static NSString * const KCellReuseIdentifierDeviceCategoryCell = @"DeviceCategoryCell";
static NSString * const KCellReuseIdentifierDeviceProductCell = @"IMSDeviceProductCell";
static NSString * const KCellReuseIdentifierDeviceLocalBindedCell = @"DeviceLocalBindedCell";

@interface IMSDeviceChooseTypeViewController ()<UITableViewDelegate, UITableViewDataSource, UICollectionViewDelegate, UICollectionViewDataSource>

@property (nonatomic, strong) IMSDeviceSearchView *searchView;                                  /*搜索View*/
@property (nonatomic, strong) NSMutableArray<IMSDeviceCategoryInfoModel *> *categoryList;       /*分类list*/
@property (nonatomic, strong) NSMutableArray<IMSDeviceInfoModel *> *localDeviceList;            /*最终展示的本地发现设备*/
@property (nonatomic, strong) NSMutableArray<IMLCandDeviceModel *> *discoveryDeviceList;
@property (nonatomic, strong) NSMutableArray<id<IMSLocalDevice>> *discoveryBTDeviceList;
@property (nonatomic, strong) NSMutableArray<IMSDeviceInfoModel *> *bindBluetoothDeviceList;
@property (nonatomic, strong) NSMutableArray<IMSDeviceProductInfoModel *> *productList;         /*产品list*/
@property (nonatomic, strong) UITableView *localDeviceTableView;                                /*本地发现TV*/
@property (nonatomic, strong) UITableView *categoryDeviceTableView;                             /*分类TV*/
@property (nonatomic, strong) UICollectionView *collectionView;                                 /*产品CV*/
@property (nonatomic, weak) IMSDeviceLocalCell *localBTCell;
@property (nonatomic, assign) BOOL isBTDeviceAdding;
@property (nonatomic, assign) NSInteger categorySelectIndex;                                    /*当前选中的分类*/

@property (nonatomic, strong) CLLocationManager *cllocation;

@end

@implementation IMSDeviceChooseTypeViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"添加设备";
    self.view.backgroundColor = [UIColor ims_backgroundColor];
    [self configNavigationBar];
    [self configTableView];
    [self requestDeviceCategoryList];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    self.navigationController.navigationBarHidden = NO;
    //页面重新进入后清空本地设备重新发现
    [self.discoveryDeviceList removeAllObjects];
    [self.discoveryBTDeviceList removeAllObjects];
    [self.localDeviceList removeAllObjects];
    
    //重新去掉数据，同时重新布局
    [self.localDeviceTableView reloadData];
    
    [self startDiscoverDevices];
    IMSDeviceLogVerbose(@"重新进入:self.discoveryDeviceList = %@ ,self.localDeviceList = %@",self.discoveryDeviceList, self.localDeviceList);
    
    if ([self checkLocationState] == NO) {
        [self showLocationNoOpenAlertViewController];
    }
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    
    IMSDeviceLogVerbose(@"停止本地发现。。。");
    [[IMLLocalDeviceMgr sharedMgr] stopDiscovery];
    [[IMSThingDiscoveryRegistry sharedRegistry] stopDiscovery:^(BOOL succeeded, NSError * _Nullable error) {
        
    }];
    
    if (self.bindBluetoothDeviceList.count > 0) {
        [self.localDeviceTableView reloadData];
        [self.bindBluetoothDeviceList removeAllObjects];
    }
}


/**
 iOS 检测定位服务提示
 */
- (void)showLocationNoOpenAlertViewController {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示"
                                                                   message:@"定位未开，可能获取不到wifi名称,影响配网体验" /////TODO
                                                            preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *confirm = [UIAlertAction actionWithTitle:@"去设置"
                                                      style:UIAlertActionStyleDefault
                                                    handler:^(UIAlertAction * _Nonnull action) {
                                                        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
                                                    }];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消"
                                                     style:UIAlertActionStyleDefault
                                                   handler:^(UIAlertAction * _Nonnull action) {
                                                       
                                                   }];
    [alert addAction:cancel];
    [alert addAction:confirm];
    [self presentViewController:alert animated:YES completion:nil];
}


// iOS 13 定位检查
- (BOOL) checkLocationState {
    if (@available(iOS 13.0, *)) {
        if ([CLLocationManager authorizationStatus] == kCLAuthorizationStatusDenied) {
            [self showLocationNoOpenAlertViewController];
            return NO;
        }
        
        if (self.cllocation == nil) {
            self.cllocation = [[CLLocationManager alloc] init];
        }
        if(![CLLocationManager locationServicesEnabled] || [CLLocationManager authorizationStatus] == kCLAuthorizationStatusNotDetermined){
            [self.cllocation requestWhenInUseAuthorization];
            return NO;
        }
    }
    return YES;
}

#pragma mark - Method

- (void)setIsBTDeviceAdding:(BOOL)isBTDeviceAdding {
    _isBTDeviceAdding = isBTDeviceAdding;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.isBTDeviceAdding) {
            [self.localBTCell startAddBTDeviceAnimation];
        } else {
            [self.localBTCell stopAddBTDeviceAnimation];
        }
    });
}

- (void)reloadProductTablViewWithSelectIndex:(NSInteger)row {
    IMSDeviceCategoryInfoModel *categoryInfo = self.categoryList[row];
    [self.collectionView setPageNum:1];
    [self requestCategoryDeviceListWithCategoryKey:categoryInfo.categoryKey];
    
    self.categorySelectIndex = row;
    [self.categoryDeviceTableView reloadData];
}

- (BOOL)discoveryDeviceListIsEqualToDevice:(IMLCandDeviceModel *)device {
    for (IMLCandDeviceModel *discoveryDevice in self.discoveryDeviceList) {
        if ([device.deviceName isEqualToString:discoveryDevice.deviceName] && [device.productKey isEqualToString:discoveryDevice.productKey]) {
            return YES;
        }
    }
    return NO;
}

- (BOOL)discoveryBTDeviceListIsEqualToDevice:(id<IMSLocalDevice>)device {
    for (id<IMSLocalDevice> discoveryDevice in self.discoveryBTDeviceList) {
        if ([device.deviceName isEqualToString:discoveryDevice.deviceName] && [device.productKey isEqualToString:discoveryDevice.productKey]) {
            return YES;
        }
    }
    
    return NO;
}

- (IMLCandDeviceModel *)getCandDevice:(IMSDeviceInfoModel *)device {
    for (IMLCandDeviceModel *candDevice in self.discoveryDeviceList) {
        if ([candDevice.productKey isEqualToString:device.productKey] && [candDevice.deviceName isEqualToString:device.deviceName]) {
            return candDevice;
        }
    }
    return nil;
}

#pragma mark - Action

#pragma mark - Scan

- (void)scanClickedAction:(id)sender {
    if (!self.isBTDeviceAdding) {
        IMSScanViewController *controller = [[IMSScanViewController alloc] init];
        controller.titleStr = @"扫描二维码";
        controller.tipStr = @"请将设备二维码放置在识别框中";
        controller.errorStr = @"请在iPhone的”设置-隐私-相机“选项中，允许App访问你的相机";
        controller.errorConfirm = @"确认";
        
        __weak typeof(controller) wController = controller;
        controller.resultBlock = ^(NSString *value) {
            [wController dismissViewControllerAnimated:YES completion:^{
                [self scanJudgeWithValue:value];
            }];
        };
        [self.navigationController presentViewController:controller animated:YES completion:nil];
    }
}

- (void)scanJudgeWithValue:(NSString *)value {
    [IMSDeviceScanService scanJudgeWithValue:value completionHandler:^(NSString *productKey, NSString *deviceName, IMSDeviceProductType type, NSError *error) {
        if (error) {
            [self ims_showHUDWithMessage:@"不支持的二维码"];
        } else {
			[self showProvisionPluginWithProductKey:productKey deviceName:deviceName token:nil addDeviceFrom:nil];
        }
    }];
}

#pragma mark - Add Bluetooth Device

- (void)bluetoothClickedAction {
    if (!self.isBTDeviceAdding) {
        [self showProvisionPluginWithProductKey:@"Bluetooth" deviceName:nil token:nil addDeviceFrom:nil];
    }
}

- (void)searchViewClick {
    IMSDeviceSearchViewController *searchViewController = [[IMSDeviceSearchViewController alloc] init];
    [self.navigationController pushViewController:searchViewController animated:YES];
}

#pragma mark - Request

- (void)requestDeviceCategoryList {
    [self ims_showHUDWithIndicator];
    
    [[IMSDeviceClient sharedClient] loadDeviceCategoryListWithPageNum:self.categoryDeviceTableView.pageNum pageSize:20 completionHandler:^(NSInteger totalNum, NSArray<IMSDeviceCategoryInfoModel *> *list, NSError *error) {
        if (error) {
            [self ims_showHUDWithMessage:error.localizedDescription];
        } else {
            [self.categoryList addObjectsFromArray:list];
            [self ims_hideHUD];
        }
        
        IMSDeviceLogVerbose(@"品类 list == %@",list);
        if (!error && ![self.categoryDeviceTableView imsDevice_endRefreshingNoMoreDataWithItemCount:self.categoryList.count totalNum:totalNum]) {
            self.categoryDeviceTableView.pageNum++;
        }

        [self.categoryDeviceTableView reloadData];
        
        if (self.categoryList.count > 0) {
            IMSDeviceCategoryInfoModel *categoryInfo = self.categoryList[self.categorySelectIndex];
            [self requestCategoryDeviceListWithCategoryKey:categoryInfo.categoryKey];
        }
    }];
}

- (void)requestCategoryDeviceListWithCategoryKey:(NSString *)categoryKey {
    if (categoryKey) {
        [self ims_showHUDWithIndicator];
        
        [[IMSDeviceClient sharedClient] loadCategoryProductListWithPageNum:self.collectionView.pageNum pageSize:20 categoryKey:categoryKey completionHandler:^(NSInteger totalNum, NSArray<IMSDeviceProductInfoModel *> *list, NSError *error) {
            if (error) {
                [self ims_showHUDWithMessage:error.localizedDescription];
            } else {
                [self ims_hideHUD];
                if (self.collectionView.pageNum == 1) {
                    [self.productList removeAllObjects];
                }
                
                [self.productList addObjectsFromArray:list];
            }
            
            IMSDeviceLogVerbose(@"品类key = %@下产品 list == %@",categoryKey ,list);
            if (!error && ![self.collectionView imsDevice_endRefreshingNoMoreDataWithItemCount:self.productList.count totalNum:totalNum]) {
                self.collectionView.pageNum++;
            }
            
            [self.collectionView reloadData];
        }];
    } else {
        IMSDeviceLogError(@"error：缺少必传参数，categoryKey：%@", categoryKey);
    }
}

- (void)requestFilterLocalDeviceList:(NSArray<NSDictionary *> *)deviceList {
    [[IMSDeviceClient sharedClient] filterLocalProductWithIotDevices:deviceList completionHandler:^(NSArray<IMSDeviceInfoModel *> *list, NSError *error) {
        if (error) {
            [self ims_showHUDWithMessage:error.localizedDescription];
        } else {
            IMSDeviceLogVerbose(@"云端过滤后返回设备列表：%@", list);
            IMSDeviceLogVerbose(@"本地数据列表 == %@",self.localDeviceList);
            if (list.count > 0) {
                [self.localDeviceList addObjectsFromArray:list];

                IMSDeviceLogVerbose(@"云端过滤后本地发现设备列表：%@", self.localDeviceList);
            }
        }
    
        [self.localDeviceList addObjectsFromArray:self.bindBluetoothDeviceList];
        IMSDeviceLogVerbose(@"过滤完成的设备总列表 == %@",self.localDeviceList);
        [self.localDeviceTableView reloadData];
    }];
}

- (void)startBindDeviceWithProductKey:(NSString *)productKey deviceName:(NSString *)deviceName {
    [self ims_showHUDWithIndicator];
    
    [IMSDeviceBindService bindDeviceWithProductKey:productKey deviceName:deviceName netType:IMSDeviceCategoryProductNetTypeNone roomIds:self.roomId ? @[self.roomId] : nil completionHandler:^(NSString *iotId, NSError *error) {
        [self bindCompletionHandler:iotId productKey:productKey error:error];
    }];
}

- (void)bindCompletionHandler:(NSString *)iotId productKey:(NSString *)productKey error:(NSError *)error {
    if (error) {
        [self ims_showHUDWithMessage:error.localizedDescription];
    } else {
        [self ims_hideHUD];
        
        if (self.bindCallBack) {
            self.bindCallBack(productKey, iotId);
        } else {
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
    }
}

#pragma mark - 插件回调

- (IMSRouterCallback)provisionPluginCallback:(NSString *)deviceName {
    IMSRouterCallback callback = ^(NSError *error, NSDictionary *info) {
        IMSDeviceLogVerbose(@"插件回调 info == %@, error = %@",info ,error);
        if (error) {
            IMSDeviceLogError(@"配网 error:%@", error);
            [self ims_showHUDWithMessage:error.localizedDescription];
        } else if (info && [info count] > 0) {
            IMSDeviceLogVerbose(@"配网 info: %@", info);
            
            id value = info[@"isExit"];
            if ([value boolValue]) {
                [self.navigationController popToRootViewControllerAnimated:NO];
            } else {
                NSString *tempProductKey = info[@"productKey"];
                NSString *iotId = info[@"iotId"];
                if (iotId.length > 0) {
                    if (self.bindCallBack) {
                        self.bindCallBack(tempProductKey, iotId);
                    }
                } else {
                    [self.navigationController popToViewController:self animated:YES];
                    
                    NSString *tempDeviceName = nil;
                    if (deviceName) {
                        tempDeviceName = deviceName;
                    } else {
                        tempDeviceName = info[@"deviceName"];
                    }
                    
                    if (self.roomId.length > 0) {
                        [self startBindDeviceWithProductKey:tempProductKey deviceName:tempDeviceName];
                    } else {
                        [self showBindControllerWithProductKey:tempProductKey deviceName:tempDeviceName];
                    }
                }
            }
        } else {
            [self.navigationController popToViewController:self animated:YES];
            if (self.bindCallBack) {
                self.bindCallBack(nil, nil);
            }
            IMSDeviceLogVerbose(@"配网正常退出...");
        }
    };
    
    return callback;
}


- (void)showProvisionPluginWithProductKey:(NSString *)productKey
                               deviceName:(NSString *)deviceName
                                    token:(NSString *)token
                            addDeviceFrom:(NSString *)addDeviceFrom {
    IMSRouterCallback callback = [self provisionPluginCallback:deviceName];
    [IMSDevicePluginsService showProvisionWithProductKey:productKey deviceName:deviceName token:token addDeviceFrom:addDeviceFrom houseId:self.houseId routerCompletionHandler:callback completionHandler:^(BOOL success) {
        if (!success) {
            [self ims_showHUDWithMessage:@"加载失败，请稍后再试"];
        }
    }];
}

- (void)showBindControllerWithProductKey:(NSString *)productKey deviceName:(NSString *)deviceName {
    if (productKey.length > 0) {
		IMSDeviceBindViewController *controller = [[IMSDeviceBindViewController alloc] init];
		controller.productKey = productKey;
		controller.deviceName = deviceName;
		controller.bindCallBack = self.bindCallBack;
		[self.navigationController pushViewController:controller animated:YES];
    } else {
        IMSDeviceLogError(@"绑定设备缺少productKey");
    }
}

- (void)startProvisionWithDevice:(IMSDeviceInfoModel *)device {
    if (device.productKey) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            IMLCandDeviceModel *candDevice = [self getCandDevice:device];
            
            // 蓝牙设备不需要配网
            if (device.netType == IMSDeviceCategoryProductNetTypeBT) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (device.productKey && device.deviceName) {
                        [IMSSubDeviceService subDeviceAuthenLogin:@{@"productKey":device.productKey, @"deviceName":device.deviceName} resultBlock:^(NSDictionary * _Nullable object, NSError * _Nullable error) {
                            if (error) {
                                [self ims_showHUDWithMessage:@"设备添加失败，请靠近蓝牙设备或重启设备，进行重试"];
                                self.isBTDeviceAdding = NO;
                            } else {
                                NSString *deviceName = object[@"deviceName"];
                                [IMSDeviceBindService bindDeviceWithProductKey:device.productKey deviceName:deviceName netType:device.netType roomIds:self.roomId ? @[self.roomId] : nil completionHandler:^(NSString *iotId, NSError *error) {
                                    if (error) {
                                        [self ims_showHUDWithMessage:@"设备添加失败，请靠近蓝牙设备或重启设备，进行重试"];
                                        self.isBTDeviceAdding = NO;
                                    } else {
                                        [self ims_showHUDWithMessage:@"设备添加成功！"];
                                        self.isBTDeviceAdding = NO;
                                        
                                        if (self.bindCallBack) {
                                            self.bindCallBack(nil, nil);
                                        }
                                        
                                        NSDictionary *deviceInfo = @{@"deviceName": device.deviceName ?: @"",
                                                                     @"productKey": device.productKey ?: @"",
                                                                     @"iotId": iotId ?: @""};
                                        [IMSSubDeviceService notifySubDeviceBinded:deviceInfo];
                                        
                                        if (iotId) {
                                            device.iotId = iotId;
                                        }
                                        
                                        device.isBinded = YES;
                                        [self.bindBluetoothDeviceList addObject:device];
                                        
                                        [self.localDeviceTableView reloadData];
                                    }
                                }];
                            }
                        }];
                    }
                });
            } else {
                dispatch_async(dispatch_get_main_queue(), ^{
                    IMSDeviceLogVerbose(@"进入插件的参数：productKey = %@，deviceName = %@，token = %@，addDeviceFrom = %@, 本地发现list = %@",device.productKey ,device.deviceName ,candDevice.token ,candDevice.addDeviceFrom, self.discoveryDeviceList);
                    [self showProvisionPluginWithProductKey:device.productKey deviceName:device.deviceName token:candDevice.token addDeviceFrom:candDevice.addDeviceFrom];
                });
            }
        });
    } else {
        [self ims_showHUDWithMessage:@"加载失败，请稍后再试"];
    }
}

- (void)startDiscoverDevices {
    IMSDeviceLogVerbose(@"开始发现本地设备...");

    [[IMLLocalDeviceMgr sharedMgr] startDiscoveryWithFilter: @{@"groupId" : @"HOMELINK_AQUARIUS"} discoverBlcok:^(NSArray *devices, NSError *err) {
        IMSDeviceLogVerbose(@"发现（未云端过滤的）待配网设备 error = %@, devices = %@",err,devices);
        if (devices && devices.count > 0) {
            IMSDeviceLogVerbose(@"发现本地设备: %@", devices);
            IMSDeviceLogError(@"发现（未云端过滤的）待配网设备 error = %@, devices = %@",err,devices);
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                NSMutableArray *iotDevices = [NSMutableArray arrayWithCapacity:devices.count];
                for (IMLCandDeviceModel *device in devices) {
                    if (device.productKey && device.deviceName) {
                        if (![self discoveryDeviceListIsEqualToDevice:device]) {
                            IMSDeviceLogVerbose(@"合格其他设备：pk = %@；dn = %@",device.productKey,device.deviceName);
                            [iotDevices addObject:@{@"productKey": device.productKey, @"deviceName": device.deviceName}];
                        }
                    } else {
                        IMSDeviceLogError(@"error:缺少必传参数，productKey：%@，deviceName：%@，device：%@", device.productKey, device.deviceName, device);
                    }
                }
                
                if (iotDevices.count > 0) {
                    @synchronized (self) {
                        [self.discoveryDeviceList addObjectsFromArray:devices];
                        IMSDeviceLogVerbose(@"本地发现去重list = %@",self.discoveryDeviceList);
                    }
                    [self requestFilterLocalDeviceList:iotDevices];
                }
            });
        } else if (err) {
            IMSDeviceLogError(@"error:本地发现设备出错: %@", err);
        }
    }];
    
    // 发现蓝牙设备
    [[IMSThingDiscoveryRegistry sharedRegistry] startDiscoveryWithFilter:@{@"deviceType": @[@"breeze"]} didFoundBlock:^(NSArray * _Nullable result, NSError * _Nullable error) {
        IMSDeviceLogVerbose(@"发现（未云端过滤的）蓝牙设备 error = %@, result = %@",error,result);
        NSMutableArray *iotDevices = [NSMutableArray arrayWithCapacity:result.count];
        for (id<IMSLocalDevice>device in result) {
            if (device.productKey && device.deviceName) {
                if (![self discoveryBTDeviceListIsEqualToDevice:device]) {
                    IMSDeviceLogVerbose(@"合格蓝牙设备：pk = %@；dn = %@",device.productKey,device.deviceName);
                    [iotDevices addObject:@{@"productKey": device.productKey, @"deviceName": device.deviceName}];
                }
            } else {
                IMSDeviceLogError(@"error:缺少必传参数，productKey：%@，deviceName：%@，device：%@", device.productKey, device.deviceName, device);
            }
            
            if (iotDevices.count > 0) {
                @synchronized (self) {
                    [self.discoveryBTDeviceList addObjectsFromArray:result];
                }
                [self requestFilterLocalDeviceList:iotDevices];
            }
        }
    }];
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView == self.localDeviceTableView) {
        return self.localDeviceList.count;
    }
    return self.categoryList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView == self.localDeviceTableView) {
        IMSDeviceInfoModel *device = nil;
        if (self.localDeviceList.count > indexPath.row) {
            device = self.localDeviceList[indexPath.row];
        }
        if (device.isBinded) {
            IMSDeviceBasicCell *cell = [tableView dequeueReusableCellWithIdentifier:KCellReuseIdentifierDeviceLocalBindedCell forIndexPath:indexPath];
            cell.device = device;

            return cell;
        } else {
            IMSDeviceLocalCell *cell = [tableView dequeueReusableCellWithIdentifier:KCellReuseIdentifierDeviceLocalCell forIndexPath:indexPath];
            [cell updateLayout];
            if (self.localDeviceList.count > indexPath.row) {
                [cell setDevice:self.localDeviceList[indexPath.row]];
            }

            __weak typeof(self) wSelf = self;
            __weak typeof(cell) wCell = cell;
            cell.addDeviceClickedBlock = ^() {
                IMSDeviceInfoModel *device = [wCell device];
                if (device.netType == IMSDeviceCategoryProductNetTypeBT) {
                    wSelf.localBTCell = wCell;
                    wSelf.isBTDeviceAdding = YES;
                }
                [wSelf startProvisionWithDevice:device];
            };

            return cell;
        }
    }
    
    if (tableView == self.categoryDeviceTableView) {
        IMSDeviceBasicCell *cell = [tableView dequeueReusableCellWithIdentifier:KCellReuseIdentifierDeviceCategoryCell forIndexPath:indexPath];
        IMSDeviceCategoryInfoModel *model = self.categoryList[indexPath.row];
        [cell setCategoryInfo:model];
        if (indexPath.row == self.categorySelectIndex) {
            cell.backgroundColor = [UIColor whiteColor];
            cell.ims_textLabel.textColor = [UIColor ims_systemMaticColor];
        } else {
            cell.backgroundColor = [UIColor imsDevice_colorWithHexString:@"F6F6F6"];
            cell.ims_textLabel.textColor = [UIColor ims_accessaryColor];
        }
        
        return cell;
    }
    
    return nil;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView == self.categoryDeviceTableView) {
        [tableView imsDevice_hiddenAllCellOfSeparatorViewWithCell:(IMSDeviceBasicCell *)cell indexPath:indexPath];
    }
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section {
    if (tableView == self.localDeviceTableView) {
        UITableViewHeaderFooterView *headerView = (UITableViewHeaderFooterView *)view;
        headerView.backgroundView.backgroundColor = [UIColor ims_backgroundColor];
        headerView.textLabel.textColor = [UIColor ims_accessaryColor];
        headerView.textLabel.font = [UIFont ims_regularFontOfSize:12];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView == self.localDeviceTableView ) {
        return kLocalDistanceCellHeight;
    }
    return kCategotyCellHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return CGFLOAT_MIN;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (tableView == self.localDeviceTableView) {
        if (self.localDeviceList.count == 0) {
            return CGFLOAT_MIN;
        }
        return kLocalTableViewSectionViewHegiht;
    }
    return CGFLOAT_MIN;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (!self.isBTDeviceAdding) {
        if (tableView == self.localDeviceTableView) {
            IMSDeviceInfoModel *deviceInfo = self.localDeviceList[indexPath.row];
            if (deviceInfo.isBinded) {
                [IMSDevicePluginsService showDeviceControlPanelWithIotId:deviceInfo.iotId productKey:deviceInfo.productKey completionHandler:nil];
            }
        } else if (tableView == self.categoryDeviceTableView) {
            [self reloadProductTablViewWithSelectIndex:indexPath.row];
        }
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (tableView == self.localDeviceTableView && self.localDeviceList.count != 0) {
        return @"本地发现的设备";
    }
    
    return nil;
}

#pragma mark - UICollectionViewDataSource

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.productList.count;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    IMSDeviceProductCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:KCellReuseIdentifierDeviceProductCell forIndexPath:indexPath];
    IMSDeviceProductInfoModel *productInfo = self.productList[indexPath.row];
    cell.ims_titleLabel.text = productInfo.productName;
    [cell.ims_imageV imsDevice_setImageWithURL:[NSURL URLWithString:productInfo.image] placeholderImage:[UIImage imsDevice_imageNamed:@"IMSDevice_placeholder"]];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    IMSDeviceProductInfoModel *productInfo = self.productList[indexPath.row];
    if (productInfo.netType == IMSDeviceCategoryProductNetTypeCELLULAR) {
        IMSScanViewController *controller = [[IMSScanViewController alloc] init];
        controller.titleStr = @"扫描二维码";
        controller.tipStr = @"请将设备二维码放置在识别框中";
        controller.errorStr = @"请在iPhone的”设置-隐私-相机“选项中，允许App访问你的相机";
        controller.errorConfirm = @"确认";
        
        __weak typeof(controller) wController = controller;
        controller.resultBlock = ^(NSString *value) {
            [wController dismissViewControllerAnimated:YES completion:^{
                [self scanJudgeWithValue:value];
            }];
        };
        [self.navigationController presentViewController:controller animated:YES completion:nil];
    } else {
        [self showProvisionPluginWithProductKey:productInfo.productKey deviceName:nil token:nil addDeviceFrom:nil];
    }
}

#pragma mark - Layout

- (void)configNavigationBar {
    UIButton *scanBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    scanBtn.frame = CGRectMake(0, 0, 35, 44);
    [scanBtn setImage:[UIImage imsDevice_imageNamed:@"IMSDevice_scan_green"] forState:UIControlStateNormal];
    [scanBtn addTarget:self action:@selector(scanClickedAction:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *scanItem = [[UIBarButtonItem alloc] initWithCustomView:scanBtn];
    
    UIButton *bluetoothBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    bluetoothBtn.frame = CGRectMake(0, 0, 35, 44);
    [bluetoothBtn setImage:[UIImage imsDevice_imageNamed:@"IMSDevice_bluetooth_green"] forState:UIControlStateNormal];
    [bluetoothBtn addTarget:self action:@selector(bluetoothClickedAction) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *bluetoothItem = [[UIBarButtonItem alloc] initWithCustomView:bluetoothBtn];
    [self.navigationItem setRightBarButtonItems:@[scanItem, bluetoothItem]];
}

- (void)configTableView {
    self.searchView = [IMSDeviceSearchView initView];
    self.searchView.searchTF.userInteractionEnabled = NO;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(searchViewClick)];
    [self.searchView addGestureRecognizer:tap];
    [self.view addSubview:self.searchView];
    [self.searchView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.right.equalTo(self.view);
        make.height.mas_equalTo(kSearchViewHeight);
    }];
    
    //本地设备
    self.localDeviceTableView = [self configureTableViewDetail];
    [self.view addSubview:self.localDeviceTableView];
    [self.localDeviceTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.searchView.mas_bottom);
        make.left.right.equalTo(self.view);
		if (@available(iOS 11.0, *)) {
		make.bottom.equalTo(self.view.mas_safeAreaLayoutGuideBottom);
		} else {
			make.bottom.equalTo(self.view);
		}
    }];
    [self.localDeviceTableView registerClass:[IMSDeviceLocalCell class] forCellReuseIdentifier:KCellReuseIdentifierDeviceLocalCell];
    [self.localDeviceTableView registerClass:[IMSDeviceBasicCell class] forCellReuseIdentifier:KCellReuseIdentifierDeviceLocalBindedCell];
    if (@available(iOS 11.0, *)) {
        self.localDeviceTableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    
    UIView *categotyAndProductBGView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.height, [UIScreen mainScreen].bounds.size.height - kSearchViewHeight - 44 - [UIApplication sharedApplication].statusBarFrame.size.height)];
    categotyAndProductBGView.backgroundColor = [UIColor ims_backgroundColor];
    self.localDeviceTableView.tableFooterView = categotyAndProductBGView;
    
    //品类
    self.categoryDeviceTableView = [self configureTableViewDetail];
    [categotyAndProductBGView addSubview:self.categoryDeviceTableView];
    [self.categoryDeviceTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(categotyAndProductBGView.mas_top).offset(1);
        make.width.mas_equalTo(100);
		
		if (@available(iOS 11.0, *)) {
			make.left.equalTo(categotyAndProductBGView.mas_left);	make.bottom.equalTo(categotyAndProductBGView.mas_safeAreaLayoutGuideBottom);

		} else {
			make.left.bottom.equalTo(categotyAndProductBGView);
		}
    }];
    [self.categoryDeviceTableView registerClass:[IMSDeviceBasicCell class] forCellReuseIdentifier:KCellReuseIdentifierDeviceCategoryCell];
    self.categoryDeviceTableView.mj_footer = [IMSFooterRefreshView footerWithRefreshingBlock:^{
        __strong typeof(self) weakSelf = self;
        [weakSelf requestDeviceCategoryList];
    }];
    
    //产品
    [categotyAndProductBGView addSubview:self.collectionView];
    [self.collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(categotyAndProductBGView.mas_top).offset(1);
         make.left.equalTo(self.categoryDeviceTableView.mas_right);
		
		if (@available(iOS 11.0, *)) {
			make.right.equalTo(categotyAndProductBGView.mas_right);	make.bottom.equalTo(categotyAndProductBGView.mas_safeAreaLayoutGuideBottom);
			
		} else {
			make.right.bottom.equalTo(categotyAndProductBGView);
		}
    }];
}

- (UITableView *)configureTableViewDetail {
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.backgroundColor = self.view.backgroundColor;
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.showsVerticalScrollIndicator = NO;
    
    return tableView;
}

- (void)updateCategoryAndProductTableViewLayout {
    if (self.localDeviceList.count == 0) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.localDeviceTableView mas_updateConstraints:^(MASConstraintMaker *make) {
                make.height.mas_offset(0);
            }];
        });
    } else {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.localDeviceTableView mas_updateConstraints:^(MASConstraintMaker *make) {
                make.height.mas_offset(kLocalTableViewSectionViewHegiht + kLocalDistanceCellHeight * self.localDeviceList.count);
            }];
        });
    }
}

#pragma mark - Lazy loading

- (NSMutableArray<IMSDeviceInfoModel *> *)localDeviceList {
    if (!_localDeviceList) {
        _localDeviceList = [[NSMutableArray alloc] init];
    }
    return _localDeviceList;
}

- (NSMutableArray<IMSDeviceInfoModel *> *)bindBluetoothDeviceList {
    if (!_bindBluetoothDeviceList) {
        _bindBluetoothDeviceList = [[NSMutableArray alloc] init];
    }
    return _bindBluetoothDeviceList;
}

- (NSMutableArray<IMLCandDeviceModel *> *)discoveryDeviceList {
    if (!_discoveryDeviceList) {
        _discoveryDeviceList = [[NSMutableArray alloc] init];
    }
    return _discoveryDeviceList;
}

- (NSMutableArray<id<IMSLocalDevice>> *)discoveryBTDeviceList {
    if (!_discoveryBTDeviceList) {
        _discoveryBTDeviceList = [[NSMutableArray alloc] init];
    }
    return _discoveryBTDeviceList;
}

- (NSMutableArray<IMSDeviceCategoryInfoModel *> *)categoryList {
    if (!_categoryList) {
        _categoryList = [[NSMutableArray alloc] init];
    }
    return _categoryList;
}

- (NSMutableArray<IMSDeviceProductInfoModel *> *)productList {
    if (!_productList) {
        _productList = [[NSMutableArray alloc] init];
    }
    return _productList;
}

- (UICollectionView *)collectionView {
    if (!_collectionView) {
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
        flowLayout.itemSize = CGSizeMake(kProductCollectionViewCellWidth, kProductCollectionViewCellHeight);
        flowLayout.minimumLineSpacing = 20;
        flowLayout.minimumInteritemSpacing = 20;
        flowLayout.sectionInset = UIEdgeInsetsMake(43, 10, 0, 10);
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:flowLayout];
        _collectionView.backgroundColor = [UIColor whiteColor];
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        [_collectionView registerClass:[IMSDeviceProductCell class] forCellWithReuseIdentifier:KCellReuseIdentifierDeviceProductCell];
        _collectionView.mj_footer = [IMSFooterRefreshView footerWithRefreshingBlock:^{
            __strong typeof(self) weakSelf = self;
            IMSDeviceCategoryInfoModel *categoryInfo = weakSelf.categoryList[weakSelf.categorySelectIndex];
            [weakSelf requestCategoryDeviceListWithCategoryKey:categoryInfo.categoryKey];
        }];
    }
    
    return _collectionView;
}

@end
