//
//  IMSOTAFirmwareDetailViewController.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/27.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSOTAFirmwareDetailViewController.h"
#import <IMSHUD/UIViewController+HUD.h>
#import <IMSCategory/IMSCategory.h>
#import "NSBundle+IMSDeviceExtension.h"
#import "UIImage+IMSDeviceExtension.h"
#import "UIView+IMSDeviceExtension.h"
#import "UIButton+IMSOTAAnimation.h"
#import "IMSDeviceLog.h"
#import "IMSDeviceClient.h"
#import "IMSOTAFirmwareInfoModel.h"
#import "IMSOTAMQTTProgressInfoModel.h"
#import "IMSOTAManager.h"
#import "IMSDeviceProductInfoModel.h"
#import <BreezeSdk/Breeze.h>
#import <OtaBusinessSdk/OtaBusinessSdk.h>

@interface IMSOTAFirmwareDetailViewController ()<IMSOTADelegate,BreezeDelagete>

@property (weak, nonatomic) IBOutlet UIImageView *stateImageView;
@property (weak, nonatomic) IBOutlet UILabel *latestVersionLabel;
@property (weak, nonatomic) IBOutlet UILabel *currentVersionLabel;
@property (weak, nonatomic) IBOutlet UIButton *upgradeButton;

//wifi和BT是一样的数据模型，用同一个即可
@property (nonatomic, strong) IMSOTAFirmwareInfoModel *firmwareInfo;
@property (nonatomic, strong) IMSOTAProgressInfoModel *progressInfo;

@property (nonatomic, assign, getter=isUpgradeSuccess) BOOL upgradeSuccess;

@property (nonatomic, assign) BOOL isBlueToothDevice;
@property (nonatomic, assign) IMSDeviceCategoryProductNetType netType;
@property (nonatomic, strong) LKLinkOtaBusiness *otaBusiness;
@property (nonatomic, strong) Breeze *breeze;
@property (nonatomic, strong) NSString *mac;
@property (nonatomic, assign) BOOL isConnectedBreeze;
@property (nonatomic, assign) BOOL isBreezeReboot;

@end

@implementation IMSOTAFirmwareDetailViewController

- (instancetype)init {
    self = [super initWithNibName:NSStringFromClass([self class]) bundle:[NSBundle imsDevice_bundle]];
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(50, 0, [UIScreen mainScreen].bounds.size.width - 100, 40)];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, view.frame.size.width, view.frame.size.height)];
    titleLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:18];
    titleLabel.text = [NSString stringWithFormat:@"%@%@", self.productName, @"固件升级"];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [view addSubview:titleLabel];
    self.navigationItem.titleView = view;
    
    [self configUpgradeButton];
    
    [self requestDeviceNetType];
}

- (void)dealloc {
    if (!self.isBlueToothDevice) {
        [[IMSOTAManager sharedInstance].otaCompoment unsubscribe];
    }
}

#pragma mark - Config

- (void)configUpgradeButton {
    [self.upgradeButton setTitle:@"立即升级" forState:UIControlStateNormal];
    [self.upgradeButton imsDevice_makeCircle];
}

- (void)configOTAManager {
    IMSOTAManager *otaManager = [IMSOTAManager sharedInstance];
    [otaManager configCompomentType:IMSOTACompomentTypeWifi];
    [otaManager.otaCompoment setOtaDelegate:self];
}

#pragma mark - Request

- (void)requestDeviceNetType {
    [[IMSDeviceClient sharedClient] queryProductInfoWithIotId:self.iotId completionHandler:^(IMSDeviceProductInfoModel *productInfo, NSError *error) {
        if (error) {
            IMSDeviceLogError(@"error == %@",error);
            [self ims_showHUDWithMessage:error.localizedDescription];
            return;
        }
        
        if (productInfo == nil) {
            IMSDeviceLogError(@"productInfo == %@",productInfo);
            [self ims_showHUDWithMessage:@"获取固件信息失败,请重试"];
            self.latestVersionLabel.text = @"获取固件信息失败,请重试";
            return;
        }
        
        if (productInfo.netType == IMSDeviceCategoryProductNetTypeBT) {
            self.isBlueToothDevice = YES;
            [self requestBTDeviceMac];
        } else {
            [self configOTAManager];
            [self requestOTAFirmwareDetail];
        }
    }];
}

- (void)requestBTDeviceMac {
    [[IMSDeviceClient sharedClient] queryBlueToothDeviceMacWithIotId:self.iotId completionHandler:^(NSString *mac, NSError *error) {
        if (error || mac.length == 0) {
            IMSDeviceLogError(@"获取mac地址error = %@，bleMac = %@!",error,mac);
            [self ims_showHUDWithMessage:error.localizedDescription];
            return ;
        }
        //连接蓝牙
        self.mac = mac;
        [self ims_showHUDIndicatorWithMessage:@"蓝牙连接..." to:self.view];
        [self configureBTbreez];
        
        [self requestOTAFirmwareDetail];
    }];
}

- (void)requestOTAFirmwareDetail {
    if (self.iotId) {
        [self ims_showHUDWithIndicator];
        
        [[IMSDeviceClient sharedClient] loadOTAFirmwareDetailAndUpgradeStatusWithIotId:self.iotId houseId:self.houseId  completionHandler:^(IMSOTAFirmwareInfoModel *firmwareInfo, IMSOTAProgressInfoModel *progressInfo, NSError *error) {
            if (error) {
                [self ims_showHUDWithMessage:error.localizedDescription];
                [self showGetFirmwareFailState];
            } else {
                [self ims_hideHUD];
                self.firmwareInfo = firmwareInfo;
                
                if (self.isBlueToothDevice) {
                    [self showGetFirmwareSuccessState];
                    [self unconfirmedState];
                } else {
                    self.progressInfo = progressInfo;
                    [self showGetFirmwareSuccessState];
                    [self refreshUpgradeStatusWithUpgradeStatus:progressInfo.upgradeStatus];
                }
            }
        }];
    } else {
        IMSDeviceLogError(@"error：缺少必传参数，iotId：%@", self.iotId);
    }
}

#pragma mark - OTA升级公共代码

#pragma mark - Action

- (IBAction)upgradeClickedAction:(id)sender {
    if (self.isUpgradeSuccess) {
        [self.navigationController popViewControllerAnimated:YES];
        return;
    }
    
    if (self.firmwareInfo) {
        [self startUpgrade];
    } else {
        [self requestOTAFirmwareDetail];
    }
}

- (void)startUpgrade {
    if (self.isBlueToothDevice) {
        if (self.isConnectedBreeze == NO) {
            [self ims_showHUDIndicatorWithMessage:@"正在重连..." to:self.view];
            [_breeze connectPeripheralUseMac:self.mac];
            return;
        }
        
        [self requestBlueToothDeviceFirmwareUpgrade];
        return;
    }
    
    switch (self.progressInfo.upgradeStatus) {
            case IMSOTAUpgradeStatusUnconfirmed:
            case IMSOTAUpgradeStatusException:
            case IMSOTAUpgradeStatusFail:
            [self requestDeviceFirmwareUpgrade];
            break;
            case IMSOTAUpgradeStatusUpgrading:
            [self upgradingState];
            break;
            case IMSOTAUpgradeStatusSuccess:
            [self upgradeSuccessState];
            break;
            
        default:
            [self requestDeviceFirmwareUpgrade];
            break;
    }
}

#pragma mark - RequestResultState

- (void)showGetFirmwareFailState {
    self.stateImageView.image = [UIImage imsDevice_imageNamed:@"IMSOTA_icon_fail"];
    self.latestVersionLabel.textColor = [UIColor ims_accessorialColor];
    self.latestVersionLabel.font = [UIFont ims_regularFontOfSize:14];
    self.latestVersionLabel.text = @"获取固件信息失败,请重试";
    self.currentVersionLabel.text = @"";
    [self.upgradeButton setTitle:@"刷新" forState:UIControlStateNormal];
}

- (void)showGetFirmwareSuccessState {
    self.stateImageView.image = [UIImage imsDevice_imageNamed:@"IMSOTA_icon_upArrow"];
    self.latestVersionLabel.textColor = [UIColor ims_systemMaticColor];
    self.latestVersionLabel.font = [UIFont ims_semiboldFontOfSize:14];
}

- (void)unconfirmedState {
    self.latestVersionLabel.text = [NSString stringWithFormat:@"V%@ %@", self.firmwareInfo.version ?: @"", self.firmwareInfo.timestamp ?: @""];
    self.currentVersionLabel.text = [NSString stringWithFormat:@"%@ V%@ %@", @"当前版本", self.firmwareInfo.currentVersion ?: @"", self.firmwareInfo.currentTimestamp ?: @""];
}

- (void)waitingState {
    self.latestVersionLabel.text = [NSString stringWithFormat:@"V%@ %@", self.firmwareInfo.version ?: @"", self.firmwareInfo.timestamp ?: @""];
    self.currentVersionLabel.text = [NSString stringWithFormat:@"%@ V%@ %@", @"当前版本", self.firmwareInfo.currentVersion ?: @"", self.firmwareInfo.currentTimestamp ?: @""];
    [self.upgradeButton imsDevice_startUpgradeAnimation];
    [self.upgradeButton setTitle:@"等待中" forState:UIControlStateNormal];
}

- (void)upgradingState {
    self.latestVersionLabel.text = [NSString stringWithFormat:@"V%@ %@", self.firmwareInfo.version ?: @"", self.firmwareInfo.timestamp ?: @""];
    self.currentVersionLabel.text = [NSString stringWithFormat:@"%@ V%@ %@", @"当前版本", self.firmwareInfo.currentVersion ?: @"", self.firmwareInfo.currentTimestamp ?: @""];
    [self.upgradeButton imsDevice_startUpgradeAnimation];
    [self.upgradeButton setTitle:@"升级中" forState:UIControlStateNormal];
}

- (void)upgradeSuccessState {
    self.upgradeSuccess = YES;
    
    [self.upgradeButton imsDevice_stopUpgradeAnimation];
    self.stateImageView.image = [UIImage imsDevice_imageNamed:@"IMSOTA_icon_success"];
    self.latestVersionLabel.text = @"升级成功";
    self.firmwareInfo.timestamp = nil;
    self.currentVersionLabel.text = [NSString stringWithFormat:@"%@ V%@ %@", @"当前版本", self.firmwareInfo.version ?: @"", self.firmwareInfo.timestamp ?: @""];
    [self.upgradeButton imsDevice_stopUpgradeAnimation];
    [self.upgradeButton setTitle:@"完成" forState:UIControlStateNormal];
}

- (void)upgradeExceptionState {
    self.stateImageView.image = [UIImage imsDevice_imageNamed:@"IMSOTA_icon_fail"];
    self.latestVersionLabel.textColor = [UIColor ims_accessorialColor];
    self.latestVersionLabel.font = [UIFont ims_regularFontOfSize:14];
    self.latestVersionLabel.text = @"设备无响应,请重试";
    self.currentVersionLabel.text = @"";
    [self.upgradeButton imsDevice_stopUpgradeAnimation];
    [self.upgradeButton setTitle:@"重试" forState:UIControlStateNormal];
}

- (void)upgradeFailState {
    [self.upgradeButton imsDevice_stopUpgradeAnimation];
    [self.upgradeButton setTitle:@"立即升级" forState:UIControlStateNormal];
}

- (void)showUpgradeFailAlertController {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:@"固件升级失败,是否重试" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        
    }];
    [alert ims_addAction:cancelAction];
    
    UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self upgradeClickedAction:nil];
    }];
    [alert ims_addAction:confirmAction];
    
    [self presentViewController:alert animated:YES completion:nil];
}

#pragma mark - 其他OTA模块代码

- (void)requestDeviceFirmwareUpgrade {
    [[IMSOTAManager sharedInstance].otaCompoment upgradeWithIotId:self.iotId houseId:self.houseId version:self.firmwareInfo.version];
    
    [self waitingState];
}

- (void)refreshUpgradeStatusWithUpgradeStatus:(IMSOTAUpgradeStatus)status {
    switch (status) {
            case IMSOTAUpgradeStatusUpgrading:
            [self upgradingState];
            break;
            case IMSOTAUpgradeStatusException:
            [self upgradeExceptionState];
            break;
            case IMSOTAUpgradeStatusFail:
            [self upgradeFailState];
            
            [self showUpgradeFailAlertController];
            break;
            case IMSOTAUpgradeStatusSuccess:
            [self upgradeSuccessState];
            break;
            
        default:
            [self unconfirmedState];
            break;
    }
}

#pragma mark - IMSOTADelegate

- (void)otaDidProgress:(IMSOTAMQTTProgressInfoModel *)progress {
    self.progressInfo.upgradeStatus = progress.upgradeStatus;
    [self refreshUpgradeStatusWithUpgradeStatus:progress.upgradeStatus];
}

- (void)otaDidFinish:(NSError *)error progress:(IMSOTAMQTTProgressInfoModel *)progress {
    self.progressInfo.upgradeStatus = progress.upgradeStatus;
    if (error) {
        IMSDeviceLogError(@"OTA升级失败：%@", error.localizedDescription);
        
        [self upgradeFailState];
        
        [self showUpgradeFailAlertController];
    } else {
        [self refreshUpgradeStatusWithUpgradeStatus:progress.upgradeStatus];
    }
}


#pragma mark - 蓝牙OAT模块代码

- (void)configureBTbreez {
    _breeze = [[Breeze alloc] init];
    [_breeze addBreezeDelagete:self];
    [_breeze connectPeripheralUseMac:self.mac];
}

- (LKLinkOtaBusiness *)otaBusiness {
    if (!_otaBusiness) {
        _otaBusiness = [LKLinkOtaBusiness setupOtaBiz:self.breeze];
    }
    
    return _otaBusiness;
}

- (void)updateFailState {
    [self upgradeFailState];
    [self showUpgradeFailAlertController];
}

- (void)requestBlueToothDeviceFirmwareUpgrade {
    [self.otaBusiness startUpgrade:self.iotId alcsOTA:NO  type:LKOTADeviceTypeBle lisener:^(LKOTANotificationType type, NSDictionary *result) {
        IMSDeviceLogVerbose(@"升级详情 \n %@",result);
        
        if (self.isConnectedBreeze == NO) {
            [self ims_showHUDWithMessage:@"蓝牙已断连,请重新连接！"];
            return ;
        }
        
        if (type == LKOTANotificationTypeCheck) {
            NSError *err = [result objectForKey:@"error"];
            [self upgradingState];
            if (err != nil) {
                IMSDeviceLogError(@"升级时预检查失败 error = %@",err.localizedDescription);
                [self updateFailState];
            } else {
                IMSDeviceLogVerbose(@"升级时预检查完成");
            }
        } else if (type == LKOTANotificationTypeDownload) {
            [self upgradingState];
            NSDictionary *subResult = [result objectForKey:@"result"];
            NSError *err = [result objectForKey:@"error"];
            if (err != nil) {
                IMSDeviceLogError(@"下载OTA包失败 error = %@",err.localizedDescription);
                [self updateFailState];
            } else {
                int progress = [[subResult valueForKey:@"progress"] intValue];
                IMSDeviceLogVerbose(@"下载OTA包 progress = %d",progress);
            }
        } else if (type == LKOTANotificationTypeTransmit) {
            [self upgradingState];
            NSDictionary *subResult = [result objectForKey:@"result"];
            NSError *err = [result objectForKey:@"error"];
            if (err != nil) {
                [self updateFailState];
                IMSDeviceLogError(@"传输OTA包失败 error = %@",err.localizedDescription);
            } else {
                int progress = [[subResult valueForKey:@"progress"] intValue];
                IMSDeviceLogVerbose(@"传输OTA包 progress = %d",progress);
                if (progress == 100) {
                    self.isBreezeReboot = YES;
                }
            }
        } else if (type == LKOTANotificationTypeReboot) {
            [self upgradingState];
            NSDictionary *subResult = [result objectForKey:@"result"];
            NSError *err = [result objectForKey:@"error"];
            if (err != nil) {
                IMSDeviceLogError(@"重启设备升级失败 error = %@",err.localizedDescription);
                [self updateFailState];
            } else {
                int progress = [[subResult valueForKey:@"progress"] intValue];
                IMSDeviceLogVerbose(@"重启设备升级 progress = %d",progress);
            }
        } else if (type == LKOTANotificationTypeFinish) {
            NSError * err = [result objectForKey:@"error"];
            if (err != nil) {
                IMSDeviceLogError(@"设备升级失败 error = %@",err.localizedDescription);
                [self updateFailState];
            } else {
                IMSDeviceLogVerbose(@"设备升级成功");
                [self upgradeSuccessState];
            }
        }
    }];
    
    [self waitingState];
}

#pragma mark - BreezeDelagete

/**
 手机蓝牙状态变化
 
 @param breeze Breeze对象
 @param state 状态描述
 */
- (void)breeze:(Breeze *)breeze didCentralStateChanged:(CBManagerState)state API_AVAILABLE(ios(10.0)){
    if (state == CBManagerStatePoweredOn) {
        IMSDeviceLogVerbose(@"BreezeDelagete：手机蓝牙已开启!");
    } else {
        IMSDeviceLogError(@"BreezeDelagete：手机蓝牙未开启!");
        [self ims_showHUDWithMessage:@"手机蓝牙未开启！"];
    }
}

/**
 连接结果通知
 
 @param breeze Breeze对象
 @param peripheral 已连接的peripheral对象
 @param error 错误信息
 */
- (void)breeze:(Breeze *)breeze didConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error {
    if (error != nil) {
        self.isConnectedBreeze = NO;
        IMSDeviceLogError(@"BreezeDelagete：蓝牙已断连,请重新连接蓝牙! error = %@",error);
        [self ims_showHUDWithMessage:@"蓝牙已断连,请重新连接！"];
        [self unconfirmedState];
        return;
    }
    
    [self ims_hideHUD];
    self.isConnectedBreeze = YES;
    IMSDeviceLogVerbose(@"BreezeDelagete：蓝牙连接成功");
}

/**
 蓝牙设备状态变化
 
 @param breeze Breeze对象
 @param state 状态描述
 */
- (void)breeze:(Breeze *)breeze didPeripheralStateChanged:(CBPeripheralState)state{
    if (state == CBPeripheralStateDisconnected) {
        IMSDeviceLogError(@"BreezeDelagete：蓝牙已断连,请重新连接蓝牙!");
        self.isConnectedBreeze = YES;
        if (!self.isBreezeReboot) {
            [self ims_showHUDWithMessage:@"蓝牙已断连,请重新连接！"];
        }
    } else if (state == CBPeripheralStateConnected) {
        IMSDeviceLogVerbose(@"BreezeDelagete：蓝牙已连接");
        self.isConnectedBreeze = NO;
    }
}

/**
 发现蓝牙设备
 
 @param breeze Breeze对象
 @param peripheral 外围设备
 @param advertisementData <#advertisementData description#>
 @param RSSI <#RSSI description#>
 @param deviceData <#deviceData description#>
 */
- (void)breeze:(Breeze *)breeze didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI extra:(NSDictionary *)deviceData {
    IMSDeviceLogVerbose(@"Breeze Delegate, 搜索到设备");
    IMSDeviceLogVerbose(@"发现到蓝牙设备，handleDiscoverBleDevice, productId:%@, mac:%@",deviceData[@"productId"],deviceData[@"mac"]);
}

- (void)breeze:(Breeze *)breeze didReceivedData:(NSData *)data msgId:(NSInteger)msgId error:(NSError *)error{
    IMSDeviceLogVerbose(@"breeze didReceivedData");
}

@end



















