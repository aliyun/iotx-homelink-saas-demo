//
//  IMSDeviceHomeViewController.h
//  IMSDevice
//
//  Created by X i n long Li on 2018/3/29.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IMSDeviceHomeViewController : UIViewController

/**
 是否需要刷新
 在viewWillAppear时调用刷新后置为NO
 */
@property (nonatomic, assign) BOOL needRefresh;

@end
