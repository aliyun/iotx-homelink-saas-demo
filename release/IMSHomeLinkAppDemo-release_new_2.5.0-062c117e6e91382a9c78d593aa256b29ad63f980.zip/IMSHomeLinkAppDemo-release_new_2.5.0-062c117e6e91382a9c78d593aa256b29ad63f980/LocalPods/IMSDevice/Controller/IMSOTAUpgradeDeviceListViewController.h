//
//  IMSOTAUpgradeDeviceListViewController.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/29.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IMSOTAUpgradeDeviceListViewController : UITableViewController

/**
 全屋家id，必传
 */
@property (nonatomic, copy) NSString *houseId;

@end
