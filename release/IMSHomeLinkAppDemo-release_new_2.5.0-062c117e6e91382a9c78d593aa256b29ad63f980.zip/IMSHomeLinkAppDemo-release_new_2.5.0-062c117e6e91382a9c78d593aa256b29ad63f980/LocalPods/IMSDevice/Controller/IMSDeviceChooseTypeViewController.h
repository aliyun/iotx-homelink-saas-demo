//
//  ChooseDeviceTypeViewController.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/2.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IMSDeviceChooseTypeViewController : UIViewController

/**
 全屋家id，必传
 */
@property (nonatomic, copy) NSString *houseId;

/**
 全屋房间id，有则传
 */
@property (nonatomic, copy) NSString *roomId;

/**
 绑定完成后返回页面，不指定返回到rootViewController并跳转设备控制面板
 */
@property (nonatomic, copy) void(^bindCallBack)(NSString *productKey, NSString *iotId);


/**
 绑定扫码体验页面回调
 */
@property (nonatomic, copy) void(^bindVirtualCallBack)(NSString *productKey, NSString *iotId);


/**
 本地配网绑定完成回调的PK，由于闭包冲突不能添加参数，故加上
 */
@property (nonatomic, copy) NSString *productKey;

@end







