//
//  IMSDeviceSearchViewController.h
//  Bolts
//
//  Created by chuntao.wang1 on 2018/11/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXTERN NSString * const KSearchDeviceAndBindSuccessNotifi;

@interface IMSDeviceSearchViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
