//
//  IMSDeviceSearchViewController.m
//  Bolts
//
//  Created by chuntao.wang1 on 2018/11/27.
//

#import "IMSDeviceSearchViewController.h"
#import <Masonry/Masonry.h>
#import <IMSCategory/IMSCategory.h>
#import "IMSDeviceBasicCell+IMSDeviceCategoryInfoModel.h"
#import <IMSRefresh/IMSRefresh.h>
#import "IMSDeviceSearchView.h"
#import "IMSDeviceProductInfoModel.h"
#import <IMSHUD/IMSHUD.h>
#import "IMSDeviceBindService.h"
#import "IMSDeviceBindViewController.h"
#import "IMSDevicePluginsService.h"
#import "IMSDeviceLog.h"
#import "IMSDeviceClient.h"
#import "IMSDeviceSearchProductListModel.h"
#import "IMSDeviceCache.h"
#import "UIImage+IMSDeviceExtension.h"
#import <SDWebImage/UIImageView+WebCache.h>

static CGFloat kSearchViewHeight = 68.f;
static CGFloat kSearchProductCellHeight = 64.f;
static NSString *const KCellSearchDeviceProductCell = @"IMSDeviceBasicCell";
NSString *const KSearchDeviceAndBindSuccessNotifi = @"IMSSearchDeviceAndBindSuccessNotifi";

@interface IMSDeviceSearchViewController ()<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>

@property (nonatomic, strong) IMSDeviceSearchView *searchView;  /* 列表 */
@property (nonatomic, strong) UITableView *tableView;           /* 搜索框 */
@property (nonatomic, strong) NSMutableArray<IMSDeviceSearchProductListModel *> *allProductList;    /* 全量产品list */
@property (nonatomic, strong) NSMutableArray<IMSDeviceSearchProductListModel *> *searchProductList; /* 搜索数据list */
@property (nonatomic, assign) BOOL showSearchResultList;        /* 是否显示搜索数据 */

@end

@implementation IMSDeviceSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self configureView];
    
    [self.allProductList addObjectsFromArray:[[IMSDeviceCache shareInstance] listFromIMSdeviceCache]];
    if (self.allProductList.count == 0) {
        [self loadProductList];
    } else {
        [self.tableView reloadData];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:NO];
}

#pragma mark - Configure

- (void)configureView {
    self.title = @"添加设备";
    self.view.backgroundColor = [UIColor ims_backgroundColor];
    [self configureSearchView];
    [self configureTableView];
}

- (void)configureSearchView {
    self.searchView = [IMSDeviceSearchView initView];
    [self.view addSubview:self.searchView];
    [self.searchView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.equalTo(self.view);
        make.height.mas_offset(kSearchViewHeight);
    }];
    [self.searchView.searchTF addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];

}

- (void)configureTableView{
    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.searchView.mas_bottom).offset(1);
		if (@available(iOS 11.0,*)) {
			make.right.left.equalTo(self.view);
			make.bottom.equalTo(self.view.mas_safeAreaLayoutGuideBottom);
		} else {
			make.right.left.bottom.equalTo(self.view);
		}
    }];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.backgroundColor = self.view.backgroundColor;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.tableView registerClass:[IMSDeviceBasicCell class] forCellReuseIdentifier:KCellSearchDeviceProductCell];
    self.tableView.sectionHeaderHeight = 36;
    self.tableView.sectionFooterHeight = 0;
    self.tableView.mj_footer = nil;
}

#pragma mark - Method

- (void)startProvisionWithProductInfo:(IMSDeviceSearchProductListModel *)productInfo {
    [IMSDevicePluginsService showProvisionWithProductKey:productInfo.productKey deviceName:nil token:nil addDeviceFrom:nil houseId:nil routerCompletionHandler:^(NSError *error, NSDictionary *info) {
        if (error) {
            IMSDeviceLogError(@"配网 error:%@", error);
            [self ims_showHUDWithMessage:error.localizedDescription];
        } else if (info && [info count] > 0) {
            IMSDeviceLogInfo(@"配网 info: %@", info);
            
            id value = info[@"isExit"];
            if ([value boolValue]) {
                IMSDeviceLogInfo(@"设备已绑定，返回设备主页...");
                [self.navigationController popToRootViewControllerAnimated:NO];
            } else {
                NSString *productKey = info[@"productKey"];
                NSString *iotId = info[@"iotId"];
                if (iotId.length > 0) {
                    [self sendNofiWithIotId:iotId productKey:productKey];
                } else {
                    NSString *deviceName = info[@"deviceName"];
                    [self showBindControllerWithProductKey:productKey deviceName:deviceName];
                }
            }
        } else {
            [self.navigationController popToViewController:self animated:YES];
            IMSDeviceLogInfo(@"配网正常退出...");
        }
    } completionHandler:^(BOOL success) {
        if (!success) {
            [self ims_showHUDWithMessage:@"加载失败，请稍后再试"];
        }
    }];
}

- (void)showBindControllerWithProductKey:(NSString *)productKey deviceName:(NSString *)deviceName {
    if (productKey.length > 0) {
         __weak typeof(self) weakSelf = self;
        IMSDeviceBindViewController *controller = [[IMSDeviceBindViewController alloc] init];
        controller.productKey = productKey;
        controller.deviceName = deviceName;
        controller.bindCallBack = ^(NSString *productKey, NSString *iotId) {
            [weakSelf sendNofiWithIotId:iotId productKey:productKey];
        };
        [self.navigationController pushViewController:controller animated:YES];
    } else {
        IMSDeviceLogError(@"绑定设备缺少productKey");
    }
}

- (void)sendNofiWithIotId:(NSString *)iotId productKey:(NSString *)productKey {
    NSDictionary *dict = @{
                           @"productKey":productKey,
                           @"iotId":iotId
                           };
    [[NSNotificationCenter defaultCenter] postNotificationName:KSearchDeviceAndBindSuccessNotifi object:self userInfo:dict];
    [self.navigationController popToRootViewControllerAnimated:NO];
}

#pragma mark - Net

- (void)loadProductList {
    [self ims_showHUDWithIndicator];
    [self.allProductList removeAllObjects];
    [self requestList:1];
}

- (void)requestList:(NSInteger)pageNum {
    __weak typeof(self) weakSelf = self;
    [[IMSDeviceClient sharedClient] loadSearchDeviceListWithPageNum:pageNum pageSize:100 productName:nil completionHandler:^(NSInteger totalNum, NSArray<IMSDeviceSearchProductListModel *> *list, NSError *error) {
        if (error) {
            IMSDeviceLogError(@"获取搜索列表数据 error = %@",error);
            [weakSelf ims_showHUDWithMessage:error.description];
            [weakSelf.allProductList removeAllObjects];
            return ;
        }
        
        if (totalNum == 0) {
            [weakSelf ims_hideHUD];
            return;
        }
        
        [weakSelf.allProductList addObjectsFromArray:list];
        if (weakSelf.allProductList.count == totalNum) {
            [weakSelf ims_hideHUD];
            [weakSelf.tableView reloadData];
            [[IMSDeviceCache shareInstance] cacheIMSDeviceSearchAllProductModelList:weakSelf.allProductList];
        } else {
            NSInteger newPageNum = pageNum + 1;
            [weakSelf requestList:newPageNum];
        }
    }];
}

#pragma mark - UITextFieldDelegate

- (void)textFieldDidChange:(UITextField *)textfild {
    [self.searchProductList removeAllObjects];
    NSString *keyStr = [textfild.text uppercaseString];
    for (IMSDeviceSearchProductListModel *model in self.allProductList) {
        if ([[model.productName uppercaseString] containsString:keyStr]) {
            [self.searchProductList addObject:model];
        }
    }

    self.showSearchResultList = ![textfild.text isEqualToString:@""] ? YES : NO;
    [self.tableView reloadData];
}

#pragma Mark - UITableViewDelegate || UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.showSearchResultList) {
        return self.searchProductList.count;
    }
    return self.allProductList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    IMSDeviceBasicCell *cell = [tableView dequeueReusableCellWithIdentifier:KCellSearchDeviceProductCell];
    IMSDeviceSearchProductListModel *model;
    if (self.showSearchResultList) {
        model = self.searchProductList[indexPath.row];
        cell.ims_separatorView.hidden = self.searchProductList.count - 1 == indexPath.row;
    } else {
        model = self.allProductList[indexPath.row];
        cell.ims_separatorView.hidden = self.allProductList.count - 1 == indexPath.row;
    }
    cell.ims_textLabel.text = model.productName;
    [cell.ims_imageView sd_setImageWithURL:[NSURL URLWithString:model.productImage] placeholderImage:[UIImage imsDevice_imageNamed:@"IMSDevice_placeholder"]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    IMSDeviceSearchProductListModel *model;
    if (self.showSearchResultList) {
        model = self.searchProductList[indexPath.row];
    } else {
        model = self.allProductList[indexPath.row];
    }
    
    [self startProvisionWithProductInfo:model];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return kSearchProductCellHeight;
}

#pragma mark - lazy loading

- (NSMutableArray *)allProductList {
    if (!_allProductList) {
        _allProductList = [[NSMutableArray alloc] init];
    }
    return _allProductList;
}

- (NSMutableArray *)searchProductList {
    if (!_searchProductList) {
        _searchProductList = [[NSMutableArray alloc] init];
    }
    return _searchProductList;
}

@end
