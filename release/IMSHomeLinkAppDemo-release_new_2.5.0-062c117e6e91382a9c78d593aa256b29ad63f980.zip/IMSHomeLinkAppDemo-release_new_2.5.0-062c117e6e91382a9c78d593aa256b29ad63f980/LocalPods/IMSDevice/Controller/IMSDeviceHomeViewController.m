//
//  IMSDeviceHomeViewController.m
//  IMSDevice
//
//  Created by X i n long Li on 2018/3/29.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSDeviceHomeViewController.h"
#import <IMSThingCapability/IMSThingManager.h>
#import <IMSScanner/IMSScanner.h>
#import "IMSDeviceChooseTypeViewController.h"
#import <IMSRouter/IMSRouter.h>
#import <IMSRefresh/IMSRefresh.h>
#import <IMSHUD/UIViewController+HUD.h>
#import <IMSCategory/IMSCategory.h>
#import <IMSAccount/IMSAccount.h>
#import "NSBundle+IMSDeviceExtension.h"
#import "UIImage+IMSDeviceExtension.h"
#import "IMSDeviceLog.h"
#import "IMSDeviceClient.h"
#import "IMSDeviceScanService.h"
#import "IMSDevicePluginsService.h"
#import "IMSDeviceHomeCell.h"
#import "IMSDeviceHomeItem.h"
#import "IMSDeviceSearchViewController.h"
#import <IMSOpenAccountBase/IMSAccountManager.h>
#import "IMSDeviceCache.h"
#import "IMSDeviceBindViewController.h"
#import <AlinkAppExpress/AlinkAppExpress.h>
#import "IMSDeviceNetWorkStatus.h"

static CGFloat const kCollectionCellLeading     = 16.f;
static CGFloat const kCollectionCellHeight      = 96.f;
static CGFloat const kCollectionCellLineSpacing = 12.f;
static NSInteger const kDeviceListSize = 60;
static NSString *const kDeviceLoginSuccessKey = @"ALBBOA_NOTIFICATION_USER_LOGGED_IN";

@interface IMSDeviceHomeViewController () <UICollectionViewDelegate, UICollectionViewDataSource,IMSThingObserver>
@property (weak, nonatomic) IBOutlet UILabel            *titleLab;
@property (weak, nonatomic) IBOutlet UICollectionView   *collectionView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *headerTopSpace;
@property (weak, nonatomic) IBOutlet UIView             *homeMaskView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *collectionViewBottom;
//noData
@property (weak, nonatomic) IBOutlet UIView             *noDataBGView;
@property (weak, nonatomic) IBOutlet UILabel            *noDataView;
@property (weak, nonatomic) IBOutlet UIButton           *noDataButton;
@property (weak, nonatomic) IBOutlet UIView            *noNetView;
@property (weak, nonatomic) IBOutlet UILabel           *noNetLabel;

@property (nonatomic, strong) NSMutableArray <IMSDeviceHomeItem *>*deviceItems;
@property (nonatomic, strong) UIView                        *tabBarMaskView;
@property (nonatomic, assign) NSInteger currenPage;
// 已经打开了一个插件
@property (nonatomic, assign) BOOL isDidInRouter;
// 本地控制
@property (nonatomic, strong) IMSThing *thingShell;
@property (nonatomic, assign) NSInteger currentCellIndex;
@property (nonatomic, assign) BOOL isLocalControl;  //本地app需改属性
@property (nonatomic, assign) BOOL isNotNetControl; //是否局域网控制
@property (nonatomic, strong) NSMutableArray<IMSThing *> *imsThingShellArray;
@property (nonatomic, strong) NSMutableArray<IMSDeviceHomeItem *> *imsLocalDeviceArray;

@end

@implementation IMSDeviceHomeViewController

#pragma mark - LifeCircle

- (instancetype)init {
    return [self initWithNibName:NSStringFromClass([self class]) bundle:[NSBundle imsDevice_deviceBundleWithClass:[self class]]];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    IMSLogDebug(@"PerformanceTag", @"{\"mod\":\"iOS\", \"event\":\"pageinit\", \"id\":\"\", \"params\":{\"pagename\":\"homepage\"}}");
    self.navigationItem.title = @"设备排序";
    self.titleLab.text = @"我的设备";
    self.noDataView.text = @"暂无设备，请添加设备";
    
    [self initView];
    [self configNavigationBar];
    [self configTabBar];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    self.navigationController.navigationBar.shadowImage = [UIImage ims_imageWithColor:[UIColor whiteColor]];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(searchViewControllerBindDeviceSuccess:) name:KSearchDeviceAndBindSuccessNotifi object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(imsBoneRouterBindDeviceSuccess:) name:IMSBoneRouterBindDeviceSuccessNoti object:nil];
    
    if (self.needRefresh) {
        [self headerRefresh];
        [self ims_showHUDIndicatorWithMessage:@"加载中..."];
        self.needRefresh = NO;
    }
    
    if (self.isDidInRouter) {
        self.isDidInRouter = NO;
    }
    
    _imsThingShellArray = [[NSMutableArray alloc] init];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self ims_hideHUD];
}

- (void)dealloc {
	IMSDeviceLogInfo(@"device home vc dealloc");
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - Init

- (void)initView {
    self.extendedLayoutIncludesOpaqueBars = YES;
    [self.collectionView addSubview:self.noDataBGView];
    [self.collectionView addSubview:self.noNetView];
    self.noDataBGView.hidden = YES;
    self.noNetView.hidden = YES;
    
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    flowLayout.itemSize = CGSizeMake([UIScreen mainScreen].bounds.size.width - kCollectionCellLeading * 2, kCollectionCellHeight);
    flowLayout.minimumLineSpacing = kCollectionCellLineSpacing;
    
    NSString *cellString = NSStringFromClass([IMSDeviceHomeCell class]);
    UINib *nib = [UINib nibWithNibName:cellString bundle:[NSBundle imsDevice_deviceBundleWithClass:[self class]]];
    self.collectionView.collectionViewLayout = flowLayout;
    [self.collectionView registerNib:nib forCellWithReuseIdentifier:cellString];
    self.collectionView.mj_header = [IMSHeaderRefreshView headerWithRefreshingTarget:self refreshingAction:@selector(headerRefresh)];
    self.collectionView.mj_footer = [IMSFooterRefreshView footerWithRefreshingTarget:self refreshingAction:@selector(footerRefresh)];
    self.collectionView.mj_footer.hidden = YES;
    [self headerRefresh];
    [self ims_showHUDIndicatorWithMessage:@"加载中..."];
    
    if ([[UIApplication sharedApplication] statusBarFrame].size.height > 20.f) {
        self.headerTopSpace.constant = 43.f;
        self.collectionViewBottom.constant = 83.f;
    }
}

- (void)configNavigationBar {
    self.navigationController.navigationBar.translucent = NO;
    [self.navigationController.navigationBar setTintColor:[UIColor ims_colorWithRed:122 green:122 blue:122]];
}

- (void)configTabBar {
    [self.tabBarController.tabBar setBackgroundColor:[UIColor whiteColor]];
    
    UIView *tabMaskView = [[UIView alloc] initWithFrame:self.tabBarController.tabBar.bounds];
    tabMaskView.backgroundColor = [UIColor ims_colorWithRed:0 green:0 blue:0 alpha:0.3];
    tabMaskView.alpha = 0.f;
    [self.tabBarController.tabBar addSubview:tabMaskView];
    self.tabBarMaskView = tabMaskView;
}

#pragma mark - UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.deviceItems.count;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    IMSDeviceHomeCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([IMSDeviceHomeCell class]) forIndexPath:indexPath];
    IMSDeviceHomeItem *item = [self.deviceItems objectAtIndex:indexPath.row];
    cell.deviceItem = item;
    return cell;
}

#pragma mark - UICollectionViewDelegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {

    IMSDeviceHomeItem *deviceItem = [self.deviceItems objectAtIndex:indexPath.row];
    [self showDeviceControlPanelWithIotId:deviceItem.iotId productKey:deviceItem.productKey];
}

#pragma mark - Request

- (void)headerRefresh {
    self.currenPage = 0;
    [self loadDataWithPage:self.currenPage];
}

- (void)footerRefresh {
    self.currenPage += 1;
    [self loadDataWithPage:self.currenPage];
}

- (void)loadDataWithPage:(NSInteger)page {
	
	[[IMSDeviceClient sharedClient] fetchDeviceListWithPage:page pageSize:kDeviceListSize callback:^(NSError *error, NSInteger offset, NSArray<IMSDeviceHomeItem *> *items) {
		IMSLogDebug(@"PerformanceTag", @"{\"mod\":\"iOS\", \"event\":\"pageshow\", \"id\":\"\", \"params\":{\"pagename\":\"homepage\"}}");
		[self ims_hideHUD];
		self.collectionView.mj_footer.hidden = NO;
		[self.collectionView.mj_header endRefreshing];
		[self.collectionView.mj_footer endRefreshing];
		if (error) {
			self.deviceItems = nil;
			if ([IMSDeviceNetWorkStatus isReachable]) {
				//无数据
				self.noNetView.hidden = YES;
				self.noDataBGView.hidden = NO;
				self.noDataView.text = @"暂无设备，请添加设备";
			} else {
				//没网
				self.noDataBGView.hidden = YES;
				self.noNetView.hidden = NO;
				self.noNetLabel.text = @"网络异常，请检查网络";
			}
			
			[self.collectionView reloadData];

			return;
		} else {
			// 使用有网下数据
			self.isNotNetControl = NO;
			[self.imsLocalDeviceArray removeAllObjects];

			self.noNetView.hidden = YES;
			self.currenPage = self.currenPage == 0 ? 0 : self.currenPage - 1;
		}
		
		// 缓存用户绑定设备,用于确定本地发现设备的共享类型
		if (self.currenPage > 0) {
			[self.deviceItems addObjectsFromArray:items];
		} else {
			self.deviceItems = [NSMutableArray arrayWithArray:items];
		}
		//注册thing
		[self imsRegistThingWithArray:self.deviceItems];

		self.noDataBGView.hidden = self.deviceItems.count;
		if (items.count < kDeviceListSize) {
			[self.collectionView.mj_footer endRefreshingWithNoMoreData];
		} else {
			[self.collectionView.mj_footer resetNoMoreData];
		}
		[self.collectionView reloadData];
	}];
}
    
#pragma mark - 本地控制
    
// 本地控制，注册所有的iotID
- (void)imsRegistThingWithArray:(NSArray<IMSDeviceHomeItem *> *)array {
    [self.imsThingShellArray removeAllObjects];
    for (IMSDeviceHomeItem *item in array) {
        IMSThing *imsThing = [kIMSThingManager buildThing:item.iotId];
        [imsThing registerThingObserver:self];
        [self.imsThingShellArray addObject:imsThing];
    }
}


// 更新（状态）数据，刷新列表
- (void)reloadCollectionViewState:(IMSDeviceHomeStatus )state index:(NSInteger)index {
    IMSDeviceHomeItem *deviceItem = self.deviceItems[index];
    deviceItem.status = state;
    [self.collectionView reloadItemsAtIndexPaths:@[[NSIndexPath indexPathForRow:index inSection:0]]];
    // 缓存最新的值
    [[IMSDeviceCache shareInstance] imsCacheHomeBindDeviceList:self.deviceItems];
}

// 设备属性名枚举
- (IMSDeviceHomeStatus)status:(NSInteger)deviceState {
    switch (deviceState) {
        case 1:
            return IMSDeviceHomeStatusOnlined;
        case 3:
            return IMSDeviceHomeStatusOffline;
        case 8:
            return IMSDeviceHomeStatusDisable;
        case 1000:
            return IMSDeviceHomeStatusLocalOnlined;

        default:
            return IMSDeviceHomeStatusNormal;
    }
}

#pragma mark - IMSThingObserver

/**
 物的状态变更回调，如上线，离线等
 */
- (void)onStatusChange:(NSString *)iotId params:(NSDictionary *)params {
    if (iotId == nil || iotId.length == 0 || params == nil) {
        IMSDeviceLogError(@"首页设备状态变更失败 iotId = %@",iotId);
        return;
    }
    
    NSDictionary *dict = params[@"status"];
    if (dict == nil) {
        IMSDeviceLogError(@"首页设备状态变更失败 dict = %@",dict);
        return;
    }
    
    NSString *valueStr = [NSString stringWithFormat:@"%@",dict[@"value"]];
    if (valueStr.length == 0) {
        IMSDeviceLogError(@"首页设备状态变更失败 valueStr = %@",valueStr);
        return;
    }
    
    IMSDeviceHomeStatus state = [self status:[valueStr integerValue]];
    BOOL isFind = NO;
    for (NSInteger i=0; i<self.deviceItems.count; i++) {
        IMSDeviceHomeItem *item = self.deviceItems[i];
        if ([iotId isEqualToString:item.iotId]) {
            self.currentCellIndex = i;
            isFind = YES;
            break;
        }
    }
    
    if (isFind) {
        [self reloadCollectionViewState:state index:self.currentCellIndex];
    } else {
        IMSDeviceLogVerbose(@"该iotId不在设备列表中 iotId = %@",iotId);
    }
}

/**
 物有事件触发，如提示，告警等
 */
- (void)onEventHappen:(NSString *)iotId params:(NSDictionary *)params {

}

/**
 物的属性发生变化
 */
- (void)onPropertyChange:(NSString *)iotId params:(NSDictionary *)params {
	
}
    
#pragma mark - Action

- (void)addDevice {
    IMSDeviceChooseTypeViewController *vc = [[IMSDeviceChooseTypeViewController alloc] init];
    __weak typeof(self) weakSelf = self;
    vc.bindCallBack = ^(NSString *productKey, NSString *iotId) {
        if (productKey && iotId) {
            [weakSelf bindDeivceCompletionHandler:iotId productKey:productKey];
        } else {
            [weakSelf headerRefresh];
        }
    };
    vc.bindVirtualCallBack = ^(NSString *productKey, NSString *iotId) {
        if (productKey && iotId) {
            [self showDeviceControlPanelWithIotId:iotId productKey:productKey];
            [self setNeedRefresh:YES];
        } else {
            [weakSelf headerRefresh];
        }
    };
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)noDataAddClick:(id)sender {
    NSLog(@"noDataView添加设备");
    [self addDevice];
}

- (IBAction)addClick:(id)sender {
    NSLog(@"Navi添加设备");
    [self addDevice];
}

#pragma mark - 插件

- (void)bindDeivceCompletionHandler:(NSString *)iotId productKey:(NSString *)productKey {
    [self.navigationController popToRootViewControllerAnimated:NO];
    
    [self showDeviceControlPanelWithIotId:iotId productKey:productKey];
    
    [self setNeedRefresh:YES];
}

- (void)showDeviceControlPanelWithIotId:(NSString *)iotId productKey:(NSString *)productKey {
    // 避免插件重复打开策略：进入前设置为 YES，打开失败和退出时，设置为NO，第二次点击的时候，如果还在插件内部，屏蔽掉这次点击
    __weak typeof(self) weakSelf = self;
    void(^callback)(NSError *, NSDictionary *dic) = ^(NSError *error, NSDictionary *dic) {
        IMSDeviceLogVerbose(@"插件退出回调 error = %@, dic = %@",error,dic);
        weakSelf.isDidInRouter = NO;
        [weakSelf.collectionView.mj_header beginRefreshing];
    };
    NSDictionary *options = @{
                              @"iotId":iotId ?: @"",
                              AKRouterCompletionHandlerKey:callback,
							  @"groupId":@"HOMELINK_AQUARIUS"
                              };
    if (self.isDidInRouter) {
         IMSDeviceLogVerbose(@"插件未退出,不可重复进入插件");
        return;
    }
    self.isDidInRouter = YES;
    IMSDeviceLogVerbose(@"开始进入插件 iotId = %@, productKey = %@",iotId,productKey);
    [IMSDevicePluginsService showDeviceControlPanelWithProductKey:productKey options:options completionHandler:^(BOOL success) {
        [self ims_hideHUD];
        if (!success) {
            weakSelf.isDidInRouter = NO;
        }
    }];
}

- (void)searchViewControllerBindDeviceSuccess:(NSNotification *)info {
    NSString *iotId = info.userInfo[@"iotId"];
    NSString *productKey = info.userInfo[@"productKey"];
    if (iotId.length == 0 || productKey.length == 0) {
        IMSDeviceLogError(@"绑定设备缺少参数：iotId == %@ 、productKey = %@",iotId,productKey);
        return;
    }
    
    [self showDeviceControlPanelWithIotId:iotId productKey:productKey];
    
    [self setNeedRefresh:YES];
}

#pragma mark - 成功通知

- (void)imsBoneRouterBindDeviceSuccess:(NSNotification *)info {
    IMSDeviceLogVerbose(@"插件绑定成功info = %@",info);
    [self showDeviceControlPanelWithIotId:info.userInfo[@"iotId"] productKey:info.userInfo[@"productKey"]];
	
	[self setNeedRefresh:YES];
}

@end
