//
//  IMSDeviceBindViewController.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/3/28.
//  Copyright © 2018年 alibaba. All rights reserved.
//

#import "IMSDeviceBindViewController.h"
#import "IMSDeviceHomeViewController.h"
#import "IMSDeviceClient.h"
#import "IMSDeviceLog.h"
#import <IMSHUD/UIViewController+HUD.h>
#import <IMSRouter/IMSRouterService.h>
#import "NSBundle+IMSDeviceExtension.h"
#import "IMSDeviceBindService.h"
#import "IMSDevicePluginsService.h"
#import <IMSCategory/IMSCategory.h>
#import "UIImage+IMSDeviceExtension.h"
#import <IMSRouter/IMSRouter.h>
#import "IMSDeviceProductInfoModel.h"

NSString *const IMSBoneRouterBindDeviceSuccessNoti = @"kIMSBoneRouterBindDeviceSuccessNoti";

@interface IMSDeviceBindViewController ()<IMSURLHandler>

@property (weak, nonatomic) IBOutlet UIView *imsBlueBGView;
@property (weak, nonatomic) IBOutlet UIImageView *imsAddingImageV;
@property (weak, nonatomic) IBOutlet UILabel *imsAddingTextLabel;
@property (weak, nonatomic) IBOutlet UILabel *imsAddingDetailTextLabel;

@property (weak, nonatomic) IBOutlet UIImageView *imsFailImageV;
@property (weak, nonatomic) IBOutlet UILabel *imsFailTextLabel;
@property (weak, nonatomic) IBOutlet UIImageView *imsFailHintImageV;
@property (weak, nonatomic) IBOutlet UIButton *imsReAddBtn;

@property (strong, nonatomic) IMSDeviceProductInfoModel *productInfo;

@end

@implementation IMSDeviceBindViewController

- (void)dealloc {
    [self resetNaviConfigure];
}

+ (void)load {
    NSURL *url = [NSURL URLWithString:@"https://com.aliyun.iot.ilop/page/device_bind"];
    [[IMSRouterService sharedService] registerURL:url withHandler:NSClassFromString(@"IMSDeviceBindViewController")];
}

#pragma mark - AKURLHandler

+ (UIViewController *)controllerWithParams:(NSDictionary *)params {
    IMSDeviceBindViewController *controller = [[IMSDeviceBindViewController alloc] init];
    controller.productKey = params[@"productKey"];
    controller.deviceName = params[@"deviceName"];
    controller.netType = params[@"netType"];
    return controller;
}

- (instancetype)init {
    self = [super initWithNibName:NSStringFromClass([self class]) bundle:[NSBundle imsDevice_bundle]];
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    IMSDeviceLogVerbose(@"绑定参数:productKey:%@   deviceName:%@     roomId:%@", self.productKey, self.deviceName, self.roomId);
    self.title = @"添加设备";
    self.imsAddingTextLabel.text = @"设备添加中...";
    [self imsStartAddDevice];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self imsSetBackButton];
    self.navigationItem.leftBarButtonItem.customView.hidden = YES;
    [self.navigationController setNavigationBarHidden:NO animated:animated];
    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont ims_mediumFontOfSize:18],NSForegroundColorAttributeName:[UIColor whiteColor]}];
    self.imsReAddBtn.layer.cornerRadius = 5.f;
    [self.imsReAddBtn setTitle:@"重试" forState:UIControlStateNormal];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self resetNaviConfigure];
}

#pragma mark - Request
// 路由跳转使用的是入网类型的字符串
- (IMSDeviceCategoryProductNetType)imsDeviceNetTypeWithNetType:(NSString *)netType {
    if ([netType isEqualToString:@"NET_WIFI"]) {
        return IMSDeviceCategoryProductNetTypeWIFI;
    } else if ([netType isEqualToString:@"NET_BT"]) {
        return IMSDeviceCategoryProductNetTypeBT;
    } else if ([netType isEqualToString:@"NET_ZIGBEE"]) {
        return IMSDeviceCategoryProductNetTypeZIGBEE;
    } else if ([netType isEqualToString:@"NET_CELLULAR"]) {
        return IMSDeviceCategoryProductNetTypeCELLULAR;
    } else if ([netType isEqualToString:@"NET_ETHERNET"]) {
        return IMSDeviceCategoryProductNetTypeETHERNET;
    } else if ([netType isEqualToString:@"NET_OTHER"]) {
        return IMSDeviceCategoryProductNetTypeOTHER;
    } else {
        return IMSDeviceCategoryProductNetTypeNone;
    }
}

- (void)queryProductInfo {
    if (self.netType.length > 0) {
        IMSDeviceLogVerbose(@"self.netTypeStr = %@",self.netType);
        IMSDeviceCategoryProductNetType netType = [self imsDeviceNetTypeWithNetType:self.netType];
        [self imsBindRequest:netType];
    } else {
        [[IMSDeviceClient sharedClient] queryProductInfoWithProductKey:self.productKey completionHandler:^(IMSDeviceProductInfoModel *productInfo, NSError *error) {
            if (error) {
                IMSDeviceLogError(@"请求配网信息失败 error = %@",error);
                [self imsShowFailState];
                return ;
            }
            self.productInfo = productInfo;
            [self imsBindRequest:self.productInfo.netType];
        }];
    }
}

- (void)imsBindRequest:(IMSDeviceCategoryProductNetType)netType {
    IMSDeviceLogVerbose(@"绑定页面：开始使用...");
    [IMSDeviceBindService bindDeviceWithProductKey:self.productKey deviceName:self.deviceName netType:netType roomIds:self.roomId ? @[self.roomId] : nil completionHandler:^(NSString *iotId, NSError *error) {
        [self bindCompletionHandler:iotId error:error];
    }];
}

#pragma mark - IBAction

- (IBAction)imsReStartBindDevice:(id)sender {
    [self imsStartAddDevice];
}

#pragma mark - Method

- (void)resetNaviConfigure {
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont ims_mediumFontOfSize:17],NSForegroundColorAttributeName:[UIColor blackColor]}];
}

- (void)imsStartAddDevice {
    [self queryProductInfo];
    
    // 需要同时修改：导航栏背景，蓝色背景，图片旋转，元素隐藏
    self.navigationItem.leftBarButtonItem.customView.hidden = YES;
    self.navigationController.navigationBar.barTintColor = [UIColor ims_colorWithHexRGB:0x4690f0];
    self.imsBlueBGView.backgroundColor = [UIColor ims_colorWithHexRGB:0x4690f0];
    [self startAddBTDeviceAnimation];
    
    self.imsAddingImageV.hidden = NO;
    self.imsFailImageV.hidden = YES;
    self.imsFailHintImageV.hidden = YES;
    self.imsFailTextLabel.hidden = YES;
    self.imsReAddBtn.hidden = YES;
    self.imsAddingTextLabel.hidden = NO;
    self.imsAddingDetailTextLabel.text = @"设备添加中...";
}

- (void)imsShowFailState {
    self.navigationItem.leftBarButtonItem.customView.hidden = NO;
    self.navigationController.navigationBar.barTintColor = [UIColor ims_colorWithHexRGB:0x86909b];
    self.imsBlueBGView.backgroundColor = [UIColor ims_colorWithHexRGB:0x86909b];
    [self stopAddBTDeviceAnimation];
    self.imsAddingImageV.hidden = YES;
    self.imsFailImageV.hidden = NO;
    self.imsFailHintImageV.hidden = NO;
    self.imsFailTextLabel.hidden = NO;
    self.imsReAddBtn.hidden = NO;
    self.imsAddingTextLabel.hidden = YES;
    self.imsAddingDetailTextLabel.text = @"设备添加失败";
    self.imsFailTextLabel.text = @"设备添加失败";
}

- (void)startAddBTDeviceAnimation {
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    animation.fromValue = [NSNumber numberWithFloat:0.f];
    animation.toValue = [NSNumber numberWithFloat:M_PI * 2];
    animation.duration = 1.5f;
    animation.autoreverses = NO;
    animation.fillMode = kCAFillModeForwards;
    animation.repeatCount = MAXFLOAT;
    [self.imsAddingImageV.layer addAnimation:animation forKey:nil];
}

- (void)stopAddBTDeviceAnimation {
    [self.imsAddingImageV.layer removeAllAnimations];
}

- (void)imsSetBackButton {
    UIButton *backButton = [UIButton buttonWithType:UIButtonTypeCustom];
    backButton.frame = CGRectMake(0, 0, 44, 44);
    [backButton addTarget:self action:@selector(imsPop) forControlEvents:UIControlEventTouchUpInside];
    [backButton setImage:[[UIImage imsDevice_imageNamed:@"home_bind_back"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
    backButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [backButton setImageEdgeInsets:UIEdgeInsetsMake(0, -6, 0, 0)];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backButton];
}

- (void)imsPop {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Private

- (void)bindCompletionHandler:(NSString *)iotId error:(NSError *)error {
    if (error) {
        IMSDeviceLogError(@"error:绑定失败:%@", error);
        [self imsShowFailState];
    } else if (iotId) {
        [self ims_hideHUD];
        [self resetNaviConfigure];
        IMSDeviceLogVerbose(@"info :绑定成功 iotId = %@ , productKey = %@",iotId ,self.productKey);
        if (self.bindCallBack) {
            self.bindCallBack(self.productKey, iotId);
        } else {
            [self.navigationController popToRootViewControllerAnimated:YES];
            //不是通过本地跳转的，是通过插件直接绑定页面
            // 绑定成功，发出成功通,传入PK和iotId
            NSDictionary *dict = @{@"iotId":iotId,
                                   @"productKey":self.productKey
                                   };
            [[NSNotificationCenter defaultCenter] postNotificationName:IMSBoneRouterBindDeviceSuccessNoti object:self userInfo:dict];
        }
    } else {
        IMSDeviceLogVerbose(@"info :绑定成功 无iotId");
        [self ims_showHUDWithMessage:@"无iotId 绑定失败"];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.navigationController popToRootViewControllerAnimated:YES];
        });
    }
}

@end













