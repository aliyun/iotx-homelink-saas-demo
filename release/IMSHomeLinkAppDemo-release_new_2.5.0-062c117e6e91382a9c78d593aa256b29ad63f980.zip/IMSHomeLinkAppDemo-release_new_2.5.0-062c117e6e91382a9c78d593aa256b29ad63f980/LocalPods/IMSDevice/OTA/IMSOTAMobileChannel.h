//
//  IMSMobileChannel.h
//  CocoaAsyncSocket
//
//  Created by jinstr520 on 2018/4/17.
//

#import <Foundation/Foundation.h>
#import <AlinkAppExpress/AlinkAppExpress.h>

FOUNDATION_EXTERN NSString * const IMSMobileChannelOTATopicForward;

@interface IMSOTAMobileChannel : NSObject

+ (void)startWithDownListener:(id<LKAppExpDownListener>)downListener;

+ (void)subscribe:(NSString *)topic completionHandler:(void (^)(NSError * _Nullable error))completionHandler;

+ (void)unsubscribe:(NSString *)topic completionHandler:(void (^)(NSError * _Nullable error))completionHandler;

@end
