//
//  IMSMobileChannel.m
//  CocoaAsyncSocket
//
//  Created by jinstr520 on 2018/4/17.
//

#import "IMSOTAMobileChannel.h"
#import <IMSLog/IMSLog.h>
#import <IMSApiClient/IMSApiClient.h>

static NSString * IMSMobileChannelTag = @"IMSMobileChannel";

NSString * const IMSMobileChannelOTATopicForward = @"/ota/device/forward";

@implementation IMSOTAMobileChannel

+ (void)startWithDownListener:(id<LKAppExpDownListener>)downListener {
    [[LKAppExpress sharedInstance] addDownStreamListener:YES listener:downListener];
}

+ (void)subscribe:(NSString *)topic completionHandler:(void (^)(NSError * _Nullable error))completionHandler {
    [[LKAppExpress sharedInstance] subscribe:topic complete:^(NSError * _Nullable error) {
        if (error) {
            IMSLogInfo(@"IMSMobileChannel", error.localizedDescription);
        } else {
            NSString *message = [NSString stringWithFormat:@"%@:订阅成功", topic];
            IMSLogInfo(@"IMSMobileChannel", message);
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            if (completionHandler) {
                completionHandler(error);
            }
        });
    }];
}

+ (void)unsubscribe:(NSString *)topic completionHandler:(void (^)(NSError * _Nullable error))completionHandler {
    [[LKAppExpress sharedInstance] unsubscribe:topic complete:^(NSError * _Nullable error) {
        if (error) {
            IMSLogDebug(@"IMSMobileChannel", error.localizedDescription);
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            if (completionHandler) {
                completionHandler(error);
            }
        });
    }];
}

@end























