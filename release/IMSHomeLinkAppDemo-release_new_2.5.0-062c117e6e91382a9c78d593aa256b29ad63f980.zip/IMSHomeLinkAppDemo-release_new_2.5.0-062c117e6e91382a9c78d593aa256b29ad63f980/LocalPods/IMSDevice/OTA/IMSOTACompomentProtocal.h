//
//  IMSOTACompomentProtocal.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/10.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IMSOTADelegate.h"

typedef NS_ENUM(NSInteger, IMSOTACompomentType) {
    IMSOTACompomentTypeNone,
    IMSOTACompomentTypeBluetooth,
    IMSOTACompomentTypeWifi,
};

@class IMSOTAFirmwareInfoModel, IMSOTAProgressInfoModel;

@protocol IMSOTACompomentProtocal <NSObject>

@required

/**
 触发固件升级

 @param iotId 设备id
 @param houseId 全屋家id，全屋必传
 @param version 固件版本号
 */
- (void)upgradeWithIotId:(NSString *)iotId
                 houseId:(NSString *)houseId
                 version:(NSString *)version;

/**
 取消订阅
 */
- (void)unsubscribe;

@optional

@property (nonatomic, weak) id<IMSOTADelegate> otaDelegate;

@end





















