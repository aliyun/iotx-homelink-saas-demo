//
//  IMSOTAFactory.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/10.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "IMSOTACompomentProtocal.h"

@interface IMSOTAFactory : NSObject

+ (id<IMSOTACompomentProtocal>)getInstance:(IMSOTACompomentType)type;

@end


















