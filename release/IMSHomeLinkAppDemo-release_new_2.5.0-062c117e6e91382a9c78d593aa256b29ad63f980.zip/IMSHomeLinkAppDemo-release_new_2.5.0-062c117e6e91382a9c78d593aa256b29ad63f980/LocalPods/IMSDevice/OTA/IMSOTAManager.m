//
//  IMSOTAManager.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/10.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSOTAManager.h"
#import "IMSOTAFactory.h"

@implementation IMSOTAManager

+ (instancetype)sharedInstance {
    static IMSOTAManager *manager;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[[self class] alloc] init];
    });
    
    return manager;
}

- (void)configCompomentType:(IMSOTACompomentType)type {
    if (_compomentType != type) {
        _compomentType = type;
        
        id<IMSOTACompomentProtocal> otaCompoment = [IMSOTAFactory getInstance:type];
        _otaCompoment = otaCompoment;
    }
}

@end



















