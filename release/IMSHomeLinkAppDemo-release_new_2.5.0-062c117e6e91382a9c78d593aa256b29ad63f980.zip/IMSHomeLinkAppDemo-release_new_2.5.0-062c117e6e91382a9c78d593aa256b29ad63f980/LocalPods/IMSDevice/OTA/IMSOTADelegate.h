//
//  IMSOTADelegate.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/10.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@class IMSOTAFirmwareInfoModel, IMSOTAMQTTProgressInfoModel;

@protocol IMSOTADelegate <NSObject>

@optional

/**
 升级完成回调，包含触发升级失败、升级失败、升级异常、升级成功四种状态

 @param error 错误信息
 @param progress 进度信息
 */
- (void)otaDidFinish:(NSError *)error progress:(IMSOTAMQTTProgressInfoModel *)progress;

/**
 开始升级回调，包含等待中、升级中两种种状态

 @param progress 进度信息
 */
- (void)otaDidProgress:(IMSOTAMQTTProgressInfoModel *)progress;

@end




















