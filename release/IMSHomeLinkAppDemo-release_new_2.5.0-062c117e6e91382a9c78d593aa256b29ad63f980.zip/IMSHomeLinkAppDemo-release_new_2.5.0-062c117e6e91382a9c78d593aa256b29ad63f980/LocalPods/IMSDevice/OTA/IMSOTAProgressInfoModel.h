//
//  IMSOTAProgressInfoModel.h
//  CocoaAsyncSocket
//
//  Created by jinstr520 on 2018/4/16.
//

#import <Mantle/Mantle.h>

typedef NS_ENUM(NSInteger, IMSOTAUpgradeStatus) {
    /** 待升级或待确认 */
    IMSOTAUpgradeStatusUnconfirmed,
    /** 升级中 */
    IMSOTAUpgradeStatusUpgrading,
    /** 升级异常 */
    IMSOTAUpgradeStatusException,
    /** 升级失败 */
    IMSOTAUpgradeStatusFail,
    /** 升级完成 */
    IMSOTAUpgradeStatusSuccess,         
};

@interface IMSOTAProgressInfoModel : MTLModel<MTLJSONSerializing>

/**
 设备id
 */
@property (nonatomic, copy) NSString *iotId;

/**
 升级进度1~100
 */
@property (nonatomic, assign) NSInteger step;

/**
 升级进度错误码对应信息描述
 */
@property (nonatomic, copy) NSString *desc;

/**
 升级状态
 */
@property (nonatomic, assign) IMSOTAUpgradeStatus upgradeStatus;
@property (nonatomic, copy) NSString *startTime;
@property (nonatomic, assign) BOOL needConfirm;

@end


















