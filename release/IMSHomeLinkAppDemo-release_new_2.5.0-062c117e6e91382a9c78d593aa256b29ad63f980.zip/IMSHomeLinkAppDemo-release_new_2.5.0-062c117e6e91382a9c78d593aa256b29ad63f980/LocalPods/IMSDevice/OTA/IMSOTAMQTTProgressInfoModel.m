//
//  IMSOTAMQTTProgressInfoModel.m
//  CloudApiSDK
//
//  Created by jinstr520 on 2018/4/28.
//

#import "IMSOTAMQTTProgressInfoModel.h"

@implementation IMSOTAMQTTProgressInfoModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
    return @{
             @"iotId" : @"iotId",
             @"step" : @"step",
             @"desc" : @"desc",
             @"srcVersion" : @"srcVersion",
             @"destVersion" : @"destVersion",
             @"upgradeStatus" : @"upgradeStatus",
             };
}

@end
