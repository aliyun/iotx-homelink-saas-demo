//
//  IMSOTAModel.h
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/10.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Mantle/Mantle.h>

@interface IMSOTAFirmwareInfoModel : MTLModel<MTLJSONSerializing>

/**
 当前版本时间戳
 */
@property (nonatomic, copy) NSString *currentTimestamp;

/**
 设备当前固件版本号
 */
@property (nonatomic, copy) NSString *currentVersion;

/**
 最新固件版本号，当设备当前固件版本号最新时，为设备当前固件版本号
 */
@property (nonatomic, copy) NSString *version;

/**
 文件包大小
 */
@property (nonatomic, copy) NSString *size;

/**
 版本详情描述
 */
@property (nonatomic, copy) NSString *desc;

/**
 固件名称
 */
@property (nonatomic, copy) NSString *name;

/**
 固件文件md5
 */
@property (nonatomic, copy) NSString *md5;

/**
 最新固件时间戳
 */
@property (nonatomic, copy) NSString *timestamp;

/**
 固件地址，sts加密
 */
@property (nonatomic, copy) NSString *url;

@end





















