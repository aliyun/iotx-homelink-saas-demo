//
//  IMSOTAMQTTProgressInfoModel.h
//  CloudApiSDK
//
//  Created by jinstr520 on 2018/4/28.
//

#import "IMSOTAProgressInfoModel.h"

@interface IMSOTAMQTTProgressInfoModel : IMSOTAProgressInfoModel

/**
 最近一次升级源版本
 */
@property (nonatomic, copy) NSString *srcVersion;

/**
 最近一次升级目标版本
 */
@property (nonatomic, copy) NSString *destVersion;

@end


















