//
//  IMSOTAModel.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/10.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSOTAFirmwareInfoModel.h"
#import "NSString+IMSDeviceExtension.h"
#import "NSValueTransformer+IMSDeviceExtension.h"

@implementation IMSOTAFirmwareInfoModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
    return @{
             @"currentTimestamp":@"currentTimestamp",
             @"currentVersion":@"currentVersion",
             @"desc":@"desc",
             @"md5":@"md5",
             @"name":@"name",
             @"size":@"size",
             @"timestamp":@"timestamp",
             @"url":@"url",
             @"version":@"version"
             };
}

+ (NSValueTransformer *)JSONTransformerForKey:(NSString *)key {
    if ([key isEqualToString:@"timestamp"] || [key isEqualToString:@"currentTimestamp"]) {
        return [NSValueTransformer imsDevice_timestampTransformer];
    }
    return nil;
}

@end















