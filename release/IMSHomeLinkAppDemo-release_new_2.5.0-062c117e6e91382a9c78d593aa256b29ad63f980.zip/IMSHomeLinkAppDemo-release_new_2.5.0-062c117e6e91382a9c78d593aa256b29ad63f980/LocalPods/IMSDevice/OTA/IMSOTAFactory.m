//
//  IMSOTAFactory.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/10.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSOTAFactory.h"
#import "IMSOTACompomentWifi.h"

@implementation IMSOTAFactory

+ (id<IMSOTACompomentProtocal>)getInstance:(IMSOTACompomentType)type {
    id<IMSOTACompomentProtocal> instance = nil;
    switch (type) {
        case IMSOTACompomentTypeWifi:
            instance = [[IMSOTACompomentWifi alloc] init];
            break;
            
        default:
            break;
    }
    return instance;
}

@end
