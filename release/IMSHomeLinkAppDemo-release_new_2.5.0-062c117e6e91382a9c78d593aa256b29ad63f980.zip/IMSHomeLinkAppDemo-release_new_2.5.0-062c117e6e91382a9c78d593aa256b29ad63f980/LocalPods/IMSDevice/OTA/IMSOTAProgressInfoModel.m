//
//  IMSOTAProgressInfoModel.m
//  CocoaAsyncSocket
//
//  Created by jinstr520 on 2018/4/16.
//

#import "IMSOTAProgressInfoModel.h"
#import "NSString+IMSDeviceExtension.h"
#import "NSValueTransformer+IMSDeviceExtension.h"

@implementation IMSOTAProgressInfoModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
    return @{
             @"iotId" : @"iotId",
             @"step" : @"step",
             @"desc" : @"desc",
             @"needConfirm" : @"needConfirm",
             @"upgradeStatus" : @"upgradeStatus",
             @"startTime" : @"startTime",
             };
}

+ (NSValueTransformer *)startTimeJSONTransformer {
    return [NSValueTransformer imsDevice_timestampTransformer];
}

@end









