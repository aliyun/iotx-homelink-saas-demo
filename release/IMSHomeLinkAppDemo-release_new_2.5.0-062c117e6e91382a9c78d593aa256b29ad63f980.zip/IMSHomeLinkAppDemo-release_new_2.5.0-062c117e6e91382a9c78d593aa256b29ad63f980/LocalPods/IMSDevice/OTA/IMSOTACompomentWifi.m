//
//  IMSWifiOTA.m
//  IMSDevice
//
//  Created by jinstr520 on 2018/4/10.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSOTACompomentWifi.h"
#import "IMSDeviceClient.h"
#import "IMSOTAMobileChannel.h"
#import "IMSOTAFirmwareInfoModel.h"
#import "IMSOTAMQTTProgressInfoModel.h"

@implementation IMSOTACompomentWifi {
    id<IMSOTADelegate> _otaDelegate;
    NSString *_iotId;
    NSString *_version;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [IMSOTAMobileChannel startWithDownListener:self];
    }
    return self;
}

#pragma mark - Property

- (void)setOtaDelegate:(id<IMSOTADelegate>)otaDelegate {
    _otaDelegate = otaDelegate;
}

- (id<IMSOTADelegate>)otaDelegate {
    return _otaDelegate;
}

#pragma mark - LKAppExpDownListener

- (void)onDownstream:(NSString * _Nonnull)topic data:(NSDictionary * _Nullable)data {
    if ([topic isEqualToString:IMSMobileChannelOTATopicForward]) {
        NSError *error = nil;
        IMSOTAMQTTProgressInfoModel *progressInfo = [MTLJSONAdapter modelOfClass:[IMSOTAMQTTProgressInfoModel class] fromJSONDictionary:data error:&error];
        
        if (progressInfo.upgradeStatus == IMSOTAUpgradeStatusSuccess
            || progressInfo.upgradeStatus == IMSOTAUpgradeStatusException
            || progressInfo.upgradeStatus == IMSOTAUpgradeStatusFail) {
            if ([self.otaDelegate respondsToSelector:@selector(otaDidFinish:progress:)]) {
                [self.otaDelegate otaDidFinish:nil progress:progressInfo];
            }
        } else {
            if ([self.otaDelegate respondsToSelector:@selector(otaDidProgress:)]) {
                [self.otaDelegate otaDidProgress:progressInfo];
            }
        }
    }
}

- (BOOL)shouldHandle:(NSString *)topic {
    return YES;
}

#pragma mark - IMSOTACompomentProtocal

- (void)upgradeWithIotId:(NSString *)iotId
                 houseId:(NSString *)houseId
                 version:(NSString *)version {
    if (iotId) {
        _iotId = iotId;
        _version = version;
        [[IMSDeviceClient sharedClient] upgradeWifiDeviceFirmwareWithIotIds:@[iotId] houseId:houseId completionHandler:^(NSDictionary *data, NSError *error) {
            if (error) {
                if ([self.otaDelegate respondsToSelector:@selector(otaDidFinish:progress:)]) {
                    [self.otaDelegate otaDidFinish:error progress:nil];
                }
            } else {
                [IMSOTAMobileChannel subscribe:IMSMobileChannelOTATopicForward completionHandler:nil];
            }
        }];
    }
}

- (void)unsubscribe {
    [IMSOTAMobileChannel unsubscribe:IMSMobileChannelOTATopicForward completionHandler:nil];
}

@end




















