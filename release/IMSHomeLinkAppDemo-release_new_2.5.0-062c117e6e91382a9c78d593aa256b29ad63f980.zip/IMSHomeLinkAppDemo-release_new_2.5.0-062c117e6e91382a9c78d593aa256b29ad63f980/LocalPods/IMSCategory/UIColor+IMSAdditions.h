//
//  UIColor+IMSAdditions.h
//  IMSCategory
//
//  Created by 冯君骅 on 2018/4/14.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (IMSAdditions)

// 快速的创建方法， rgb值不需/255.0f
+ (UIColor *)ims_colorWithRed:(CGFloat)red green:(CGFloat)green blue:(CGFloat)blue;
+ (UIColor *)ims_colorWithRed:(CGFloat)red green:(CGFloat)green blue:(CGFloat)blue alpha:(CGFloat)alpha;

/**
 十六进制的初始化方法

 @param hexRGB eg:0xFFFFF
 @return UIColor实例
 */
+ (UIColor *)ims_colorWithHexRGB:(NSUInteger)hexRGB;
+ (UIColor *)ims_colorWithHexRGB:(NSUInteger)hexRGB alpha:(CGFloat)alpha;

// 这些颜色会被缓存
+ (UIColor *)ims_systemMaticColor;
+ (UIColor *)ims_negativeColor;
+ (UIColor *)ims_titleColor;
+ (UIColor *)ims_accessaryColor;
+ (UIColor *)ims_accessorialColor;
+ (UIColor *)ims_marginalColor;
+ (UIColor *)ims_backgroundColor;
+ (UIColor *)ims_fillColor;

/**
 用于初始化上面的几个标志性颜色
 @param plist 键值对
 eg:@{@"SystemMatic":@(0x00C989),
      @"Negative":@(0xFF352F),
 	  @"Title":@(0x333333),
	  @"Accessary":@(0x999999),
 	  @"Accessorial":@(0xAFB8BD),
	  @"Marginal":@(0xEDEDED),
 	  @"Background":@(0xF6F6F6),
 	  @"Fill":@(0xFFFFFF)
 	}
 */
+ (void)configDefaultColorsWithPlist:(NSDictionary *)plist;

@end
