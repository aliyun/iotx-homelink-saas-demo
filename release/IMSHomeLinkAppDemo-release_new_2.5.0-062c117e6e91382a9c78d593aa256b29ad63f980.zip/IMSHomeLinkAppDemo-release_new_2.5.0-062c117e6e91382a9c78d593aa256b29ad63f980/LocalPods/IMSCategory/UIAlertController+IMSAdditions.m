//
//  UIAlertController+IMSAdditions.m
//  IMSCategory
//
//  Created by 冯君骅 on 2018/4/16.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "UIAlertController+IMSAdditions.h"
#import "UIColor+IMSAdditions.h"
#import <objc/runtime.h>

@implementation UIAlertController (IMSAdditions)

+ (instancetype)ims_alertControllerWithTitle:(nullable NSString *)title message:(nullable NSString *)message preferredStyle:(UIAlertControllerStyle)preferredStyle {
	return [self alertControllerWithTitle:title message:message preferredStyle:preferredStyle];
}

- (void)ims_addAction:(UIAlertAction *)action {
	[self ims_changeColorWithAction:action color:[UIColor ims_systemMaticColor]];
	[self addAction:action];
}

- (void)ims_addTextFieldWithConfigurationHandler:(void (^)(UITextField * _Nonnull))configurationHandler {
	[self addTextFieldWithConfigurationHandler:configurationHandler];
	[self.textFields enumerateObjectsUsingBlock:^(UITextField * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
		if (obj.placeholder.length > 0) {
			obj.attributedPlaceholder = [[NSAttributedString alloc] initWithString:obj.placeholder attributes:@{NSForegroundColorAttributeName:[UIColor ims_accessaryColor]}];
			obj.textColor = [UIColor ims_titleColor];
		}
	}];
}

- (void)ims_changeColorWithAction:(id)action color:(UIColor *)color {
	if (@available(iOS 8.0, *)) {
		if (![action isKindOfClass:[UIAlertAction class]]) {
			return;
		}
		unsigned int count = 0;
		Ivar *ivars = class_copyIvarList([UIAlertAction class], &count);

		for(int idx =0; idx < count; idx++){
			Ivar ivar = ivars[idx];
			NSString *ivarName = [NSString stringWithCString:ivar_getName(ivar) encoding:NSUTF8StringEncoding];
			if ([ivarName isEqualToString:@"_titleTextColor"]) {
				[((UIAlertAction *)action) setValue:color forKey:@"titleTextColor"];
			}
		}
	}
}

@end
