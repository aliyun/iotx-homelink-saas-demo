//
//  UIAlertController+IMSAdditions.h
//  IMSCategory
//
//  Created by 冯君骅 on 2018/4/16.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

@interface UIAlertController (IMSAdditions)

- (void)ims_addAction:(UIAlertAction *)action;
- (void)ims_addTextFieldWithConfigurationHandler:(void (^)(UITextField * _Nonnull))configurationHandler;
- (void)ims_changeColorWithAction:(id)action color:(UIColor *)color;
@end
NS_ASSUME_NONNULL_END
