//
//  UIFont+IMSAdditions.m
//  IMSCategory
//
//  Created by 冯君骅 on 2018/4/14.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "UIFont+IMSAdditions.h"
static NSString* const kRegular = @"PingFangSC-Regular";
static NSString* const kSemibold = @"PingFangSC-Semibold";
static NSString* const kUltralight = @"PingFangSC-Ultralight";
static NSString* const kLight = @"PingFangSC-Light";
static NSString* const kThin = @"PingFangSC-Thin";
static NSString* const kMedium = @"PingFangSC-Medium";

@implementation UIFont (IMSAdditions)

+ (UIFont *)ims_regularFontOfSize:(CGFloat)fontSize {
	return [UIFont fontWithName:kRegular size:fontSize];
}
+ (UIFont *)ims_semiboldFontOfSize:(CGFloat)fontSize {
	return [UIFont fontWithName:kSemibold size:fontSize];
}
+ (UIFont *)ims_ultralightFontOfSize:(CGFloat)fontSize {
	return [UIFont fontWithName:kUltralight size:fontSize];
}
+ (UIFont *)ims_lightFontOfSize:(CGFloat)fontSize {
	return [UIFont fontWithName:kLight size:fontSize];
}
+ (UIFont *)ims_thinFontOfSize:(CGFloat)fontSize {
	return [UIFont fontWithName:kThin size:fontSize];
}
+ (UIFont *)ims_mediumFontOfSize:(CGFloat)fontSize {
	return [UIFont fontWithName:kMedium size:fontSize];
}
@end
