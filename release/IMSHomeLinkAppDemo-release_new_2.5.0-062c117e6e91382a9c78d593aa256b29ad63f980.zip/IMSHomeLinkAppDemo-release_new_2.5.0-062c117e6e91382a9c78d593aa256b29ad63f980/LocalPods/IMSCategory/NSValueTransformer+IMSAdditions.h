//
//  NSValueTransformer+IMSAdditions.h
//  IMSCategory
//
//  Created by 冯君骅 on 2018/6/8.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface NSValueTransformer (IMSAdditions)
+ (NSValueTransformer *)ims_dateValueTransformer;
@end
