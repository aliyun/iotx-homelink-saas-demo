//
//  NSURL+IMSAdditions.m
//  IMSCategory
//
//  Created by 冯君骅 on 2018/6/5.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "NSURL+IMSAdditions.h"

@implementation NSURL (IMSAdditions)
- (NSDictionary *)ims_queryParams {
	NSMutableDictionary *params = [@{} mutableCopy];
	
	if ([self query]) {
		NSArray *items = [[self query] componentsSeparatedByString:@"&"];
		
		for (NSString *item in items) {
			NSArray *components = [item componentsSeparatedByString:@"="];
			if (components.count == 0) {
				continue;
			}
			
			NSString *key = [components[0] stringByRemovingPercentEncoding];
			id value = nil;
			if (components.count == 1) {
				// key with no value
				value = @"";
			}
			if (components.count == 2) {
				value = [components[1] stringByRemovingPercentEncoding];
				// cover case where there is a separator, but no actual value
				value = [value length] ? value : @"";
			}
			
			params[key] = value ?: @"";
		}
	}
	
	return params;
}
@end
