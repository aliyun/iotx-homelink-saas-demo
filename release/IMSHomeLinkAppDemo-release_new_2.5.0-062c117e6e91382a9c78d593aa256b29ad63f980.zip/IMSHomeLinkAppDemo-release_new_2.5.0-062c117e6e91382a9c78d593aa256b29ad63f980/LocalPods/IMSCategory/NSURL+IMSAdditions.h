//
//  NSURL+IMSAdditions.h
//  IMSCategory
//
//  Created by 冯君骅 on 2018/6/5.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSURL (IMSAdditions)
- (NSDictionary *)ims_queryParams;
@end
