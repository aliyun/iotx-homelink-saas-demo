//
//  NSError+IMSErrorMessage.h
//  IMSCategory
//
//  Created by X i n long Li on 2018/5/9.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSError (IMSErrorMessage)

- (NSError *)ims_localizedMessage;

@end
