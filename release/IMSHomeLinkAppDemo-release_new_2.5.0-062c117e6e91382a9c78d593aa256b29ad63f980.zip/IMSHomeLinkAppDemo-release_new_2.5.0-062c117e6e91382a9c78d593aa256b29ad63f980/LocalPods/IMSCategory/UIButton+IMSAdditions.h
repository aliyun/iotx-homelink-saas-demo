//
//  UIButton+IMSAdditions.h
//  IMSCategory
//
//  Created by chuntao.wang1 on 2018/5/16.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (IMSAdditions)

/**
 增加button点击范围
 
 @param top 上边增加像素
 @param right 右边增加像素
 @param bottom 下边增加像素
 @param left 左边增加像素
 */
- (void)ims_enlargeEdgeWithTop:(CGFloat)top right:(CGFloat)right bottom:(CGFloat)bottom left:(CGFloat)left;

@end
