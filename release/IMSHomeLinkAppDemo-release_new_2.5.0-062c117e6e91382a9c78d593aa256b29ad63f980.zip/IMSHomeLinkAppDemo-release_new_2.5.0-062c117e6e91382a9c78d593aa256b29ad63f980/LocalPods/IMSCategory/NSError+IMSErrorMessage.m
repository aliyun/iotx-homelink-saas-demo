//
//  NSError+IMSErrorMessage.m
//  IMSCategory
//
//  Created by X i n long Li on 2018/5/9.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "NSError+IMSErrorMessage.h"

static NSString *const kIMSErrorUserLanguageCodeKey = @"IMSUserLanguageCodeKey";

@implementation NSError (IMSErrorMessage)

- (NSError *)ims_localizedMessage {
    NSString *desc = [self descriptionWithErrorCode:self.code];
    return [NSError errorWithDomain:NSURLErrorDomain code:self.code userInfo:@{NSLocalizedDescriptionKey:desc}];
}

- (NSString *)descriptionWithErrorCode:(NSInteger)errorDomain {
    NSDictionary *dic = nil;
    NSNumber *number = [[NSUserDefaults standardUserDefaults] valueForKey:kIMSErrorUserLanguageCodeKey];
    if ([number integerValue] == 2) {
        dic = [self chineseMessageDic];
    } else {
        dic = [self englishMessageDic];
    }
    NSString *desc = [dic objectForKey:@(errorDomain)];
    desc = desc ?: @"";
    return desc;
}

- (NSDictionary *)chineseMessageDic {
    return @{@(NSURLErrorCancelled):@"已撤销",
             @(NSURLErrorTimedOut):@"请求超时",
             @(NSURLErrorBadServerResponse):@"服务异常",
             @(NSURLErrorNotConnectedToInternet):@"网络异常，请稍后再试"};
}

- (NSDictionary *)englishMessageDic {
    return @{@(NSURLErrorCancelled):@"Cancelled",
             @(NSURLErrorTimedOut):@"Timeout",
             @(NSURLErrorBadServerResponse):@"Bad server",
             @(NSURLErrorNotConnectedToInternet):@"Not connected to internet"};
}

@end
