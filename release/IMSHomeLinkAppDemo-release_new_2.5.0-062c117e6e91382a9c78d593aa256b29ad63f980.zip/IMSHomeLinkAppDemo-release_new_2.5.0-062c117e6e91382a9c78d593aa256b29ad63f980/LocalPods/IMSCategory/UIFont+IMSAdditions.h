//
//  UIFont+IMSAdditions.h
//  IMSCategory
//
//  Created by 冯君骅 on 2018/4/14.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIFont (IMSAdditions)
// 苹方-简 常规体
+ (UIFont *)ims_regularFontOfSize:(CGFloat)fontSize;
// 苹方-简 中粗体
+ (UIFont *)ims_semiboldFontOfSize:(CGFloat)fontSize;
// 苹方-简 极细体
+ (UIFont *)ims_ultralightFontOfSize:(CGFloat)fontSize;
// 苹方-简 细体
+ (UIFont *)ims_lightFontOfSize:(CGFloat)fontSize;
// 苹方-简 纤细体
+ (UIFont *)ims_thinFontOfSize:(CGFloat)fontSize;
// 苹方-简 中黑体
+ (UIFont *)ims_mediumFontOfSize:(CGFloat)fontSize;
@end
