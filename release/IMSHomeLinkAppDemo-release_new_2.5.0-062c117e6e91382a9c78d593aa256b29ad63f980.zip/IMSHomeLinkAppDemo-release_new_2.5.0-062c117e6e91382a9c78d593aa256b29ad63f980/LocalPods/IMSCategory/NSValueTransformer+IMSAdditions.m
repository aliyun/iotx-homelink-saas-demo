//
//  NSValueTransformer+IMSAdditions.m
//  IMSCategory
//
//  Created by 冯君骅 on 2018/6/8.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "NSValueTransformer+IMSAdditions.h"
#import <Mantle/Mantle.h>

@implementation NSValueTransformer (IMSAdditions)

+ (NSValueTransformer *)ims_dateValueTransformer {
	return [MTLValueTransformer transformerUsingForwardBlock:^id(NSNumber *timestamps, BOOL *success, NSError *__autoreleasing *error) {
		NSDate *date = [NSDate dateWithTimeIntervalSince1970:timestamps.integerValue / 1000];
		return date;
	} reverseBlock:^id(NSDate *date, BOOL *success, NSError *__autoreleasing *error) {
		return @([date timeIntervalSince1970]);
	}];
}

@end
