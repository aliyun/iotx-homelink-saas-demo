//
//  UIImage+IMSAdditions.h
//  IMSCategory
//
//  Created by 冯君骅 on 2018/5/9.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (IMSAdditions)
- (UIImage *)ims_imageWithColor:(UIColor *)color size:(CGSize)size cornerRadius:(CGFloat)cornerRadius;


/**
 纯色图片

 @param color 颜色
 @return 图片
 */
+ (UIImage *)ims_imageWithColor:(UIColor *)color;

/**
 图片按比例显示
 
 @param image 图片
 @param size 图片区域
 @return 图片
 */
+ (UIImage *)ims_imageCompress:(UIImage *)image toSize:(CGSize)size;

@end
