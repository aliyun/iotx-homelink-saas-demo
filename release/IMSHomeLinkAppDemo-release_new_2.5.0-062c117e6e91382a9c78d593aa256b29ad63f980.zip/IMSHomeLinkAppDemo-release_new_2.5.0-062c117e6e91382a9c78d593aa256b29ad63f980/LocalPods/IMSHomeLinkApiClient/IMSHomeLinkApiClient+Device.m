//
//  IMSHomeLinkApiClient+Device.m
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/27.
//

#import "IMSHomeLinkApiClient+Device.h"



@implementation IMSHomeLinkApiClient (Device)

/**
 基础的网络请求
 
 @param path 请求路径
 @param version 版本
 @param params 请求参数
 @param finished 回调
 */
- (void)requestWithPath:(NSString *)path
				version:(NSString *)version
				 params:(NSDictionary *)params
			   finished:(void(^)(id data,NSError * __nullable error))finished {
	[self requestWithPath:path version:version params:params completoinHandler:^(id data, NSError *error) {
		if (![data isKindOfClass:[NSDictionary class]]) {
			data = nil;
		}
		
		if (finished) {
			finished(data,error);
		}
	}];
}

- (void)commonDevicesWithHouseId:(NSString *)houseId
						  pageNo:(NSUInteger)pageNo
						pageSize:(NSUInteger)pageSize
						finished:(void(^)(IMSHomeLinkDeviceListModel *model,NSError * __nullable error))finished {
	NSString *path = @"/homelink/device/frequency/list";
	HomeLinkClientAssert(houseId.length > 0,path);
	if (!(houseId.length > 0)) {
		return;
	}
	
	NSMutableDictionary *params = [[NSMutableDictionary alloc] initWithCapacity:4];
	params[@"houseId"] = houseId;
	params[@"pageNo"] = @(pageNo);
	params[@"pageSize"] = @(pageSize);
	
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		IMSHomeLinkDeviceListModel *model;
		if (data) {
			model = [MTLJSONAdapter modelOfClass:IMSHomeLinkDeviceListModel.class fromJSONDictionary:data error:nil];
		}
		
		if (finished) {
			finished(model,error);
		}
	}];
}

- (void)updateCommonDevicesWithHouseId:(NSString *)houseId
							 iotIdList:(NSArray<NSString *> * __nullable)iotIdList
							  finished:(void(^)(BOOL success,NSError * __nullable error))finished {
	NSString *path = @"/homelink/device/frequency/update";
	HomeLinkClientAssert(houseId.length > 0, path);
	if (!(houseId.length > 0)) {
		return;
	}
	
	NSMutableDictionary *params = [[NSMutableDictionary alloc] initWithCapacity:2];
	params[@"houseId"] = houseId;
	params[@"iotIdList"] = iotIdList ?: [NSNull null];
	
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		if (finished) {
			finished(error ? NO : YES,error);
		}
	}];
}

- (void)changeDeviceToRoom:(NSString *)roomId
				 iotIdList:(NSArray <NSString *> *)iotIdList
				  finished:(void(^)(BOOL success,NSError * __nullable error))finished {
	NSString *path = @"/homelink/room/device/change";
	HomeLinkClientAssert(roomId.length > 0, path);
	if (!(roomId.length > 0)) {
		return;
	}
	
	NSMutableDictionary *params = [[NSMutableDictionary alloc] initWithCapacity:4];
	params[@"toRoomId"] = roomId;
	params[@"iotIdList"] = iotIdList ?: [NSNull null];
	
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		if (finished) {
			finished(error ? NO : YES,error);
		}
	}];
}

- (void)houseDeviceListWithHouseId:(NSString *)houseId
						  nodeType:(IMSDeviceNodeType)nodeType
							pageNo:(NSUInteger)pageNo
						  pageSize:(NSUInteger)pageSize
						  finished:(void(^)(IMSHomeLinkDeviceListModel *model,NSError * __nullable error))finished {
	NSString *path = @"/homelink/house/device/list";
	HomeLinkClientAssert(houseId.length > 0, path);
	if (!(houseId.length > 0)) {
		return;
	}
	
	NSMutableDictionary *params = [[NSMutableDictionary alloc] initWithCapacity:4];
	params[@"houseId"] = houseId;
	NSString *nodeTypeStr = [[IMSHomeLinkDeviceModel nodeTypeTransformer] reverseTransformedValue:@(nodeType)];
	if (nodeTypeStr != (id)kCFNull && nodeTypeStr.length > 0) {
		params[@"nodeType"] = nodeTypeStr;
	}
	params[@"pageNo"] = @(pageNo);
	params[@"pageSize"] = @(pageSize);
	
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		IMSHomeLinkDeviceListModel *model;
		if (data) {
			model = [MTLJSONAdapter modelOfClass:IMSHomeLinkDeviceListModel.class fromJSONDictionary:data error:nil];
		}
		
		if (finished) {
			finished(model,error);
		}
	}];
	
}


- (void)roomDeviceListWithRoomId:(NSString *)roomId
						nodeType:(IMSDeviceNodeType)nodeType
						  pageNo:(NSUInteger)pageNo
						pageSize:(NSUInteger)pageSize
						finished:(void(^)(IMSHomeLinkDeviceListModel *model,NSError * __nullable error))finished {
	NSString *path = @"/homelink/room/device/list";
	HomeLinkClientAssert(roomId.length > 0, path);
	if (!(roomId.length > 0)) {
		return;
	}
	
	NSMutableDictionary *params = [[NSMutableDictionary alloc] initWithCapacity:4];
	params[@"roomId"] = roomId;
	NSString *nodeTypeStr = [[IMSHomeLinkDeviceModel nodeTypeTransformer] reverseTransformedValue:@(nodeType)];
	if (nodeTypeStr != (id)kCFNull && nodeTypeStr.length > 0) {
		params[@"nodeType"] = nodeTypeStr;
	}
	params[@"pageNo"] = @(pageNo);
	params[@"pageSize"] = @(pageSize);
	
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		IMSHomeLinkDeviceListModel *model;
		if (data) {
			model = [MTLJSONAdapter modelOfClass:IMSHomeLinkDeviceListModel.class fromJSONDictionary:data error:nil];
		}
		
		if (finished) {
			finished(model,error);
		}
	}];
}


- (void)memberDeviceListWithRoomId:(NSString *)roomId
				  memberIdentityId:(NSString *)memberIdentityId
						  nodeType:(IMSDeviceNodeType)nodeType
							pageNo:(NSUInteger)pageNo
						  pageSize:(NSUInteger)pageSize
						  finished:(void(^)(IMSHomeLinkDeviceListModel *model,NSError * __nullable error))finished {
	NSString *path = @"/homelink/room/member/device/list";
	HomeLinkClientAssert(roomId.length > 0, path);
	if (!(roomId.length > 0)) {
		return;
	}
	
	NSMutableDictionary *params = [[NSMutableDictionary alloc] initWithCapacity:4];
	params[@"roomId"] = roomId;
	if (memberIdentityId) {
		params[@"memberIdentityId"] = memberIdentityId;
	}
	NSString *nodeTypeStr = [[IMSHomeLinkDeviceModel nodeTypeTransformer] reverseTransformedValue:@(nodeType)];
	if (nodeTypeStr != (id)kCFNull && nodeTypeStr.length > 0) {
		params[@"nodeType"] = nodeTypeStr;
	}
	params[@"pageNo"] = @(pageNo);
	params[@"pageSize"] = @(pageSize);
	
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		IMSHomeLinkDeviceListModel *model;
		if (data) {
			model = [MTLJSONAdapter modelOfClass:IMSHomeLinkDeviceListModel.class fromJSONDictionary:data error:nil];
		}
		
		if (finished) {
			finished(model,error);
		}
	}];
}
@end
