//
//  IMSHomeLinkApiClient.h
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/1.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>

#define HomeLinkClientAssert(condition,url) NSAssert((condition), @"url = %@ ,Invalid parameter not satisfying: %@", @#condition, url)

@interface IMSHomeLinkApiClient : NSObject
// 单例对应的实例对象
+ (instancetype)sharedClient;

// 发送业务请求，默认为需要IoT身份认证
- (void)requestWithPath:(NSString *)path
				version:(NSString *)version
				 params:(NSDictionary *)params
	  completoinHandler:(void (^)(id data, NSError *error))completion;


// 发送业务请求，可以指定是否需要IoT身份认证
- (void)requestWithPath:(NSString *)path
				version:(NSString *)version
				 params:(NSDictionary *)params
			 needsLogin:(BOOL)needsLogin
	  completoinHandler:(void (^)(id data, NSError *error))completion;

@end
