//
//  IMSHomeLinkApiClient+UserManager.h
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/28.
//

#import <IMSHomeLinkApiClient/IMSHomeLinkApiClient.h>
#import <IMSHomeLinkApiClient/IMSHomeLinkUserListModel.h>
#import <IMSHomeLinkApiClient/IMSMemberUpdateModel.h>
NS_ASSUME_NONNULL_BEGIN
@interface IMSHomeLinkApiClient (UserManager)
/**
 家庭成员列表
 
 @param pageNo 页码
 @param pageSize 每页item的数量
 @param finished 回调
 */
- (void)memberListWithHouseId:(NSString *)houseId
					   pageNo:(NSUInteger)pageNo
					 pageSize:(NSUInteger)pageSize
				     finished:(void(^)(IMSHomeLinkUserListModel *model,NSError * __nullable error))finished;


/**
 管理员移除指定的家庭成员

 @param identityIdList 要移除的用户的身份ID列表，如果id不存在将不做删除动作
 @param houseId 房屋id
 @param finished 回调
 */
- (void)removeMembers:(NSArray <NSString *>*)identityIdList
			  houseId:(NSString *)houseId
		     finished:(void(^)(BOOL success,NSError * __nullable error))finished;


/**
 管理员更新家庭成员

 @param memberIdentityId 要变更的用户身份ID，只能是家庭普通成员
 @param houseId 房屋id
 @param roomList 用户对房间操作的列表
 @param deviceList 用户对设备操作的列表
 @param sceneList 用户对场景操作的列表
 @param finished 回调
 */
- (void)updateMember:(NSString *)memberIdentityId
			 houseId:(NSString *)houseId
            roomList:(NSArray *)roomList
		  deviceList:(NSArray <IMSMemberUpdateModel *> *)deviceList
		   sceneList:(NSArray <IMSMemberUpdateModel *> *)sceneList
			finished:(void(^)(BOOL success,NSError * __nullable error))finished;


/**
 转让管理员

 @param houseId 房屋id
 @param newIdentityId 目标用户的身份ID
 @param finished 回调
 */
- (void)transferMemberManagerWithHouseId:(NSString *)houseId
						   newIdentityId:(NSString *)newIdentityId
								finished:(void(^)(BOOL success,NSError * __nullable error))finished;
@end
NS_ASSUME_NONNULL_END
