//
//  IMSHomeLinkApiClient+House.m
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/28.
//

#import "IMSHomeLinkApiClient+House.h"

@implementation IMSHomeLinkApiClient (House)

/**
 基础的网络请求
 
 @param path 请求路径
 @param version 版本
 @param params 请求参数
 @param finished 回调
 */
- (void)requestWithPath:(NSString *)path
				version:(NSString *)version
				 params:(NSDictionary *)params
			   finished:(void(^)(id data,NSError * __nullable error))finished {
	[self requestWithPath:path version:version params:params completoinHandler:^(id data, NSError *error) {
		if (![data isKindOfClass:[NSDictionary class]]) {
			data = nil;
		}
		
		if (finished) {
			finished(data,error);
		}
	}];
}

- (void)houseListWithPageNo:(NSUInteger)pageNo
				   pageSize:(NSUInteger)pageSize
				   finished:(void(^)(IMSHomelinkHouseListModel *model,NSError * __nullable error))finished {
	NSString *path = @"/homelink/house/list";
	
	NSDictionary *params = @{@"pageNo":@(pageNo),
							 @"pageSize":@(pageSize)
							 };
	
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		IMSHomelinkHouseListModel *model;
		if (data) {
			model = [MTLJSONAdapter modelOfClass:IMSHomelinkHouseListModel.class fromJSONDictionary:data error:nil];
		}
		
		if (finished) {
			finished(model,error);
		}
	}];
}

- (void)roomJurisdictionListWithHouseId:(NSString *)houseId
                       memberIdentityId:(NSString *)memberIdentityId
                                 pageNo:(NSInteger )pageNo
                               pageSize:(NSInteger )pageSize
                               finished:(void(^)(IMSHomelinkRoomListModel *model,NSError * __nullable error))finished{
    NSString *path = @"/homelink/room/member/list";
    NSDictionary *params = @{
                             @"memberIdentityId": (memberIdentityId ?: [NSNull null]),
                             @"pageNo":@(pageNo),
                             @"pageSize":@(pageSize),
                             @"houseId":(houseId ?: [NSNull null])
                             };
    [self requestWithPath:path version:@"1.0.3" params:params finished:^(id data, NSError * _Nullable error) {
        IMSHomelinkRoomListModel *model;
        if (data) {
            model = [MTLJSONAdapter modelOfClass:IMSHomelinkRoomListModel.class fromJSONDictionary:data error:nil];
        }
        if (finished) {
            finished(model,error);
        }
    }];
}

- (void)roomListWithMemberIdentityId:(NSString * __nullable)memberIdentityId
							 HouseId:(NSString *)houseId
							  pageNo:(NSUInteger)pageNo
							pageSize:(NSUInteger)pageSize
							finished:(void(^)(IMSHomelinkRoomListModel *model,NSError * __nullable error))finished {
	
	NSString *path = @"/homelink/room/list";
	
	NSDictionary *params = @{
							 @"memberIdentityId": (memberIdentityId ?: [NSNull null]),
							 @"pageNo":@(pageNo),
							 @"pageSize":@(pageSize),
							 @"houseId":(houseId ?: [NSNull null])
							 };
	
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		IMSHomelinkRoomListModel *model;
		if (data) {
			model = [MTLJSONAdapter modelOfClass:IMSHomelinkRoomListModel.class fromJSONDictionary:data error:nil];
		}
		
		if (finished) {
			finished(model,error);
		}
	}];
}

- (void)sortRoomWithHouseId:(NSString *)houseId
				  orderList:(NSArray<IMSRoomSortModel *> *)orderList
				   finished:(void(^)(BOOL success,NSError * __nullable error))finished {
	NSString *path = @"/homelink/room/order/update";
	HomeLinkClientAssert(houseId.length > 0, path);
	if (!(houseId.length > 0)) {
		return;
	}
	
	NSMutableDictionary *params = [[NSMutableDictionary alloc] initWithCapacity:4];
	params[@"houseId"] = houseId;
	
	NSArray *jsonDatas = [MTLJSONAdapter JSONArrayFromModels:orderList error:nil];
	params[@"orderList"] = jsonDatas ?: [NSNull null];
	
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		if (finished) {
			finished(error ? NO : YES,error);
		}
	}];
}

- (void)roomDetailWithRoomId:(NSString *)roomId
					 houseId:(NSString *)houseId
					finished:(void(^)(IMSHomelinkRoomModel *model,NSError * __nullable error))finished {
	NSString *path = @"/homelink/room/detail/get";
	HomeLinkClientAssert(roomId.length > 0, path);
	HomeLinkClientAssert(houseId.length > 0, path);
	if (!(roomId.length > 0) || !(houseId.length > 0)) {
		return;
	}
	
	NSMutableDictionary *params = [[NSMutableDictionary alloc] initWithCapacity:4];
	params[@"roomId"] = roomId;
	params[@"houseId"] = houseId;
	
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		IMSHomelinkRoomModel *model;
		if (data) {
			model = [MTLJSONAdapter modelOfClass:IMSHomelinkRoomModel.class fromJSONDictionary:data error:nil];
		}
		
		if (finished) {
			finished(model,error);
		}
	}];
}

- (void)updateRoomInfoWithRoomId:(NSString *)roomId
						roomName:(NSString * __nullable)roomName
					 roomPicture:(NSString * __nullable)roomPicture
						finished:(void(^)(BOOL success,NSError * __nullable error))finished {
	NSString *path = @"/homelink/room/detail/update";
	HomeLinkClientAssert(roomId.length > 0, path);
	HomeLinkClientAssert(roomName.length > 0 || roomPicture.length > 0, path);
	if (!(roomId.length > 0)) {
		return;
	}
	
	if (!(roomName.length > 0 || roomPicture.length > 0)) {
		return;
	}
	
	NSMutableDictionary *params = [[NSMutableDictionary alloc] initWithCapacity:3];
	params[@"roomId"] = roomId;
	if (roomName.length > 0) {
		params[@"roomName"] = roomName;
	}
	
	if (roomPicture.length > 0) {
		params[@"roomPicture"] = roomPicture;
	}
	
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		if (finished) {
			finished(error ? NO : YES,error);
		}
	}];
	
}

- (void)createRoomWithHouseId:(NSString *)houseId
					 roomName:(NSString *)roomName
				  roomPicture:(NSString *)roomPicture
				 deviceIdList:(NSArray <NSString *> *)deviceIdList finished:(void(^)(BOOL success,NSError * __nullable error))finished {
	NSString *path = @"/homelink/room/create";
	HomeLinkClientAssert(houseId.length > 0, path);
	if (!(houseId.length > 0)) {
		return;
	}
	
	NSMutableDictionary *params = [[NSMutableDictionary alloc] initWithCapacity:4];
	params[@"houseId"] = houseId;
	params[@"roomName"] = roomName ?: [NSNull null];
	params[@"roomPicture"] = roomPicture ?: [NSNull null];
	params[@"deviceIdList"] = deviceIdList ?: [NSNull null];
	
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		if (finished) {
			finished(error ? NO : YES,error);
		}
	}];
	
}

- (void)deleteRoom:(NSString *)roomId
		   houseId:(NSString *)houseId
		  finished:(void(^)(BOOL success,NSError * __nullable error))finished {
	NSString *path = @"/homelink/room/delete";
	HomeLinkClientAssert(roomId.length > 0 && houseId.length > 0, path);
	if (!(roomId.length > 0) || !(houseId.length > 0)) {
		return;
	}

	NSMutableDictionary *params = [[NSMutableDictionary alloc] initWithCapacity:4];
	params[@"roomId"] = roomId;
	params[@"houseId"] = houseId;
	
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		if (finished) {
			finished(error ? NO : YES,error);
		}
	}];
}

- (void)wallpaperListWithFinished:(void(^)(NSArray<IMSHomeLinkWallpaperModel *> *models,NSError * __nullable error))finished {
	NSString *path = @"/homelink/room/default/picture/list";
	
	[[IMSHomeLinkApiClient sharedClient] requestWithPath:path version:@"1.0.0" params:@{} completoinHandler:^(id data, NSError *error) {
		NSArray *models;
		if ([data isKindOfClass:[NSArray class]]) {
			models = [MTLJSONAdapter modelsOfClass:IMSHomeLinkWallpaperModel.class fromJSONArray:data error:nil];
		}
		
		if (finished) {
			finished(models,error);
		}
	}];
}

- (void)houseDetail:(NSString *)houseId
		   finished:(void(^)(IMSHomelinkHouseModel *model,NSError * __nullable error))finished {
	NSString *path = @"/homelink/house/detail/get";
	HomeLinkClientAssert(houseId.length > 0, path);
	if (!(houseId.length > 0)) {
		return;
	}
	NSDictionary *params = @{@"houseId":houseId};
	
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		IMSHomelinkHouseModel *model;
		if (data) {
			model = [MTLJSONAdapter modelOfClass:IMSHomelinkHouseModel.class fromJSONDictionary:data error:nil];
		}
		
		if (finished) {
			finished(model,error);
		}
	}];
}

- (void)updateHouseDetail:(NSString *)houseId
				houseName:(NSString * __nullable)houseName
				  address:(IMSHouseAddressModel * __nullable)address
				 finished:(void(^)(BOOL success,NSError * __nullable error))finished {
	NSString *path = @"/homelink/house/detail/update";
	HomeLinkClientAssert(houseId.length > 0, path);
	if (!(houseId.length > 0)) {
		return;
	}
	
	NSMutableDictionary *params = @{@"houseId":houseId}.mutableCopy;
	if (houseName.length > 0) {
		params[@"houseName"] = houseName;
	}
	
	if (address) {
		NSDictionary *addressDict = [[IMSHomelinkHouseModel addressTransformer] reverseTransformedValue:address];
		NSMutableDictionary *tmp = addressDict.mutableCopy;
		[addressDict enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, NSString  *addr, BOOL * _Nonnull stop) {
			if (addr == (id)kCFNull) {
				[tmp removeObjectForKey:key];
			}
		}];
		if (tmp) {
			params[@"address"] = tmp;
		}
	}
	
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		if (finished) {
			finished(error ? NO : YES,error);
		}
	}];
	
}

- (void)transferHouse:(NSString *)houseId
		newIdentityId:(NSString *)newIdentityId
			 finished:(void(^)(BOOL success,NSError * __nullable error))finished {
	NSString *path = @"/homelink/house/transfer";
	HomeLinkClientAssert(houseId.length > 0, path);
	HomeLinkClientAssert(newIdentityId.length > 0, path);
	if (!(houseId.length > 0) || !(newIdentityId.length > 0)) {
		return;
	}
	
	NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
	params[@"houseId"] = houseId;
	params[@"newIdentityId"] = newIdentityId;
	
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		if (finished) {
			finished(error ? NO : YES,error);
		}
	}];
}

@end
