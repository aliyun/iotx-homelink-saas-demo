//
//  IMSHomeLinkApiClient+UserManager.m
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/28.
//

#import "IMSHomeLinkApiClient+UserManager.h"

@implementation IMSHomeLinkApiClient (UserManager)

/**
 基础的网络请求
 
 @param path 请求路径
 @param version 版本
 @param params 请求参数
 @param finished 回调
 */
- (void)requestWithPath:(NSString *)path
				version:(NSString *)version
				 params:(NSDictionary *)params
			   finished:(void(^)(id data,NSError * __nullable error))finished {
	[self requestWithPath:path version:version params:params completoinHandler:^(id data, NSError *error) {
		if (![data isKindOfClass:[NSDictionary class]]) {
			data = nil;
		}
		
		if (finished) {
			finished(data,error);
		}
	}];
}

- (void)memberListWithHouseId:(NSString *)houseId
					   pageNo:(NSUInteger)pageNo
					 pageSize:(NSUInteger)pageSize
					 finished:(void(^)(IMSHomeLinkUserListModel *model,NSError * __nullable error))finished {
	NSString *path = @"/homelink/member/list";
	HomeLinkClientAssert(houseId.length > 0, path);
	if (!(houseId.length > 0)) {
		return;
	}
	NSDictionary *params = @{@"houseId":houseId,
							 @"pageNo":@(pageNo),
							 @"pageSize":@(pageSize)
							 };
	
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		IMSHomeLinkUserListModel *model;
		if (data) {
			model = [MTLJSONAdapter modelOfClass:IMSHomeLinkUserListModel.class fromJSONDictionary:data error:nil];
		}
		
		if (finished) {
			finished(model,error);
		}
	}];
}

- (void)removeMembers:(NSArray <NSString *>*)identityIdList
			  houseId:(NSString *)houseId
			 finished:(void(^)(BOOL success,NSError * __nullable error))finished {
	NSString *path = @"/homelink/member/remove";
	HomeLinkClientAssert(houseId.length > 0, path);
	if (!(houseId.length > 0)) {
		return;
	}
	HomeLinkClientAssert(identityIdList.count > 0, path);
	if (!(identityIdList.count > 0)) {
		return;
	}
	
	NSDictionary *params = @{@"houseId":houseId,
							 @"identityIdList":identityIdList
							 };
	
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		if (finished) {
			finished(error ? NO : YES,error);
		}
	}];
}

- (void)updateMember:(NSString *)memberIdentityId
             houseId:(NSString *)houseId
            roomList:(NSArray *)roomList
          deviceList:(NSArray <IMSMemberUpdateModel *> *)deviceList
           sceneList:(NSArray <IMSMemberUpdateModel *> *)sceneList
            finished:(void(^)(BOOL success,NSError * __nullable error))finished {
	NSString *path = @"/homelink/member/update";
	HomeLinkClientAssert(houseId.length > 0, path);
	if (!(houseId.length > 0)) {
		return;
	}
	HomeLinkClientAssert(memberIdentityId.length > 0, path);
	if (!(memberIdentityId.length > 0)) {
		return;
	}
	
	NSMutableDictionary *params = @{@"houseId":houseId,
							 @"memberIdentityId":memberIdentityId
							 }.mutableCopy;
    NSArray *roomListDicts = [MTLJSONAdapter JSONArrayFromModels:roomList error:nil];
    NSArray *deviceListDicts = [MTLJSONAdapter JSONArrayFromModels:deviceList error:nil];
	NSArray *sceneListDicts = [MTLJSONAdapter JSONArrayFromModels:sceneList error:nil];
    if (roomListDicts) {
        params[@"roomList"] = roomListDicts;
    }
    if (deviceListDicts) {
		params[@"deviceList"] = deviceListDicts;
	}
	if (sceneListDicts) {
		params[@"sceneList"] = sceneListDicts;
	}
	
	[self requestWithPath:path version:@"1.0.3" params:params finished:^(id data, NSError * _Nullable error) {
		if (finished) {
			finished(error ? NO : YES,error);
		}
	}];
	
}

- (void)transferMemberManagerWithHouseId:(NSString *)houseId
						   newIdentityId:(NSString *)newIdentityId
								finished:(void(^)(BOOL success,NSError * __nullable error))finished {
	NSString *path = @"/homelink/member/transfer";
	HomeLinkClientAssert(houseId.length > 0, path);
	if (!(houseId.length > 0)) {
		return;
	}
	HomeLinkClientAssert(newIdentityId.length > 0, path);
	if (!(newIdentityId.length > 0)) {
		return;
	}
	
	NSDictionary *params = @{@"houseId":houseId,
									@"newIdentityId":newIdentityId
									};
	
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		if (finished) {
			finished(error ? NO : YES,error);
		}
	}];
}
@end
