//
//  IMSHomelinkRoomModel.h
//  IMSHomeLinkHouseApiClient
//
//  Created by 冯君骅 on 2018/6/5.
//

#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>
@interface IMSHomelinkRoomModel : MTLModel<MTLJSONSerializing>
@property (copy, nonatomic) NSString *houseId;
@property (copy, nonatomic) NSString *roomName;
@property (copy, nonatomic) NSString *roomId;
@property (strong, nonatomic) NSURL *roomPicture;
@property (assign, nonatomic) NSInteger deviceCount;
@property (strong, nonatomic) NSArray<NSString *> *deviceIdList;
@property (assign, nonatomic) BOOL fullDevicesControl;
@property (assign, nonatomic) NSInteger onLineDeviceCount;
@end
