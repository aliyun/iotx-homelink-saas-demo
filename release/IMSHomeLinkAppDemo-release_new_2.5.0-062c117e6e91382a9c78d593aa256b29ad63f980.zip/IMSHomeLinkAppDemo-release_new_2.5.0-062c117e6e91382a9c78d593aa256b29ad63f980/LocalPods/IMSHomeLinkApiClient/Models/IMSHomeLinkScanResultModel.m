//
//  IMSHomeLinkScanResultModel.m
//  IMSHomeLinkHouse
//
//  Created by 冯君骅 on 2018/6/7.
//

#import "IMSHomeLinkScanResultModel.h"

@implementation IMSHomeLinkScanResultModel
+ (NSDictionary *)JSONKeyPathsByPropertyKey {
	return @{@"qrCode":@"qrCode",
			 @"content":@"content"
			 };
}

+ (NSValueTransformer *)contentJSONTransformer {
	return [MTLJSONAdapter dictionaryTransformerWithModelClass:IMSHomeLinkScanResultMsgModel.class];
}

@end
