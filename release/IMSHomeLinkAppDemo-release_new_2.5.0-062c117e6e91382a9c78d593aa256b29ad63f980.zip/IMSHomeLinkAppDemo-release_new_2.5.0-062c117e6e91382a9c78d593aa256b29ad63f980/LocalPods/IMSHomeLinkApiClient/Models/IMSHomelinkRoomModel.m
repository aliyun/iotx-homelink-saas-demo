//
//  IMSHomelinkRoomModel.m
//  IMSHomeLinkHouseApiClient
//
//  Created by 冯君骅 on 2018/6/5.
//

#import "IMSHomelinkRoomModel.h"

@implementation IMSHomelinkRoomModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
	return @{@"houseId":@"houseId",
			 @"roomName":@"roomName",
			 @"roomId":@"roomId",
			 @"roomPicture":@"roomPicture",
			 @"deviceCount":@"deviceCount",
             @"fullDevicesControl":@"fullDevicesControl"
			 };
}

+ (NSValueTransformer *)roomPictureTransformer {
	return [NSValueTransformer valueTransformerForName:MTLURLValueTransformerName];
}

@end
