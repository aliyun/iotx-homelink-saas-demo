//
//  NSValueTransformer+IMSHomeLinkHouseAddition.h
//  IMSHomeLinkHouseApiClient
//
//  Created by 冯君骅 on 2018/6/4.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 二维码类型

 - IMSHomeLinkQRCodeTypeHouseDelivery: 交付家
 - IMSHomeLinkQRCodeTypeHouseShare: 分享家
 - IMSHomeLinkQRCodeTypeRoomShare: 分享房间
 - IMSHomeLinkQRCodeTypeSceneShare: 分享场景
 - IMSHomeLinkQRCodeTypeMerberAdd: 添加成员
 - IMSHomeLinkQRCodeTypeDeviceShare: 添加设备
 - IMSHomeLinkQRCodeTypeHouseTransfer: 转让家
 */
typedef NS_ENUM(NSUInteger,IMSHomeLinkQRCodeType){
	IMSHomeLinkQRCodeTypeHouseDelivery,
	IMSHomeLinkQRCodeTypeHouseShare,
	IMSHomeLinkQRCodeTypeRoomShare,
	IMSHomeLinkQRCodeTypeSceneShare,
	IMSHomeLinkQRCodeTypeMerberAdd,
	IMSHomeLinkQRCodeTypeDeviceShare,
	IMSHomeLinkQRCodeTypeHouseTransfer
};

/**
 壁纸类型

 - IMSWallpaperTypeRoom: 房间壁纸
 */
typedef NS_ENUM(NSUInteger, IMSWallpaperType){
	IMSWallpaperTypeHouse,
	IMSWallpaperTypeRoom
};

/**
 房间角色
 
 - IMSHomeLinkHouseRoleManager: 管理员
 - IMSHomeLinkHouseRoleMerber: 家庭成员
 */
typedef NS_ENUM(NSUInteger,IMSHomeLinkHouseRole){
	IMSHomeLinkHouseRoleManager,
	IMSHomeLinkHouseRoleMerber
};

@interface NSValueTransformer (IMSHomeLinkHouseAddition)
+ (NSValueTransformer *)ims_roleTypeTransformer;
+ (NSValueTransformer *)ims_qrCodeTypeTransformer;
+ (NSValueTransformer *)ims_wallpaperTypeTransformer;
@end
