//
//  IMSRoomSortModel.m
//  IMSHomeLinkHouse
//
//  Created by 冯君骅 on 2018/6/12.
//

#import "IMSRoomSortModel.h"

@implementation IMSRoomSortModel
- (instancetype)initWithRoomId:(NSString *)roomId
					 fromOrder:(NSUInteger)fromOrder
					   toOrder:(NSUInteger)toOrder {
	if (self = [super init]) {
		self.roomId = roomId;
		self.fromOrder = fromOrder;
		self.toOrder = toOrder;
	}
	return self;
}

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
	return @{@"roomId":@"roomId",
			 @"fromOrder":@"fromOrder",
			 @"toOrder":@"toOrder"
			 };
}
@end
