//
//  IMSHomelinkHouseModel.h
//  IMSHomeLinkHouseApiClient
//
//  Created by 冯君骅 on 2018/6/4.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>
#import <IMSHomeLinkApiClient/IMSHouseAddressModel.h>
#import <IMSHomeLinkApiClient/NSValueTransformer+IMSHomeLinkHouseAddition.h>
@interface IMSHomelinkHouseModel : MTLModel<MTLJSONSerializing>
// 房屋id
@property (copy, nonatomic) NSString *houseId;
// 房屋名字
@property (copy, nonatomic) NSString *houseName;
// 用户identityId
@property (copy, nonatomic) NSString *identityId;
// 用户角色
@property (assign, nonatomic) IMSHomeLinkHouseRole role;
// 房间数量
@property (assign, nonatomic) NSUInteger roomCount;
// 设备数量
@property (assign, nonatomic) NSUInteger deviceCount;
// 地址
@property (strong, nonatomic) IMSHouseAddressModel *address;

+ (NSValueTransformer *)roleTypeTransformer;
+ (NSValueTransformer *)addressTransformer;
@end
