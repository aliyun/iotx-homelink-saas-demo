//
//  IMSHomeLinkWallpaperModel.h
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/7.
//

#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>
#import <IMSHomeLinkApiClient/NSValueTransformer+IMSHomeLinkHouseAddition.h>
@interface IMSHomeLinkWallpaperModel : MTLModel<MTLJSONSerializing>
@property (assign, nonatomic) IMSWallpaperType type;
@property (strong, nonatomic) NSArray<NSURL *> *urls;
@end
