//
//  IMSHomeLinkDeviceListModel.m
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/8.
//

#import "IMSHomeLinkDeviceListModel.h"

@implementation IMSHomeLinkDeviceListModel
+ (NSDictionary *)JSONKeyPathsByPropertyKey {
	return @{@"total":@"total",
			 @"pageNo":@"pageNo",
			 @"pageSize":@"pageSize",
			 @"list":@"data"
			 };
}

+ (NSValueTransformer *)listJSONTransformer {
	return [MTLJSONAdapter arrayTransformerWithModelClass:IMSHomeLinkDeviceModel.class];
}

@end
