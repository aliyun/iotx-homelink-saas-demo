//
//  IMSHomeLinkScanResultModel.h
//  IMSHomeLinkHouse
//
//  Created by 冯君骅 on 2018/6/7.
//

#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>
#import <IMSHomeLinkApiClient/IMSHomeLinkScanResultMsgModel.h>
@interface IMSHomeLinkScanResultModel : MTLModel<MTLJSONSerializing>
@property (copy, nonatomic) NSString *qrCode;
@property (strong, nonatomic) IMSHomeLinkScanResultMsgModel *content;
@end
