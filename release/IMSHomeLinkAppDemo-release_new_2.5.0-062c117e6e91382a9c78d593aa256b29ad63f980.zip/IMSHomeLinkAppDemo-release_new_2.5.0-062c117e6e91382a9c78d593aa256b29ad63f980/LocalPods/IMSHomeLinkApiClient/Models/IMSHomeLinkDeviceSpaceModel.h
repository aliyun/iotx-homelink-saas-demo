//
//  IMSHomeLinkDeviceSpaceModel.h
//  IMSHomeLinkHouseApiClient
//
//  Created by 冯君骅 on 2018/6/8.
//

#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>

@interface IMSHomeLinkDeviceSpaceModel : MTLModel<MTLJSONSerializing>
@property (copy, nonatomic) NSString *spaceName;
@property (assign, nonatomic) NSInteger spaceOrder;
@property (copy, nonatomic) NSString *houseId;
@property (copy, nonatomic) NSString *spaceId;
@end
