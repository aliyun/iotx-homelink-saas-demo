//
//  IMSHomeLinkUser.h
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/28.
//

#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>
#import <IMSHomeLinkApiClient/NSValueTransformer+IMSHomeLinkHouseAddition.h>

@interface IMSHomeLinkUser : MTLModel <MTLJSONSerializing>
@property (copy, nonatomic) NSString *identityId;
@property (copy, nonatomic) NSString *memberName;
@property (assign, nonatomic) IMSHomeLinkHouseRole role;

@end
