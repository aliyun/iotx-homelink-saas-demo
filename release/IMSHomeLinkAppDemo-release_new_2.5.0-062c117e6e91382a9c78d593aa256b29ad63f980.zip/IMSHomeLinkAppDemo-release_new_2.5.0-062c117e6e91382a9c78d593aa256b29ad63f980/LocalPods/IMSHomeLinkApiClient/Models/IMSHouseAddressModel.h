//
//  IMSHouseAddressModel.h
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/28.
//

#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>
@interface IMSHouseAddressModel : MTLModel <MTLJSONSerializing>
// 国家
@property (copy, nonatomic) NSString *country;
// 省份
@property (copy, nonatomic) NSString *province;
// 城市
@property (copy, nonatomic) NSString *city;
// 地区
@property (copy, nonatomic) NSString *district;
// 详细地址
@property (copy, nonatomic) NSString *detail;
@end
