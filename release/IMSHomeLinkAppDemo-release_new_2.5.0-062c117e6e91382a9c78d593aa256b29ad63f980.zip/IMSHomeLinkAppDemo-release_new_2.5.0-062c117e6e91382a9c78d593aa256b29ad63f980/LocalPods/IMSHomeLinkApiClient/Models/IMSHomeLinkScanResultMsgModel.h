//
//  IMSHomeLinkScanResultMsgModel.h
//  IMSHomeLinkHouse
//
//  Created by 冯君骅 on 2018/6/11.
//

#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>

@class IMSHomeLinkScanRoomInfoModel;

@interface IMSHomeLinkScanResultMsgModel : MTLModel<MTLJSONSerializing>
@property (strong, nonatomic) NSArray<IMSHomeLinkScanRoomInfoModel *> *roomInfo;
@property (assign, nonatomic) NSInteger sceneCount;
@end

@interface IMSHomeLinkScanRoomInfoModel : MTLModel<MTLJSONSerializing>
@property (copy, nonatomic) NSString *roomName;
@property (assign, nonatomic) NSInteger deviceCount;
@end
