//
//  IMSHomeLinkSceneListModel.m
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/27.
//

#import "IMSHomeLinkSceneListModel.h"

@interface IMSHomeLinkSceneListModel ()
@property (strong, nonatomic) NSArray<IMSHomeLinkSceneModel *> *scenes;
@end

@implementation IMSHomeLinkSceneListModel
+ (NSDictionary *)JSONKeyPathsByPropertyKey {
	return @{@"total":@"total",
			 @"pageNo":@"pageNo",
			 @"pageSize":@"pageSize",
			 @"scenes":@"scenes",
			 @"list":@"data"
			 };
}

- (void)setScenes:(NSArray<IMSHomeLinkSceneModel *> *)scenes {
	_list = scenes;
}

+ (NSValueTransformer *)listJSONTransformer {
	return [MTLJSONAdapter arrayTransformerWithModelClass:IMSHomeLinkSceneModel.class];
}

+ (NSValueTransformer *)scenesJSONTransformer {
	return [MTLJSONAdapter arrayTransformerWithModelClass:IMSHomeLinkSceneModel.class];
}
@end
