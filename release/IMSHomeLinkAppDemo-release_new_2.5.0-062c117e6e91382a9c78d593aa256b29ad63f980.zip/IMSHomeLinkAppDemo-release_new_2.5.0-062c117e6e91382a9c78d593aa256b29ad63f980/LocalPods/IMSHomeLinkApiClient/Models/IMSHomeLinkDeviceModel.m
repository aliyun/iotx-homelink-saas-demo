//
//  IMSHomeLinkDeviceModel.m
//  IMSHomeLinkHouseApiClient
//
//  Created by 冯君骅 on 2018/6/8.
//

#import "IMSHomeLinkDeviceModel.h"

@implementation IMSHomeLinkDeviceModel
+ (NSDictionary *)JSONKeyPathsByPropertyKey {
	return @{@"identityId":@"identityId",
			 @"iotId":@"iotId",
			 @"productKey":@"productKey",
			 @"deviceName":@"deviceName",
			 @"productName":@"productName",
			 @"categoryImage":@"categoryImage",
			 @"netType":@"netType",
			 @"thingType":@"thingType",
			 @"status":@"status",
			 @"nodeType":@"nodeType",
			 @"owned":@"owned",
			 @"nickName":@"nickName",
			 @"gmtCreate":@"gmtCreate",
			 @"gmtModified":@"gmtModified",
			 @"roomInfo":@"roomInfo"
			 };
}

+ (NSValueTransformer *)JSONTransformerForKey:(NSString *)key {
	if ([key isEqualToString:@"categoryImage"]) {
		return [self categoryImageTransformer];
	} else if ([key isEqualToString:@"netType"]) {
		return [self netTypeTransformer];
	} else if ([key isEqualToString:@"thingType"]) {
		return [self thingTypeTransformer];
	} else if ([key isEqualToString:@"status"]) {
		return [self statusTransformer];
	} else if ([key isEqualToString:@"nodeType"]) {
		return [self nodeTypeTransformer];
	} else if ([key isEqualToString:@"owned"]) {
		return [self ownedTransformer];
	} else if ([key isEqualToString:@"gmtCreate"]) {
		return [self dateValueTransformer];
	} else if ([key isEqualToString:@"gmtModified"]) {
		return [self dateValueTransformer];
	} else if ([key isEqualToString:@"roomInfo"]) {
		return [self roomInfoTransformer];
	}
	return nil;
}

+ (NSValueTransformer *)netTypeTransformer {
	return [NSValueTransformer 	mtl_valueMappingTransformerWithDictionary:@{
			@(0): @(IMSDeviceNetTypeLORA),
			@(3): @(IMSDeviceNetTypeWIFI),
			@(4): @(IMSDeviceNetTypeZIGBEE),
			@(5): @(IMSDeviceNetTypeBT),
			@(6): @(IMSDeviceNetTypeCELLULAR),
			@(7): @(IMSDeviceNetTypeETHERNET),
			} defaultValue:@(IMSDeviceNetTypeWIFI) reverseDefaultValue:@(3)];
}

+ (NSValueTransformer *)ownedTransformer {
	return [NSValueTransformer 	mtl_valueMappingTransformerWithDictionary:@{
				@(1): @(IMSDeviceShareTypePersonal),
				@(0): @(IMSDeviceShareTypeShared),
				@(-1): @(IMSDeviceShareTypeDisable)
			} defaultValue:@(IMSDeviceShareTypeAll) reverseDefaultValue:[NSNull null]];
}

+ (NSValueTransformer *)thingTypeTransformer {
	return [NSValueTransformer mtl_valueMappingTransformerWithDictionary:@{
			   @"VIRTUAL": @(IMSDeviceThingTypeVirtual),
			   @"WEB": @(IMSDeviceThingTypeWeb),
			   @"APP": @(IMSDeviceThingTypeApp),
			   @"DEVICE": @(IMSDeviceThingTypeDevice)
			}];
}
+ (NSValueTransformer *)nodeTypeTransformer {
	return [NSValueTransformer mtl_valueMappingTransformerWithDictionary:@{
			   @"DEVICE": @(IMSDeviceNodeTypeDevice),
			   @"GATEWAY": @(IMSDeviceNodeTypeGateWay)
			} defaultValue:@(IMSDeviceNodeTypeAll) reverseDefaultValue:[NSNull null]];
}

+ (NSValueTransformer *)statusTransformer {
	return [NSValueTransformer 	mtl_valueMappingTransformerWithDictionary:@{
							@(1): @(IMSDeviceStatusOnlined),
							@(3): @(IMSDeviceStatusOffline),
							@(8): @(IMSDeviceStatusDisable),}
			 defaultValue:@(IMSDeviceStatusNormal) reverseDefaultValue:@(0)];
}

+ (NSValueTransformer *)categoryImageTransformer {
	return [NSValueTransformer valueTransformerForName:MTLURLValueTransformerName];
}

+ (NSValueTransformer *)roomInfoTransformer {
	return [MTLJSONAdapter dictionaryTransformerWithModelClass:IMSHomeLinkDeviceSpaceModel.class];
}

+ (NSValueTransformer *)dateValueTransformer {
	return [MTLValueTransformer transformerUsingForwardBlock:^id(NSNumber *timestamps, BOOL *success, NSError *__autoreleasing *error) {
		NSDate *date = [NSDate dateWithTimeIntervalSince1970:timestamps.integerValue / 1000];
		return date;
	} reverseBlock:^id(NSDate *date, BOOL *success, NSError *__autoreleasing *error) {
		return @([date timeIntervalSince1970]);
	}];
}

@end
