//
//  IMSHomelinkRoomListModel.m
//  IMSHomeLinkHouseApiClient
//
//  Created by 冯君骅 on 2018/6/5.
//

#import "IMSHomelinkRoomListModel.h"

@implementation IMSHomelinkRoomListModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
	return @{@"total":@"total",
			 @"pageNo":@"pageNo",
			 @"pageSize":@"pageSize",
			 @"list":@"data"};
	
}

+ (NSValueTransformer *)listJSONTransformer {
	return [MTLJSONAdapter arrayTransformerWithModelClass:IMSHomelinkRoomModel.class];
}

@end
