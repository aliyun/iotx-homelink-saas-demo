//
//  IMSHomeLinkUser.m
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/28.
//

#import "IMSHomeLinkUser.h"

@implementation IMSHomeLinkUser
+ (NSDictionary *)JSONKeyPathsByPropertyKey {
	return @{@"identityId":@"identityId",
			 @"memberName":@"memberName",
			 @"role":@"role"
			 };
}

+ (NSValueTransformer *)JSONTransformerForKey:(NSString *)key {
	if ([key isEqualToString:@"role"]) {
		return [self roleTypeTransformer];
	}
	return nil;
}

+ (NSValueTransformer *)roleTypeTransformer {
	return [NSValueTransformer ims_roleTypeTransformer];
}

@end
