//
//  IMSRoomSortModel.h
//  IMSHomeLinkHouse
//
//  Created by 冯君骅 on 2018/6/12.
//

#import <Foundation/Foundation.h>
#import <Mantle/mantle.h>
@interface IMSRoomSortModel : MTLModel<MTLJSONSerializing>

- (instancetype)initWithRoomId:(NSString *)roomId
					  fromOrder:(NSUInteger)fromOrder
						toOrder:(NSUInteger)toOrder;

@property (copy, nonatomic) NSString *roomId;
@property (assign, nonatomic) NSUInteger fromOrder;
@property (assign, nonatomic) NSUInteger toOrder;
@end
