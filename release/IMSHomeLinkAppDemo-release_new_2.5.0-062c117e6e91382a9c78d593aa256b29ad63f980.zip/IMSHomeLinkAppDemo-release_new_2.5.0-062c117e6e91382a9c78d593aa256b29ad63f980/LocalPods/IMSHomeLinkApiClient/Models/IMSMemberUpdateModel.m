//
//  IMSMemberUpdateModel.m
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/28.
//

#import "IMSMemberUpdateModel.h"

@implementation IMSMemberUpdateModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
	return @{@"iotId":@"iotId",
			 @"sceneId":@"sceneId",
			 @"roomId":@"roomId",
			 @"operation":@"operation"
			 };
}

+ (NSValueTransformer *)JSONTransformerForKey:(NSString *)key {
	if ([key isEqualToString:@"operation"]) {
		return [self operationTransformer];
	}
	return nil;
}

+ (NSValueTransformer *)operationTransformer {
	return [NSValueTransformer mtl_valueMappingTransformerWithDictionary:@{
				@(0): @(IMSMemberUpdateOperationRemove),
				@(1): @(IMSMemberUpdateOperationAdd)}
				defaultValue:@(IMSMemberUpdateOperationRemove) reverseDefaultValue:@(0)];
}


@end
