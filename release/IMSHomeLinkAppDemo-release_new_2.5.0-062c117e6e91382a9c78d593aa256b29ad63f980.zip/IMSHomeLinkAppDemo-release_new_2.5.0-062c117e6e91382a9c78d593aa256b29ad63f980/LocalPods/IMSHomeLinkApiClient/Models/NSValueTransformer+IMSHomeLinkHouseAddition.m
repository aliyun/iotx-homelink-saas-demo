//
//  NSValueTransformer+IMSHomeLinkHouseAddition.m
//  IMSHomeLinkHouseApiClient
//
//  Created by 冯君骅 on 2018/6/4.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "NSValueTransformer+IMSHomeLinkHouseAddition.h"
#import <Mantle/Mantle.h>

@implementation NSValueTransformer (IMSHomeLinkHouseAddition)

+ (NSValueTransformer *)ims_qrCodeTypeTransformer {
	return [NSValueTransformer mtl_valueMappingTransformerWithDictionary:@{
			   @"HOUSE_DELIVERY": @(IMSHomeLinkQRCodeTypeHouseDelivery),
			   @"HOUSE_SHARE": @(IMSHomeLinkQRCodeTypeHouseShare),
			   @"ROOM_SHARE": @(IMSHomeLinkQRCodeTypeRoomShare),
			   @"SCENE_SHARE": @(IMSHomeLinkQRCodeTypeSceneShare),
			   @"MEMBER_ADD": @(IMSHomeLinkQRCodeTypeMerberAdd),
			   @"DEVICE_SHARE": @(IMSHomeLinkQRCodeTypeDeviceShare),
			   @"HOUSE_TRANSFER": @(IMSHomeLinkQRCodeTypeHouseTransfer)
			   }];
}

+ (NSValueTransformer *)ims_wallpaperTypeTransformer {
	return [NSValueTransformer mtl_valueMappingTransformerWithDictionary:@{
			   @"ROOM_DEFAULT_PICTURE": @(IMSWallpaperTypeRoom),
			} defaultValue:@(IMSWallpaperTypeHouse) reverseDefaultValue:@"HOUSE_DEFAULT_PICTURE"];
}

+ (NSValueTransformer *)ims_roleTypeTransformer {
	return [NSValueTransformer mtl_valueMappingTransformerWithDictionary:@{
																		   @(1): @(IMSHomeLinkHouseRoleManager),
																		   @(2): @(IMSHomeLinkHouseRoleMerber)} defaultValue:@(IMSHomeLinkHouseRoleManager) reverseDefaultValue:@(1)];
}
@end
