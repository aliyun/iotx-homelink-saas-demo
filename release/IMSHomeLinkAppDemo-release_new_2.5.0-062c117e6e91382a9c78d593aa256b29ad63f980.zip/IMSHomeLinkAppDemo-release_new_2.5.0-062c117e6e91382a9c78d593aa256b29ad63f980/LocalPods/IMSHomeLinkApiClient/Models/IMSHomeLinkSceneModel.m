//
//  IMSHomeLinkSceneModel.m
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/27.
//

#import "IMSHomeLinkSceneModel.h"

@interface IMSHomeLinkSceneModel ()
// 场景id
@property (copy, nonatomic) NSString *tmpId;
@end

@implementation IMSHomeLinkSceneModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
	return @{
			 @"tmpId":@"id",
			 @"sceneId":@"sceneId",
			 @"name":@"name",
			 @"icon":@"icon",
			 @"desc":@"description",
			 @"status":@"status",
			 @"enable":@"enable",
			 @"createTime":@"createTime",
			 @"accessible":@"accessible"
			 };
}

- (void)setTmpId:(NSString *)tmpId {
	_sceneId = tmpId;
}

+ (NSValueTransformer *)JSONTransformerForKey:(NSString *)key {
	if ([key isEqualToString:@"status"]) {
		return [self statusTransformer];
	} else if ([key isEqualToString:@"icon"]) {
		return [self iconTransformer];
	}
	return nil;
}

+ (NSValueTransformer *)iconTransformer {
	return [NSValueTransformer valueTransformerForName:MTLURLValueTransformerName];
}

+ (NSValueTransformer *)statusTransformer {
	return [NSValueTransformer mtl_valueMappingTransformerWithDictionary:@{@(1):@(IMSHomeLinkSceneStatusNormal),@(2):@(IMSHomeLinkSceneStatusUnavaliable)}];
}

@end
