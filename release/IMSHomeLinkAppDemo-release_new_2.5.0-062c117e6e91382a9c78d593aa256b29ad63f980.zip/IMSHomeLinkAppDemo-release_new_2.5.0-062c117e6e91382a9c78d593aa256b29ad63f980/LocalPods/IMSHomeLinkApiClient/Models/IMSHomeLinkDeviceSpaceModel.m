//
//  IMSHomeLinkDeviceSpaceModel.m
//  IMSHomeLinkHouseApiClient
//
//  Created by 冯君骅 on 2018/6/8.
//

#import "IMSHomeLinkDeviceSpaceModel.h"

@implementation IMSHomeLinkDeviceSpaceModel
+ (NSDictionary *)JSONKeyPathsByPropertyKey {
	return @{@"spaceName":@"spaceName",
			 @"spaceOrder":@"spaceOrder",
			 @"houseId":@"houseId",
			 @"spaceId":@"spaceId"
			 };
}
@end
