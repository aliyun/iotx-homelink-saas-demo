//
//  IMSHomelinkHouseListModel.h
//  IMSHomeLinkHouseApiClient
//
//  Created by 冯君骅 on 2018/6/4.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>
#import <IMSHomeLinkApiClient/IMSHomelinkHouseModel.h>
@interface IMSHomelinkHouseListModel : MTLModel<MTLJSONSerializing>
@property (strong, nonatomic) NSArray<IMSHomelinkHouseModel *> *list;
@end
