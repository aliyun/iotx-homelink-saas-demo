//
//  IMSHomelinkHouseListModel.m
//  IMSHomeLinkHouseApiClient
//
//  Created by 冯君骅 on 2018/6/4.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSHomelinkHouseListModel.h"

@implementation IMSHomelinkHouseListModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
	return @{@"list":@"data"};
}

+ (NSValueTransformer *)listJSONTransformer {
	return [MTLJSONAdapter arrayTransformerWithModelClass:IMSHomelinkHouseModel.class];
}

@end
