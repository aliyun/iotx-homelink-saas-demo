//
//  IMSHouseAddressModel.m
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/28.
//

#import "IMSHouseAddressModel.h"

@implementation IMSHouseAddressModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
	return @{@"country":@"country",
			 @"province":@"province",
			 @"city":@"city",
			 @"district":@"district",
			 @"detail":@"detail"
			 };
}
@end
