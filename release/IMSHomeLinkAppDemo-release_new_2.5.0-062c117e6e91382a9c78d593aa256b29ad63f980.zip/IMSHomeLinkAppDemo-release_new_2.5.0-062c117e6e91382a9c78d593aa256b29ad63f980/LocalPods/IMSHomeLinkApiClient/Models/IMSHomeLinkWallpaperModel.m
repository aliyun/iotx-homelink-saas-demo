//
//  IMSHomeLinkWallpaperModel.m
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/7.
//

#import "IMSHomeLinkWallpaperModel.h"

@implementation IMSHomeLinkWallpaperModel
+ (NSDictionary *)JSONKeyPathsByPropertyKey {
	return @{@"type":@"type",
			 @"urls":@"urlList"
			 };
}

+ (NSValueTransformer *)urlsJSONTransformer {
	return [NSValueTransformer mtl_arrayMappingTransformerWithTransformer: [NSValueTransformer valueTransformerForName:MTLURLValueTransformerName]];
}

+ (NSValueTransformer *)typeJSONTransformer {
	return [NSValueTransformer ims_wallpaperTypeTransformer];
}


@end
