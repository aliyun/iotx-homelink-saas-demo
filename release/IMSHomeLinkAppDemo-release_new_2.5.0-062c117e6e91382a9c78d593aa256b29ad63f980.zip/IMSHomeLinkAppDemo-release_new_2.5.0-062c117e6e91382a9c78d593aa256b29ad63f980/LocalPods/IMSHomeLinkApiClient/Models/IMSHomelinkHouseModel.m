//
//  IMSHomelinkHouseModel.m
//  IMSHomeLinkHouseApiClient
//
//  Created by 冯君骅 on 2018/6/4.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSHomelinkHouseModel.h"

@implementation IMSHomelinkHouseModel
+ (NSDictionary *)JSONKeyPathsByPropertyKey {
	return @{@"houseId":@"houseId",
			 @"houseName":@"houseName",
			 @"identityId":@"identityId",
			 @"role":@"role",
			 @"roomCount":@"roomCount",
			 @"deviceCount":@"deviceCount",
			 @"address":@"address"
			 };
}

+ (NSValueTransformer *)JSONTransformerForKey:(NSString *)key {
	if ([key isEqualToString:@"role"]) {
		return [self roleTypeTransformer];
	} else if ([key isEqualToString:@"address"]) {
		return [self addressTransformer];
	}
	return nil;
}

+ (NSValueTransformer *)roleTypeTransformer {
	return [NSValueTransformer ims_roleTypeTransformer];
}

+ (NSValueTransformer *)addressTransformer {
	return [MTLJSONAdapter dictionaryTransformerWithModelClass:IMSHouseAddressModel.class];
}

@end
