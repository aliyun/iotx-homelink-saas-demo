//
//  IMSHomeLinkUserListModel.m
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/28.
//

#import "IMSHomeLinkUserListModel.h"

@implementation IMSHomeLinkUserListModel
+ (NSDictionary *)JSONKeyPathsByPropertyKey {
	return @{@"total":@"total",
			 @"pageNo":@"pageNo",
			 @"pageSize":@"pageSize",
			 @"list":@"data"
			 };
}

+ (NSValueTransformer *)listJSONTransformer {
	return [MTLJSONAdapter arrayTransformerWithModelClass:IMSHomeLinkUser.class];
}
@end
