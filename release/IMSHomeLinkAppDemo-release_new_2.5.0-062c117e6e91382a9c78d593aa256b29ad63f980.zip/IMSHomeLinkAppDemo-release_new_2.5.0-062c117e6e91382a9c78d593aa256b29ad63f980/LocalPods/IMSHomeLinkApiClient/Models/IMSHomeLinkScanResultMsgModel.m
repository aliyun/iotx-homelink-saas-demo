//
//  IMSHomeLinkScanResultMsgModel.m
//  IMSHomeLinkHouse
//
//  Created by 冯君骅 on 2018/6/11.
//

#import "IMSHomeLinkScanResultMsgModel.h"

@implementation IMSHomeLinkScanResultMsgModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
	return @{@"roomInfo":@"roomInfo",
			 @"sceneCount":@"sceneCount"};
}

+ (NSValueTransformer *)JSONTransformerForKey:(NSString *)key {
	if ([key isEqualToString:@"roomInfo"]) {
		return [self roomInfoTransformer];
	}
	return nil;
}

+ (NSValueTransformer *)roomInfoTransformer {
	return [MTLJSONAdapter arrayTransformerWithModelClass:IMSHomeLinkScanRoomInfoModel.class];
}

@end

@implementation IMSHomeLinkScanRoomInfoModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
	return @{@"roomName":@"roomName",
			 @"deviceCount":@"deviceCount"};
}

@end


