//
//  IMSMemberUpdateModel.h
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/28.
//

#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>

typedef NS_ENUM(NSUInteger,IMSMemberUpdateOperation){
	IMSMemberUpdateOperationRemove,
	IMSMemberUpdateOperationAdd
};

@interface IMSMemberUpdateModel : MTLModel <MTLJSONSerializing>
@property (copy, nonatomic) NSString *iotId;
@property (copy, nonatomic) NSString *sceneId;
@property (copy, nonatomic) NSString *roomId;
@property (assign, nonatomic) IMSMemberUpdateOperation operation;
@end
