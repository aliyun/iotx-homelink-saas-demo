//
//  IMSHomeLinkSceneModel.h
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/27.
//

#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>

/**
 cell的状态
 
 - IMSHomeLinkSceneStatusNormal: 普通状态
 - IMSHomeLinkSceneStatusUnavaliable: 被破坏
 */
typedef NS_ENUM(NSUInteger, IMSHomeLinkSceneStatus){
	IMSHomeLinkSceneStatusNormal = 1,
	IMSHomeLinkSceneStatusUnavaliable = 2
};

@interface IMSHomeLinkSceneModel : MTLModel <MTLJSONSerializing>
// 场景id
@property (copy, nonatomic) NSString *sceneId;
// 名称
@property (copy, nonatomic) NSString *name;
// 图标url
@property (strong, nonatomic) NSURL *icon;
// 描述
@property (copy, nonatomic) NSString *desc;
// 状态
@property (assign, nonatomic) IMSHomeLinkSceneStatus status;
// 场景开关状态（app上按钮）
@property (assign, nonatomic) BOOL enable;
// 创建时间戳
@property (nonatomic, assign) NSInteger createTime;
// 访问权限
@property (nonatomic, assign) BOOL accessible;
@end
