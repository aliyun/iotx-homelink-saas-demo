//
//  IMSHomelinkRoomListModel.h
//  IMSHomeLinkHouseApiClient
//
//  Created by 冯君骅 on 2018/6/5.
//

#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>
#import <IMSHomeLinkApiClient/IMSHomelinkRoomModel.h>
@interface IMSHomelinkRoomListModel : MTLModel<MTLJSONSerializing>
@property (assign, nonatomic) NSInteger total;
@property (assign, nonatomic) NSInteger pageNo;
@property (assign, nonatomic) NSInteger pageSize;
@property (strong, nonatomic) NSArray<IMSHomelinkRoomModel *> *list;
@end
