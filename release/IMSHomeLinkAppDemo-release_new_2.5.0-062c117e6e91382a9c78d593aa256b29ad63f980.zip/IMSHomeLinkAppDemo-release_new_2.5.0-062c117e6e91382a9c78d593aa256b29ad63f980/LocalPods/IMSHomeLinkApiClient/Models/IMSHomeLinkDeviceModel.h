//
//  IMSHomeLinkDeviceModel.h
//  IMSHomeLinkHouseApiClient
//
//  Created by 冯君骅 on 2018/6/8.
//

#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>
#import <IMSHomeLinkApiClient/IMSHomeLinkDeviceSpaceModel.h>

/**
 表示设备绑定类型
 
 - IMSDeviceShareTypePersonal: 用户拥有的设备
 - IMSDeviceShareTypeShared: 用户被分享的设备
 - IMSDeviceShareTypeDisable: 没有权限
 - IMSDeviceShareTypeAll: 所有设备
 */
typedef NS_ENUM(NSUInteger,IMSDeviceShareType){
	IMSDeviceShareTypePersonal,
	IMSDeviceShareTypeShared,
	IMSDeviceShareTypeDisable,
	IMSDeviceShareTypeAll
};

// 设备类型
typedef NS_ENUM(NSUInteger, IMSDeviceThingType){
	IMSDeviceThingTypeVirtual,
	IMSDeviceThingTypeWeb,
	IMSDeviceThingTypeApp,
	IMSDeviceThingTypeDevice,
	IMSDeviceThingTypeAll
};

// 设备节点类型
typedef NS_ENUM(NSUInteger, IMSDeviceNodeType){
	IMSDeviceNodeTypeDevice,
	IMSDeviceNodeTypeGateWay,
	IMSDeviceNodeTypeAll
};

/**
 设备状态
 
 - IMSDeviceStatusNormal: 未激活
 - IMSDeviceStatusOnlined: 在线
 - IMSDeviceStatusOffline: 离线
 - IMSDeviceStatusDisable: 无效
 */
typedef NS_ENUM(NSUInteger, IMSDeviceStatus) {
	IMSDeviceStatusNormal,
	IMSDeviceStatusOnlined,
	IMSDeviceStatusOffline,
	IMSDeviceStatusDisable
};

/**
 设备配网类型
 
 - IMSDeviceNetTypeLORA:
 - IMSDeviceNetTypeWIFI: WiFi
 - IMSDeviceNetTypeZIGBEE: 局域网
 - IMSDeviceNetTypeBT: 蓝牙
 - IMSDeviceNetTypeCELLULAR: 移动网络
 - IMSDeviceNetTypeETHERNET: 以太网
 */
typedef NS_ENUM(NSInteger, IMSDeviceNetType) {
	IMSDeviceNetTypeLORA = 0,
	IMSDeviceNetTypeWIFI = 3,
	IMSDeviceNetTypeZIGBEE = 4,
	IMSDeviceNetTypeBT = 5,
	IMSDeviceNetTypeCELLULAR = 6,
	IMSDeviceNetTypeETHERNET = 7,
};

@interface IMSHomeLinkDeviceModel : MTLModel<MTLJSONSerializing>
// 用户的identityId
@property (copy, nonatomic) NSString *identityId;
// 设备的iotId
@property (copy, nonatomic) NSString *iotId;
// 三元组之一，配网使用
@property (copy, nonatomic) NSString *productKey;
// 三元组之一，配网使用
@property (copy, nonatomic) NSString *deviceName;
// 设备产品名称
@property (copy, nonatomic) NSString *productName;
// 设备分类图片
@property (strong, nonatomic) NSURL *categoryImage;
// 设备配网类型
@property (assign, nonatomic) IMSDeviceNetType netType;
// 设备配网类型
@property (assign, nonatomic) IMSDeviceThingType thingType;
// 设备状态
@property (assign, nonatomic) IMSDeviceStatus status;
// 设备节点类型
@property (assign, nonatomic) IMSDeviceNodeType nodeType;
// 绑定类型
@property (assign, nonatomic) IMSDeviceShareType owned;
// 设备昵称
@property (copy, nonatomic) NSString *nickName;
// 创建时间
@property (strong, nonatomic) NSDate *gmtCreate;
// 修改时间
@property (strong, nonatomic) NSDate *gmtModified;
// 空间归属
@property (strong, nonatomic) IMSHomeLinkDeviceSpaceModel *roomInfo;

+ (NSValueTransformer *)netTypeTransformer;
+ (NSValueTransformer *)ownedTransformer;
+ (NSValueTransformer *)thingTypeTransformer;
+ (NSValueTransformer *)nodeTypeTransformer;
+ (NSValueTransformer *)statusTransformer;
+ (NSValueTransformer *)categoryImageTransformer;
+ (NSValueTransformer *)roomInfoTransformer;
+ (NSValueTransformer *)dateValueTransformer;
@end
