//
//  IMSHomeLinkApiClient+House.h
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/28.
//

#import <IMSHomeLinkApiClient/IMSHomeLinkApiClient.h>
#import <IMSHomeLinkApiClient/IMSHomelinkHouseListModel.h>
#import <IMSHomeLinkApiClient/IMSHomelinkRoomListModel.h>
#import <IMSHomeLinkApiClient/IMSRoomSortModel.h>
#import <IMSHomeLinkApiClient/IMSHomeLinkWallpaperModel.h>
NS_ASSUME_NONNULL_BEGIN

@interface IMSHomeLinkApiClient (House)

/**
 房屋列表
 
 @param pageNo 页码
 @param pageSize 每页item的数量
 @param finished 回调
 */
- (void)houseListWithPageNo:(NSUInteger)pageNo
				   pageSize:(NSUInteger)pageSize
				   finished:(void(^)(IMSHomelinkHouseListModel *model,NSError * __nullable error))finished;
/**
 获取房间权限列表（管理员查询某个特定家庭成员拥有房屋的房间权限列表）
 
 @param houseId 房屋ID
 @param memberIdentityId 待查询权限的用户id
 @param pageNo 页码
 @param pageSize 每页item的数量
 @param finished 回调
 */
- (void)roomJurisdictionListWithHouseId:(NSString *)houseId
                       memberIdentityId:(NSString *)memberIdentityId
                                 pageNo:(NSInteger )pageNo
                               pageSize:(NSInteger )pageSize
                               finished:(void(^)(IMSHomelinkRoomListModel *model,NSError * __nullable error))finished;

/**
 房间列表
 @param memberIdentityId 要查询的用户身份ID
 @param houseId 房屋id
 @param pageNo 页码
 @param pageSize 每页item的数量
 @param finished 回调
 */
- (void)roomListWithMemberIdentityId:(NSString * __nullable)memberIdentityId
							 HouseId:(NSString *)houseId
							  pageNo:(NSUInteger)pageNo
							pageSize:(NSUInteger)pageSize
							finished:(void(^)(IMSHomelinkRoomListModel *model,NSError * __nullable error))finished;

/**
 房间排序 （后续实现、本期不做）
 
 @param houseId 房屋id
 @param orderList 排序数据
 @param finished 回调
 */
- (void)sortRoomWithHouseId:(NSString *)houseId
				  orderList:(NSArray<IMSRoomSortModel *> *)orderList
				   finished:(void(^)(BOOL success,NSError * __nullable error))finished;


/**
 获取房间详情
 @param roomId 房间id
 @param houseId 房屋id
 @param finished 回调
 */
- (void)roomDetailWithRoomId:(NSString *)roomId
					 houseId:(NSString *)houseId
					finished:(void(^)(IMSHomelinkRoomModel *model,NSError * __nullable error))finished;

/**
 更新房间信息
 
 @param roomId 房间id
 @param roomName 房间名称
 @param roomPicture 房间壁纸
 @param finished 回调
 */
- (void)updateRoomInfoWithRoomId:(NSString *)roomId
						roomName:(NSString * __nullable)roomName
					 roomPicture:(NSString * __nullable)roomPicture
						finished:(void(^)(BOOL success,NSError * __nullable error))finished;

/**
 新建房间
 
 @param houseId 房屋id
 @param roomName 房间名称
 @param roomPicture 房间壁纸
 @param deviceIdList 设备列表id数组
 @param finished 回调
 */
- (void)createRoomWithHouseId:(NSString *)houseId
					 roomName:(NSString *)roomName
				  roomPicture:(NSString *)roomPicture
				 deviceIdList:(NSArray <NSString *> *)deviceIdList finished:(void(^)(BOOL success,NSError * __nullable error))finished;

/**
 删除房间
 
 @param roomId 房间id
 @param houseId 房屋id
 @param finished 回调
 */
- (void)deleteRoom:(NSString *)roomId
		   houseId:(NSString *)houseId
		  finished:(void(^)(BOOL success,NSError * __nullable error))finished;

/**
 房间壁纸列表
 
 @param finished 回调
 */
- (void)wallpaperListWithFinished:(void(^)(NSArray<IMSHomeLinkWallpaperModel *> *models,NSError * __nullable error))finished;


/**
 获取房屋详情

 @param houseId 房屋id
 @param finished 回调
 */
- (void)houseDetail:(NSString *)houseId
		   finished:(void(^)(IMSHomelinkHouseModel *model,NSError * __nullable error))finished;

/**
 修改房屋详情

 @param houseId 房屋ID
 @param houseName 房屋名称
 @param address 房屋地址
 @param finished 回调
 */
- (void)updateHouseDetail:(NSString *)houseId
				houseName:(NSString * __nullable)houseName
				  address:(IMSHouseAddressModel * __nullable)address
				 finished:(void(^)(BOOL success,NSError * __nullable error))finished;


/**
 转让家

 @param houseId 房屋ID
 @param newIdentityId 目标用户的身份ID
 @param finished 回调
 */
- (void)transferHouse:(NSString *)houseId
		newIdentityId:(NSString *)newIdentityId
			 finished:(void(^)(BOOL success,NSError * __nullable error))finished;

@end

NS_ASSUME_NONNULL_END
