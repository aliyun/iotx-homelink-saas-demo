//
//  IMSHomeLinkApiClient+Scene.h
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/27.
//

#import <IMSHomeLinkApiClient/IMSHomeLinkApiClient.h>
#import <IMSHomeLinkApiClient/IMSHomeLinkSceneListModel.h>
NS_ASSUME_NONNULL_BEGIN

@interface IMSHomeLinkApiClient (Scene)

/**
 查询场景列表

 @param groupId 全屋的houseId
 @param pageNo 页码
 @param pageSize 每页item的数量
 @param finished 回调
 */
- (void)sceneListWithGroupId:(NSString *)groupId
					  pageNo:(NSUInteger)pageNo
					pageSize:(NSUInteger)pageSize
					finished:(void(^)(IMSHomeLinkSceneListModel *model,NSError * __nullable error))finished;

/**
 房屋管理员查询成员场景权限列表
 
 @param groupId 房屋的Id
 @param targetIdentityId 待查询权限的用户id
 @param pageNo 页码
 @param pageSize 每页item的数量
 @param finished 回调
 */
- (void)memberSceneListWithGroupId:(NSString *)groupId
				  targetIdentityId:(NSString *)targetIdentityId
						    pageNo:(NSUInteger)pageNo
						  pageSize:(NSUInteger)pageSize
						  finished:(void(^)(IMSHomeLinkSceneListModel *model,NSError * __nullable error))finished;
@end

NS_ASSUME_NONNULL_END
