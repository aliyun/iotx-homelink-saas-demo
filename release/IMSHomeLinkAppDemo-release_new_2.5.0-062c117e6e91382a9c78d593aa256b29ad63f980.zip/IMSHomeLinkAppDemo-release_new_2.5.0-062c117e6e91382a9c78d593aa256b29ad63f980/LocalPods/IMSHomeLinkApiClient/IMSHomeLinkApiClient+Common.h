//
//  IMSHomeLinkApiClient+Common.h
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/28.
//

#import <IMSHomeLinkApiClient/IMSHomeLinkApiClient.h>
#import <IMSHomeLinkApiClient/NSValueTransformer+IMSHomeLinkHouseAddition.h>
#import <IMSHomeLinkApiClient/IMSHomeLinkScanResultModel.h>

NS_ASSUME_NONNULL_BEGIN
@interface IMSHomeLinkApiClient (Common)
/**
 生成二维码
 
 @param bizType 二维码类型
 @param houseIds 房屋id数组
 @param roomIds 房间id数组
 @param deviceIds 设备id数组
 @param sceneIds 场景id数组
 @param finished 回调
 */
- (void)generateQrcode:(IMSHomeLinkQRCodeType)bizType
			  houseIds:(NSArray <NSString *> * __nullable)houseIds
			   roomIds:(NSArray <NSString *> * __nullable)roomIds
			 deviceIds:(NSArray <NSString *> * __nullable)deviceIds
			  sceneIds:(NSArray <NSString *> * __nullable)sceneIds
			  finished:(void(^)(IMSHomeLinkScanResultModel *model,NSError * __nullable error))finished;

/**
 扫描二维码
 
 @param qrcode 二维码内容
 @param finished 回调
 */
- (void)scanQrcode:(NSString *)qrcode
		  finished:(void(^)(IMSHomeLinkScanResultModel *model,NSError * __nullable error))finished;
@end
NS_ASSUME_NONNULL_END
