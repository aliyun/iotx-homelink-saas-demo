//
//  IMSHomeLinkApiClient+Scene.m
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/27.
//

#import "IMSHomeLinkApiClient+Scene.h"

@implementation IMSHomeLinkApiClient (Scene)

/**
 基础的网络请求
 
 @param path 请求路径
 @param version 版本
 @param params 请求参数
 @param finished 回调
 */
- (void)requestWithPath:(NSString *)path
				version:(NSString *)version
				 params:(NSDictionary *)params
			   finished:(void(^)(id data,NSError * __nullable error))finished {
	[self requestWithPath:path version:version params:params completoinHandler:^(id data, NSError *error) {
		if (![data isKindOfClass:[NSDictionary class]]) {
			data = nil;
		}
		
		if (finished) {
			finished(data,error);
		}
	}];
}

- (void)sceneListWithGroupId:(NSString *)groupId
					  pageNo:(NSUInteger)pageNo
					pageSize:(NSUInteger)pageSize
					finished:(void(^)(IMSHomeLinkSceneListModel *model,NSError * __nullable error))finished {
	NSString *path = @"/scene/list/get";
	HomeLinkClientAssert(groupId.length > 0, path);
	if (!(groupId.length > 0)) {
		return;
	}
	
	NSMutableDictionary *params = [[NSMutableDictionary alloc] initWithCapacity:4];
	params[@"groupId"] = groupId;
	params[@"pageNo"] = @(pageNo);
	params[@"pageSize"] = @(pageSize);
	
	[self requestWithPath:path version:@"1.0.1" params:params finished:^(id data, NSError * _Nullable error) {
		IMSHomeLinkSceneListModel *model;
		if (data) {
			model = [MTLJSONAdapter modelOfClass:IMSHomeLinkSceneListModel.class fromJSONDictionary:data error:nil];
		}
		
		if (finished) {
			finished(model,error);
		}
	}];
}

- (void)memberSceneListWithGroupId:(NSString *)groupId
				  targetIdentityId:(NSString *)targetIdentityId
							pageNo:(NSUInteger)pageNo
						  pageSize:(NSUInteger)pageSize
						  finished:(void(^)(IMSHomeLinkSceneListModel *model,NSError * __nullable error))finished {
	NSString *path = @"/scene/member/binding/list";
	HomeLinkClientAssert(groupId.length > 0, path);
	HomeLinkClientAssert(targetIdentityId.length > 0, path);
	if (!(groupId.length > 0) || !(targetIdentityId.length > 0)) {
		return;
	}
	NSMutableDictionary *params = [[NSMutableDictionary alloc] initWithCapacity:4];
	params[@"groupId"] = groupId;
	params[@"targetIdentityId"] = targetIdentityId;
	params[@"pageNo"] = @(pageNo);
	params[@"pageSize"] = @(pageSize);
	[self requestWithPath:path version:@"1.0.0" params:params finished:^(id data, NSError * _Nullable error) {
		IMSHomeLinkSceneListModel *model;
		if (data) {
			model = [MTLJSONAdapter modelOfClass:IMSHomeLinkSceneListModel.class fromJSONDictionary:data error:nil];
		}
		if (finished) {
			finished(model,error);
		}
	}];
}
@end
