//
//  IMSHomeLinkApiClient+Common.m
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/28.
//

#import "IMSHomeLinkApiClient+Common.h"

@implementation IMSHomeLinkApiClient (Common)

/**
 基础的网络请求
 
 @param path 请求路径
 @param version 版本
 @param params 请求参数
 @param finished 回调
 */
- (void)requestWithPath:(NSString *)path
				version:(NSString *)version
				 params:(NSDictionary *)params
			   finished:(void(^)(id data,NSError * __nullable error))finished {
	[self requestWithPath:path version:version params:params completoinHandler:^(id data, NSError *error) {
		if (![data isKindOfClass:[NSDictionary class]]) {
			data = nil;
		}
		
		if (finished) {
			finished(data,error);
		}
	}];
}

- (void)generateQrcode:(IMSHomeLinkQRCodeType)bizType
			  houseIds:(NSArray <NSString *> * __nullable)houseIds
			   roomIds:(NSArray <NSString *> * __nullable)roomIds
			 deviceIds:(NSArray <NSString *> * __nullable)deviceIds
			  sceneIds:(NSArray <NSString *> * __nullable)sceneIds
			  finished:(void(^)(IMSHomeLinkScanResultModel *model,NSError * __nullable error))finished {
	NSString *path = @"/homelink/share/generate/qrcode";
	NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
	NSString *bizTypeStr = [[NSValueTransformer ims_qrCodeTypeTransformer] reverseTransformedValue:@(bizType)];
	params[@"bizType"] = bizTypeStr ?: [NSNull null];
	if (houseIds.count > 0) {
		params[@"houseIds"] = houseIds;
	}
	if (roomIds.count > 0) {
		params[@"roomIds"] = roomIds;
	}
	if (deviceIds.count > 0) {
		params[@"deviceIds"] = deviceIds;
	}
	if (sceneIds.count > 0) {
		params[@"sceneIds"] = sceneIds;
	}
	[self requestWithPath:path version:@"1.0.3" params:params finished:^(id data, NSError * _Nullable error) {
		IMSHomeLinkScanResultModel *model;
		if (data) {
			model = [MTLJSONAdapter modelOfClass:IMSHomeLinkScanResultModel.class fromJSONDictionary:data error:nil];
		}
		if (finished) {
			finished(model,error);
		}
	}];
}

- (void)scanQrcode:(NSString *)qrcode
		  finished:(void(^)(IMSHomeLinkScanResultModel *model,NSError * __nullable error))finished {
	NSString *path = @"/homelink/share/parse/qrCode";
	NSDictionary *params = @{
							 @"qrCode":(qrcode ?: [NSNull null])
							 };
	
	[self requestWithPath:path version:@"1.0.3" params:params finished:^(id data, NSError * _Nullable error) {
		if (finished) {
			finished(nil,error);
		}
	}];
}
@end
