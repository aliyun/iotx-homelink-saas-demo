//
//  IMSHomeLinkApiClient+Device.h
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/27.
//

#import "IMSHomeLinkApiClient.h"
#import <IMSHomeLinkApiClient/IMSHomeLinkDeviceListModel.h>

NS_ASSUME_NONNULL_BEGIN
@interface IMSHomeLinkApiClient (Device)

/**
 常用设备列表
 
 @param houseId 房屋id
 @param pageNo 页码
 @param pageSize 每页item的数量
 @param finished 回调
 */
- (void)commonDevicesWithHouseId:(NSString *)houseId
						  pageNo:(NSUInteger)pageNo
						pageSize:(NSUInteger)pageSize
						finished:(void(^)(IMSHomeLinkDeviceListModel *model,NSError * __nullable error))finished;

/**
 更新常用设备列表
 
 @param houseId 房屋id
 @param iotIdList 设备id列表
 @param finished 回调
 */
- (void)updateCommonDevicesWithHouseId:(NSString *)houseId
							 iotIdList:(NSArray<NSString *> * __nullable)iotIdList
							  finished:(void(^)(BOOL success,NSError * __nullable error))finished;

/**
 转移设备
 
 @param roomId 目的房间id
 @param iotIdList 设备列表
 @param finished 回调
 */
- (void)changeDeviceToRoom:(NSString *)roomId
				 iotIdList:(NSArray <NSString *> *)iotIdList
				  finished:(void(^)(BOOL success,NSError * __nullable error))finished;

/**
 房屋设备列表
 
 @param houseId 房间id
 @param nodeType 设备NodeType
 @param pageNo 页码
 @param pageSize 每页item的数量
 @param finished 回调
 */
- (void)houseDeviceListWithHouseId:(NSString *)houseId
						  nodeType:(IMSDeviceNodeType)nodeType
							pageNo:(NSUInteger)pageNo
						  pageSize:(NSUInteger)pageSize
						  finished:(void(^)(IMSHomeLinkDeviceListModel *model,NSError * __nullable error))finished;

/**
 房间设备列表
 
 @param roomId 房间id
 @param nodeType 设备NodeType
 @param pageNo 页码
 @param pageSize 每页item的数量
 @param finished 回调
 */
- (void)roomDeviceListWithRoomId:(NSString *)roomId
						nodeType:(IMSDeviceNodeType)nodeType
						  pageNo:(NSUInteger)pageNo
						pageSize:(NSUInteger)pageSize
						finished:(void(^)(IMSHomeLinkDeviceListModel *model,NSError * __nullable error))finished;


/**
 管理员查看成员在房间下设备列表

 @param roomId 房间ID
 @param memberIdentityId 成员用户ID
 @param nodeType 设备NodeType
 @param pageNo 页码
 @param pageSize 每页item的数量
 @param finished 回调
 */
- (void)memberDeviceListWithRoomId:(NSString *)roomId
				  memberIdentityId:(NSString *)memberIdentityId
						  nodeType:(IMSDeviceNodeType)nodeType
							pageNo:(NSUInteger)pageNo
						  pageSize:(NSUInteger)pageSize
						  finished:(void(^)(IMSHomeLinkDeviceListModel *model,NSError * __nullable error))finished;

@end

NS_ASSUME_NONNULL_END
