//
//  IMSHomeLinkApiClient.m
//  IMSHomeLinkApiClient
//
//  Created by 冯君骅 on 2018/6/1.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSHomeLinkApiClient.h"

#import <IMSApiClient/IMSApiClient.h>
#import <IMSAuthentication/IMSAuthentication.h>
#import <IMSAccount/IMSAccountService.h>

NSString *const InternalServerErrorDomain = @"InternalServerErrorDomain";

@implementation IMSHomeLinkApiClient
+ (instancetype)sharedClient {
	static IMSHomeLinkApiClient *client = nil;
	
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		client = [[[self class] alloc] init];
	});
	
	return client;
}


- (void)requestWithPath:(NSString *)path
				version:(NSString *)version
				 params:(NSDictionary *)params
	  completoinHandler:(void (^)(id data, NSError *error))completion {
	return [self requestWithPath:path
						 version:version
						  params:params
					  needsLogin:YES
			   completoinHandler:completion];
}

- (void)requestWithPath:(NSString *)path
				version:(NSString *)version
				 params:(NSDictionary *)params
			 needsLogin:(BOOL)needsLogin
	  completoinHandler:(void (^)(id data, NSError *error))completion {
	IMSIoTRequestBuilder *builder = [[IMSIoTRequestBuilder alloc] initWithPath:path
																	apiVersion:version
																		params:params];
	if (needsLogin) {
		[builder setAuthenticationType:IMSAuthenticationTypeIoT];
	}
	
	[builder setScheme:@"https://"];
	
	IMSRequest *request = [[builder setAuthenticationType:IMSAuthenticationTypeIoT] build];
	[IMSRequestClient asyncSendRequest:request responseHandler:^(NSError *error, IMSResponse *response) {
		// 返回请求过期后，需要重新登录；重新登录后重新初始化主框架，不需要重新请求
		if (response.code == 401) {
			if (NSClassFromString(@"IMSAccountService") != nil) {
				// 先退出登录
				if ([[IMSAccountService sharedService] isLogin]) {
					[[IMSAccountService sharedService] logout];
				}
				
				return;
			}
		}
		
		if (error || response.code != 200) {
			
			NSError *underlyingError = error.userInfo[NSUnderlyingErrorKey];
			NSString *localizedDesc;
			switch (underlyingError.code) {
				case kCFURLErrorTimedOut:
					localizedDesc = @"请求超时";
					break;
				case kCFURLErrorNotConnectedToInternet:
					localizedDesc = @"未连接到网络";
					break;
				case kCFURLErrorBadServerResponse:
					localizedDesc = @"未连接到服务";
					break;
				default:
					break;
			}
			
			if (localizedDesc.length > 0) {
				NSDictionary *info = @{
									   NSLocalizedDescriptionKey : localizedDesc ? : [NSNull null]
									   };
				error = [NSError errorWithDomain:InternalServerErrorDomain code:underlyingError.code userInfo:info];
			} else {
				NSDictionary *info = @{
									   @"message" : response.message ? : @"",
									   NSLocalizedDescriptionKey : response.localizedMsg.length > 0 ? response.localizedMsg : @"未知错误",
									   @"rawData" : response ? : [NSNull null]
									   };
				error = [NSError errorWithDomain:InternalServerErrorDomain code:response.code userInfo:info];
			}
		}
		
		id data = response.data;
		
		if (!data || data == (id)kCFNull) {
			data = nil;
		}
		
		if (completion) {
			completion(data, error);
		}
	}];
}
@end
