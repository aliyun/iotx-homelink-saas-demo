//
//  IMSOpenAccountBase.h
//  IMSOpenAccountBase
//
//  Created by chuntao.wang1 on 2018/5/9.
//  Copyright © 2018年 chuntao.wang1. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for IMSOpenAccountBase.
FOUNDATION_EXPORT double IMSOpenAccountBaseVersionNumber;

//! Project version string for IMSOpenAccountBase.
FOUNDATION_EXPORT const unsigned char IMSOpenAccountBaseVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IMSOpenAccountBase/PublicHeader.h>


#import <IMSOpenAccountBase/IMSOpenAccountBaseConstant.h>

#import <IMSOpenAccountBase/IMSAccountManager.h>
#import <ALBBOpenAccountCloud/ALBBOpenAccountSDK.h>

#if __has_include(<IMSOpenAccountBase/IMSOpenAccount.h>)
#import <IMSOpenAccountBase/IMSOpenAccount.h>
#endif

#import <IMSOpenAccountBase/IMSRegionManager.h>

#import <IMSOpenAccountBase/IMSOpenAccountUICustom.h>


