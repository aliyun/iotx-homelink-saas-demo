//
//  IMSAccountManager.m
//  IMSOpenAccount
//
//  Created by dujin on 2018/4/26.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSAccountManager.h"
#import <IMSAccount/IMSAccount.h>
#import <ALBBOpenAccountCloud/ALBBOpenAccountSDK.h>
#import <IMSAuthentication/IMSAuthentication.h>
#import <IMSApiClient/IMSDefine.h>
#import <IMSApiClient/IMSConfiguration.h>

#import "IMSOpenAccountUICustom.h"

#if __has_include(<IMSTemplateConfig/IMSTemplateConfig.h>)
#import <IMSTemplateConfig/IMSTemplateConfig.h>
#endif

#if __has_include(<IMSOpenAccountBase/IMSOpenAccount.h>)
#import <IMSOpenAccountBase/IMSOpenAccount.h>
#endif

#define IMSKeyWindow [UIApplication sharedApplication].delegate.window

@interface IMSAccountManager ()<IMSAccountUICustomProtocol>

@property (nonatomic, strong) UINavigationController *regionNaviController;
@property (nonatomic, assign) BOOL isHiddenLocalize;

@end

@implementation IMSAccountManager

+ (instancetype)sharedManager {
    static id instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        //配置化开关
		[IMSConfiguration sharedInstance].language = @"zh-CN";
        
    }
    return self;
}

- (void)closeLocalize {
    self.isHiddenLocalize = YES;
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"IMSOpenAccountHiddenLocalize"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [IMSConfiguration sharedInstance].language = @"zh-CN";
}

- (void)configureApiClientAndIot {
#if __has_include(<IMSOpenAccountBase/IMSOpenAccount.h>)
    //OA初始化
    IMSOpenAccount *openAccount = [IMSOpenAccount sharedInstance];
    [IMSAccountService sharedService].sessionProvider = openAccount;
    [IMSAccountService sharedService].accountProvider = openAccount;
#endif

    //iot用户统一身份认证
    IMSAccountService *accountService = [IMSAccountService sharedService];
    [IMSCredentialManager initWithAccountProtocol:accountService.sessionProvider];
    IMSIoTAuthentication *iotAuthDelegate = [[IMSIoTAuthentication alloc] initWithCredentialManager:IMSCredentialManager.sharedManager];
    [IMSRequestClient registerDelegate:iotAuthDelegate forAuthenticationType:IMSAuthenticationTypeIoT];
}

- (void)resetRootViewControllerWithLoginSuccess:(void(^)(UIViewController *viewController))success {
    [[NSNotificationCenter defaultCenter] addObserverForName:ALBBOpenAccountNotificationUserLoggedIn object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification * _Nonnull note) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"IMSNotificationAccountLogin" object:nil];
        success([self getCurrentVC]);
    }];
    
    [[NSNotificationCenter defaultCenter] addObserverForName:ALBBOpenAccountNotificationUserLoggedOut object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification * _Nonnull note) {
        [self logoutJump];
    }];
    
    if ([[IMSAccountService sharedService] isLogin]) {
        success([self getCurrentVC]);
    } else {
        [self logoutJump];
    }
}
    
- (void)pushOpenAccountLoginControllerWithNavigationController:(UINavigationController *)navigationController {
    if (navigationController == nil) {
        navigationController = [self getCurrentVC].navigationController;
    }
    
     [[IMSOpenAccountUICustom sharedInstance] pushOpenAccountLoginControllerWithNavigationController:navigationController];
}

- (void)pushCountryCodeViewControllerWithNavigationController:(UINavigationController *)navigationController isEasyStyle:(BOOL)isEasyStyle{
    [IMSOpenAccountUICustom sharedInstance].delegate = self;
    [[IMSOpenAccountUICustom sharedInstance] pushCountryCodeViewControllerWithNavigationController:navigationController isEasyStyle:isEasyStyle];
}

#pragma mark - IMSAccountUICustomProtocol

- (void)ims_countryCodeChooseCode:(NSString *)code {
    if ([self.delegate respondsToSelector:@selector(ims_currentSelectCode:)]) {
        [self.delegate ims_currentSelectCode:code];
    }
}

#pragma mark - Private

- (void)logoutJump {
    UINavigationController *navi = [[UINavigationController alloc] init];
    IMSKeyWindow.rootViewController = navi;
	[[IMSOpenAccountUICustom sharedInstance] pushOpenAccountLoginControllerWithNavigationController:navi];
}

- (UIViewController *)getCurrentVC {
    UIViewController *result = nil;
    
    UIWindow *window = [[UIApplication sharedApplication] keyWindow];
    if (window.windowLevel != UIWindowLevelNormal) {
        NSArray *windows = [[UIApplication sharedApplication] windows];
        for (UIWindow *temp in windows) {
            if (temp.windowLevel == UIWindowLevelNormal) {
                window = temp;
                break;
            }
        }
    }
    
    result = window.rootViewController;
    while (result.presentedViewController) {
        result = result.presentedViewController;
    }
    
    if ([result isKindOfClass:[UITabBarController class]]) {
        result = [(UITabBarController *)result selectedViewController];
    }
    
    if ([result isKindOfClass:[UINavigationController class]]) {
        result = [(UINavigationController *)result visibleViewController];
    }
    return result;
}


@end
