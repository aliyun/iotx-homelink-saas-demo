//
//  IMSOpenAccountHeaderView.h
//  IMSAccountDemo
//
//  Created by chuntao.wang1 on 2018/4/12.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^IMSOpenAccountHeaderViewEventCallback)(void);

@interface IMSOpenAccountHeaderView : UIView

//返回按钮
@property (nonatomic, strong) UIButton *backButton;
//标题
@property (nonatomic, strong) UILabel *titleLabel;
//背景图片
@property (nonatomic, strong) UIImageView *backgroundImageView;

//返回回调
@property (nonatomic, strong) IMSOpenAccountHeaderViewEventCallback backButtonBlock;

@end
