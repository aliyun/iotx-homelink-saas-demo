//
//  IMSOpenAccountHeaderView.m
//  IMSAccountDemo
//
//  Created by chuntao.wang1 on 2018/4/12.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSOpenAccountHeaderView.h"

#import <Masonry/Masonry.h>
#import <IMSCategory/IMSCategory.h>

#import "UIImage+OpenAccountBaseBundle.h"
#import "IMSOpenAccountBase.h"
#import "UIColor+IMSOpenAccountColorExtension.h"

#if __has_include(<IMSTemplateConfig/IMSTemplateConfig.h>)
#import <IMSTemplateConfig/IMSTemplateConfig.h>
#endif

@interface IMSOpenAccountHeaderView ()

@end

@implementation IMSOpenAccountHeaderView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setupSubviews];
    }
    return self;
}

#pragma mark - Layout

- (void)setupSubviews {
    [self addSubview:self.backgroundImageView];
    [self.backgroundImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
    }];
    
    [self addSubview:self.backButton];
    [self.backButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(-3);
        make.width.height.mas_offset(40);
        make.centerY.equalTo(self.mas_centerY);
    }];
    
    [self addSubview:self.titleLabel];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(30);
        make.centerY.equalTo(self.mas_centerY);
        make.right.equalTo(self).offset(-5);
    }];
}

#pragma mark - Private

- (IBAction)clickBackButton:(id)sender {
    if (self.backButtonBlock) {
        self.backButtonBlock();
    }
}

#pragma mark - Setter

- (UIImageView *)backgroundImageView {
    if (!_backgroundImageView) {
        _backgroundImageView = [UIImageView new];
        UIImage *image = [UIImage ims_bundleImageNamed:@"Account_HeaderBackground"];
        _backgroundImageView.image = [UIImage ims_imageCompress:image toSize:CGSizeMake([UIScreen mainScreen].bounds.size.width, 180)];
        //只要一次判断
        if (![[NSUserDefaults standardUserDefaults] objectForKey:@"IMS_OPENACCOUNT_HEADER_STATE_STYLE_IS_FIRST"]) {
            //获取图片的灰度判断状态栏的颜色
            BOOL result = [UIColor judgeColorIsNearWhiteColorWithImage:_backgroundImageView.image];
            [[NSUserDefaults standardUserDefaults] setBool:result forKey:@"IMS_OPENACCOUNT_HEADER_STATE_STYLE"];
            [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"IMS_OPENACCOUNT_HEADER_STATE_STYLE_IS_FIRST"];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
    }
    return _backgroundImageView;
}

- (UIButton *)backButton {
    if (!_backButton) {
        _backButton = [UIButton buttonWithType:UIButtonTypeCustom];
        UIImage *image = [UIImage ims_bundleImageNamed:@"Account_NaviBack"];
        [_backButton setImage:image forState:UIControlStateNormal];
        [_backButton addTarget:self action:@selector(clickBackButton:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _backButton;
}

- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [UILabel new];
        _titleLabel.numberOfLines = 0;
        _titleLabel.font = [UIFont ims_semiboldFontOfSize:30.f];
#if __has_include(<IMSTemplateConfig/IMSTemplateConfig.h>)
        IMSTemplateConfig *config = [[IMSTemplateConfig alloc] initWithModule:@"IMSOpenAccountBase"];
        _titleLabel.textColor = [config colorForKey:@"OA_header_title_color"];
#else
        _titleLabel.textColor = [UIColor whiteColor];
#endif
        _titleLabel.userInteractionEnabled = YES;
        UITapGestureRecognizer *tapGesturRecognizer=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickBackButton:)];
        [_titleLabel addGestureRecognizer:tapGesturRecognizer];

    }
    return _titleLabel;
}
@end
