//
//  UIImage+OpenAccountBaseBundle.h
//  IMSLife
//
//  Created by dujin on 2018/4/12.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (OpenAccountBaseBundle)


/**
 获取bundle图片

 @param name 图片名称
 @return 图片
 */
+ (UIImage *)ims_bundleImageNamed:(NSString *)name;

@end
