//
//  IMSRegionManager.m
//  IMSLife
//
//  Created by dujin on 2018/4/17.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSRegionManager.h"

NSString * const IMSOpenAccountRegionKey = @"IMSOpenAccountRegionKey";
NSString * const IMSOpenAccountRegionValueChina = @"IMSOpenAccountRegionValueChina";
NSString * const IMSOpenAccountRegionValueSingapore = @"IMSOpenAccountRegionValueSingapore";

NSString * const IMSOpenAccountCountryModel = @"IMSOpenAccountCountryModel";

@implementation IMSRegionManager

+ (IMSOpenAccountRegion)getRegion {
    return [IMSRegionManager stringToRegion:[[NSUserDefaults standardUserDefaults] valueForKey:IMSOpenAccountRegionKey]];
}

+ (void)setRegion:(IMSOpenAccountRegion)region {
    NSString *value = [IMSRegionManager regionToString:region];
    [[NSUserDefaults standardUserDefaults] setValue:value ? : @"" forKey:IMSOpenAccountRegionKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

#pragma mark - Convert

+ (IMSOpenAccountRegion)stringToRegion:(NSString *)value {
    if ([value isEqualToString:IMSOpenAccountRegionValueChina]) {
        return IMSOpenAccountRegionChina;
    } else if ([value isEqualToString:IMSOpenAccountRegionValueSingapore]) {
        return IMSOpenAccountRegionSingapore;
    }
    return IMSOpenAccountRegionNone;
}

+ (NSString *)regionToString:(IMSOpenAccountRegion)region {
    switch (region) {
        case IMSOpenAccountRegionChina:
            return IMSOpenAccountRegionValueChina;
        case IMSOpenAccountRegionSingapore:
            return IMSOpenAccountRegionValueSingapore;
        default:
            return nil;
    }
    return nil;
}

@end
