//
//  IMSOpenAccountUICustom.m
//  IMSLife
//
//  Created by chuntao.wang1 on 2018/4/11.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSOpenAccountUICustom.h"

#import <UIKit/UIKit.h>
#import <IMSHUD/UIViewController+HUD.h>
#import <IMSAccount/IMSAccountService.h>
#import <ALBBOpenAccountCloud/ALBBOpenAccountSDK.h>
#import <Masonry/Masonry.h>

#import "IMSOpenAccountHeaderView.h"
#import "IMSRegionManager.h"

#import <IMSCategory/IMSCategory.h>
#import "IMSOpenAccountBaseConstant.h"
#import "NSBundle+OpenAccountBase.h"
#import "UIImage+OpenAccountBaseBundle.h"
#import "IMSOpenAccountBase.h"

#if __has_include(<IMSTemplateConfig/IMSTemplateConfig.h>)
#import <IMSTemplateConfig/IMSTemplateConfig.h>
#endif

@interface IMSOpenAccountUICustom() <
ALBBOpenAccountLoginViewDelegate,
ALBBOpenAccountRegisterViewDelegate,
ALBBOpenAccountSetPwdViewDelegate,
ALBBOpenAccountResetPwdViewDelegate,
ALBBOpenAccountFindPwdViewDelegate,
ALBBOpenAccountCountryCodeViewDelegate,
ALBBOpenAccountPhonePrefixDelegate,
UIGestureRecognizerDelegate>

@property (nonatomic, strong) UIImage *headerImage;
@property (nonatomic, strong) UINavigationController *navigationController;
@property (nonatomic, assign) BOOL isHiddenLocalize;
@property (nonatomic, assign) BOOL pushResetPwd;
@property (nonatomic, assign) BOOL resetPwdSuccess;
@property (nonatomic, strong) UIColor *buttonColor;
@property (nonatomic, assign) BOOL isEasyStyle;

@end

@implementation IMSOpenAccountUICustom

+ (instancetype)sharedInstance {
    static IMSOpenAccountUICustom *accountCustom;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        accountCustom = [[[self class] alloc] init];
    });
    return accountCustom;
}

- (id)init {
    if (self = [super init]) {
        id<ALBBOpenAccountUIService> uiService = ALBBService(ALBBOpenAccountUIService);
        [uiService setLoginViewDelegate:self];
        [uiService setRegisterViewDelegate:self];
        [uiService setSetPwdViewDelegate:self];
        [uiService setFindPwdViewDelegate:self];
        [uiService setResetPwdViewDelegate:self];
        [uiService setCountryCodeViewDelegate:self];
		self.isHiddenLocalize = YES;
		
        _headerImage = [UIImage ims_imageWithColor:[UIColor ims_systemMaticColor]];
		[[ALBBOpenAccountSDK sharedInstance] setLocale:@"zh.lproj"];
		NSString *path = [[NSBundle ims_getIMSOpenAccountBaseBundle].bundlePath stringByAppendingString:@"zh.lproj"];
		NSBundle *bundle = [NSBundle bundleWithPath:path];
		[[ALBBOpenAccountSDK sharedInstance] setLocaleBundle:bundle];
    }
    return self;
}

- (void)pushOpenAccountLoginControllerWithNavigationController:(UINavigationController *)navigationController{
    self.pushResetPwd = NO;
    self.isEasyStyle = NO;
    self.navigationController = navigationController;
    id<ALBBOpenAccountUIService> uiService = ALBBService(ALBBOpenAccountUIService);
    [uiService disableSDKLoginNavAction];
    [uiService showLoginInNavigationController:self.navigationController success:^(ALBBOpenAccountSession *currentSession) {
        
    } failure:nil];
}

- (void)pushFindPwdViewControllerWithNavigationController:(UINavigationController *)navigationController {
    self.pushResetPwd = YES;
    self.isEasyStyle = NO;
    self.navigationController = navigationController;
    id<ALBBOpenAccountUIService> uiService = ALBBService(ALBBOpenAccountUIService);
    //这里的代理和直接登录进入不同步，需要重新设置
    [uiService setFindPwdViewDelegate:self];
    [uiService setResetPwdViewDelegate:self];
    [uiService disableSDKLoginNavAction];
	
	__weak typeof(self) weakSelf = self;
    [uiService showFindPasswordInNavigationController:navigationController success:^(ALBBOpenAccountSession *currentSession) {
		__strong typeof(weakSelf) self = weakSelf;
		self.resetPwdSuccess = YES;
		
		[[NSNotificationCenter defaultCenter] postNotificationName:@"IMS_OPENACCOUNT_USER_LOGOUT_OUT" object:self];
		dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
			
			[[IMSAccountService sharedService] logout];
			
		});
		
    } failure:nil];
}

- (void)pushCountryCodeViewControllerWithNavigationController:(UINavigationController *)navigationController isEasyStyle:(BOOL)isEasyStyle {
	
    self.isEasyStyle = isEasyStyle;
    self.navigationController = navigationController;
    id<ALBBOpenAccountUIService> uiService = ALBBService(ALBBOpenAccountUIService);
    [uiService disableSDKLoginNavAction];
    [uiService showCountryCodeInNavagationController:navigationController delegate:self];
}

#pragma mark - ALBBOpenAccountPhonePrefixDelegate

- (void)updatePhonePrefix:(NSString *)phonePrefix {
    if ([self.delegate respondsToSelector:@selector(ims_countryCodeChooseCode:)]) {
        // 调用代理对象的登录方法，代理对象去实现登录方法
        [self.delegate ims_countryCodeChooseCode:phonePrefix];
    }
}

#pragma mark - ALBBOpenAccountLoginViewDelegate

- (void)loginViewDidLoad:(ALBBOpenAccountLoginViewController *)viewController {
	
    [self setButtonBackgroundImage:viewController.submitButton image:self.headerImage];
    [self insertHeaderViewWithTitle:@"登录" toController:viewController index:0];
    
    viewController.usernameLabel.text = @"手机号码";
    viewController.passwordLabel.text = @"密码";
	
    viewController.usernameLabel.font = [UIFont ims_regularFontOfSize:12.f];
    viewController.passwordLabel.font = [UIFont ims_regularFontOfSize:12.f];
    [viewController.submitButton setAttributedTitle:[self semiboldAttributedStringWithString:@"登录"] forState:UIControlStateNormal];
    [viewController.registerLinkBtn setAttributedTitle:[self mediumAttributedStringWithString:@"免费注册"] forState:UIControlStateNormal];
    [viewController.findPwdLinkBtn setTitle:@"忘记密码？" forState:UIControlStateNormal];
    
    [viewController.prefixIcon.titleLabel removeFromSuperview];
    [viewController.prefixIcon setImage:[UIImage ims_bundleImageNamed:@"Account_arrow_bottom"] forState:UIControlStateNormal];
    viewController.prefixLabel.text = [NSString stringWithFormat:@"+%@",@"86"];
    [viewController.prefixIcon ims_enlargeEdgeWithTop:10 right:10 bottom:10 left:50];
	viewController.prefixIcon.userInteractionEnabled = NO;

	if (self.resetPwdSuccess) {
		self.resetPwdSuccess = NO;
		[viewController ims_showHUDWithMessage:@"修改密码后 需重新登录"];
	}
}

- (void)loginViewWillAppear:(ALBBOpenAccountLoginViewController *)viewController {
    [viewController.navigationController setNavigationBarHidden:YES animated:NO];
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"IMS_OPENACCOUNT_HEADER_STATE_STYLE"]) {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
    } else {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    }
    [self openPopGestureRecognizer];
}

- (void)loginViewWillDisappear;{
    if (![[NSUserDefaults standardUserDefaults] boolForKey:@"IMS_OPENACCOUNT_HEADER_STATE_STYLE"]) {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
    } else {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    }
}

#pragma mark - ALBBOpenAccountRegisterViewDelegate

- (void)registerViewDidLoad:(ALBBOpenAccountRegisterViewController *)viewController {
    [self setButtonBackgroundImage:viewController.submitButton image:self.headerImage];
    [self insertHeaderViewWithTitle:@"手机注册" toController:viewController index:0];
    
    viewController.usernameLabel.text = @"手机号码";
    viewController.smscodeLabel.text = @"验证码";
    viewController.usernameLabel.font = [UIFont ims_regularFontOfSize:12.f];
    viewController.smscodeLabel.font = [UIFont ims_regularFontOfSize:12.f];
    [viewController.submitButton setAttributedTitle:[self semiboldAttributedStringWithString:@"下一步"] forState:UIControlStateNormal];
    [viewController.sendButton setTitle:@"发送验证码" forState:UIControlStateNormal];
    
    [viewController.prefixIcon.titleLabel removeFromSuperview];
    [viewController.prefixIcon setImage:[UIImage ims_bundleImageNamed:@"Account_arrow_bottom"] forState:UIControlStateNormal];
    viewController.prefixLabel.text = [NSString stringWithFormat:@"+%@",@"86"];
    [viewController.prefixIcon ims_enlargeEdgeWithTop:10 right:10 bottom:10 left:50];
	viewController.prefixIcon.userInteractionEnabled = NO;

    if (self.isHiddenLocalize) {
        //隐藏会有约束警告，不用直接删除
//        [viewController.prefixIcon removeFromSuperview];
//        [viewController.prefixLabel removeFromSuperview];
//        [viewController.usernameField mas_updateConstraints:^(MASConstraintMaker *make) {
//            make.left.equalTo(@30);
//        }];
    }
}

- (void)registerViewWillAppear:(ALBBOpenAccountRegisterViewController *)viewController {
    [self.navigationController setNavigationBarHidden:YES animated:NO];
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"IMS_OPENACCOUNT_HEADER_STATE_STYLE"]) {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
    } else {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    }
    [self openPopGestureRecognizer];
}

- (void)registerViewWillDisappear {
    if (![[NSUserDefaults standardUserDefaults] boolForKey:@"IMS_OPENACCOUNT_HEADER_STATE_STYLE"]) {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
    } else {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    }
}

#pragma mark - ALBBOpenAccountSetPwdViewDelegate

- (void)setPwdViewDidLoad:(ALBBOpenAccountSetPwdViewController *)viewController {
    [self setButtonBackgroundImage:viewController.submitButton image:self.headerImage];
	[self insertHeaderViewWithTitle:@"输入密码" toController:viewController index:0];
    viewController.passwordLabel.text = @"密码";
    viewController.passwordLabel.font = [UIFont ims_regularFontOfSize:12.f];
	[viewController.visibleButton setImage:[UIImage ims_bundleImageNamed:@"Account_pwd_show"] forState:UIControlStateNormal];
	[viewController.visibleButton setImage:[UIImage ims_bundleImageNamed:@"Account_pwd_hidden"] forState:UIControlStateSelected];
    [viewController.submitButton setAttributedTitle:[self semiboldAttributedStringWithString:@"完成"] forState:UIControlStateNormal];
}

- (void)setPwdViewWillAppear:(ALBBOpenAccountSetPwdViewController *)viewController {
    [self.navigationController setNavigationBarHidden:YES animated:NO];
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"IMS_OPENACCOUNT_HEADER_STATE_STYLE"]) {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
    } else {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    }
    [self openPopGestureRecognizer];
}

- (void)setPwdViewWillDisappear {
    if (![[NSUserDefaults standardUserDefaults] boolForKey:@"IMS_OPENACCOUNT_HEADER_STATE_STYLE"]) {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
    } else {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    }
}

#pragma mark - ALBBOpenAccountFindPwdViewDelegate

- (void)findPwdViewDidLoad:(ALBBOpenAccountFindPwdViewController *)viewController {
    [self setButtonBackgroundImage:viewController.nextButton image:self.headerImage];
    NSString *titleStr;
    if (self.pushResetPwd) {
        titleStr = @"修改密码";
        viewController.usernameField.text = [[ALBBOpenAccountSession sharedInstance] getUser].mobile;
		viewController.title = @"修改密码";
		[viewController.usernameLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.top.equalTo(viewController.view).offset(30);	make.left.equalTo(viewController.view).offset(30);
		}];
		
    } else {
        titleStr = @"找回密码";
		[self insertHeaderViewWithTitle:titleStr toController:viewController index:0];
		
		[viewController.usernameLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.left.equalTo(viewController.view).offset(30);	make.top.equalTo(viewController.view).offset(210);
		}];
    }
	
    viewController.usernameLabel.text = @"手机号码";
    viewController.smscodeLabel.text = @"验证码";
    viewController.usernameLabel.font = [UIFont ims_regularFontOfSize:12.f];
    viewController.smscodeLabel.font = [UIFont ims_regularFontOfSize:12.f];
    [viewController.nextButton setAttributedTitle:[self semiboldAttributedStringWithString:@"下一步"] forState:UIControlStateNormal];
    [viewController.sendButton setTitle:@"发送验证码" forState:UIControlStateNormal];
    viewController.usernameField.enabled = YES;
    
    [viewController.prefixIcon.titleLabel removeFromSuperview];
    [viewController.prefixIcon setImage:[UIImage ims_bundleImageNamed:@"Account_arrow_bottom"] forState:UIControlStateNormal];
    viewController.prefixLabel.text = [NSString stringWithFormat:@"+%@",@"86"];

    [viewController.prefixIcon ims_enlargeEdgeWithTop:10 right:10 bottom:10 left:50];
	viewController.prefixIcon.userInteractionEnabled = NO;
	
}

- (void)findPwdViewWillAppear:(ALBBOpenAccountFindPwdViewController *)viewController {
	
	if (self.pushResetPwd) {
		return;
	}
	
	[self.navigationController setNavigationBarHidden:YES animated:NO];
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"IMS_OPENACCOUNT_HEADER_STATE_STYLE"]) {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
    } else {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    }
	[self openPopGestureRecognizer];
}

- (void)findPwdViewWillDisappear {
	
	if (self.pushResetPwd) {
		return;
	}
	
    if (![[NSUserDefaults standardUserDefaults] boolForKey:@"IMS_OPENACCOUNT_HEADER_STATE_STYLE"]) {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
    } else {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    }
}

#pragma mark - ALBBOpenAccountResetPwdViewDelegate

- (void)resetPwdViewDidLoad:(ALBBOpenAccountResetPwdViewController *)viewController {
    [self setButtonBackgroundImage:viewController.submitButton image:self.headerImage];
	if (self.pushResetPwd) {
		[viewController.passwordLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.left.equalTo(viewController.view).offset(30);
			make.right.equalTo(viewController.view).offset(-30);
			make.top.equalTo(viewController.view).offset(30);
		}];
	} else {
		[self insertHeaderViewWithTitle:@"输入新密码" toController:viewController index:0];
		[viewController.passwordLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.left.equalTo(viewController.view).offset(30);
			make.right.equalTo(viewController.view).offset(-30);
			make.top.equalTo(viewController.view).offset(210);
		}];
	}
	
    viewController.passwordLabel.text = @"密码";
    viewController.passwordLabel.font = [UIFont ims_regularFontOfSize:12.f];
	[viewController.visibleButton setImage:[UIImage ims_bundleImageNamed:@"Account_pwd_show"] forState:UIControlStateNormal];
	[viewController.visibleButton setImage:[UIImage ims_bundleImageNamed:@"Account_pwd_hidden"] forState:UIControlStateSelected];

	NSString *submitButtonTitle;
	if (self.pushResetPwd) {
		submitButtonTitle = @"确定";
	} else {
		submitButtonTitle = @"完成";
	}
    [viewController.submitButton setAttributedTitle:[self semiboldAttributedStringWithString:submitButtonTitle] forState:UIControlStateNormal];
}

- (void)resetPwdViewWillAppear:(ALBBOpenAccountResetPwdViewController *)viewController {
	if (self.pushResetPwd) {
		return;
	}
    [self.navigationController setNavigationBarHidden:YES animated:NO];
    if ([[NSUserDefaults standardUserDefaults] boolForKey:@"IMS_OPENACCOUNT_HEADER_STATE_STYLE"]) {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
    } else {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    }
    [self openPopGestureRecognizer];
}

- (void)resetPwdViewWillDisappear {
	if (self.pushResetPwd) {
		return;
	}
    if (![[NSUserDefaults standardUserDefaults] boolForKey:@"IMS_OPENACCOUNT_HEADER_STATE_STYLE"]) {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
    } else {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    }
}

#pragma mark - ALBBOpenAccountCountryCodeViewDelegate

- (void)countryCodeViewDidLoad:(ALBBOpenAccountCountryCodeViewController *)viewController {
    viewController.countryCodeTableView.sectionIndexColor = IMSOpenAccountBase_RGBA(31, 200, 139);
    if (self.isEasyStyle) {
        viewController.countryCodeTableView.tableHeaderView = nil;
        viewController.title = @"选择国家代码";
        [viewController.countryCodeTableView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@0);
        }];
    } else {
        [self insertHeaderViewWithTitle:@"选择国家代码" toController:viewController index:999];
    }
}

- (void)countryCodeViewWillAppear:(ALBBOpenAccountCountryCodeViewController *) viewController {
    [self openPopGestureRecognizer];
    if (self.isEasyStyle) {
        [self.navigationController setNavigationBarHidden:NO animated:NO];
    } else {
        [self.navigationController setNavigationBarHidden:YES animated:NO];
        if ([[NSUserDefaults standardUserDefaults] boolForKey:@"IMS_OPENACCOUNT_HEADER_STATE_STYLE"]) {
            [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
        } else {
            [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
        }
    }
}

- (void)countryCodeViewWillDisappear {
    if (self.isEasyStyle) {
        if (![[NSUserDefaults standardUserDefaults] boolForKey:@"IMS_OPENACCOUNT_HEADER_STATE_STYLE"]) {
            [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
        } else {
            [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
        }
    } else {
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:NO];
    }
}

#pragma mark - UIGestureRecognizerDelegate

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
	if ([[self getCurrentVC] isKindOfClass:[ALBBOpenAccountLoginViewController class]]) {
		return NO;
	}
    return YES;
}

#pragma mark - Method

- (void)setButtonBackgroundImage:(UIButton *)button image:(UIImage *)bgImage {
    [button setBackgroundImage:bgImage forState:UIControlStateNormal];
    [button setBackgroundImage:bgImage forState:UIControlStateHighlighted];
}

- (void)openPopGestureRecognizer {
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.delegate = self;
    }
}

- (void)insertHeaderViewWithTitle:(NSString *)title toController:(UIViewController *)controller index:(NSInteger)index{
    __weak typeof(controller) weakController = controller;
    IMSOpenAccountHeaderView *view = [[IMSOpenAccountHeaderView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 180)];
    view.titleLabel.text = title;
    if (self.isHiddenLocalize && [controller isKindOfClass:[ALBBOpenAccountLoginViewController class]]) {
        view.backButton.hidden = YES;
    } else {
        view.backButton.hidden = NO;
        view.backButtonBlock = ^{
//            [weakController.navigationController setNavigationBarHidden:NO animated:NO];
            [weakController.navigationController popViewControllerAnimated:YES];
        };
    }
    [controller.view insertSubview:view atIndex:index];
}

- (NSAttributedString *)semiboldAttributedStringWithString:(NSString *)string {
    NSDictionary *attrDict = @{NSFontAttributeName:[UIFont ims_semiboldFontOfSize:14.f],
                               NSForegroundColorAttributeName:[UIColor whiteColor]
                               };
    return [[NSAttributedString alloc]initWithString:string attributes:attrDict];
}

- (NSAttributedString *)mediumAttributedStringWithString:(NSString *)string {
	NSDictionary *attrDict = @{NSFontAttributeName:[UIFont ims_mediumFontOfSize:14.f],
							   NSForegroundColorAttributeName:[UIColor whiteColor]
							   };
	return [[NSAttributedString alloc]initWithString:string attributes:attrDict];
}

//为免费登录配置化颜色以便变亮色背景图影响视觉
- (NSAttributedString *)registerAttributedStringWithString:(NSString *)string {
#if __has_include(<IMSTemplateConfig/IMSTemplateConfig.h>)
    IMSTemplateConfig *config = [[IMSTemplateConfig alloc] initWithModule:@"IMSOpenAccountBase"];
    NSDictionary *attrDict = @{NSFontAttributeName:[UIFont ims_regularFontOfSize:14.f],
                               NSForegroundColorAttributeName:[config colorForKey:@"OA_header_title_color"]
                               };
#else
    NSDictionary *attrDict = @{NSFontAttributeName:[UIFont ims_regularFontOfSize:14.f],
                               NSForegroundColorAttributeName:[UIColor whiteColor]
                               };
#endif
    return [[NSAttributedString alloc]initWithString:string attributes:attrDict];
}

- (UIViewController *)getCurrentVC {
    UIViewController *result = nil;
    UIWindow * window = [[UIApplication sharedApplication] keyWindow];
    if (window.windowLevel != UIWindowLevelNormal) {
        NSArray *windows = [[UIApplication sharedApplication] windows];
        for(UIWindow *tmpWin in windows) {
            if (tmpWin.windowLevel == UIWindowLevelNormal) {
                window = tmpWin;
                break;
            }
        }
    }
    id  nextResponder = nil;
    UIViewController *appRootVC=window.rootViewController;
    //如果是present上来的appRootVC.presentedViewController 不为nil
    if (appRootVC.presentedViewController) {
        nextResponder = appRootVC.presentedViewController;
    } else{
        UIView *frontView = [[window subviews] objectAtIndex:0];
        nextResponder = [frontView nextResponder];
    }
    
    if ([nextResponder isKindOfClass:[UITabBarController class]]) {
        UITabBarController * tabbar = (UITabBarController *)nextResponder;
        UINavigationController * nav = (UINavigationController *)tabbar.viewControllers[tabbar.selectedIndex];
        result=nav.childViewControllers.lastObject;
        
    } else if ([nextResponder isKindOfClass:[UINavigationController class]]) {
        UIViewController * nav = (UIViewController *)nextResponder;
        result = nav.childViewControllers.lastObject;
    } else {
        result = nextResponder;
    }
    
    return result;
}

@end
