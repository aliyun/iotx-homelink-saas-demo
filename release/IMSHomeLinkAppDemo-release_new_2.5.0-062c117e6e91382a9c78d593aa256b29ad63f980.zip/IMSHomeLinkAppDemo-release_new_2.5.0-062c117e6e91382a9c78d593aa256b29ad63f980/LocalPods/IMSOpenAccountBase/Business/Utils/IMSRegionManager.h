//
//  IMSRegionManager.h
//  IMSLife
//
//  Created by dujin on 2018/4/17.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, IMSOpenAccountRegion) {
    IMSOpenAccountRegionNone,
    IMSOpenAccountRegionChina,
    IMSOpenAccountRegionSingapore,
};

@interface IMSRegionManager : NSObject

+ (IMSOpenAccountRegion)getRegion;

+ (void)setRegion:(IMSOpenAccountRegion)region;

@end
