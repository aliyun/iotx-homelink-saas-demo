//
//  UIImage+IMSOpenAccountBase.m
//  CloudApiSDK
//
//  Created by chuntao.wang1 on 2018/5/14.
//

#import "UIImage+IMSOpenAccountBase.h"

NSString * const IMSOpenAccountBaseBundleName = @"IMSOpenAccountBase";

@implementation UIImage (IMSOpenAccountBase)

+ (UIImage *)openAccountBundleimageNamed:(NSString *)name {
    if (name.length > 0) {
        NSString *bundlePath = [[NSBundle mainBundle] pathForResource:IMSOpenAccountBaseBundleName ofType:@"bundle"];
        NSBundle *bundle = [NSBundle bundleWithPath:bundlePath];
        if (bundle) {
            return [UIImage imageNamed:name inBundle:bundle compatibleWithTraitCollection:nil];
        }
    }
    return nil;
}
@end
