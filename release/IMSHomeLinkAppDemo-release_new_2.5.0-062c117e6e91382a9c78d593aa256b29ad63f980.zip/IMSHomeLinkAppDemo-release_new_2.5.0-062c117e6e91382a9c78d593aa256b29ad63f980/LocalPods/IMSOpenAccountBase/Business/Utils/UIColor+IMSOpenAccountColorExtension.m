//
//  UIColor+IMSOpenAccountColorExtension.m
//  test
//
//  Created by chuntao.wang1 on 2018/5/24.
//  Copyright © 2018年 chuntao.wang1. All rights reserved.
//

#import "UIColor+IMSOpenAccountColorExtension.h"

@implementation UIColor (IMSOpenAccountColorExtension)

+ (BOOL)judgeColorIsNearWhiteColorWithImage:(UIImage *)image {
    BOOL leftResult = [UIColor judgeIsNearWhiteColorCurrnetLocationPoint:CGPointMake(20, 10) image:image];
    BOOL midResult = [UIColor judgeIsNearWhiteColorCurrnetLocationPoint:CGPointMake([UIScreen mainScreen].bounds.size.width/2.0, 10) image:image];
    BOOL rightResult = [UIColor judgeIsNearWhiteColorCurrnetLocationPoint:CGPointMake([UIScreen mainScreen].bounds.size.width - 10, 10) image:image];
    if (leftResult && midResult && rightResult) {
        //多点判断三点的颜色都接近白色，这时候用黑色
        return YES;
    } else {
        return NO;
    }
}

+ (BOOL)judgeIsNearWhiteColorCurrnetLocationPoint:(CGPoint)point image:(UIImage *)image {
    
    if (!CGRectContainsPoint(CGRectMake(0.0f, 0.0f, image.size.width, image.size.height), point)) {
        return nil;
    }
    
    CGFloat gray = 0;
    NSInteger pointX = trunc(point.x);
    NSInteger pointY = trunc(point.y);
    CGImageRef cgImage = image.CGImage;
    NSUInteger width = image.size.width;
    NSUInteger height = image.size.height;
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    int bytesPerPixel = 4;
    int bytesPerRow = bytesPerPixel * 1;
    NSUInteger bitsPerComponent = 8;
    unsigned char pixelData[4] = { 0, 0, 0, 0 };
    CGContextRef context = CGBitmapContextCreate(pixelData,
                                                 1,
                                                 1,
                                                 bitsPerComponent,
                                                 bytesPerRow,
                                                 colorSpace,
                                                 kCGImageAlphaPremultipliedLast |     kCGBitmapByteOrder32Big);
    CGColorSpaceRelease(colorSpace);
    CGContextSetBlendMode(context, kCGBlendModeCopy);
    
    CGContextTranslateCTM(context, -pointX, pointY-(CGFloat)height);
    CGContextDrawImage(context, CGRectMake(0.0f, 0.0f, (CGFloat)width, (CGFloat)height), cgImage);
    CGContextRelease(context);
    
    CGFloat red   = (CGFloat)pixelData[0];
    CGFloat green = (CGFloat)pixelData[1];
    CGFloat blue  = (CGFloat)pixelData[2];
    //CGFloat alpha = (CGFloat)pixelData[3];
    //[UIColor colorWithRed:red/255.0 green:green/255.0 blue:blue/255.0 alpha:alpha/255.0];
    //灰度模型公式
    gray = red * 0.299 + green * 0.587 + blue * 0.114;
    if (gray > 200) {
        //这里阀值设为200，超过表明颜色靠近白色
        return YES;
    } else {
        return NO;
    }
}

@end
