//
//  IMSOpenAccountUICustom.h
//  IMSLife
//
//  Created by chuntao.wang1 on 2018/4/11.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "IMSAccountManager.h"

typedef void (^loginSuccessBlock)(void);

//获取当前国家码选择code
@protocol IMSAccountUICustomProtocol <NSObject>
- (void)ims_countryCodeChooseCode:(NSString *)code;
@end

@interface IMSOpenAccountUICustom : NSObject

@property (nonatomic, weak) id<IMSAccountUICustomProtocol>delegate;

+ (instancetype)sharedInstance;

//PS:想要状态栏颜色变白色，请求plist文件中设置View controller-based status bar appearance为NO

/**
 push推出登录界面

 @param navigationController 当前导航栏(地区导航栏)
 */
- (void)pushOpenAccountLoginControllerWithNavigationController:(UINavigationController *)navigationController;

/**
 push推出修改密码

 @param navigationController 当前导航栏(账号管理导航栏)
 */
- (void)pushFindPwdViewControllerWithNavigationController:(UINavigationController *)navigationController;

/**
 push国家code选择

@param navigationController 当前导航栏(账号管理导航栏)
@param isEasyStyle （单纯的地区码样式/同登录样式的地区码）
 */
- (void)pushCountryCodeViewControllerWithNavigationController:(UINavigationController *)navigationController isEasyStyle:(BOOL)isEasyStyle;

@end
