//
//  NSBundle+OpenAccountBase.h
//  IMSOpenAccountBase
//
//  Created by chuntao.wang1 on 2018/5/9.
//  Copyright © 2018年 chuntao.wang1. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSBundle (OpenAccountBase)

+ (NSBundle *)ims_getIMSOpenAccountBaseBundle;

@end
