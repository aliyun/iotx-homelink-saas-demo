//
//  NSBundle+OpenAccountBase.m
//  IMSOpenAccountBase
//
//  Created by chuntao.wang1 on 2018/5/9.
//  Copyright © 2018年 chuntao.wang1. All rights reserved.
//

#import "NSBundle+OpenAccountBase.h"

static NSString *const IMSOpenAccountBase = @"IMSOpenAccountBase";

@implementation NSBundle (OpenAccountBase)

+ (NSBundle *)ims_getIMSOpenAccountBaseBundle {
    NSBundle *bundle = [NSBundle bundleWithPath:[[NSBundle mainBundle] pathForResource:IMSOpenAccountBase ofType:@"bundle"]];
    return bundle;
}

@end
