//
//  UIImage+OpenAccountBaseBundle.m
//  IMSLife
//
//  Created by dujin on 2018/4/12.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "UIImage+OpenAccountBaseBundle.h"

NSString * const OpenAccountBaseBundleName = @"IMSOpenAccountBase";

@implementation UIImage (OpenAccountBaseBundle)

+ (UIImage *)ims_bundleImageNamed:(NSString *)name {
    if (name.length > 0) {
        NSString *bundlePath = [[NSBundle mainBundle] pathForResource:OpenAccountBaseBundleName ofType:@"bundle"];
        NSBundle *bundle = [NSBundle bundleWithPath:bundlePath];
        if (bundle) {
            return [UIImage imageNamed:name inBundle:bundle compatibleWithTraitCollection:nil];
        }
    }
    return nil;
}

@end
