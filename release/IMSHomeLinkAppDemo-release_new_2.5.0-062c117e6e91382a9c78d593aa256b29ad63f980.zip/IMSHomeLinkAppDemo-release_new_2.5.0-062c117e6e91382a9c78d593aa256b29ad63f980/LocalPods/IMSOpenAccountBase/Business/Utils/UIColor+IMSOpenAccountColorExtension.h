//
//  UIColor+IMSOpenAccountColorExtension.h
//  test
//
//  Created by chuntao.wang1 on 2018/5/24.
//  Copyright © 2018年 chuntao.wang1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (IMSOpenAccountColorExtension)


/**
 获取图片某点的灰色模型色值  PS:需要先设置frame，才能采点

 @param image 图片
 @return 是否接近白色
 */
+ (BOOL)judgeColorIsNearWhiteColorWithImage:(UIImage *)image;


@end
