//
//  UIImage+IMSOpenAccountBase.h
//  CloudApiSDK
//
//  Created by chuntao.wang1 on 2018/5/14.
//

#import <UIKit/UIKit.h>

@interface UIImage (IMSOpenAccountBase)

+ (UIImage *)openAccountBundleimageNamed:(NSString *)name;

@end
