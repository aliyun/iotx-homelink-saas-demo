//
//  IMSOpenAccountBaseConstant.h
//  IMSOpenAccountBase
//
//  Created by narcissu on 2018/3/20.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#ifndef IMSOpenAccountBaseConstant_h
#define IMSOpenAccountBaseConstant_h
#import <UIKit/UIKit.h>

#pragma mark - Localize

static inline UIColor *IMSOpenAccountBase_RGBA(CGFloat r, CGFloat g, CGFloat b) {
    return [UIColor colorWithRed:((r) / 255.0) green:((g) / 255.0) blue:((b) / 255.0) alpha:(1)];
}

#endif /* IMSSceneConstant_h */
