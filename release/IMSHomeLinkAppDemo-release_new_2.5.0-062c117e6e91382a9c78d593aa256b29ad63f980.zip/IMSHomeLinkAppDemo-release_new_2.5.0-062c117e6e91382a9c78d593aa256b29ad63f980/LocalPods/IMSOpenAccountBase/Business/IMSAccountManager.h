//
//  IMSAccountManager.h
//  IMSOpenAccount
//
//  Created by dujin on 2018/4/26.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <IMSApiClient/IMSConfiguration.h>
#import <ALBBOpenAccountUI/ALBBOpenAccountCountryCodeViewController.h>

/**
 退出登录时IMS发送的通知，不同于OASDK退出通知，便于处理其他模块业务
 */
#define IMSOpenAccountNotificationUserLoggedOut @"IMS_OPENACCOUNT_USER_LOGOUT_OUT"

/**
 国际化app下，选择region，切换host初始化
 */
#define IMSOpenAccountRegionChoiceFinish @"IMS_OPENACCOUNT_REGION_CHOICE_FINISH"


//登录成功回调
typedef void (^IMSOpenAccountLoginSuccessBlock)(void);

//业务需要：单独推出国家代码选择时候使用
//ps：push事设置代理，点击即可通过代理获取code
@protocol IMSAccountManagerProtocol <ALBBOpenAccountPhonePrefixDelegate>
- (void)ims_currentSelectCode:(NSString *)code;
@end

@interface IMSAccountManager : NSObject

@property (nonatomic, weak) id<IMSAccountManagerProtocol>delegate;

+ (instancetype)sharedManager;

/**
 如果外部自行初始化，可省略
 */
- (void)configureApiClientAndIot;

/**
 关闭国际化：（去掉地区、号码前缀）
 PS：进行配置化可在配置plist文件设置
 */
- (void)closeLocalize;

/**
 设置rootVC，回调登录成功失败
 PS:内部已做登录判断，所有设置rootVC都在回调里设置

 @param success 成功回调当前VC
 */
- (void)resetRootViewControllerWithLoginSuccess:(void(^)(UIViewController *viewController))success;

/**
 push国家代码选择界面
 
 @param navigationController 当前navigationController
 @param isEasyStyle （单纯的地区码样式/同登录样式的地区码）
 */
- (void)pushCountryCodeViewControllerWithNavigationController:(UINavigationController *)navigationController isEasyStyle:(BOOL)isEasyStyle;

/**
 push登录界面
 
@param navigationController navigationController(nil时为当前VC的导航栏)
*/
- (void)pushOpenAccountLoginControllerWithNavigationController:(UINavigationController *)navigationController;

@end
