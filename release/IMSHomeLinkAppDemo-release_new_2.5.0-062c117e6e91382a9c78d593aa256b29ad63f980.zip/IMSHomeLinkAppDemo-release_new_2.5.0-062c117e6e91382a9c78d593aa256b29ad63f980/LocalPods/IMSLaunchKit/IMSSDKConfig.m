//
//  IMSSDKConfig.m
//  IMSLaunchKit
//
//  Created by Hager Hu on 2018/5/15.
//

#import "IMSSDKConfig.h"

@implementation IMSSDKConfig

@end
