//
//  IMSLogLaunch.h
//  spring-demo
//
//  Created by dujin on 2018/6/11.
//  Copyright © 2018年 Alibaba. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IMSLogLaunch : NSObject <UIApplicationDelegate>

@end
