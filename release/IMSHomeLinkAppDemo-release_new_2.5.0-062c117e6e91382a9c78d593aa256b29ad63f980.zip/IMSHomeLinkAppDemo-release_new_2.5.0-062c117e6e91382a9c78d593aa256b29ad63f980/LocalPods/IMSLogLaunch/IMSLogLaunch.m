//
//  IMSLogLaunch.m
//  spring-demo
//
//  Created by dujin on 2018/6/11.
//  Copyright © 2018年 Alibaba. All rights reserved.
//

#import "IMSLogLaunch.h"

#import <IMSLog/IMSLog.h>

static NSString *const kIMSLogLaunchLogLevel = @"logLevel";
static NSString *const kIMSLogLaunchLogTags = @"logTags";

@implementation IMSLogLaunch

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    // 设置打印日志
    IMSLogLevel logLevel = IMSLogLevelVerbose;
	
    [IMSLog setAllTagsLevel:logLevel];
	
    [IMSLog showInConsole:TRUE];
    
    return TRUE;
}

@end
