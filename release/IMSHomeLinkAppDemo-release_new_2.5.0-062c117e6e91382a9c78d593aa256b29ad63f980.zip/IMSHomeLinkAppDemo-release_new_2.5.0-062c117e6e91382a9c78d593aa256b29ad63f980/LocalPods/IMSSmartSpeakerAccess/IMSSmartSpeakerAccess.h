//
//  IMSSmartSpeakerAccess.h
//  IMSSmartSpeakerAccess
//
//  Created by chaokong on 2018/7/11.
//  Copyright © 2018年 chaokong. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for IMSSmartSpeakerAccess.
FOUNDATION_EXPORT double IMSSmartSpeakerAccessVersionNumber;

//! Project version string for IMSSmartSpeakerAccess.
FOUNDATION_EXPORT const unsigned char IMSSmartSpeakerAccessVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IMSSmartSpeakerAccess/PublicHeader.h>
#import <IMSSmartSpeakerAccess/IMSTmallSpeakerApi.h>
#import <IMSSmartSpeakerAccess/IMSTaobaoAuthWebViewController.h>
#import <IMSSmartSpeakerAccess/IMSThirdPartyDetailViewController.h>
#import <IMSSmartSpeakerAccess/IMSThirdPartyCommonMarco.h>
