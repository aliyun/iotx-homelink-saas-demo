//
//  IMSTaobaoAuthWebViewController.m
//  IMSLocalize
//
//  Created by chaokong on 2018/7/11.
//

#import "IMSTaobaoAuthWebViewController.h"
#import <WebKit/WebKit.h>
#import <Masonry/Masonry.h>
#import "IMSTmallSpeakerApi.h"
#import <IMSApiClient/IMSConfiguration.h>

static NSString* const IMSTaobaoAuthRedirectUrl = @"https://homelink.iot.aliyun.com";

static NSString* const IMSTaobaoAuthDomain = @"homelink.iot.aliyun.com";

@interface IMSTaobaoAuthWebViewController ()<WKNavigationDelegate>
@property (nonatomic, strong) WKWebView *webview;
@property (nonatomic, copy) void (^completion)(NSError *, NSDictionary *);
@end

@implementation IMSTaobaoAuthWebViewController

- (instancetype)initWithCompletion:(void (^)(NSError *, NSDictionary *))completion{
    self = [super init];
    self.completion = completion;
    return self;
}

- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [super viewDidLoad];
    WKWebView *webView = [[WKWebView alloc]init];
    [self.view addSubview:webView];
    [webView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view);
        make.right.equalTo(self.view);
        make.top.equalTo(self.view);
        make.bottom.equalTo(self.view);
    }];
    //    webView.UIDelegate = self;
    webView.navigationDelegate = self;
	
	[webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"https://oauth.taobao.com/authorize?response_type=code&client_id=%@&redirect_uri=%@&view=wap",[IMSConfiguration sharedInstance].appKey,IMSTaobaoAuthRedirectUrl]]]];
}

#pragma mark - WKNavigationDelegate

// 在发送请求之前，决定是否跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
	
	BOOL redirect = [navigationAction.request.URL.absoluteString hasPrefix:IMSTaobaoAuthRedirectUrl];
	
    if (!redirect){
        //允许跳转
        decisionHandler(WKNavigationActionPolicyAllow);
    } else {
        //不允许跳转
        decisionHandler(WKNavigationActionPolicyCancel);
        NSURLComponents *components = [NSURLComponents componentsWithString:navigationAction.request.URL.absoluteString];
		
		NSString *errorDescription;
        for (NSURLQueryItem *item in components.queryItems){
            if ([item.name isEqualToString:@"code"]){
                [IMSTmallSpeakerApi bindTaobaoIdWithParams:@{@"authCode":item.value} completion:^(NSError *err, NSDictionary *result) {
                    
                    if (self.completion){
                        self.completion(err, result);
                    }
                    [self.navigationController popViewControllerAnimated:YES];
					return;
                }];
                break;
			} else if ([item.name isEqualToString:@"error_description"]) {
				errorDescription = item.value;
				if (self.completion) {
					NSError *error = [NSError errorWithDomain:IMSTaobaoAuthDomain code:-1 userInfo:@{NSLocalizedDescriptionKey : (errorDescription ?: @"授权未知错误")}];
					self.completion(error, nil);
					[self.navigationController popViewControllerAnimated:YES];
				}
				return;
			}
        }
    }
}

@end
