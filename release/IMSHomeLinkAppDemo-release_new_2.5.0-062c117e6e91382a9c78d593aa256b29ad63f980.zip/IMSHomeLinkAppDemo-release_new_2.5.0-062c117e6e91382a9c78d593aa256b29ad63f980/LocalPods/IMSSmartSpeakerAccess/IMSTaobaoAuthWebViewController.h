//
//  IMSTaobaoAuthWebViewController.h
//  IMSLocalize
//
//  Created by chaokong on 2018/7/11.
//

#import <UIKit/UIKit.h>

@interface IMSTaobaoAuthWebViewController : UIViewController
- (instancetype)initWithCompletion:(void (^)(NSError *, NSDictionary *))completion;
@end
