//
//  IMSThirdPartyDeviceModel.h
//  CocoaAsyncSocket
//
//  Created by chuntao.wang1 on 2018/7/13.
//

#import <Mantle/Mantle.h>

@class IMSThirdPartyDeviceData;

@interface IMSThirdPartyDeviceModel : MTLModel<MTLJSONSerializing>
    
//云端总数
@property (nonatomic, assign) NSInteger total;
//设备列表
@property (nonatomic, strong) NSArray<IMSThirdPartyDeviceData *> *data;
//当前页号
@property (nonatomic, assign) NSInteger pageNo;
//页大小
@property (nonatomic, assign) NSInteger pageSize;

@end

@interface IMSThirdPartyDeviceData : MTLModel<MTLJSONSerializing>

//图片
@property (nonatomic, strong) NSURL *icon;
//设备名称
@property (nonatomic, strong) NSString *label;
//设备iotId
@property (nonatomic, strong) NSString *value;
    
@end
