//
//  IMSThirdPartyDeviceModel.m
//  CocoaAsyncSocket
//
//  Created by chuntao.wang1 on 2018/7/13.
//

#import "IMSThirdPartyDeviceModel.h"

@implementation IMSThirdPartyDeviceData
    
+ (NSDictionary *)JSONKeyPathsByPropertyKey {
    return @{@"icon"            : @"icon",
             @"label"           : @"label",
             @"value"           : @"value",
             };
}
    
+ (NSValueTransformer *)iconJSONTransformer {
    return [NSValueTransformer valueTransformerForName:MTLURLValueTransformerName];
}
    
    @end

@implementation IMSThirdPartyDeviceModel
    
+ (NSDictionary *)JSONKeyPathsByPropertyKey {
    return @{@"total"              : @"total",
             @"data"               : @"data",
             @"pageNo"             : @"pageNo",
             @"pageSize"           : @"pageSize"
             };
}
    
+ (NSValueTransformer *)dataJSONTransformer {
    return [MTLJSONAdapter arrayTransformerWithModelClass:IMSThirdPartyDeviceData.class];
}

@end


