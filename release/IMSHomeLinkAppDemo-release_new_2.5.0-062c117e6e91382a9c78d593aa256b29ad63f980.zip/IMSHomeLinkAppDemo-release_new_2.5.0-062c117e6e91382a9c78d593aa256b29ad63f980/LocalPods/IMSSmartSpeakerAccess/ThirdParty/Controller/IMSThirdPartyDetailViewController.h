//
//  IMSThirdPartyDetailViewController.h
//  IMSLife
//
//  Created by chuntao.wang1 on 2018/7/11.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IMSThirdPartyCommonMarco.h"

@interface IMSThirdPartyDetailViewController : UIViewController

@end
