//
//  IMSThirdPartyDetailViewController.m
//  IMSLife
//
//  Created by chuntao.wang1 on 2018/7/11.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import "IMSThirdPartyDetailViewController.h"

#import "NSBundle+IMSSmartSpeakerAccess.h"
#import "UIImage+IMSSmartSpeakerAccess.h"
#import "IMSThirdPartyCommonMarco.h"

#import "IMSThirdPartyCell.h"
#import "IMSThirdPartyDeviceCell.h"
#import "IMSThirdPartyInstructionCell.h"
#import "IMSThirdPartyBindCell.h"
#import "IMSThirdPartyDeviceCell+Data.h"
#import "IMSThirdPartyBindCell+Data.h"

#import "IMSThirdPartyDeviceModel.h"

#import "IMSTaobaoAuthWebViewController.h"

#import <IMSSmartSpeakerAccess/IMSTmallSpeakerApi.h>
#import <IMSHUD/IMSHUD.h>

static NSString *const IMSThirdParty_Cell = @"IMSThirdPartyCell";
static NSString *const IMSThirdPartyBind_Cell = @"IMSThirdPartyBindCell";
static NSString *const IMSThirdPartyDevice_Cell = @"IMSThirdPartyDeviceCell";
static NSString *const IMSThirdPartyInstruction_Cell = @"IMSThirdPartyInstructionCell";

@interface IMSThirdPartyDetailViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic ,strong) UITableView *tableView;
@property (nonatomic, strong) IMSThirdPartyDeviceModel *deviceModel;
@property (nonatomic, assign) BOOL isBinded;

@end

@implementation IMSThirdPartyDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self configureUI];
    [self configureData];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	self.navigationController.navigationBarHidden = NO;
}

#pragma mark - Net

- (void)getTmallGenieBindStateRequest {
    [IMSTmallSpeakerApi getTaobaoIdWithParams:@{@"accountType":@"TAOBAO"} completion:^(NSError *error, NSDictionary *data) {
        if (error) {
            [self ims_showHUDWithMessage:error.localizedDescription];
        } else {
            if(data) {
				
				if (!data ||
					data == (id)kCFNull ||
					![data isKindOfClass:[NSDictionary class]]) {
					return;
				}
				
				[self reloadTableViewCellTitleWithDict:data];
            }
        }
    }];
}

- (void)unbindTmallGenieRequest {
    [IMSTmallSpeakerApi unbindTaobaoIdWithParams:@{@"accountType":@"TAOBAO"} completion:^(NSError *error, NSDictionary *data) {
        if (error) {
            [self ims_showHUDWithMessage:error.localizedDescription];
        } else {
            self.isBinded = NO;
            [self reloadSectionWithNumber:1];
        }
    }];
}

- (void)getDeviceListRequest {
    NSString *channel = @"TmallGenie";
	
    NSDictionary *params = @{@"channel":channel,
                             @"pageNo":@(1),
                             @"pageSize":@(50)
                             };
    [IMSTmallSpeakerApi getSupportDeviceWithParams:params completion:^(NSError * error, NSDictionary *data) {
        if (error) {
            [self ims_showHUDWithMessage:error.localizedDescription];
        } else {
			
			if (!data ||
				data == (id)kCFNull ||
				![data isKindOfClass:[NSDictionary class]]) {
				return;
			}
			
            self.deviceModel = [MTLJSONAdapter modelOfClass:[IMSThirdPartyDeviceModel class] fromJSONDictionary:data error:nil];
            self.deviceModel.data.count == 0 ?: [self reloadSectionWithNumber:2];
        }
    }];
}

#pragma mark - Method

- (void)configureData {
	
    [self getDeviceListRequest];
    [self getTmallGenieBindStateRequest];
}

- (void)reloadTableViewCellTitleWithDict:(NSDictionary *)dict {
	NSString *accountId = [dict objectForKey:@"accountId"];
	NSString *accountType = [dict objectForKey:@"accountType"];
	if (accountId &&
		accountType &&
		[accountId isKindOfClass:[NSString class]] &&
		[accountType isKindOfClass:[NSString class]] &&
		accountId.length > 0 &&
		accountType.length > 0) {
		//绑定成功&&已经绑定
		self.isBinded = YES;
		[self reloadSectionWithNumber:1];
	}

}

- (void)reloadSectionWithNumber:(NSInteger)number {
    NSIndexSet *indexSet = [[NSIndexSet alloc] initWithIndex:number];
    [self.tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationAutomatic];
}
    
- (NSMutableAttributedString *)ims_attributedStringWithString:(NSString *)string {
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:string];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = 20; // 调整行间距
    NSRange range = NSMakeRange(0, [attributedString length]);
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:range];
    [attributedString addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:14] range:range];
    return attributedString;
}

#pragma mark - UITableViewDelegate & UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0 || section == 1 || section == 3) {
        return 1;
    } else {
		return self.deviceModel.data.count != 0 ? self.deviceModel.data.count : 1;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.section) {
        case 0: {
            IMSThirdPartyCell *cell = [tableView dequeueReusableCellWithIdentifier:IMSThirdParty_Cell forIndexPath:indexPath];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.rightArrowBtn.hidden = YES;
            cell.imageV.image = [UIImage ims_SmartbundleImageNamed:@"Third_Tmall"];
            return cell;
        }
            break;
        case 1: {
            IMSThirdPartyBindCell *cell = [tableView dequeueReusableCellWithIdentifier:IMSThirdPartyBind_Cell forIndexPath:indexPath];
            [cell setIMSThirdPartyDeviceCellWithIsBinded:self.isBinded];
            return cell;
        }
            break;
        case 2: {
            IMSThirdPartyDeviceCell *cell = [tableView dequeueReusableCellWithIdentifier:IMSThirdPartyDevice_Cell forIndexPath:indexPath];
            [cell setIMSThirdPartyDeviceCellWithIndexPath:indexPath model:self.deviceModel];
            return cell;
        }
            break;
        case 3: {
            IMSThirdPartyInstructionCell *cell = [tableView dequeueReusableCellWithIdentifier:IMSThirdPartyInstruction_Cell forIndexPath:indexPath];
            cell.titleLabel.text = @"您可以这样说:";
            cell.instructionLabel.attributedText = [self ims_attributedStringWithString:@"“天猫精灵，打开灯”\n“天猫精灵，把灯调亮一点”\n“天猫精灵，把灯调成蓝色”\n“天猫精灵，打开窗帘”\n“天猫精灵，风扇调到3档”\n“天猫精灵，取暖器温度调到三十度”"];
            cell.instructionLabel.textColor = IMSSmartSpeakerAccess_RGBA(51, 51, 51);
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
            break;
        default:
            break;
    }
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return 120;
    } else if (indexPath.section == 1) {
        return 54;
    } else if (indexPath.section == 2) {
        return 64;
    } else {
        //ios10 label布局不能直接自动计算高度
        NSAttributedString *string = [self ims_attributedStringWithString:@"“天猫精灵，打开灯”\n“天猫精灵，把灯调亮一点”\n“天猫精灵，把灯调成蓝色”\n“天猫精灵，打开窗帘”\n“天猫精灵，风扇调到3档”\n“天猫精灵，取暖器温度调到三十度”"];
        CGSize size = [string boundingRectWithSize:CGSizeMake([UIScreen mainScreen].bounds.size.width - 48, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading context:nil].size;
        return size.height + 138;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return CGFLOAT_MIN;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return 0;
    } else if (section == 1) {
        return 20;
    } else if (section == 2) {
        return 36;
    } else {
        return 36;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	if (indexPath.section == 1) {
        if (self.isBinded) {
            [self unbindTmallGenieRequest];
        } else {
            IMSTaobaoAuthWebViewController *vc = [[IMSTaobaoAuthWebViewController alloc] initWithCompletion:^(NSError *error, NSDictionary *dict) {
				if (error) {
					[self ims_showHUDWithMessage:error.userInfo[NSLocalizedDescriptionKey]];
				}
                [self reloadTableViewCellTitleWithDict:dict];
            }];
            [self.navigationController pushViewController:vc animated:YES];
        }
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 36)];
    
    UILabel *timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, 0, 200, 36)];
    timeLabel.textColor = IMSSmartSpeakerAccess_RGBA(153,153,153);
    timeLabel.font = [UIFont systemFontOfSize:12];
    [view addSubview:timeLabel];
    
    if (section == 2) {
        timeLabel.text = @"可控设备";
    } else if (section == 3) {
        NSString *titleStr = @"平台指令";
        timeLabel.text = titleStr;
    }
    return view;
}

#pragma mark - Configure

- (void)configureUI {
	self.title = @"天猫精灵";
    [self.view addSubview:self.tableView];
}

#pragma mark - Setter & Getter

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height - 44 - [UIApplication sharedApplication].statusBarFrame.size.height) style:UITableViewStyleGrouped];
        _tableView.backgroundColor = IMSSmartSpeakerAccess_RGBA(246, 246, 246);
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.estimatedRowHeight = 400;
        _tableView.estimatedSectionFooterHeight = 0;
        _tableView.estimatedSectionHeaderHeight = 10;
        _tableView.estimatedRowHeight = UITableViewAutomaticDimension;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [_tableView registerNib:[UINib nibWithNibName:IMSThirdParty_Cell bundle:[NSBundle ims_SmartSpeakerAccessBundle]] forCellReuseIdentifier:IMSThirdParty_Cell];
        [_tableView registerNib:[UINib nibWithNibName:IMSThirdPartyBind_Cell bundle:[NSBundle ims_SmartSpeakerAccessBundle]] forCellReuseIdentifier:IMSThirdPartyBind_Cell];
        [_tableView registerNib:[UINib nibWithNibName:IMSThirdPartyDevice_Cell bundle:[NSBundle ims_SmartSpeakerAccessBundle]] forCellReuseIdentifier:IMSThirdPartyDevice_Cell];
        [_tableView registerNib:[UINib nibWithNibName:IMSThirdPartyInstruction_Cell bundle:[NSBundle ims_SmartSpeakerAccessBundle]] forCellReuseIdentifier:IMSThirdPartyInstruction_Cell];
    }
    return _tableView;
}

@end
