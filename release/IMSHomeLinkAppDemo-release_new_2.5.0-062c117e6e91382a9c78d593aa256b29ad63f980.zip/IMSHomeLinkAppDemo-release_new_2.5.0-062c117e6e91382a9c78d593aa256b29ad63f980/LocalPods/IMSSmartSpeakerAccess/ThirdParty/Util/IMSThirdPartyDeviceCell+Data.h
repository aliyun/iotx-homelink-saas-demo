//
//  IMSThirdPartyDeviceCell+Data.h
//  CocoaAsyncSocket
//
//  Created by chuntao.wang1 on 2018/7/25.
//

#import "IMSThirdPartyDeviceCell.h"
#import "IMSThirdPartyCommonMarco.h"
#import "IMSThirdPartyDeviceModel.h"

@interface IMSThirdPartyDeviceCell (Data)

/**
 设备cell

 @param indexPath indexPath
 @param model 数据model
 */
- (void)setIMSThirdPartyDeviceCellWithIndexPath:(NSIndexPath *)indexPath model:(IMSThirdPartyDeviceModel *)model;

@end
