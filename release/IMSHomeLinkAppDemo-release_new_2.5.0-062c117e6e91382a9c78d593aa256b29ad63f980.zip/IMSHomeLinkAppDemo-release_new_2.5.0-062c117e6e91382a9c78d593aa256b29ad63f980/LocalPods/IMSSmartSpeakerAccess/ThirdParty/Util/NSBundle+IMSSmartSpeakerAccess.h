//
//  NSBundle+IMSSmartSpeakerAccess.h
//  CocoaAsyncSocket
//
//  Created by chuntao.wang1 on 2018/7/12.
//

#import <Foundation/Foundation.h>

@interface NSBundle (IMSSmartSpeakerAccess)

+ (NSBundle *)ims_SmartSpeakerAccessBundle;

@end
