//
//  IMSThirdPartyBindCell+Data.m
//  CocoaAsyncSocket
//
//  Created by chuntao.wang1 on 2018/7/25.
//

#import "IMSThirdPartyBindCell+Data.h"
#import "UIImage+IMSSmartSpeakerAccess.h"

@implementation IMSThirdPartyBindCell (Data)

- (void)setIMSThirdPartyDeviceCellWithIsBinded:(BOOL)isBinded {
	self.leftTitleLabel.hidden = YES;
	self.rightTitleLabel.hidden = NO;
	if (isBinded) {
		self.rightTitleLabel.textColor = [UIColor redColor];
		self.rightTitleLabel.text = @"解绑账号";
	} else {
		self.rightTitleLabel.text = @"绑定账号";
	}
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}

@end
