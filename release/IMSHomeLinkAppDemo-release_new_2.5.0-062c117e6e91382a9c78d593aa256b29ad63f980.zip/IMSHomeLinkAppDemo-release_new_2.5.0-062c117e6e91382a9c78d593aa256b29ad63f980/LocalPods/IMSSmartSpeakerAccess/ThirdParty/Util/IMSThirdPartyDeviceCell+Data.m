//
//  IMSThirdPartyDeviceCell+Data.m
//  CocoaAsyncSocket
//
//  Created by chuntao.wang1 on 2018/7/25.
//

#import "IMSThirdPartyDeviceCell+Data.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "UIImage+IMSSmartSpeakerAccess.h"

@implementation IMSThirdPartyDeviceCell (Data)

- (void)setIMSThirdPartyDeviceCellWithIndexPath:(NSIndexPath *)indexPath model:(IMSThirdPartyDeviceModel *)model {
    if (model.data.count == 0) {
        self.leftTitleLabel.textColor = IMSSmartSpeakerAccess_RGBA(153, 153, 153);
        self.leftTitleLabel.text = @"当前没有支持的设备";
        self.leftTitleLabel.hidden = NO;
    } else {
        if (indexPath.row != model.data.count - 1) {
            self.lineView.hidden = NO;
        } else {
            self.lineView.hidden = YES;
        }
        self.leftTitleLabel.hidden = YES;
        self.imageV.hidden = NO;
        self.midTitleLabel.hidden = NO;
        if (@available(iOS 6.0, *)) {
            IMSThirdPartyDeviceData *data = model.data[indexPath.row];
            [self.imageV sd_setImageWithURL:data.icon placeholderImage:[UIImage ims_SmartbundleImageNamed:@"Third_Device"]];
            self.midTitleLabel.text = data.label;
        } else {
            // Fallback on earlier versions
        }
    }
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}

@end
