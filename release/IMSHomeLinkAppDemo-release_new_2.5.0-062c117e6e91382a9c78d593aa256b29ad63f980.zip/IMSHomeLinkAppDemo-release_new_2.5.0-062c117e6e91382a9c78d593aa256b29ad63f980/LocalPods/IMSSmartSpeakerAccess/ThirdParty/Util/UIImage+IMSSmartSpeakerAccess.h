//
//  UIImage+IMSSmartSpeakerAccess.h
//  CocoaAsyncSocket
//
//  Created by chuntao.wang1 on 2018/7/12.
//

#import <UIKit/UIKit.h>

@interface UIImage (IMSSmartSpeakerAccess)

+ (UIImage *)ims_SmartbundleImageNamed:(NSString *)name;

@end
