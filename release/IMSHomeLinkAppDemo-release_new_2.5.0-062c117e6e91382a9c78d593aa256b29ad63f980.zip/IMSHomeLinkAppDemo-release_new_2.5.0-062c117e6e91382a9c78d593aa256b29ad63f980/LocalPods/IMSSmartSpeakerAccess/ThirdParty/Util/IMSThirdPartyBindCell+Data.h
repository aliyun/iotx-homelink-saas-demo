//
//  IMSThirdPartyBindCell+Data.h
//  CocoaAsyncSocket
//
//  Created by chuntao.wang1 on 2018/7/25.
//

#import "IMSThirdPartyBindCell.h"
#import "IMSThirdPartyCommonMarco.h"
#import "IMSThirdPartyDeviceModel.h"

@interface IMSThirdPartyBindCell (Data)


/**
 绑定cell

 @param isBinded 平台是否已绑定
 */
- (void)setIMSThirdPartyDeviceCellWithIsBinded:(BOOL)isBinded;

@end
