//
//  NSBundle+IMSSmartSpeakerAccess.m
//  CocoaAsyncSocket
//
//  Created by chuntao.wang1 on 2018/7/12.
//

#import "NSBundle+IMSSmartSpeakerAccess.h"

static NSString *const IMSSmartSpeakerAccessBundle = @"IMSSmartSpeakerAccess";

@implementation NSBundle (IMSSmartSpeakerAccess)

+ (NSBundle *)ims_SmartSpeakerAccessBundle {
    NSBundle *bundle = [NSBundle bundleWithPath:[[NSBundle mainBundle] pathForResource:IMSSmartSpeakerAccessBundle ofType:@"bundle"]];
    return bundle;
}

@end
