//
//  IMSThirdPartyCommonMarco.h
//  Pods
//
//  Created by chuntao.wang1 on 2018/7/13.
//

#ifndef IMSThirdPartyCommonMarco_h
#define IMSThirdPartyCommonMarco_h

static inline UIColor *IMSSmartSpeakerAccess_RGBA(CGFloat r, CGFloat g, CGFloat b) {
    return [UIColor colorWithRed:((r) / 255.0) green:((g) / 255.0) blue:((b) / 255.0) alpha:(1)];
}

#endif /* IMSThirdPartyCommonMarco_h */
