//
//  UIImage+IMSSmartSpeakerAccess.m
//  CocoaAsyncSocket
//
//  Created by chuntao.wang1 on 2018/7/12.
//

#import "UIImage+IMSSmartSpeakerAccess.h"

NSString * const IMSSmartSpeakerAccessBundleName = @"IMSSmartSpeakerAccess";

@implementation UIImage (IMSSmartSpeakerAccess)

+ (UIImage *)ims_SmartbundleImageNamed:(NSString *)name {
    if (name.length > 0) {
        NSString *bundlePath = [[NSBundle mainBundle] pathForResource:IMSSmartSpeakerAccessBundleName ofType:@"bundle"];
        NSBundle *bundle = [NSBundle bundleWithPath:bundlePath];
        if (bundle) {
            if (@available(iOS 8.0, *)) {
                return [UIImage imageNamed:name inBundle:bundle compatibleWithTraitCollection:nil];
            } else {
                // Fallback on earlier versions
            }
        }
    }
    return nil;
}

@end
