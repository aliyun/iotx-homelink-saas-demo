//
//  IMSThirdPartyCell.h
//  IMSLife
//
//  Created by chuntao.wang1 on 2018/7/11.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IMSThirdPartyCell : UITableViewCell

//图片
@property (weak, nonatomic) IBOutlet UIImageView *imageV;
//箭头
@property (weak, nonatomic) IBOutlet UIButton *rightArrowBtn;

@end
