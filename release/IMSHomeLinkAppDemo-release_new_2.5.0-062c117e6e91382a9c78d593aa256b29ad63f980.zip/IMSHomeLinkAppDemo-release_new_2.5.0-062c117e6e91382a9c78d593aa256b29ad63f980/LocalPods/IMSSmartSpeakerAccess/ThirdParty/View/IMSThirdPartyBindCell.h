//
//  IMSThirdPartyBindCell.h
//  IMSLife
//
//  Created by chuntao.wang1 on 2018/7/11.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

//默认全部影藏，根据需要显示
@interface IMSThirdPartyBindCell : UITableViewCell

//左侧title（绑定步骤）
@property (weak, nonatomic) IBOutlet UILabel *leftTitleLabel;
//右侧箭头
@property (weak, nonatomic) IBOutlet UIButton *rightArrowBtn;
//绑定账号
@property (weak, nonatomic) IBOutlet UILabel *rightTitleLabel;
//底部横线
@property (weak, nonatomic) IBOutlet UIView *lineView;

@end
