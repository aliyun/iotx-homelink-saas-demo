//
//  IMSThirdPartyDeviceCell.h
//  IMSLife
//
//  Created by chuntao.wang1 on 2018/7/11.
//  Copyright © 2018年 Aliyun.com. All rights reserved.
//

#import <UIKit/UIKit.h>

//默认全部影藏，根据需要显示
@interface IMSThirdPartyDeviceCell : UITableViewCell

//设备图片
@property (weak, nonatomic) IBOutlet UIImageView *imageV;
//中间title（设备名称）
@property (weak, nonatomic) IBOutlet UILabel *midTitleLabel;
//左侧title（默认文案）
@property (weak, nonatomic) IBOutlet UILabel *leftTitleLabel;
//底部横线
@property (weak, nonatomic) IBOutlet UIView *lineView;

@end
