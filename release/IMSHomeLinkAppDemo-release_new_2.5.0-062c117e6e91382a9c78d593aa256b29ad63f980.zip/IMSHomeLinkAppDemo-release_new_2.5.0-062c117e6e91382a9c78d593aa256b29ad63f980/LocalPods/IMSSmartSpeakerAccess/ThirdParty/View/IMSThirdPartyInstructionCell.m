//
//  IMSThirdPartyInstructionCell.m
//  CocoaAsyncSocket
//
//  Created by chuntao.wang1 on 2018/7/18.
//

#import "IMSThirdPartyInstructionCell.h"

@implementation IMSThirdPartyInstructionCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
