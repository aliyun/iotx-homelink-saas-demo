//
//  IMSThirdPartyInstructionCell.h
//  CocoaAsyncSocket
//
//  Created by chuntao.wang1 on 2018/7/18.
//

#import <UIKit/UIKit.h>

@interface IMSThirdPartyInstructionCell : UITableViewCell
//title
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
//instruction
@property (weak, nonatomic) IBOutlet UILabel *instructionLabel;
    
@end
