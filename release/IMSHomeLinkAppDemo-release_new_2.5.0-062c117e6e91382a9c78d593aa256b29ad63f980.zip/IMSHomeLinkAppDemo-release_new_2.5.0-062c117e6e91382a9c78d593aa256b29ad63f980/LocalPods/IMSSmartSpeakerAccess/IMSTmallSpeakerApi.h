//
//  IMSTmallSpeakerApi.h
//  IMSLocalize
//
//  Created by chaokong on 2018/7/11.
//

#import <Foundation/Foundation.h>

@interface IMSTmallSpeakerApi : NSObject
// 用户绑定淘宝Id
+ (void)bindTaobaoIdWithParams:(NSDictionary *)para
                    completion:(void (^)(NSError *, NSDictionary *))completion;
// 用户解绑淘宝Id
+ (void)unbindTaobaoIdWithParams:(NSDictionary *)para
                      completion:(void (^)(NSError *, NSDictionary *))completion;
// 查询用户绑定的淘宝Id
+ (void)getTaobaoIdWithParams:(NSDictionary *)para
                   completion:(void (^)(NSError *, NSDictionary *))completion;
// 查询品类下支持的设备
+ (void)getSupportDeviceWithParams:(NSDictionary *)para
                        completion:(void (^)(NSError *, NSDictionary *))completion;
@end
